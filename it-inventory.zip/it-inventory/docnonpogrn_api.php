<?php
session_start();
$directory = __DIR__ ;
// require_once __DIR__ . "/classes/config.php";
require_once $_SERVER["DOCUMENT_ROOT"] . '/includes/configli.php'; // mysql connections
require_once __DIR__ . "/classes/myclassautoloader.php";
require_once __DIR__ . "/api/FileClient.class.php";
/**
* ThisDocAPI class
*/
class ThisDocAPI extends BaseDocAPI
{

	function __construct(){
	}



	function readDoc($docnumber){

		$genericDocument = new ErpDocumentNonPoGRN();
		$formStructure = json_encode($genericDocument->formStructure('GRN', 'default', 'read'), JSON_PRETTY_PRINT);

		$docnumber = $_GET['docnumber'];
		$apiObj = new ThisDocAPI();
		$docData = $apiObj->_readDoc($docnumber, $formStructure);
		$docObj = json_decode($docData, true);

		// again read doc with doctype and formtype
		$doctype = $docObj['doctype'];
		$formtype = $docObj['formtype'];
		$formStructure = json_encode($genericDocument->formStructure($doctype, $formtype, 'read'), JSON_PRETTY_PRINT);
		$docData = $apiObj->_readDoc($docnumber, $formStructure);
		$docObj = json_decode($docData, true);

		// $docObj['docstatus'] = $apiObj->docStatusTranslatorF[$docObj['docstatus']];

		$docLines = $docObj['lines'];
		unset($docObj['lines']);
		$newDocLines = array();
		foreach ($docLines as $docLine) {
			$currLine                = $docLine;
			// $currLine['linestatus'] = $this->lineStatusTranslatorF[$docLine['linestatus']];
			array_push($newDocLines, $currLine);
		}
		$docObj['lines'] = $newDocLines;

		return json_encode($docObj);

	}

	function readDocLineWise($docnumber, $idlines){

		$genericDocument = new ErpDocumentNonPoGRN();
		$formStructure = json_encode($genericDocument->formStructure('GRN', 'default', 'read'), JSON_PRETTY_PRINT);

		// $docnumber = $_GET['docnumber'];
		$docData = $this->_readDocLineWise($docnumber, $formStructure , $idlines);
		$docObj = json_decode($docData, true);

		$doctype = $docObj['doctype'];
		$formtype = $docObj['formtype'];
		$formStructure = json_encode($genericDocument->formStructure($doctype, $formtype, 'read'), JSON_PRETTY_PRINT);
		$docData = $this->_readDocLineWise($docnumber, $formStructure , $idlines);
		$docObj = json_decode($docData, true);


		$docLines = $docObj['lines'];
		unset($docObj['lines']);
		$newDocLines = array();
		foreach ($docLines as $docLine) {
			$currLine                = $docLine;
			array_push($newDocLines, $currLine);
		}
		$docObj['lines'] = $newDocLines;
		return json_encode($docObj);

	}



	function saveDoc($docdata, $formStructure){

		$docobj = json_decode($docdata, true);
		$doctype = $docobj['doctype'];
		$formtype = $docobj['formtype'];

		$genericDocument = new ErpDocumentNonPoGRN();
		$formStructure = json_encode($genericDocument->formStructure($doctype, $formtype, 'create'), JSON_PRETTY_PRINT);		

		if(isset($docobj['docnumber']) && $docobj['docnumber'] != ""){ // update Doc
			$returnJSON = $this->updateDoc($docdata, $formStructure);
			return json_encode($returnJSON);	
		} else {													   // create Doc
			$returnJSON = $this->createDoc($docdata, $formStructure);
			$returnJSON->createdocheader = "yes";
			return json_encode($returnJSON);
		}
	}



	function createDoc($docdata, $formStructure){
		$conn = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$formStructure = json_decode($formStructure, true);
		$tablename = $formStructure['schema']['tablename'];
		$doctype   = $formStructure['header']['doctype'];
		$formtype  = $formStructure['header']['formtype'];
		$doccounter= $formStructure['doccounter'];

		$docobj = json_decode($docdata, true);
		$doclins = $docobj['lines'];
		unset($docobj['lines']);

		foreach ($docobj as $key => $value) {
			$newValue = str_replace("'", "\'", $value);
			$docobj[$key] = $newValue;
		}

		foreach ($doclins as $key => $value) {
			$newValue = str_replace("'", "\'", $value);
			$doclins[$key] = $newValue;
		}

		$docnumber = $this->getNextDocNumber($doccounter);
		$docobj['docnumber'] = $docnumber;
		$newDocLines = array();
		foreach ($doclins as $docLine) {

			$currLine                = $docLine;
			// translate line status
			$currLine['doclinenumber'] = $docnumber . '-' . $currLine['linenumber'];
			// unset some field
			array_push($newDocLines, $currLine);
		}
		$docobj['lines'] = $newDocLines;

		// system entries
		// $docobj['lines'] = $doclins;

		$returnJSON = $this->_createDoc(json_encode($docobj), json_encode($formStructure));


		if($returnJSON->docnumber != ''){
			$sqlArray = array();
			foreach ($newDocLines as $index => $line) {
				$requisitionlinenumber = $line['requisitionlinenumber'];
				$doclinenumber = $line['doclinenumber'];
				// $sql = "UPDATE erp_nonpo SET linestatus = 2 , ponumber = '$returnJSON->docnumber',polinenumber='$doclinenumber' WHERE doclinenumber='$requisitionlinenumber'";
				// $sqlArray[] = $sql;
			}	

			foreach ($sqlArray as $index => $sql) {
				$resultUpdate = $conn->query($sql);
			}

		}


		return $returnJSON;

	}



	function _createDoc($docdata, $formStructure){
		$conn = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$formStructure = json_decode($formStructure, true);
		$tablename = $formStructure['schema']['tablename'];
		$doctype   = $formStructure['header']['doctype'];
		$formtype  = $formStructure['header']['formtype'];
		$doccounter= $formStructure['doccounter'];

		$docobj = json_decode($docdata, true);
		$doclins = $docobj['lines'];
		unset($docobj['lines']);

		$sql_array = array();
		$hcolumnFields = array();
		$hfieldValues = array();
		// process header
		$docnumber = $docobj['docnumber'];
		unset($docobj['docnumber']);
		unset($docobj['docstatus']);
		unset($docobj['entrypersonbadge']);
		unset($docobj['entrypersonname']);
		unset($docobj['doccreationtime']);
		// system entries
		if($docnumber == ''){
			$docnumber = $this->getNextDocNumber($doccounter);
		}
		$hcolumnFields[] = 'docnumber';
		$hfieldValues[]  = $docnumber;

		$hcolumnFields[] = 'entrypersonbadge';
		$hfieldValues[]  = $_SESSION['LoggedBadge'];

		$entrypersonname = "";
		$sqlGetName = "SELECT * from mrd_employee_basicinfo where Badge='".$_SESSION['LoggedBadge']."';";
		$result = $conn->query($sqlGetName);
		while($row = $result->fetch_assoc()){
			$entrypersonname = $row['Name'];
		}
		$hcolumnFields[] = 'entrypersonname';
		$hfieldValues[]  = $entrypersonname;

		$hcolumnFields[] = 'docstatus';
		$hfieldValues[]  = '0';
		$hcolumnFields[] = 'doccreationtime';
		$hfieldValues[]  = date('Y-m-d H:i:s', time());

		// $totalamount = $docobj['totalamount'];

		// $vattax = (($docobj['povatandtax'] * $totalamount) / 100);
		// $poadditionalcost = $docobj['poadditionalcost'];
		// $podiscountamount = $docobj['podiscountamount'];

		// $nettotal = ($totalamount + $vattax + $poadditionalcost - $podiscountamount);

		// $docobj['ponettotal'] = $nettotal;

		// $f = new NumberToWordConverter;
		// $nettotalW = floor($nettotal);
		// $docobj['totalamountwords'] = $f->numberTowords($nettotalW);


		foreach ($docobj as $fieldname => $fieldvalue) {
			$hcolumnFields[] = $fieldname;
			$hfieldValues[] = $fieldvalue;
		}

		// process lines
		foreach ($doclins as $index => $line) {


			//customize balance update start
			$templatecode = $line['templatecode'];
			$projectcode = $line['projectcode'];
			// $whlocation = $line['whlocation'];
			$whlocation = $docobj['whlocation'];
			$company = $docobj['company'];
			$costdepartment = '';
			$itemname = $docobj['itemname'];
			$binlocation = $line['binlocation'];
			$itemcode = $line['itemcode'];
			$tnxquantity = $line['tnxquantity'];
			$itemnature = $line['itemnature'];
			$uom = $line['uom'];

			$getProjectInfosql = "SELECT * FROM erp_nonpo_project WHERE projectcode='$projectcode'";
			$resultProjectInfo = $conn->query($getProjectInfosql);
			while($row = $resultProjectInfo->fetch_assoc()){
				$costdepartment = $row['costdepartment'];
			}
			

			$sqlMultiplier = "SELECT multiplier FROM erp_stock_transaction_template WHERE templatecode='$templatecode'";
			$queryResultMultiplier = $conn->query($sqlMultiplier);
			$multiplier = $queryResultMultiplier->fetch_assoc()['multiplier'];
			$tnxquantity = ($tnxquantity * $multiplier) ;

			$checkBalSql = "SELECT * FROM erp_balance WHERE itemcode='$itemcode' AND projectcode='$projectcode' AND whlocation='$whlocation' AND binlocation='$binlocation' AND company='$company'";
			$queryResultBal = $conn->query($checkBalSql);
			$queryRowsNum = $queryResultBal->num_rows;

			if($queryRowsNum == 0){
				$sqlInsert = "INSERT INTO erp_balance (projectcode,whlocation,binlocation,itemcode,tnxquantity,uom,itemnature,company,costdepartment,itemname) VALUES('$projectcode','$whlocation','$binlocation','$itemcode','$tnxquantity','$uom','$itemnature','$company','$costdepartment','$itemname')";
				$result = $conn->query($sqlInsert);
			}else{
				$updateSql = "UPDATE erp_balance SET tnxquantity=(tnxquantity+$tnxquantity) WHERE itemcode='$itemcode' AND projectcode='$projectcode' AND whlocation='$whlocation' AND binlocation='$binlocation' AND company='$company'";
				$result = $conn->query($updateSql);
			}

			//customize balance update end


			$columnFields = array();
			$fieldValues = array();
			unset($line['lineentrytime']);
			unset($line['linestatus']);
			foreach ($line as $fieldname => $fieldvalue) {
				$columnFields[] = $fieldname;
				$fieldValues[] = $fieldvalue;
			}
			// push header data in line
			foreach ($hcolumnFields as $index => $fieldname) {
				$columnFields[] = $fieldname;
				$fieldValues[]  = $hfieldValues[$index];		
			}		

			$columnFields = implode(", ", $columnFields);
			$fieldValues  = "'" . implode("','", $fieldValues) . "'";

			$sql = "INSERT INTO $tablename ($columnFields) VALUES($fieldValues)";
			$sql_array[] = $sql;

		}

		// Execute Query
		foreach ($sql_array as $key => $sql) {
			$result = $conn->query($sql);	  
			if(!$result){
				array_push($returnJSON->errormsgs, "Error, $sql");
				return $returnJSON;
			}
		}
      	$conn->close();

		if ($result) {
			$returnJSON->docnumber = $docnumber;
		} else {
			array_push($returnJSON->errormsgs, "Error, please tell ERP department: commit failed.");
		}
		return $returnJSON;

	}

	function updateDoc($docdata, $formStructure){
		$conn = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$formStructure = json_decode($formStructure, true);
		$tablename = $formStructure['schema']['tablename'];		

		$newdocobj = json_decode($docdata, true);
		$docnumber = $newdocobj['docnumber'];


		// $totalamount = $newdocobj['totalamount'];
		// $f = new NumberToWordConverter;


		// $vattax = (($newdocobj['povatandtax'] * $totalamount) / 100);
		// $poadditionalcost = $newdocobj['poadditionalcost'];
		// $podiscountamount = $newdocobj['podiscountamount'];

		// $nettotal = ($totalamount + $vattax + $poadditionalcost - $podiscountamount);

		// $newdocobj['ponettotal'] = $nettotal;
		
		// $nettotalW = floor($nettotal);
		// $newdocobj['totalamountwords'] = $f->numberTowords($nettotalW);


		$doclins = $newdocobj['lines']; // format: lines = array(0 => array, 1 => array, ....)
		unset($newdocobj['lines']);

		foreach ($newdocobj as $key => $value) {
			$newValue = str_replace("'", "\'", $value);
			$newdocobj[$key] = $newValue;
		}
		
		foreach ($doclins as $key => $value) {
			$newValue = str_replace("'", "\'", $value);
			$doclins[$key] = $newValue;
		}

		$newDocLines = array();
		foreach ($doclins as $docLine) {

			$currLine                = $docLine;
			// translate line status
			$currLine['doclinenumber'] = $docnumber . '-' . $currLine['linenumber'];
			// unset some field
			unset($currLine['linestatus']);
			unset($currLine['lineentrytime']);
			array_push($newDocLines, $currLine);
		}

		$newdocobj['lines'] = $newDocLines;
		// $newdocobj['docstatus'] = $this->docStatusTranslatorB[$newdocobj['docstatus']]; // it should be base class
		$returnJSON = $this->_updateDoc(json_encode($newdocobj), json_encode($formStructure));

		if($returnJSON->docnumber != ''){
			$sqlArray = array();
			foreach ($newDocLines as $index => $line) {
				$requisitionlinenumber = $line['requisitionlinenumber'];
				$doclinenumber = $line['doclinenumber'];
				// $sql = "UPDATE erp_nonpo SET linestatus = 2 , ponumber = '$returnJSON->docnumber',polinenumber='$doclinenumber' WHERE doclinenumber='$requisitionlinenumber'";
				// $sqlArray[] = $sql;
			}	

			foreach ($sqlArray as $index => $sql) {
				$resultUpdate = $conn->query($sql);
			}

		}

		return $returnJSON;

	}



	function _updateDoc($docdata, $formStructure){
		$conn = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$formStructure = json_decode($formStructure, true);
		$tablename = $formStructure['schema']['tablename'];		

		$newdocobj = json_decode($docdata, true);
		$docnumber = $newdocobj['docnumber'];
		$olddocobj = json_decode($this->_readDoc($docnumber, json_encode($formStructure)), true);

		// $newdocobj['docstatus'] = $this->docStatusTranslatorB[$newdocobj['docstatus']];

		$docLinesArray = $newdocobj['lines']; // format: lines = array(0 => array, 1 => array, ....)
		unset($newdocobj['lines']);
		$docHeaderArray = $newdocobj;

		// Generating query varriables
		// HEADER
		// update SQL for header
		$sql_array = array();
		$updateSet = "";
		foreach ($docHeaderArray as $keyHeader => $valueHeader) {
			if ($keyHeader != 'docnumber') {
				$updateSet .= $keyHeader . "=" . "'" . $valueHeader . "',";
			}
		}	
		
		date_default_timezone_set("Asia/Dhaka");
		$updateSet .= "lastupdateuser =" . "'" . $_SESSION["USERNAME"] . "',"; 

		$lastUpdateTime  = date('Y-m-d H:i:s', time());
		$updateSet .= "lastupdatetime =" . "'" . $lastUpdateTime . "',"; 

		$updateSet = rtrim($updateSet ,',');
		$sqlH = "UPDATE $tablename SET $updateSet WHERE docnumber = '$docnumber'";
		
		// LINES
		// Case 1 - New Lines: idlines will be blank. (user can add new lines in document's update mode.)
		// Case 2 - Existing Lines: idlines will be specified. (user just updated these lines)
		// Case 3 - Removed Lines: line will be missing.

		// Calculate the differences
		foreach ($docLinesArray as $docLine) {
			$lineNumbers_new[] = $docLine['linenumber'];
		}
		$lineNumbers_new = array_unique($lineNumbers_new, SORT_NUMERIC);
		foreach ($olddocobj['lines'] as $docLine) {
			$lineNumbers_old[] = $docLine['linenumber'];
		}
		$lineNumbers_old = array_unique($lineNumbers_old, SORT_NUMERIC);

		$lineNumbers_added   = array_diff($lineNumbers_new, $lineNumbers_old);
		$lineNumbers_same    = array_intersect($lineNumbers_new, $lineNumbers_old);
		$lineNumbers_removed = array_diff($lineNumbers_old, $lineNumbers_new);


		/*
		Iterate through the lines and build an array of SQL queries
		*/
		foreach ($docLinesArray as $lineIndex => $LineArray) {
		// here, value is also an array
		// $idlines_this = $LineArray['idlines'];
		$this_linenumber = $LineArray['linenumber'];
		unset($LineArray['idlines']);

		if (in_array($this_linenumber, $lineNumbers_added)) {
			  // Case 1 - New Line
				$columnFields = array();
				$fieldValues = array();
				unset($LineArray['lineentrytime']);
				foreach ($LineArray as $fieldname => $fieldvalue) {
					$columnFields[] = $fieldname;
					$fieldValues[] = $fieldvalue;
				}
				$columnFields[] = 'docnumber';
				$fieldValues[] = $docnumber;

				$columnFields = implode(", ", $columnFields);
				$fieldValues  = "'" . implode("','", $fieldValues) . "'";
				$sql = "INSERT INTO $tablename ($columnFields) VALUES($fieldValues)";
				$sql_array[] = $sql;

			} else {
			  // Case 2 - Existing Line
				$updateSet = "";
				foreach ($LineArray as $fieldname => $fieldvalue) {
					$updateSet .= $fieldname . "=" . "'" . $fieldvalue . "',";
				}

				$updateSet = rtrim($updateSet ,',');
				$sql = "UPDATE $tablename SET $updateSet WHERE docnumber = '$docnumber' AND linenumber = '$this_linenumber'";
				$sql_array[] = $sql;
			}
		}

		// Case 3 - Removed Lines
		if (sizeof($lineNumbers_removed) > 0) {
			$lineNumbers_removed = implode(",", $lineNumbers_removed);

			//delete line and update balance
			$sqlUpdateBalTransaction = "SELECT itemcode,templatecode,projectcode,whlocation,binlocation,tnxquantity FROM erp_balance_transaction WHERE docnumber='$docnumber' AND linenumber IN ($lineNumbers_removed)";
			$resultBalTransaction = $conn->query($sqlUpdateBalTransaction);
			while($row = $resultBalTransaction->fetch_assoc()){
				$itemcode = $row['itemcode'];
				$templatecode = $row['templatecode'];
				$projectcode = $row['projectcode'];
				$whlocation = $row['whlocation'];
				$binlocation = $row['binlocation'];
				$tnxquantity = $row['tnxquantity'];

				$sqlMultiplier = "SELECT multiplier FROM erp_stock_transaction_template WHERE templatecode='$templatecode'";
				$queryResultMultiplier = $conn->query($sqlMultiplier);
				$multiplier = $queryResultMultiplier->fetch_assoc()['multiplier'];
				$tnxquantity = ($tnxquantity * $multiplier) ;

				$updateBalSql = "UPDATE erp_balance SET tnxquantity=(tnxquantity-$tnxquantity) WHERE itemcode='$itemcode' AND projectcode='$projectcode' AND whlocation='$whlocation' AND binlocation='$binlocation'";
				$queryResultBal = $conn->query($updateBalSql);
			}

			$sql = "DELETE FROM $tablename WHERE docnumber = '$docnumber' AND linenumber IN ($lineNumbers_removed)";
			$sql_array[] = $sql;
		}


		// Execute Query
		$sql_array[] = $sqlH;
		foreach ($sql_array as $key => $sql) {
			$result = $conn->query($sql);	  
			if(!$result){
				array_push($returnJSON->errormsgs, "Error, $sql");
				return $returnJSON;
			}
		}
		$conn->close();

		if ($result) {
			$returnJSON->docnumber = $docnumber;
		} else {
			array_push($returnJSON->errormsgs, "Error, please tell ERP department: commit failed.");
		}
		return $returnJSON;

	}



	function changeDocStatus($docnumber, $docstatus){

		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$genericDocument = new ErpDocumentNonPoGRN();
		$formStructure = json_encode($genericDocument->formStructure($formtype, $crudmode), JSON_PRETTY_PRINT);

		$returnJSON = $this->_changeDocStatus($docnumber, $docstatus, $formStructure);

		// $this->updateAllRRLineStatus_sentToTextile($docnumber);

		return $returnJSON;

	}

	function poAmendment($docnumber, $docstatus){
		$conn     = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$sqlUpdate = "UPDATE erp_balance_transaction SET docstatus = '$docstatus' , amendstatus = (amendstatus+1) WHERE docnumber='$docnumber';";
		$result = $conn->query($sqlUpdate);

		if($result){
			$returnJSON->result = "success";
		}else{
			$returnJSON->result = "error ".$sqlUpdate;
		}

		return json_encode($returnJSON);

	}

	function updateAllRRLineStatus_sentToTextile($docnumber){
		$conn = new ErpDbConn;

		$sql = "SELECT rrnumber FROM erp_balance_transaction WHERE docnumber = '$docnumber'";

		echo "string...... KLM" . $sql;
		$queryResult = $conn->query($sql);

		while ($row = $queryResult->fetch_assoc()) {
			$rrnumber = $row['rrnumber'];
			$sql = "UPDATE erp_rrlines SET rrstatus = '4' WHERE rrnumber = '$rrnumber'";
			echo "string...... XXFD" . $sql;
			$conn->query($sql);
		}

		$conn->close();
	}


	function updateRevisedPO($podocnumber){
		$conn = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$sqlUpd = "UPDATE erp_balance_transaction SET docstatus='0', amendmenttimes=(amendmenttimes+1), amendstatus = (amendstatus+1) WHERE docnumber='$podocnumber'";
		$queryUpdResult = $conn->query($sqlUpd);

		$sql = "SELECT rrnumber,tnxqty FROM erp_balance_transaction WHERE docnumber='$podocnumber' AND ispoautoupdateflag='1'";
		$queryResult = $conn->query($sql);

		$getSOsql = "SELECT distinct(salesorder) AS salesorder FROM erp_balance_transaction WHERE docnumber='$podocnumber' AND ispoautoupdateflag='1'";
		$queryResultSOsql = $conn->query($getSOsql);

		while ($row = $queryResult->fetch_assoc()) {
			$rrnumber = $row['rrnumber'];
			$previousqty = $row['tnxqty'];
			$sqlUpdPO = "SELECT * FROM erp_rrlines WHERE rrnumber='$rrnumber'";
			$resultRRRow = $conn->query($sqlUpdPO);
			$queryRowsNum = $resultRRRow->num_rows;

			if($queryRowsNum != 0){
				$rrrows = $resultRRRow->fetch_assoc();


				$pofield = array();
				$pofield['itemcode']               = $rrrows['itemcode'];
				$pofield['itemtype']               = $rrrows['itemtype'];
				$pofield['itemdescription']        = $rrrows['itemdescription'];
				$pofield['pricerequisitionnumber'] = $rrrows['pricerequisitionnumber'];
				$pofield['unitprice']              = $rrrows['unitprice'];
				$pofield['iduom']                  = $rrrows['iduom'];
				$pofield['fabricinhousedate']      = $rrrows['fabricinhousedate'];
				$pofield['rrnumber']               = $rrrows['rrnumber'];
				$pofield['parentrrnumber']         = $rrrows['parentrrnumber'];
				$pofield['tnxqty']                 = $rrrows['requirednetqty'];
				$pofield['iduom']                  = $rrrows['iduom'];
				$pofield['dlvbrktext']             = $rrrows['dlvbrktext'];
				$pofield['salesorder']             = $rrrows['salesorder'];
				$pofield['previousqty']            = $previousqty;

				$updatePO = array();
				foreach ($pofield as $key => $value) {
					$updatePO[] = $key . "='" . $value . "'";
				}

				$updateString = implode(',', $updatePO);
				$sqlUpdate = "UPDATE erp_balance_transaction SET $updateString,ispoautoupdateflag='0' WHERE rrnumber='$rrnumber' AND docnumber='$podocnumber' AND ispoautoupdateflag='1'";
			}else{
				$sqlUpdate = "UPDATE erp_balance_transaction SET linestatus='9',ispoautoupdateflag='0' WHERE rrnumber='$rrnumber' AND docnumber='$podocnumber'";
			}

			// echo $sqlUpdate;
			
			$result = $conn->query($sqlUpdate);

		}

		if($result){
			$returnJSON->result = "success";
		}else{
			$returnJSON->result = "error ".$sqlUpdate;
		}

		return json_encode($returnJSON);
	}


	function getAdditionalRRPOLineInfo($podocnumber){
		$conn = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$sql = "SELECT rrnumber FROM erp_balance_transaction WHERE docnumber='$podocnumber' AND ispoautoupdateflag='1'";
		$queryResult = $conn->query($sql);

		$getSOsql = "SELECT distinct(salesorder) AS salesorder FROM erp_balance_transaction WHERE docnumber='$podocnumber' AND ispoautoupdateflag='1'";
		$queryResultSOsql = $conn->query($getSOsql);

		$arraySO = array();
		while( $rowso = $queryResultSOsql->fetch_assoc() ){
			$arraySO[] = $rowso['salesorder'];
		}

		$sonumbers = "'" . implode("','", $arraySO) . "'";

		$sqlAdditionRR = "SELECT * FROM erp_rrlines WHERE salesorder IN($sonumbers) AND rrnumber NOT IN(SELECT rrnumber FROM erp_balance_transaction WHERE docnumber='$podocnumber')";

	   	$queryResult = $conn->query($sqlAdditionRR);
	    $data = array();
	    while($row = $queryResult->fetch_assoc()){
	    	$rrnumber = $row['rrnumber'];
	    	$salesorder = $row['salesorder'];
	    	$itemcode = $row['itemcode'];
	    	$projectionPOInfo = $this->getProjectionPOInfo($rrnumber);
	    	$MLInfo = $this->getMLInfo($salesorder, $itemcode);
	    	$row['parentponumber'] = $projectionPOInfo['docnumber'];
	    	$row['parentpolinenumber'] = $projectionPOInfo['doclinenumber'];
	    	$row['orderqtycondition'] = $MLInfo['orderqtycondition'];
	    	$row['conditiondetails'] = $MLInfo['conditiondetails'];

	    	array_push($data, $row);
	    }

	    $conn->close();

	   	return json_encode($data);
	}


	function autoRevisedButtonVisibility($docnumber){
		$conn = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$countSql = "SELECT rrnumber FROM erp_balance_transaction WHERE docnumber='$docnumber' AND ispoautoupdateflag='1'";
		$queryResult = $conn->query($countSql);
		$queryRowsNum = $queryResult->num_rows;

		if($queryRowsNum == 0){
			return 0;
		}else{
			return 1;
		}

	}


	function updateRRStatus($rrnumber, $ponumber,$polinenumber){
		$conn = new ErpDbConn();
		$sql = "UPDATE erp_rrlines SET rrstatus = 3, powonumber = '$ponumber', powolinenumber='$polinenumber' WHERE rrnumber='$rrnumber'";
		$conn->query($sql);
	}


	function _saveLine($line){
		$conn = new ErpDbConn;

		$lineObj = json_decode($line, true);

		foreach ($lineObj as $key => $value) {
			$newValue = str_replace("'", "\'", $value);
			$lineObj[$key] = $newValue;
		}

		$docnumber = $lineObj['docnumber'];
		$idlines = $lineObj['idlines'];

		$doctype = $lineObj['doctype'];
		$formtype = $lineObj['formtype'];

		$genericDocument = new ErpDocumentNonPoGRN();
		$formStructure = json_encode($genericDocument->formStructure($doctype, $formtype, 'create'), JSON_PRETTY_PRINT);	
		$formStructure = json_decode($formStructure, true);

		$tablename = $formStructure['schema']['tablename'];
		$doccounter= $formStructure['doccounter'];

		// create doc with this line
		if($docnumber == ""){
			// process lines
			$columnFields = array();
			$fieldValues = array();
			unset($lineObj['linenumber']);
			unset($lineObj['lineentrytime']);
			unset($lineObj['linestatus']);
			// process header
			unset($lineObj['docnumber']);
			unset($lineObj['docstatus']);
			unset($lineObj['entrypersonbadge']);
			unset($lineObj['doccreationtime']);
			unset($lineObj['idlines']);


			//customize balance update start
			$templatecode = $lineObj['templatecode'];
			$projectcode = $lineObj['projectcode'];
			$whlocation = $lineObj['whlocation'];
			$company = $lineObj['company'];
			$costdepartment = '';
			$itemname = $lineObj['itemname'];
			// $whlocation = '';
			$binlocation = $lineObj['binlocation'];
			$itemcode = $lineObj['itemcode'];
			$tnxquantity = $lineObj['tnxquantity'];
			$itemnature = $lineObj['itemnature'];
			$uom = $lineObj['uom'];

			$getProjectInfosql = "SELECT * FROM erp_nonpo_project WHERE projectcode='$projectcode'";
			$resultProjectInfo = $conn->query($getProjectInfosql);
			while($row = $resultProjectInfo->fetch_assoc()){
				$costdepartment = $row['costdepartment'];
			}

			$sqlMultiplier = "SELECT multiplier FROM erp_stock_transaction_template WHERE templatecode='$templatecode'";
			$queryResultMultiplier = $conn->query($sqlMultiplier);
			$multiplier = $queryResultMultiplier->fetch_assoc()['multiplier'];
			$tnxquantity = ($tnxquantity * $multiplier) ;

			$checkBalSql = "SELECT * FROM erp_balance WHERE itemcode='$itemcode' AND projectcode='$projectcode' AND whlocation='$whlocation' AND binlocation='$binlocation' AND company='$company'";
			$queryResultBal = $conn->query($checkBalSql);
			$queryRowsNum = $queryResultBal->num_rows;

			if($queryRowsNum == 0){
				$sqlInsert = "INSERT INTO erp_balance (projectcode,whlocation,binlocation,itemcode,tnxquantity,uom,itemnature,company,costdepartment,itemname) VALUES('$projectcode','$whlocation','$binlocation','$itemcode','$tnxquantity','$uom','$itemnature','$company','$costdepartment','$itemname')";
				$result = $conn->query($sqlInsert);
			}else{
				$updateSql = "UPDATE erp_balance SET tnxquantity=(tnxquantity+$tnxquantity) WHERE itemcode='$itemcode' AND projectcode='$projectcode' AND whlocation='$whlocation' AND binlocation='$binlocation' AND company='$company'";
				$result = $conn->query($updateSql);
			}
			//customize balance update end


			$docnumber = $this->getNextDocNumber($doccounter);
			$lineObj['docnumber'] = $docnumber;
			$lineObj['linenumber'] = '1';

			// apply critaria if have
			$lineObj['doclinenumber'] = $docnumber . '-' . $lineObj['linenumber'];
			$polinenumber = $lineObj['doclinenumber'];
			
			foreach ($lineObj as $fieldname => $fieldvalue) {
				$columnFields[] = $fieldname;
				$fieldValues[] = $fieldvalue;
			}		

			$columnFields[] = 'entrypersonbadge';
			$fieldValues[]  = $_SESSION['LoggedBadge'];

			$columnFields[] = 'docstatus';
			$fieldValues[]  = '0';
			$columnFields[] = 'doccreationtime';
			$fieldValues[]  = date('Y-m-d H:i:s', time());


			$columnFields = implode(", ", $columnFields);
			$fieldValues  = "'" . implode("','", $fieldValues) . "'";
			$sql = "INSERT INTO $tablename ($columnFields) VALUES($fieldValues)";


			$conn->conn->query($sql);
			$idlines = $conn->conn->insert_id;

			// update rr status
			$this->updateRRStatus($lineObj['rrnumber'], $docnumber, $polinenumber);

			$lineData = $this->readDocLineWise($docnumber, $idlines);
			$lineObj = json_decode($lineData, true);
			$lineObj['doccreate'] = 'yes';
			return json_encode($lineObj);

		}

		// insert new line
		if($idlines == ""){

			// process lines
			$columnFields = array();
			$fieldValues = array();
			unset($lineObj['linenumber']);
			unset($lineObj['lineentrytime']);
			unset($lineObj['linestatus']);
			unset($lineObj['idlines']);


			//customize balance update start
			$templatecode = $lineObj['templatecode'];
			$projectcode = $lineObj['projectcode'];
			$whlocation = $lineObj['whlocation'];
			$company = $lineObj['company'];
			$costdepartment = '';
			$itemname = $lineObj['itemname'];
			$binlocation = $lineObj['binlocation'];
			$itemcode = $lineObj['itemcode'];
			$tnxquantity = $lineObj['tnxquantity'];
			$itemnature = $lineObj['itemnature'];
			$uom = $lineObj['uom'];

			$getProjectInfosql = "SELECT * FROM erp_nonpo_project WHERE projectcode='$projectcode'";
			$resultProjectInfo = $conn->query($getProjectInfosql);
			while($row = $resultProjectInfo->fetch_assoc()){
				$costdepartment = $row['costdepartment'];
			}

			$sqlMultiplier = "SELECT multiplier FROM erp_stock_transaction_template WHERE templatecode='$templatecode'";
			$queryResultMultiplier = $conn->query($sqlMultiplier);
			$multiplier = $queryResultMultiplier->fetch_assoc()['multiplier'];
			$tnxquantity = ($tnxquantity * $multiplier) ;

			$checkBalSql = "SELECT * FROM erp_balance WHERE itemcode='$itemcode' AND projectcode='$projectcode' AND whlocation='$whlocation' AND binlocation='$binlocation' AND company='$company'";
			$queryResultBal = $conn->query($checkBalSql);
			$queryRowsNum = $queryResultBal->num_rows;

			if($queryRowsNum == 0){
				$sqlInsert = "INSERT INTO erp_balance (projectcode,whlocation,binlocation,itemcode,tnxquantity,uom,itemnature,company,costdepartment,itemname) VALUES('$projectcode','$whlocation','$binlocation','$itemcode','$tnxquantity','$uom','$itemnature','$company','$costdepartment','$itemname')";
				$result = $conn->query($sqlInsert);
			}else{
				$updateSql = "UPDATE erp_balance SET tnxquantity=(tnxquantity+$tnxquantity) WHERE itemcode='$itemcode' AND projectcode='$projectcode' AND whlocation='$whlocation' AND binlocation='$binlocation' AND company='$company'";
				$result = $conn->query($updateSql);
			}

			//customize balance update end



			$sql = "SELECT idlines, linenumber FROM $tablename WHERE docnumber = '$docnumber' ORDER BY idlines DESC";
			$queryResult = $conn->query($sql);
			$last_linenumber =  $queryResult->fetch_assoc()['linenumber'];
			$lineObj['linenumber'] = (int)$last_linenumber + 1;

			// apply critaria if have
			$lineObj['doclinenumber'] = $docnumber . '-' . $lineObj['linenumber'];
			$polinenumber = $lineObj['doclinenumber'];
			
			foreach ($lineObj as $fieldname => $fieldvalue) {
				$columnFields[] = $fieldname;
				$fieldValues[] = $fieldvalue;
			}		

			$columnFields = implode(", ", $columnFields);
			$fieldValues  = "'" . implode("','", $fieldValues) . "'";
			$sql = "INSERT INTO $tablename ($columnFields) VALUES($fieldValues)";


			$conn->conn->query($sql);
			$idlines = $conn->conn->insert_id;

			// update rr status
			$this->updateRRStatus($lineObj['rrnumber'], $docnumber,$polinenumber);
			
			return $this->readDocLineWise($docnumber, $idlines);

		}

		// update line
		if($idlines != ""){
			unset($lineObj['linenumber']);
			unset($lineObj['lineentrytime']);
			unset($lineObj['linestatus']);

			$sqlgetQty = "SELECT templatecode,tnxquantity FROM erp_balance_transaction WHERE idlines='$idlines'";
			// return $sqlgetQty;
			$queryResultgetQty = $conn->query($sqlgetQty);
			$currentRow = $queryResultgetQty->fetch_assoc();
			$templatecode = $currentRow['templatecode'];
			$tnxquantity = $currentRow['tnxquantity'];
			$sqlMultiplier = "SELECT multiplier FROM erp_stock_transaction_template WHERE templatecode='$templatecode'";
			$queryResultMultiplier = $conn->query($sqlMultiplier);
			$multiplier = $queryResultMultiplier->fetch_assoc()['multiplier'];
			$tnxquantityPrv = ($tnxquantity * $multiplier);

			$templatecode = $lineObj['templatecode'];
			$projectcode = $lineObj['projectcode'];
			$whlocation = $lineObj['whlocation'];
			$binlocation = $lineObj['binlocation'];
			$itemcode = $lineObj['itemcode'];
			$tnxquantityCnt = ($lineObj['tnxquantity'] * $multiplier);
			$uom = $lineObj['uom'];

			$sqlUpdateBal = "UPDATE erp_balance SET tnxquantity=(tnxquantity-$tnxquantityPrv+$tnxquantityCnt) WHERE itemcode='$itemcode' AND projectcode='$projectcode' AND whlocation='$whlocation' AND binlocation='$binlocation'";
			// return $sqlUpdateBal;
			$result = $conn->query($sqlUpdateBal);



			$updateSet = "";
			foreach ($lineObj as $fieldname => $fieldvalue) {
				$updateSet .= $fieldname . "=" . "'" . $fieldvalue . "',";
			}			
			$updateSet = rtrim($updateSet ,',');
			$sql = "UPDATE $tablename SET $updateSet WHERE idlines = '$idlines'";

			$conn->query($sql);
			return $this->readDocLineWise($docnumber, $idlines);

		}

	}



	function searchHeaderInfo($params){
		$conn = new ErpDbConn;

		unset($params['reqType']);
		$docnumber = $params['docnumber'];

		$sql = "SELECT * FROM erp_bom WHERE docnumber='$docnumber'";

		return $conn->sqlToJson($sql);

	}

	function getNextNumber($countername){
		$conn = new ErpDbConn;
		$sql = "SELECT prefix, nextnumber from erp_counter where countername='$countername'";
		$prefix        = json_decode($conn->sqlToJson($sql), true)[0]['prefix'];
		$currentdocnum = json_decode($conn->sqlToJson($sql), true)[0]['nextnumber'];

		$sql = "UPDATE erp_counter SET nextnumber=(nextnumber+1) where countername='$countername'";
		$qresult = $conn->query($sql);

		if($qresult){
			return $currentdocnum;
		}
	}

	function getPOLineInfo($searchParams){
	    $conn = new ErpDbConn;
	  
	    $polinenumber = $searchParams['polinenumber'];
	    $tnxquantity = $searchParams['tnxquantity'];
	    $challanno = $searchParams['challanno'];
	    $whlocation = $searchParams['whlocation'];
	    $TransactionDate = $searchParams['TransactionDate'];
	    $TransactionTime = $searchParams['TransactionTime'];
	    // return $TransactionDate;
	    $polinenumberArray = explode(',', $polinenumber);
	    $tnxquantityArray = explode(',', $tnxquantity);
	    $whlocationArray = explode(',', $whlocation);

	    $polinenumberArrayWh = "'" . implode("','", $polinenumberArray) . "'";

	    $sql = "SELECT * FROM erp_nonpo WHERE doclinenumber IN ($polinenumberArrayWh)";
	   	$queryResult = $conn->query($sql);
	    $data = array();
	    $sql = array();
	    $docnumber = $this->getNextDocNumber('counter_NP_TF');

	    
		$entrypersonbadge  = $_SESSION['LoggedBadge'];
		$entrypersonname = "";
		$sqlGetName = "SELECT * from mrd_employee_basicinfo where Badge='".$_SESSION['LoggedBadge']."';";
		$result = $conn->query($sqlGetName);
		while($row = $result->fetch_assoc()){
			$entrypersonname = $row['Name'];
		}
	    
	    while($row = $queryResult->fetch_assoc()){

	    	foreach ($row as $key => $value) {
	    		$value = str_replace("'", "\'", $value);
	    		$row[$key] = $value;
	    	}

	    	$transactionno = $this->getNextNumber('counter_NP');
			$itemname = $row['itemname'];
			$itemdescription = $row['itemdescription'];
			$uom = $row['iduom'];
			$polineno = $row['doclinenumber'];
			$templatecode = 'T03';
			$transactiontype = 'Receive from Supplier';
			$prlineno = $row['requisitionlinenumber'];
			$itemcode = $row['itemcode'];
			$itemtype = $row['itemtype'];
			$projectcode = $row['project'];
			$itemnature = $row['itemnature'];
			$suppliername = $row['suppliername'];
			$company = $row['company'];
			$costcenter = $row['costcenter'];
			$costdepartment = $row['costdept'];
			$brand = $row['brand'];
			$color = $row['color'];
			$unitprice = $row['unitprice'];
			$currency = $row['currency'];
			$sizeormeasurement = $row['sizeormeasurement'];
			$transactiondate = $TransactionDate;
			$transactiontime = $TransactionTime;
			
	    	$key = array_search($polineno, $polinenumberArray);
			$tnxquantity = $tnxquantityArray[$key];
			$whlocation = $whlocationArray[$key];

			$updateRcvQtySql = "UPDATE erp_nonpo SET receivedqty=(receivedqty+$tnxquantity)  WHERE doclinenumber='$prlineno'";
			// return $updateRcvQtySql;

			$sql = "INSERT INTO erp_balance_transaction (itemname,itemdescription,uom,templatecode,transactiontype,prlineno,itemcode,polineno,projectcode,itemnature,tnxquantity,challanno,whlocation,suppliername,company,docnumber,transactiondate,transactiontime,transactionno,costdepartment,costcenter,brand,color,sizeormeasurement,entrypersonbadge,entrypersonname,itemtype, unitprice, currency) VALUES('$itemname','$itemdescription','$uom','$templatecode','$transactiontype','$prlineno','$itemcode','$polineno','$projectcode','$itemnature','$tnxquantity','$challanno','$whlocation','$suppliername','$company','$docnumber','$transactiondate','$transactiontime','$transactionno','$costdepartment','$costcenter','$brand','$color','$sizeormeasurement','$entrypersonbadge','$entrypersonname','$itemtype', '$unitprice', '$currency')";
			// return $sql;
			$result = $conn->query($sql);
			if($result){
				$conn->query($updateRcvQtySql);

				$sqlQty = "SELECT orderqty, receivedqty FROM erp_nonpo WHERE doclinenumber='$prlineno'";
				$resultQty = $conn->query($sqlQty);
				while($row = $resultQty->fetch_assoc()){
					$orderqty = $row['orderqty'];
					$receivedqty = $row['receivedqty'];

					if($orderqty <= $receivedqty){
						$updStaSql = "UPDATE erp_nonpo SET linestatus='3' WHERE doclinenumber='$prlineno'";
						$conn->query($updStaSql);
					}
				}
			}

			$sqlMultiplier = "SELECT multiplier FROM erp_stock_transaction_template WHERE templatecode='$templatecode'";
			$queryResultMultiplier = $conn->query($sqlMultiplier);
			$multiplier = $queryResultMultiplier->fetch_assoc()['multiplier'];
			$tnxquantity = ($tnxquantity * $multiplier) ;

			$checkBalSql = "SELECT * FROM erp_balance WHERE itemcode='$itemcode' AND projectcode='$projectcode' AND whlocation='$whlocation' AND uom='$uom' AND company='$company' AND polineno = '$polineno'";
			$queryResultBal = $conn->query($checkBalSql);
			$queryRowsNum = $queryResultBal->num_rows;

			if($queryRowsNum == 0){
				$sqlInsert = "INSERT INTO erp_balance (projectcode,whlocation,itemcode,tnxquantity,uom,itemnature,company,costdepartment,costcenter,itemname,brand,color,sizeormeasurement,itemdescription,itemtype, polineno, unitprice, currency, prlineno) VALUES('$projectcode','$whlocation','$itemcode','$tnxquantity','$uom','$itemnature','$company','$costdepartment','$costcenter','$itemname','$brand','$color','$sizeormeasurement','$itemdescription','$itemtype', '$polineno', '$unitprice', '$currency', '$prlineno')";
				$result = $conn->query($sqlInsert);
			}else{
				$updateSql = "UPDATE erp_balance SET tnxquantity=(tnxquantity+$tnxquantity) WHERE itemcode='$itemcode' AND projectcode='$projectcode' AND whlocation='$whlocation' AND uom='$uom' AND company='$company' AND polineno = '$polineno'";
				$result = $conn->query($updateSql);
			}

	    	// array_push($data, $row);
	    }

	    $conn->close();

	   	return $docnumber;

	}	

	function registerItemLot($docLine) {
	    // System entries both lines
	    $docLine['posting'] = 0;
	    $docLine['itemlot'] = "";
	    $itemlot    = new ItemLot($docLine['itemlot']);
	    $idsupplier = 0; // will we change the supplier to IDs?
	    if ($docLine['itemlot'] == "" || $docLine['itemlot'] == null || $docLine['itemlot'] == 0) {
	        $itemlot->registerSupplierLot($idsupplier, $docLine['suppliername'], $docLine['supplierlot']);
	        $itemlot->registerUom($docLine['iduom']);

	        //get information from requisition document

	        // $itemlot->registerOtherInfo($docLine['workorder'],$docLine['workorderlineno'],$docLine['requestdocnumber'],$docLine['requestlinenumber'],$docLine['colorcategoryandcode'],$docLine['dprnumber'],$docobj['docdate'],$fabricowner,$ppoffabricdev);
	    }
	    $docLine['itemlot'] = $itemlot->idtnx_itemlot;



	  	return $docLine['itemlot'];
	}


	function rcvChemicalItem($searchParams){
	    $conn = new ErpDbConn;
	  
	    $polinenumber = $searchParams['polinenumber'];
	    $tnxquantity = $searchParams['tnxquantity'];
	    $challanno = $searchParams['challanno'];
	    $whlocation = $searchParams['whlocation'];
	    $TransactionDate = $searchParams['TransactionDate'];
	    $TransactionTime = $searchParams['TransactionTime'];
	    $supplierlot = $searchParams['supplierlot'];
	    $manufacturingdate = $searchParams['manufacturingdate'];
	    $expiredate = $searchParams['expiredate'];
	    // return $TransactionDate;
	    $polinenumberArray = explode(',', $polinenumber);
	    $tnxquantityArray = explode(',', $tnxquantity);
	    $supplierlotArray = explode(',', $supplierlot);
	    $whlocationArray = explode(',', $whlocation);
	    $manufacturingdateArray = explode(',', $manufacturingdate);
	    $expiredateArray = explode(',', $expiredate);

	    $polinenumberArrayWh = "'" . implode("','", $polinenumberArray) . "'";

	    $sql = "SELECT * FROM erp_nonpo WHERE doclinenumber IN ($polinenumberArrayWh)";
	   	$queryResult = $conn->query($sql);
	    $data = array();
	    $sql = array();
	    $docnumber = $this->getNextDocNumber('counter_NP_TF');

		$entrypersonbadge  = $_SESSION['LoggedBadge'];
		$entrypersonname = "";
		$sqlGetName = "SELECT * from mrd_employee_basicinfo where Badge='".$_SESSION['LoggedBadge']."';";
		$result = $conn->query($sqlGetName);
		while($row = $result->fetch_assoc()){
			$entrypersonname = $row['Name'];
		}


	    
	    while($row = $queryResult->fetch_assoc()){

	    	foreach ($row as $key => $value) {
	    		$value  = str_replace("'", "\'", $value);
	    		$row[$key] = $value;

	    	}
	    	$row['supplierlot'] = $supplierlot;
	    	$itemlot  = $this->registerItemLot($row);

	    	$transactionno = $this->getNextNumber('counter_NP');
			$itemname = $row['itemname'];
			$itemdescription = $row['itemdescription'];
			$uom = $row['iduom'];
			$polineno = $row['doclinenumber'];
			$templatecode = 'T03';
			$transactiontype = 'Receive from Supplier';
			$prlineno = $row['requisitionlinenumber'];
			$itemcode = $row['itemcode'];
			$itemtype = $row['itemtype'];
			$projectcode = $row['project'];
			$itemnature = $row['itemnature'];
			$suppliername = $row['suppliername'];
			$company = $row['company'];
			$costcenter = $row['costcenter'];
			$costdepartment = $row['costdept'];
			$brand = $row['brand'];
			$color = $row['color'];
			$sizeormeasurement = $row['sizeormeasurement'];
			$unitprice = $row['unitprice'];
			$currency = $row['currency'];
			$transactiondate = $TransactionDate;
			$transactiontime = $TransactionTime;
			
	    	$key = array_search($polineno, $polinenumberArray);
			$tnxquantity = $tnxquantityArray[$key];

			$stockvalue = $tnxquantity * $unitprice;

			$supplierlot = $supplierlotArray[$key];
			$whlocation = $whlocationArray[$key];
			$manufacturingdate = $manufacturingdateArray[$key];
			$expiredate = $expiredateArray[$key];

			$date1 = new DateTime(date("Y-m-d"));
			$date2 = new DateTime($expiredate);

			$date3 = new DateTime($manufacturingdate);

			$shelflife = $date1->diff($date2);
			$shelflife = $shelflife->days;

			$totallife = $date3->diff($date2);
			$totallife = $totallife->days;

			$rcvshelflifeP = ($shelflife/$totallife)*100;


			$updateRcvQtySql = "UPDATE erp_nonpo SET receivedqty=(receivedqty+$tnxquantity)  WHERE doclinenumber='$prlineno'";
			// return $updateRcvQtySql;

			$sql = "INSERT INTO erp_balance_transaction (itemname,itemdescription,uom,templatecode,transactiontype,prlineno,itemcode,polineno,projectcode,itemnature,tnxquantity,challanno,whlocation,suppliername,company,docnumber,transactiondate,transactiontime,transactionno,costdepartment,costcenter,brand,color,sizeormeasurement,entrypersonbadge,entrypersonname,supplierlot,manufacturingdate,expiredate,itemlot,itemtype, unitprice,stockvalue,currency) VALUES('$itemname','$itemdescription','$uom','$templatecode','$transactiontype','$prlineno','$itemcode','$polineno','$projectcode','$itemnature','$tnxquantity','$challanno','$whlocation','$suppliername','$company','$docnumber','$transactiondate','$transactiontime','$transactionno','$costdepartment','$costcenter','$brand','$color','$sizeormeasurement','$entrypersonbadge','$entrypersonname','$supplierlot','$manufacturingdate','$expiredate','$itemlot','$itemtype','$unitprice','$stockvalue','$currency')";
			// return $sql;
			$result = $conn->query($sql);
			if($result){
				$conn->query($updateRcvQtySql);

				$sqlQty = "SELECT orderqty, receivedqty FROM erp_nonpo WHERE doclinenumber='$prlineno'";
				$resultQty = $conn->query($sqlQty);
				while($row = $resultQty->fetch_assoc()){
					$orderqty = $row['orderqty'];
					$receivedqty = $row['receivedqty'];

					if($orderqty <= $receivedqty){
						$updStaSql = "UPDATE erp_nonpo SET linestatus='3' WHERE doclinenumber='$prlineno'";
						$conn->query($updStaSql);
					}
				}
			}

			$sqlMultiplier = "SELECT multiplier FROM erp_stock_transaction_template WHERE templatecode='$templatecode'";
			$queryResultMultiplier = $conn->query($sqlMultiplier);
			$multiplier = $queryResultMultiplier->fetch_assoc()['multiplier'];
			$tnxquantity = ($tnxquantity * $multiplier) ;

			$checkBalSql = "SELECT * FROM erp_balance WHERE itemcode='$itemcode' AND itemlot='$itemlot' AND projectcode='$projectcode' AND whlocation='$whlocation' AND uom='$uom' AND company='$company' AND polineno = '$polineno'";
			$queryResultBal = $conn->query($checkBalSql);
			$queryRowsNum = $queryResultBal->num_rows;

			if($queryRowsNum == 0){
				$sqlInsert = "INSERT INTO erp_balance (projectcode,whlocation,itemcode,tnxquantity,uom,itemnature,company,costdepartment,costcenter,itemname,brand,color,sizeormeasurement,itemdescription,supplierlot,manufacturingdate,expiredate,itemlot,shelflife,rcvshelflifep,itemtype,unitprice,stockvalue,currency, polineno, prlineno) VALUES('$projectcode','$whlocation','$itemcode','$tnxquantity','$uom','$itemnature','$company','$costdepartment','$costcenter','$itemname','$brand','$color','$sizeormeasurement','$itemdescription','$supplierlot','$manufacturingdate','$expiredate','$itemlot','$totallife','$rcvshelflifeP','$itemtype','$unitprice','$stockvalue','$currency', '$polineno', '$prlineno')";
				$result = $conn->query($sqlInsert);
			}else{
				$updateSql = "UPDATE erp_balance SET tnxquantity=(tnxquantity+$tnxquantity),stockvalue=(stockvalue+($tnxquantity*$unitprice)) WHERE itemcode='$itemcode' AND itemlot='$itemlot' AND projectcode='$projectcode' AND whlocation='$whlocation' AND uom='$uom' AND company='$company'";
				$result = $conn->query($updateSql);
			}

	    	// array_push($data, $row);
	    }

	    $conn->close();

	   	return $docnumber;

	}


	function rcvAccessoriesItem($searchParams){
	    $conn = new ErpDbConn;
	    $insertlogObj = new InsertLogTableData();
	    date_default_timezone_set("Asia/Dhaka"); 
	  
	    $prlinenumber = $searchParams['doclinenumber'];
	    $polinenumber = $searchParams['polinenumber'];
	    $tnxquantity = $searchParams['tnxquantity'];
	    $challanno = $searchParams['challanno'];
	    $remarks = $searchParams['remarks'];
	    $whlocation = $searchParams['whlocation'];
	    $TransactionDate = $searchParams['TransactionDate'];
	    $TransactionTime = $searchParams['TransactionTime'];
	    $supplierlot = $searchParams['supplierlot'];
	    // return $TransactionDate;
	    $prlinenumberArray = explode(',', $prlinenumber);
	    $polinenumberArray = explode(',', $polinenumber);
	    $tnxquantityArray = explode(',', $tnxquantity);
	    $supplierlotArray = explode(',', $supplierlot);
	    $whlocationArray = explode(',', $whlocation);

	    $prlinenumberArrayWh = "'" . implode("','", $prlinenumberArray) . "'";
	    $polinenumberArrayWh = "'" . implode("','", $polinenumberArray) . "'";
	    $remarks  = str_replace("+", " ", $remarks);

	    $sql = "SELECT * FROM erp_nonpo WHERE doclinenumber IN ($polinenumberArrayWh)";
	   	$queryResult = $conn->query($sql);
	    $data = array();
	    $sql = array();
	    $docnumber = $this->getNextDocNumber('counter_NP_TF');

		$entrypersonbadge  = $_SESSION['LoggedBadge'];
		$creationuser  = $_SESSION['USERNAME'];
		$creationdatetime  = date('Y-m-d H:i:s', time());
		$lastupdateuser  = $_SESSION['USERNAME'];
		$lastupdatetime  = date('Y-m-d H:i:s', time());
		$entrypersonname = "";
		$sqlGetName = "SELECT * from mrd_employee_basicinfo where Badge='".$_SESSION['LoggedBadge']."';";
		$result = $conn->query($sqlGetName);
		while($row = $result->fetch_assoc()){
			$entrypersonname = $row['Name'];
		}


	    
	    while($row = $queryResult->fetch_assoc()){

	    	foreach ($row as $key => $value) {
	    		$value  = str_replace("'", "\'", $value);
	    		$row[$key] = $value;

	    	}
	    	$row['supplierlot'] = $supplierlot;

	    	$transactionno = $this->getNextNumber('counter_NP');
			$customer = $row['customer'];
			$company = $row['company'];
			$itemtype = $row['itemtype'];
			$transactiontype = 'Receive from Supplier';
			$masterreference = $row['masterreference'];
			$prlineno = $row['requisitionlinenumber'];
			$polineno = $row['doclinenumber'];
			$season = $row['season'];
			$suppliername = $row['suppliername'];
	    	$itemlot  = $this->registerItemLot($row);
			$uom = $row['iduom'];
			$trimscatagory = $row['trimscatagory'];
			$cartontype = $row['cartontype'];
			$subcode01 = $row['subcode01'];
			$subcode02 = $row['subcode02'];
			$subcode03 = $row['subcode03'];
			$subcode04 = $row['subcode04'];
			$subcode05 = $row['subcode05'];
			$subcode06 = $row['subcode06'];
			$subcode07 = $row['subcode07'];
			$subcode08 = $row['subcode08'];
			$subcode09 = $row['subcode09'];
			$subcode10 = $row['subcode10'];
			$subcode11 = $row['subcode11'];
			$itemcode = $row['itemcode'];
			$unitprice = $row['unitprice'];
			$currency = $row['currency'];
			$templatecode = 'T03';
			$style = $row['style'];
			$projectcode = $row['project'];
			$masterreference = $row['masterreference'];
			$etadate = $row['etadate'];
			$trackingNum = $row['trackingNum'];
			$stockclassification = $row['stockclassification'];
			$stockclassificationdate = $row['stockclassificationdate'];
			$itemnature = 'Consumable goods';
			$transactiondate = $TransactionDate;
			$transactiontime = $TransactionTime;
			
	    	$key = array_search($polineno, $polinenumberArray);
			$tnxquantity = $tnxquantityArray[$key];

			$stockvalue = $tnxquantity * $unitprice;

			$supplierlot = $supplierlotArray[$key];
			$whlocation = $whlocationArray[$key];

			$date1 = new DateTime(date("Y-m-d"));


			$updateRcvQtySql = "UPDATE erp_nonpo SET receivedqty = (receivedqty+$tnxquantity)  WHERE doclinenumber = '$prlineno'";
			// return $updateRcvQtySql;

			$sql = "INSERT INTO erp_balance_transaction (projectcode, customer, uom, templatecode, transactiontype, prlineno, itemcode, polineno, season, trimscatagory, cartontype, tnxquantity, challanno, whlocation, suppliername, company, docnumber, transactiondate, transactiontime, transactionno, subcode01, subcode02, subcode03, subcode04, subcode05, subcode06, subcode07, subcode08, subcode09, subcode10, subcode11, entrypersonbadge, entrypersonname, supplierlot, style, creationuser, creationdatetime, itemlot, itemtype, unitprice, stockvalue, currency, itemnature, masterreference, etadate, remarks, trackingNum, stockclassification, stockclassificationdate) VALUES('$projectcode', '$customer', '$uom', '$templatecode', '$transactiontype', '$prlineno', '$itemcode', '$polineno', '$season', '$trimscatagory', '$cartontype', '$tnxquantity', '$challanno', '$whlocation', '$suppliername', '$company', '$docnumber', '$transactiondate', '$transactiontime', '$transactionno', '$subcode01', '$subcode02', '$subcode03', '$subcode04', '$subcode05', '$subcode06', '$subcode07', '$subcode08', '$subcode09', '$subcode10', '$subcode11', '$entrypersonbadge', '$entrypersonname', '$supplierlot', '$style', '$creationuser', '$creationdatetime', '$itemlot', '$itemtype', '$unitprice', '$stockvalue', '$currency', '$itemnature', '$masterreference', '$etadate', '$remarks', '$trackingNum', '$stockclassification', '$stockclassificationdate')";
			// return $sql;
			$result = $conn->query($sql);
			$idlines = $conn->conn->insert_id;
			$insertlogObj->insertDataIntoLogTable_New('idlines', $idlines, 'erp_balance_transaction', 'erp_balance_transaction_log', 'Create');

			if($result){
				$conn->query($updateRcvQtySql);
				$insertlogObj->insertDataIntoLogTable_New('doclinenumber', $prlineno, 'erp_nonpo', 'erp_nonpo_log', 'Update');

				$sqlQty = "SELECT orderqty, receivedqty FROM erp_nonpo WHERE doclinenumber = '$prlineno'";
				$resultQty = $conn->query($sqlQty);
				while($row = $resultQty->fetch_assoc()){
					$orderqty = $row['orderqty'];
					$receivedqty = $row['receivedqty'];

					if($orderqty <= $receivedqty){
						$updStaSql = "UPDATE erp_nonpo SET linestatus = '3' WHERE doclinenumber = '$prlineno'";
						$conn->query($updStaSql);
						$insertlogObj->insertDataIntoLogTable_New('doclinenumber', $prlineno, 'erp_nonpo', 'erp_nonpo_log', 'Update');
					}
				}
			}

			$sqlMultiplier = "SELECT multiplier FROM erp_stock_transaction_template WHERE templatecode = '$templatecode'";
			$queryResultMultiplier = $conn->query($sqlMultiplier);
			$multiplier = $queryResultMultiplier->fetch_assoc()['multiplier'];
			$tnxquantity = ($tnxquantity * $multiplier) ;

			$checkBalSql = "SELECT * FROM erp_balance WHERE itemcode = '$itemcode' AND itemlot = '$itemlot' AND projectcode = '$projectcode' AND whlocation = '$whlocation' AND uom = '$uom' AND company = '$company' AND polineno = '$polineno'";
			$queryResultBal = $conn->query($checkBalSql);
			$queryRowsNum = $queryResultBal->num_rows;

			if($queryRowsNum == 0){
				$sqlInsert = "INSERT INTO erp_balance (customer, itemdescription, uom, prlineno, itemcode, polineno, season, trimscatagory, cartontype, tnxquantity, whlocation, company, subcode01, subcode02, subcode03, subcode04, subcode05, subcode06, subcode07, subcode08, subcode09, subcode10, subcode11, entrypersonbadge, entrypersonname, supplierlot, style, creationuser, creationdatetime, itemlot, itemtype, unitprice, stockvalue, currency, itemnature, projectcode, masterreference, etadate, trackingNum, suppliername, stockclassification, stockclassificationdate) VALUES('$customer', '$itemdescription', '$uom', '$prlineno', '$itemcode', '$polineno', '$season', '$trimscatagory', '$cartontype', '$tnxquantity', '$whlocation', '$company', '$subcode01', '$subcode02', '$subcode03', '$subcode04', '$subcode05', '$subcode06', '$subcode07', '$subcode08', '$subcode09', '$subcode10', '$subcode11', '$entrypersonbadge', '$entrypersonname', '$supplierlot', '$style', '$creationuser', '$creationdatetime', '$itemlot', '$itemtype', '$unitprice', '$stockvalue', '$currency', '$itemnature', '$projectcode', '$masterreference', '$etadate', '$trackingNum', '$suppliername', '$stockclassification', '$stockclassificationdate')";
				// echo $sqlInsert;
				$result = $conn->query($sqlInsert);
				$idlines = $conn->conn->insert_id;
				$insertlogObj->insertDataIntoLogTable_New('idlines', $idlines, 'erp_balance', 'erp_balance_log', 'Create');

			}else{
				$updateSql = "UPDATE erp_balance SET tnxquantity = (tnxquantity+$tnxquantity),stockvalue = (stockvalue+($tnxquantity*$unitprice)), lastupdateuser = '$lastupdateuser', lastupdatetime = '$lastupdatetime' WHERE itemcode = '$itemcode' AND itemlot = '$itemlot' AND projectcode = '$projectcode' AND whlocation = '$whlocation' AND uom = '$uom' AND company = '$company' AND polineno = '$polineno'";
				$result = $conn->query($updateSql);

				$idlines =  $queryResultBal->fetch_assoc()['idlines'];
				$insertlogObj->insertDataIntoLogTable_New('idlines', $idlines, 'erp_balance', 'erp_balance_log', 'Update');
			}

	    	// array_push($data, $row);
	    }
	    $conn->close();

	   	return $docnumber;

	}


	function rcvAccessoriesItem2($searchParams){
	    $conn = new ErpDbConn;
	    $insertlogObj = new InsertLogTableData();
	    date_default_timezone_set("Asia/Dhaka"); 
	  
	    $prlinenumber = $searchParams['doclinenumber'];
	    $polinenumber = $searchParams['polinenumber'];
	    $tnxquantity = $searchParams['tnxquantity'];
	    $challanno = $searchParams['challanno'];
	    $remarks = $searchParams['remarks'];
	    $whlocation = $searchParams['whlocation'];
	    $TransactionDate = $searchParams['TransactionDate'];
	    $TransactionTime = $searchParams['TransactionTime'];
	    $supplierlot = $searchParams['supplierlot'];
	    // return $TransactionDate;
	    $prlinenumberArray = explode(',', $prlinenumber);
	    $polinenumberArray = explode(',', $polinenumber);
	    $tnxquantityArray = explode(',', $tnxquantity);
	    $supplierlotArray = explode(',', $supplierlot);
	    $whlocationArray = explode(',', $whlocation);

	    $prlinenumberArrayWh = "'" . implode("','", $prlinenumberArray) . "'";
	    $polinenumberArrayWh = "'" . implode("','", $polinenumberArray) . "'";
	    $remarks  = str_replace("+", " ", $remarks);

	    $sql = "SELECT * FROM erp_nonpo WHERE doclinenumber IN ($polinenumberArrayWh)";
	   	$queryResult = $conn->query($sql);
	    $data = array();
	    $sql = array();
	    $docnumber = $this->getNextDocNumber('counter_NP_TF');

		$entrypersonbadge  = $_SESSION['LoggedBadge'];
		$creationuser  = $_SESSION['USERNAME'];
		$creationdatetime  = date('Y-m-d H:i:s', time());
		$lastupdateuser  = $_SESSION['USERNAME'];
		$lastupdatetime  = date('Y-m-d H:i:s', time());
		$entrypersonname = "";
		$sqlGetName = "SELECT * from mrd_employee_basicinfo where Badge='".$_SESSION['LoggedBadge']."';";
		$result = $conn->query($sqlGetName);
		while($row = $result->fetch_assoc()){
			$entrypersonname = $row['Name'];
		}


		$transactionField = array('projectcode', 'customer', 'uom', 'templatecode', 'transactiontype', 'prlineno', 'itemcode', 'polineno', 'season', 'trimscatagory', 'cartontype', 'tnxquantity', 'challanno', 'whlocation', 'suppliername', 'company', 'docnumber', 'transactiondate', 'transactiontime', 'transactionno', 'subcode01', 'subcode02', 'subcode03', 'subcode04', 'subcode05', 'subcode06', 'subcode07', 'subcode08', 'subcode09', 'subcode10', 'subcode11', 'entrypersonbadge', 'entrypersonname', 'supplierlot', 'style', 'creationuser', 'creationdatetime', 'itemlot', 'itemtype', 'unitprice', 'stockvalue', 'currency', 'itemnature', 'masterreference', 'etadate', 'remarks', 'trackingNum');

		$balanceField = array('customer', 'itemdescription', 'uom', 'prlineno', 'itemcode', 'polineno', 'season', 'trimscatagory', 'cartontype', 'tnxquantity', 'whlocation', 'company', 'subcode01', 'subcode02', 'subcode03', 'subcode04', 'subcode05', 'subcode06', 'subcode07', 'subcode08', 'subcode09', 'subcode10', 'subcode11', 'entrypersonbadge', 'entrypersonname', 'supplierlot', 'style', 'creationuser', 'creationdatetime', 'itemlot', 'itemtype', 'unitprice', 'stockvalue', 'currency', 'itemnature', 'projectcode', 'masterreference', 'etadate', 'trackingNum');
	    
	    while($row = $queryResult->fetch_assoc()){

	    	foreach ($row as $key => $value) {
	    		$value  = str_replace("'", "\'", $value);
	    		$row[$key] = $value;

	    	}
	    	$row['transactionno']= $this->getNextNumber('counter_NP');
	    	$row['itemlot']= $this->registerItemLot($row);
			$row['transactiontype']= 'Receive from Supplier';
			$row['itemnature']= 'Consumable goods';
			$row['transactiondate']= $TransactionDate;
			$row['transactiontime']= $TransactionTime;
			$polineno = $row['doclinenumber'];

	    	$key = array_search($polineno, $polinenumberArray);
			$tnxquantity = $tnxquantityArray[$key];
			$row['tnxquantity']= $tnxquantity;

			$row['stockvalue']= $tnxquantity * $unitprice;

			$row['supplierlot']= $supplierlotArray[$key];
			$row['whlocation']= $whlocationArray[$key];

			$updateRcvQtySql = "UPDATE erp_nonpo SET receivedqty = (receivedqty+$tnxquantity)  WHERE doclinenumber = '$prlineno'";
			// return $updateRcvQtySql;

			$sql = "INSERT INTO erp_balance_transaction (projectcode, customer, uom, templatecode, transactiontype, prlineno, itemcode, polineno, season, trimscatagory, cartontype, tnxquantity, challanno, whlocation, suppliername, company, docnumber, transactiondate, transactiontime, transactionno, subcode01, subcode02, subcode03, subcode04, subcode05, subcode06, subcode07, subcode08, subcode09, subcode10, subcode11, entrypersonbadge, entrypersonname, supplierlot, style, creationuser, creationdatetime, itemlot, itemtype, unitprice, stockvalue, currency, itemnature, masterreference, etadate, remarks, trackingNum) VALUES('$projectcode', '$customer', '$uom', '$templatecode', '$transactiontype', '$prlineno', '$itemcode', '$polineno', '$season', '$trimscatagory', '$cartontype', '$tnxquantity', '$challanno', '$whlocation', '$suppliername', '$company', '$docnumber', '$transactiondate', '$transactiontime', '$transactionno', '$subcode01', '$subcode02', '$subcode03', '$subcode04', '$subcode05', '$subcode06', '$subcode07', '$subcode08', '$subcode09', '$subcode10', '$subcode11', '$entrypersonbadge', '$entrypersonname', '$supplierlot', '$style', '$creationuser', '$creationdatetime', '$itemlot', '$itemtype', '$unitprice', '$stockvalue', '$currency', '$itemnature', '$masterreference', '$etadate', '$remarks', '$trackingNum')";
			// return $sql;
			$result = $conn->query($sql);
			$idlines = $conn->conn->insert_id;
			$insertlogObj->insertDataIntoLogTable_New('idlines', $idlines, 'erp_balance_transaction', 'erp_balance_transaction_log', 'Create');

			if($result){
				$conn->query($updateRcvQtySql);
				$insertlogObj->insertDataIntoLogTable_New('doclinenumber', $prlineno, 'erp_nonpo', 'erp_nonpo_log', 'Update');

				$sqlQty = "SELECT orderqty, receivedqty FROM erp_nonpo WHERE doclinenumber = '$prlineno'";
				$resultQty = $conn->query($sqlQty);
				while($row = $resultQty->fetch_assoc()){
					$orderqty = $row['orderqty'];
					$receivedqty = $row['receivedqty'];

					if($orderqty <= $receivedqty){
						$updStaSql = "UPDATE erp_nonpo SET linestatus = '3', lastupdateuser = '$lastupdateuser', lastupdatetime = '$lastupdatetime' WHERE doclinenumber = '$prlineno'";
						$conn->query($updStaSql);
						$insertlogObj->insertDataIntoLogTable_New('doclinenumber', $prlineno, 'erp_nonpo', 'erp_nonpo_log', 'Update');
					}
				}
			}

			$sqlMultiplier = "SELECT multiplier FROM erp_stock_transaction_template WHERE templatecode = '$templatecode'";
			$queryResultMultiplier = $conn->query($sqlMultiplier);
			$multiplier = $queryResultMultiplier->fetch_assoc()['multiplier'];
			$tnxquantity = ($tnxquantity * $multiplier) ;

			$checkBalSql = "SELECT * FROM erp_balance WHERE itemcode = '$itemcode' AND itemlot = '$itemlot' AND projectcode = '$projectcode' AND whlocation = '$whlocation' AND uom = '$uom' AND company = '$company' AND polineno = '$polineno'";
			$queryResultBal = $conn->query($checkBalSql);
			$queryRowsNum = $queryResultBal->num_rows;

			if($queryRowsNum == 0){
				$sqlInsert = "INSERT INTO erp_balance (customer, itemdescription, uom, prlineno, itemcode, polineno, season, trimscatagory, cartontype, tnxquantity, whlocation, company, subcode01, subcode02, subcode03, subcode04, subcode05, subcode06, subcode07, subcode08, subcode09, subcode10, subcode11, entrypersonbadge, entrypersonname, supplierlot, style, creationuser, creationdatetime, itemlot, itemtype, unitprice, stockvalue, currency, itemnature, projectcode, masterreference, etadate, trackingNum) VALUES('$customer', '$itemdescription', '$uom', '$prlineno', '$itemcode', '$polineno', '$season', '$trimscatagory', '$cartontype', '$tnxquantity', '$whlocation', '$company', '$subcode01', '$subcode02', '$subcode03', '$subcode04', '$subcode05', '$subcode06', '$subcode07', '$subcode08', '$subcode09', '$subcode10', '$subcode11', '$entrypersonbadge', '$entrypersonname', '$supplierlot', '$style', '$creationuser', '$creationdatetime', '$itemlot', '$itemtype', '$unitprice', '$stockvalue', '$currency', '$itemnature', '$projectcode', '$masterreference', '$etadate', '$trackingNum')";
				// echo $sqlInsert;
				$result = $conn->query($sqlInsert);
				$idlines = $conn->conn->insert_id;
				$insertlogObj->insertDataIntoLogTable_New('idlines', $idlines, 'erp_balance', 'erp_balance_log', 'Create');

			}else{
				$updateSql = "UPDATE erp_balance SET tnxquantity = (tnxquantity+$tnxquantity),stockvalue = (stockvalue+($tnxquantity*$unitprice)), lastupdateuser = '$lastupdateuser', lastupdatetime = '$lastupdatetime' WHERE itemcode = '$itemcode' AND itemlot = '$itemlot' AND projectcode = '$projectcode' AND whlocation = '$whlocation' AND uom = '$uom' AND company = '$company' AND polineno = '$polineno'";
				$result = $conn->query($updateSql);

				$idlines =  $queryResultBal->fetch_assoc()['idlines'];
				$insertlogObj->insertDataIntoLogTable_New('idlines', $idlines, 'erp_balance', 'erp_balance_log', 'Update');
			}

	    	// array_push($data, $row);
	    }
	    $conn->close();

	   	return $docnumber;

	}	

	function getMLInfo($salesorder, $itemcode){
		$conn = new ErpDbConn;
		$sql = "SELECT * FROM erp_fabricmaterialline WHERE materiallistid IN(SELECT materiallistid FROM erp_salesorder WHERE docnumber = '$salesorder') AND itemcode='$itemcode'";		
		$result  = $conn->query($sql);
		$row  = $result->fetch_assoc();

		return $row; 
	}	

	function getProjectionPOInfo($rrnumber){
		$conn = new ErpDbConn;
		$sql = "SELECT docnumber,doclinenumber FROM erp_balance_transaction WHERE rrnumber IN(SELECT parentrrnumber FROM erp_rrlines WHERE rrnumber='$rrnumber')";
		$result  = $conn->query($sql);
		$row  = $result->fetch_assoc();

		return $row; 
	}

	function getSOInfo($searchParams){
	    $conn = new ErpDbConn;

	    // $idlines = json_decode($idlines, true);
	  
	    $salesorder = $searchParams['salesorder'];


	    // $sql = "SELECT * FROM erp_rrlines WHERE idlines='$idlines'";
	    $sql = "SELECT * FROM erp_salesorder WHERE docnumber='$salesorder'";
	    // return $sql;
	   	$result =  $conn->sqlToJson($sql);

	    $conn->close();

	   	return $result;

	}	

	function getRRLineInfo($searchParams){
	    $conn = new ErpDbConn;

	    // $idlines = json_decode($idlines, true);
	  
	    $requisitionlinenumber = $searchParams['requisitionlinenumber'];


	    
	    $sql = "SELECT * FROM erp_nonpo WHERE doclinenumber='$requisitionlinenumber'";
	    // return $sql;
	   	$result =  $conn->sqlToJson($sql);

	    $conn->close();

	   	return $result;

	}	

	function senttoTextile($data){
		$returnJson = new stdClass();
		$conn = new ErpDbConn;

		$data      = json_decode($data, true);
		$docnumber = $data['docnumber'];
		$rrnumber  = $data['rrnumber'];
		$rrnumber  = "'" . implode("','",$rrnumber) . "'";
		$posenttotextiletime = date("Y-m-d H:i:s");

		$sqlUpdateDocStatus = "UPDATE erp_balance_transaction SET docstatus='1',linestatus='1', posenttotextiletime = '$posenttotextiletime' WHERE docnumber='$docnumber' AND linestatus!='9'";
		$sql                = "UPDATE erp_rrlines SET rrstatus = '4', linestatus = '5' WHERE rrnumber IN($rrnumber)";

		$result      = $conn->query($sqlUpdateDocStatus);
		$queryResult = $conn->query($sql);

		if($queryResult){
			$returnJson->result = 'success';
		} else {
			$returnJson->result = 'fail';
		}
		$conn->close();
		return json_encode($returnJson);

	}	

	function deleteDocLine($idlines){
		$returnJson = new stdClass();
		$conn = new ErpDbConn;

		$sql = "SELECT requisitionlinenumber FROM erp_nonpo WHERE idlines='$idlines'";
		$sqlResult = $conn->query($sql);

		$row = $sqlResult->fetch_assoc();
		$doclinenumber = $row['requisitionlinenumber'];

		$sqlUpdate = "UPDATE erp_nonpo SET linestatus='1', ponumber = '', polinenumber=''  WHERE doclinenumber='$doclinenumber'";
		$queryResult = $conn->query($sqlUpdate);

		$sqlDelete = "DELETE FROM erp_nonpo WHERE idlines='$idlines'";
		$queryResult = $conn->query($sqlDelete);

		if($queryResult){
			$returnJson->result = 'success';
		} else {
			$returnJson->result = 'fail';
		}
		$conn->close();
		return json_encode($returnJson);
	}

	function removeDocLine($idlines){
		$conn = new ErpDbConn;
		$returnJSON           = new stdClass();
		$returnJSON->errormsgs = array();

		//delete line and update balance
		$sqlUpdateBalTransaction = "SELECT itemcode,templatecode,projectcode,whlocation,binlocation,tnxquantity FROM erp_balance_transaction WHERE idlines = '$idlines'";
		$resultBalTransaction = $conn->query($sqlUpdateBalTransaction);
		while($row = $resultBalTransaction->fetch_assoc()){
			$itemcode = $row['itemcode'];
			$templatecode = $row['templatecode'];
			$projectcode = $row['projectcode'];
			$whlocation = $row['whlocation'];
			$binlocation = $row['binlocation'];
			$tnxquantity = $row['tnxquantity'];

			$sqlMultiplier = "SELECT multiplier FROM erp_stock_transaction_template WHERE templatecode='$templatecode'";
			$queryResultMultiplier = $conn->query($sqlMultiplier);
			$multiplier = $queryResultMultiplier->fetch_assoc()['multiplier'];
			$tnxquantity = ($tnxquantity * $multiplier) ;

			$updateBalSql = "UPDATE erp_balance SET tnxquantity=(tnxquantity-$tnxquantity) WHERE itemcode='$itemcode' AND projectcode='$projectcode' AND whlocation='$whlocation' AND binlocation='$binlocation'";
			$queryResultBal = $conn->query($updateBalSql);
		}

		$sql = "DELETE FROM erp_balance_transaction WHERE idlines = '$idlines'";
		$result = $conn->query($sql);
		
      	$conn->close();

		if($result){
      		$returnJSON->result = 'success';
			
		} else {
			array_push($returnJSON->errormsgs, "Error, please contact system.support@lizfashion.com: commit failed.");
		}
		return json_encode($returnJSON);
	}	

}


/**
 * Routing ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 */
if ( basename(__FILE__) == basename($_SERVER["SCRIPT_FILENAME"]) ) {
    // called directly
	if ( $_SERVER['REQUEST_METHOD'] == 'GET' ) {

		if(isset($_GET['reqType'])){

			$reqType = $_GET['reqType'];
			$obTest  = new ThisDocAPI();

			if($reqType == 'readDoc') {

				$docnumber = $_GET['docnumber'];
				$idlines   = $_GET['idlines'];
				if($idlines != ""){
					$returnData = $obTest->readDocLineWise($docnumber, $idlines);
				} else {
					$returnData = $obTest->readDoc($docnumber);
				}
				echo $returnData;

			}

			if($reqType == '_searchDoc') {
				$genericDocument = new ErpDocumentNonPoGRN();
				$formStructure = json_encode($genericDocument->formStructure('GRN', '', ''), JSON_PRETTY_PRINT);

				$where = $_GET['where'];
				$columns = $_GET['columns'];
				$returnData = $obTest->_searchDoc($formStructure, $where, $columns);
				echo $returnData;
			}

			if($reqType == 'searchHeaderInfo') {

				$returnData = $obTest->searchHeaderInfo($_GET);
				echo $returnData;

			}


			// if($reqType == 'getPOLineInfo') {

			// 	$returnData = $obTest->getPOLineInfo($_GET);
			// 	echo $returnData;

			// }

			if($reqType == 'getSOInfo') {

				$returnData = $obTest->getSOInfo($_GET);
				echo $returnData;

			}

			if($reqType == 'getRRLineInfo') {

				$returnData = $obTest->getRRLineInfo($_GET);
				echo $returnData;

			}


			if($reqType == 'autoRevisedButtonVisibility') {

				$returnData = $obTest->autoRevisedButtonVisibility($_GET['docnumber']);
				echo $returnData;

			}

			if($reqType == 'getAdditionalRRPOLineInfo') {

				$podocnumber = $_GET['docnumber'];
				$returnData = $obTest->getAdditionalRRPOLineInfo($podocnumber);
				echo $returnData;

			}

			if($reqType == 'updateRevisedNP') {

				$podocnumber = $_GET['docnumber'];
				$returnData = $obTest->updateRevisedPO($podocnumber);
				echo $returnData;

			}

		}


	} else if( $_SERVER['REQUEST_METHOD'] == 'POST' ){
	
		if(isset($_POST['reqType'])){

			$reqType = $_POST['reqType'];
			$obTest  = new ThisDocAPI();

			if($reqType == "saveDoc"){
		
				$docobj = $_POST['docobj'];
				$returnData = $obTest->saveDoc($docobj);
				echo $returnData;
			}

			if($reqType == "_saveLine"){
		
				$line = $_POST['line'];
				$returnData = $obTest->_saveLine($line);
				echo $returnData;
			}

			if($reqType == "changeDocStatus"){

				$docnumber = $_POST['docnumber'];
				$docstatus = $_POST['docstatus'];
				$returnData = $obTest->changeDocStatus($docnumber, $docstatus);
				echo $returnData;
			}

			if($reqType == "poAmendment"){

				$docnumber = $_POST['docnumber'];
				$docstatus = $_POST['docstatus'];
				$returnData = $obTest->poAmendment($docnumber, $docstatus);
				echo $returnData;
			}

			// if($reqType == "deleteDocLine"){

			// 	$idlines = $_POST['idlines'];
			// 	$returnData = $obTest->deleteDocLine($idlines);
			// 	echo $returnData;
			// }

			if($reqType == 'getPOLineInfo') {

				$returnData = $obTest->getPOLineInfo($_POST);
				echo $returnData;


			}


			if($reqType == 'rcvChemicalItem') {

				$returnData = $obTest->rcvChemicalItem($_POST);
				echo $returnData;

			}			

			if($reqType == 'rcvAccessoriesItem') {

				$returnData = $obTest->rcvAccessoriesItem($_POST);
				echo $returnData;

			}

			if($reqType == 'removeDocLine') {
				$idlines = $_POST['idlines'];
				$returnData = $obTest->removeDocLine($idlines);
				echo $returnData;
			}			
			
			if($reqType == "uploadFile"){

				$genericDocument = new ErpDocumentNonPoGRN();
				$formStructure = json_encode($genericDocument->formStructure($formtype, $crudmode), JSON_PRETTY_PRINT);				
				$returnData = $obTest->uploadFile($formStructure);
				echo $returnData;
			}

			if($reqType == "deleteFile"){

				$genericDocument = new ErpDocumentNonPoGRN();
				$formStructure = json_encode($genericDocument->formStructure($formtype, $crudmode), JSON_PRETTY_PRINT);				
				$returnData = $obTest->deleteFile($formStructure);
				echo $returnData;
			}

			if($reqType == "senttoTextile"){

				$data = $_POST['data'];
				$returnData = $obTest->senttoTextile($data);
				echo $returnData;
			}

			if($reqType == 'updateRevisedNP') {

				$podocnumber = $_POST['docnumber'];
				$returnData = $obTest->updateRevisedPO($podocnumber);
				echo $returnData;

			}


		}



	}

} else {
    // included/required

}
?>