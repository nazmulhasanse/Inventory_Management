<?php
require_once $_SERVER["DOCUMENT_ROOT"] . '/includes/user.cookies.php';    // check user login
require_once $_SERVER["DOCUMENT_ROOT"] . '/includes/config.php';          // mysql connections
require_once $_SERVER["DOCUMENT_ROOT"] . '/includes/user-privilege.php';  // privilege function
// check privilege (keep module and section empty to skip privilege check)
$module = "";
$section = "";
$privilege = userPrivileges($module, $section);
if (!$privilege['R']) { header("Location: ../user/no-permission.php"); exit();}

$formTitle = 'ICT Billing List';

$pageTittle= 'ICT Billing List';
$mainHTML  = 'html/listerp.html';
$mainJS    = 'js/list-erp-v2.js?t=2017-10-15';
$customJS  = 'js/list-ict-bills.js?t=2020-12-01';
$apiURL    = 'list-ict-bills_api.php';
$formId    = 'searchForm';

$module = "";
$section = "";
$privilege_sm = json_encode(userPrivileges($module,$section));
?>

<!DOCTYPE HTML>
<html>
<head>
    <?php require_once($_SERVER["DOCUMENT_ROOT"] . "/includes/head.php") ;?>
    <title><?php echo $formTitle;?></title>

    <link rel="stylesheet" type="text/css" href="css/listerp.css">
    <link rel="stylesheet" type="text/css" href="css/list-yourname.css?t=2017-10-15">
    <link rel="stylesheet" type="text/css" href="css/material-button.css">
    <link rel="stylesheet" type="text/css" href="plugin/msgPop.css">
</head>
<body class="right-sidebar">

<!-- Header Wrapper -->
<div id="header-wrapper">
<div class="container">
<div class="row">
<div class="12u">
<!-- Header -->
    <header id="header">
        <?php 
        include_once($_SERVER["DOCUMENT_ROOT"] . "/includes/mainmenu.php");
        ?>
    </header>
</div>
</div>
</div>
</div>

<!-- Main Wrapper -->
<div id="main-wrapper">
<div class="container">
<div class="row">
    <div class="12u skel-cell-important">
        <!-- Content -->
        <div id="content">
        <article class="last">
    <!-- HEADLINES -->
        <div class="headline1"><a href="/erp-nonpo/ict-billing-home.php">Home</a> - </div>   
        <div class="headline2"><?php echo $formTitle;?></div> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<!-- LINKS -->
        <!-- <a href="list-inv-stock.php?businessunit=Textile">Textile Inventory Stock</a> &nbsp;|&nbsp;  -->
        <br><br>
<!-- PAGE CONTENTS -->
<div id="upperButtonBar" style="height:50px;">
    <input type="button" class="btn-blue" value="Create New" title="Create New" onclick="location.href='/erp-nonpo/erpdocument.php?doctype=HBILL';" style="display: inline-block;">
</div>        
<?php
include $mainHTML;
?>
        </article>
        </div>
    </div>

</div>
</div>
</div>


<!-- Footer Wrapper -->
<div id="footer-wrapper">
    <?php include_once($_SERVER["DOCUMENT_ROOT"] . "/includes/footer.php") ;?>
</div>
<script type="text/javascript" src="plugin/fancybox/source/jquery.fancybox.js"></script>
<script type="text/javascript" src="plugin/msgPop.js"></script>
<script type="text/javascript" src="api/client_api.js?t=2017-10-15"></script>
<script type="text/javascript" src="<?php echo $mainJS; ?>"></script>   
<script type="text/javascript" src="<?php echo $customJS; ?>"></script> 
<script type="text/javascript">
$(document).ready(function() {
    var apiURL = '<?php echo $apiURL;?>';
    //                  show,   page,   api_url
    ERPLIST.getListData(50,     1,      apiURL);
}); 
</script>
<style type="text/css">
    #listTable tbody td {
        /*border         : none;*/
        border: 1px solid #ddd;
        padding        : 3px;
        text-align     : center;
        vertical-align : top;
    }

    #warning {
        width: 100px !important;
    }

    /*blink {
        color:red;
        -webkit-animation: blink 4s step-end infinite;
        animation: blink 1s step-end infinite
    }*/

    @-webkit-keyframes blink {
        67% { opacity: 0 }
    }

    @keyframes blink {
        67% { opacity: 0 }
    }
/*    #spanwarning{
        font-weight: bold;
        animation-name: example;
        animation-duration: 6s;
        animation-iteration-count: infinite;
    }

    @keyframes example {
        from {color: red;}
        to {color: white;}
    }*/

/*    #spanwarning {
        position: relative;
        font-family: sans-serif;
        text-transform: uppercase;
        letter-spacing: 4px;
        overflow: hidden;
        background: linear-gradient(90deg, red, #fff, #000);
        background-repeat: no-repeat;
        background-size: 80%;
        animation: animate 3s linear infinite;
        -webkit-background-clip: text;
        -webkit-text-fill-color: rgba(255, 255, 255, 0);
    }

@keyframes animate {
  0% {
    background-position: -500%;
  }
  100% {
    background-position: 500%;
  }
}*/


    #spanwarning {
        text-align: center;
        color: red;
        letter-spacing: 7px;
        font-weight: 700;
        animation: blur 1s ease-out infinite;
        text-shadow: 0px 0px 5px red, 0px 0px 7px #fff;
    }

    @keyframes blur {
        from {
            text-shadow:0px 0px 10px #fff,
            0px 0px 10px #fff, 
            0px 0px 25px #fff,
            0px 0px 25px #fff,
            0px 0px 25px #fff,
            0px 0px 25px #fff,
            0px 0px 25px #fff,
            0px 0px 25px #fff,
            0px 0px 50px #fff,
            0px 0px 50px #fff,
            0px 0px 50px #7B96B8,
            0px 0px 150px #7B96B8,
            0px 10px 100px #7B96B8,
            0px 10px 100px #7B96B8,
            0px 10px 100px #7B96B8,
            0px 10px 100px #7B96B8,
            0px -10px 100px #7B96B8,
            0px -10px 100px #7B96B8;
        }
    }

</style>
</body>
</html>