<?php
/********************************
 **Author: Al-Mamun    **
 **Module Name: document   **
 **Crated date: 2017-01-14 **
 ********************************/
/*
 * Check if we have iddocument
 * Get json data for this document and decode
 * Get the definition from erpdocument_define.php
 * include printdocdefine file
 * Decode data using library (if necessary) and overwrite value
 * Process Barcode
 * Quantity processing for item-lot-element
 * Unset unnecessary line element
 * Getting unique value and re-index array
 * Push calculated total value in line array
 * Draw Head Table
 * Draw Line Table
 * Draw Net Total Table
 * Draw GatePass Table
 * Draw Signature Table
 * Draw Notes Table
 */
session_start();
$directory = __DIR__ ;
require_once $_SERVER["DOCUMENT_ROOT"] . '/includes/configli.php';
require_once __DIR__ . "/classes/myclassautoloader.php";

/**
* Print Document Class
*/
class PrintDoc extends GeneralPrintDoc
{
	private $printFormat;
	public $docdefine;
	public $printdocdefine;
	private $printParams = array();

	function __construct($doctype, $formtype){
		/*
		 * Get the definition from erpdocument_define.php
		 */
		$serverUrl = "http://";
		$serverUrl .= $_SERVER["SERVER_NAME"];
		$serverUrl .= ($_SERVER["SERVER_PORT"] != "80") ? ":" . $_SERVER["SERVER_PORT"] : "";

		$rootPath = $_SERVER['DOCUMENT_ROOT'];
		$thisPath = dirname($_SERVER['PHP_SELF']);
		$onlyPath = str_replace($rootPath, '', $thisPath);
		$docdefine = file_get_contents("$serverUrl/$onlyPath/erpdocument_define.php?doctype=$doctype&formtype=$formtype&crudmode=read");
		$this->docdefine = $docdefine;
		// echo $docdefine;
	}

	public function printPage($printParams){

		$pageTittle = $printParams['pageTittle'];
		$company = $printParams['company'];
		$companyAddress = $printParams['companyAddress'];
		$docTittle = $printParams['docTittle'];
		$docSubTittle = $printParams['docSubTittle'];
		$headTable  = $printParams['headTable'];
		$lineTable  = $printParams['lineTable'];
		$notesTable  = $printParams['notesTable'];
		$gatePassPage  = $printParams['gatePassPage'];
		$paymentNdeliveryTerms  = $printParams['paymentNdeliveryTerms'];

echo <<<EOF
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
	<title>$pageTittle</title>
	<link rel="stylesheet" type="text/css" href="css/printdoc-po.css">
</head>
<body onload="printDiv('printed_content')">

<div id="printed_content">
	<div id="wrapper">
	<!-- //========== Generic Model =========-->
	<div id="div_companyinfo">
	  <p id="div_companyinfo_name">$company</p>
	  <p id="div_companyinfo_address">$companyAddress</p>
	</div>
	<div id="div_doctittle">$docTittle</div>
	<div id="div_docsubtittle">$docSubTittle</div>
	<!-- //========== Generic Model =========-->
	$headTable
	$lineTable
	$notesTable
	$varSignTable

	<div class="paymentAndDeliveryTerm">
		<span>Payment & Delivery terms</span>
		<div class="paymentAndDeliveryTermContent">$paymentNdeliveryTerms</div>
	</div>

	<div class="newpage">
	$gatePassPage
	</div>


	</div> <!-- wrapper div end -->
</div>  <!-- print content div end -->

<script type="text/javascript">
function printDiv(divName) {
   var printContents = document.getElementById(divName).innerHTML;
   var originalContents = document.body.innerHTML;

   document.body.innerHTML = printContents;
   window.print();
   document.body.innerHTML = originalContents;
}
</script>
</body>
</html>
EOF;

	} 

	function getNotes_printFormat($docdefine, $printdocdefine){
		$doctype    = $_GET['doctype'];
		if ($doctype == 'PO' || $doctype == 'BOM' || $doctype == 'CP'){

			if ($printdocdefine['hasNotesTable']) {
			  	$varNotesTable = 
			  	'<div id="div_notes">
			      	<p>' . $printdocdefine['note'] . '</p>
			      	<table id="notestable">
			        	<tr>
			          		<td id="notestable_td2"><dt id="notes_dt2"><span></span></dt></td>
			          		<td id="notestable_td2"><dt id="notes_dt2"><span></span></dt></td>
			          		<td id="notestable_td2"><dt id="notes_dt2"><span></span></dt></td>
			          		<td id="notestable_td2"><dt id="notes_dt2"><span></span></dt></td>
			        	</tr>
			        	<tr>
			          		<td id="notestable_td2">Receiver Signature</td>
			          		<td id="notestable_td2">Security Incharge</td>
			          		<td id="notestable_td2">Store Officer</td>
			          		<td id="notestable_td2">Authorized Signature</td>
			        	</tr>
			     	</table>
			    </div>';
			} else {
			  $varNotesTable = "";
			}

			return $varNotesTable;
		}

	}




	public function getPaymentNdeliveryTerms_printFormat($itemcode){
		$conn = new ErpDbConn;
		$sql = "SELECT paymentterm, deliveryterm FROM erp_fabricmaterialline WHERE itemcode = '$itemcode'";
		$data = json_decode( $conn->sqlToJson($sql), true )[0];
		$conn->close();
		return $data['paymentterm'] . "\n" . $data['deliveryterm'];
	}



	public function getDefaultPrintFormat($docdata, $docdefine, $printdocdefine){
		$docdata = json_decode($docdata, true);
		$docdefine = json_decode($docdefine, true);
		$printdocdefine = json_decode($printdocdefine, true);

		$doclines = $docdata['lines'];
		unset($docdata['lines']);

		/**
		 * Decode company name 
		 * if company code have in doc data
		 */
		if(isset($docdata['company'])){
			$companyCode    = $docdata['company'];
			$pdmObj = new Pdm();
			$companyInfo = $pdmObj->getLibraryDescription('company', $companyCode);
			$companyInfo    = json_decode($companyInfo, true);
			$company = $companyInfo[0]['Description'];
			$companyAddress = $companyInfo[0]['Zone'];
		} else {
			$company = $printdocdefine['company'];
			$companyAddress = $printdocdefine['companyAddress'];
		}

		/**
		 * Process Barcode
		 * if need to print barcode
		 */
		if($printdocdefine['printBarcode']){
			$barcodeText = $docdata[$barcodeKey]; // barcodeKey = docnumber
			$barcode = $this->processBarcode($barcodeText);
			$docdata['barcode'] = $barcode;
		} else {
			$docdata['barcode'] = "";
		}

		/**
		 * Get head table
		 */
		$headTable = $this->getHeadTable_printFormat($docdata, $docdefine, $printdocdefine);
		/**
		 * Get line Table
		 */
		$lineTable = $this->getLineTable_printFormat($docdata, $doclines, $docdefine, $printdocdefine);
		/**
		 * Get notes Table
		 */		
		$notesTable = $this->getNotes_printFormat($docdefine, $printdocdefine);
		/**
		 * Get notes Table
		 */		
		$gatePassPage = $this->getGatePassPage_printFormat($company, $companyAddress, $docdata, $doclines, $docdefine, $printdocdefine);
		$paymentNdeliveryTerms = $this->getPaymentNdeliveryTerms_printFormat($doclines[0]['itemcode']);

		/**
		 * Process default print format
		 */
		$printParams = array();
		$printParams['pageTittle'] = $docdata['docnumber'];
		$printParams['company'] = $company;
		$printParams['companyAddress'] = $companyAddress;
		$printParams['docTittle'] = $docdefine['title'];
		$printParams['docSubTittle'] = $printdocdefine['subFormTittle'];
		if(!$printdocdefine['hasDocSubTittle']) $printParams['docSubTittle'] = '';
		$printParams['headTable'] = $headTable;
		$printParams['lineTable'] = $lineTable;
		$printParams['notesTable'] = $notesTable;
		$printParams['gatePassPage'] = $gatePassPage;
		$printParams['paymentNdeliveryTerms'] = $paymentNdeliveryTerms;
		$this->printParams = $printParams;
		return $this->printParams;

	}


	function getGarmentQty($powonumber) {
		$conn = new ErpDbConn;
		$sql = "SELECT ldcslnumber FROM erp_rrlines WHERE powonumber='$powonumber'";
		$result  = $conn->query($sql);

		$ldcslnumberArray = array();
		while($row = $result->fetch_assoc()){
			$ldcslnumber = $row['ldcslnumber'];

			$ldc = explode(',', $ldcslnumber);
			foreach ($ldc as $key => $value) {
				$ldcslnumberArray[] = $value;
			}
		}

		$ldcslnumberArray = array_unique($ldcslnumberArray);
		$ldcslnumberString = "'" . implode("','", $ldcslnumberArray) . "'";
		$sqlSUM = "SELECT SUM(pieceqty) AS pieceqty FROM erp_salesorderdeliveryline WHERE ldcslnumber IN($ldcslnumberString)";
		$result  = $conn->query($sqlSUM);
		
		$result = $result->fetch_assoc();
		$garmentqty = $result['pieceqty'];
		return $garmentqty;

	}

	function getHeadTable_printFormat($docdata, $docdefine, $printdocdefine){
		$varHeadTable = "";
		if ($printdocdefine['hasHeadTable']) {
		  	$headTableStructure = $printdocdefine['headertable'];
		  	$varHeadTable = "<table id='headTable'>";
		  	$varHeadTable .= "<tr>";
		  	$i = 1;

		  	//custom headtable push data
		  	$docdefine['header']['garmentqty']['fielddesc'] = 'Garments Qty Pcs';
		  	$garmentQty = $this->getGarmentQty($docdata['docnumber']);
		  	$docdata['garmentqty'] = $garmentQty;

		  	//             column      columnvalues
		  	foreach ($headTableStructure as $columnNo => $columnFields) {

		    	$varHeadTable .= "<td class='headTable_td' id='headTable_td" . $i . "'>";
		    	$varSubHeadTable = "<table id='subheadTable'><tr><td></td></tr>";
		    	$j = 1;
		    	foreach ($columnFields as $key => $keyField) {
		      		if (isset($docdefine['header'][$keyField]['fielddesc'])) {
		          		$varSubHeadTable .= "<tr>
		          								<td class='subheadTable_td' id='subheadTable_td" . $j . "'>" . $docdefine['header'][$keyField]['fielddesc'] . "</td>
		                                  		<td class='subheadTable_colon'>:</td>
		                                  		<td class='subheadTable_td' id='subheadTable_td" . ((int) $j + 1) . "'>" . $docdata[$keyField] . "</td>
		                                	</tr>";
		      		} else {     
		          		$varSubHeadTable .= "<tr>
		          								<td class='subheadTable_td' id='subheadTable_td" . $j . "'>" . $keyField . "</td>
		                                  		<td class='subheadTable_colon'>:</td>
		                                  		<td class='subheadTable_td' id='subheadTable_td" . ((int) $j + 1) . "'>" . $docdata[$keyField] . "</td>
		                                	</tr>";
		      		}
		    	}
		    	$varSubHeadTable .= "</table>";
		    	$varHeadTable .= $varSubHeadTable . "</td>";
		    	$i++;
		  	}

		  	$varHeadTable .= "</tr>";
		  	$varHeadTable .= "</table>";
		} else {
		  	$varHeadTable = "";
		}

		return $varHeadTable;

	}

	function getLineTable_printFormat($docdata, $doclines, $docdefine, $printdocdefine){
		$varLineTable = "";
		if ($printdocdefine['hasLineTable']) {
		  	$lineTableStructure = $printdocdefine['linetable'];

		  	$varLineTable = "<table class='print' id='linetable'>";
		  	$varLineTable .= "<thead>";
		  	$varLineTable .= "<tr>";

		  	//unset line status
		  	unset($lineTableStructure['linestatus']);

		  	foreach ($lineTableStructure as $columnKey => $columnFields) {
		    	$varLineTable .= "<th>" . $columnKey . "</th>";
		  	}
		  	$varLineTable .= "</thead>";
		  	$varLineTable .= "<tbody>";

		    //========= from data loop =========
		  	foreach ($doclines as $index => $linedata) {
		    	$i = 0;
		    	$varLineTable .= "<tr>";

		    	//cancel line not in print format
		    	if($linedata['linestatus'] == '9') continue;

		    	foreach ($lineTableStructure as $columnKey => $columnFields) {
			      	$i++;
			      	// if columnFields is array then break down			      	
			      	if(is_array($columnFields)){
				      	// break down td
				      	foreach ($columnFields as $key => $value) {

				        	if (isset($docdefine['lines'][$value]['fielddesc']) && $docdefine['lines'][$value]['fielddesc'] != "") {
				          		$colon = ":"; $pre1  = "<pre>"; $pre2  = "</pre>";
				          		$varLineTable .=   $pre1 . $docdefine['lines'][$value]['fielddesc'] . $colon  . $doclines[$index][$value] . $pre2;
				        	} else {
				          		$colon = ""; $pre1  = ""; $pre2  = "";
				          		$varLineTable .=   $pre1 . $value . $colon  . $doclines[$index][$value] . $pre2;
				        	}
				      	}

			      	} else {
			      		if($columnKey == "#"){
			      			$varLineTable .= ($columnKey == '#') ? "<td class='linetable_td' id='linetable_td" . $i . "'><div class='avoid'>" . sprintf("%03d", ($index + 1)) . "</td>" : "";
			      		} else {
      						$varLineTable .=  "<td class='linetable_td' id='linetable_td" . $i . "'>"  . $linedata[$columnFields] . "</td>";
			      		}
			      	}

			      	$varLineTable .= "";
		    	}
		    	$varLineTable .= "</tr>";
		  	}
		    //========= from data loop =========

			if ($printdocdefine['hasNetTotalTable']) {
				$netTotalTableStructure = $printdocdefine['nettolaltable'];
				$varLineTable .= 
				"<tr>
					<td colspan='7' class='nettotaltable_td' id='nettotaltable_td1'>Net Total</td>
					<td id='nettotaltable_td2'>" . $docdata[$netTotalTableStructure['totalgarmentqty']] .  "</td>
					<td id='nettotaltable_td3'>" . "" .  "</td>
					<td id='nettotaltable_td3'>" . $docdata[$netTotalTableStructure['totalcartonqty']] . "</td>
				</tr>";
			}

		  	$varLineTable .= "</tbody>";
		  	$varLineTable .= "</table>";
		} else {
		  	$varLineTable = "";
		}

		return $varLineTable;

	}



}

function getItemSpecifications($itemcode, $itemtype){
	$conn = new ErpDbConn;
	$libObj = new ErpLibraryDecoder();

	$itemSpecifications = array();

	$sqlFields = "SELECT * FROM mrd_itemtype_fields WHERE ItemType ='$itemtype' AND ItemCodePart!=0 AND DBField!='' ORDER BY Sequence";
	$fieldArray = array();
	$resultFields = $conn->query($sqlFields);
	while($row = $resultFields->fetch_assoc()){
		$fieldArray[] = $row['DBField'];
	}

	$selectFields = implode(',', $fieldArray);
	$sqlItemCodeFields = "SELECT $selectFields FROM mrd_item_codes WHERE itemcode = '$itemcode'";
	$resultFieldsValue = $conn->query($sqlItemCodeFields);
	$itemcodeStr = "";
	while($value = $resultFieldsValue->fetch_assoc()){
		if(isset($value['color'])){
			$colorName = $value['color'];
			$sql = "SELECT Code FROM erpprod.mrd_library_color WHERE ColorName='$colorName'";
			$colorNameResult = $conn->query($sql);
			$colorNameResult = $colorNameResult->fetch_assoc();

			$value['color'] = $colorNameResult['Code'];
		}
		$itemcodeStr = implode('-', $value);
	}

	$itemSpecifications['itemcodestr'] = $itemcodeStr;

	
	// $sql = "SELECT construction, composition, gsm, open_tube, color, yarncount, yarn_type, diameter, subcategory, numply, lengthandwidth FROM mrd_item_codes WHERE itemcode = '$itemcode'";
	$sql = "SELECT * FROM mrd_item_codes WHERE itemcode = '$itemcode'";
	$data = json_decode( $conn->sqlToJson($sql), true )[0];

	$itemSpecifications['construction'] = $libObj->libraryCodeToDescDecoder('construction', $data['construction']);
	$itemSpecifications['composition'] = $libObj->libraryCodeToDescDecoder('composition', $data['composition']);
	$itemSpecifications['gsm'] = $libObj->libraryCodeToDescDecoder('gsm', $data['gsm']);
	$itemSpecifications['gsm'] = $data['gsm'];
	$itemSpecifications['open_tube'] = $libObj->libraryCodeToDescDecoder('open_tube', $data['open_tube']);
	$itemSpecifications['color'] = $data['color'];
	$itemSpecifications['fabricdesigntype'] = $libObj->libraryCodeToDescDecoder('fabric_design_type', $data['fabricdesigntype']);
	// $itemSpecifications['iduom'] = $data['defaultiduom'];
	$itemSpecifications['fullfabricwidth'] = $libObj->libraryCodeToDescDecoder('diameter', $data['diameter']);
	$itemSpecifications['specialtreatment'] = $libObj->libraryCodeToDescDecoder('functional_properties', $data['specialtreatment']);
	$itemSpecifications['ytem'] = $libObj->libraryCodeToDescDecoder('ytem', $data['ytem']);
	$itemSpecifications['attachingmethod'] = $libObj->libraryCodeToDescDecoder('Bonding_Method', $data['attachingmethod']);
	$itemSpecifications['membranelamination'] = $libObj->libraryCodeToDescDecoder('Membrane_Name', $data['membranelamination']);
	$itemSpecifications['epi_ppi'] = $libObj->libraryCodeToDescDecoder('epixppi/warpxweft_count', $data['epi_ppi']);

	$itemSpecifications['subcategory'] = $libObj->libraryCodeToDescDecoder('cch_subcategory', $data['subcategory']);
	$itemSpecifications['numply'] = $libObj->libraryCodeToDescDecoder('numply', $data['numply']);
	$itemSpecifications['lengthandwidth'] = $libObj->libraryCodeToDescDecoder('lengthandwidth', $data['lengthandwidth']);
	
	$conn->close();
	return $itemSpecifications;

}

function getSalesOrderInformation($salesorder,$itemcode){
	$conn = new ErpDbConn;
	$libObj = new ErpLibraryDecoder();

	$salesorderinformation = array();
	
	$sql = "SELECT ldcslnumber FROM erp_garmentid WHERE docnumber IN (SELECT materiallistid FROM erp_fabricmaterialline WHERE materiallistid IN (SELECT docnumber FROM erp_garmentid WHERE ldcslnumber LIKE '$salesorder%') AND itemcode='$itemcode')";
	$result = $conn->query($sql);
	$array_ldcsl = array();
	while($row = $result->fetch_assoc()){
		$ldcslnumber = $row['ldcslnumber'];
		if(strpos($ldcslnumber,',')){
			
	        $range = explode(',', $ldcslnumber);
	        foreach ($range as $key => $value) {
	        	array_push($array_ldcsl, $value);
	        }
	    }
	    else{
	        array_push($array_ldcsl, $ldcslnumber);
	    }
	}
	$searchParam = "'" . implode("','", $array_ldcsl) . "'"; 

	$sql = "SELECT GROUP_CONCAT(distinct(buyerpo) SEPARATOR ',') AS buyerpo, GROUP_CONCAT(distinct(style) SEPARATOR ',') AS style FROM erp_salesorder where ldcslnumber IN($searchParam) group by docnumber;";
	$data = json_decode( $conn->sqlToJson($sql), true )[0];

	// $salesorderinformation['construction'] = $libObj->libraryCodeToDescDecoder('construction', $data['construction']);
	$salesorderinformation['endcustomerpono'] = $data['buyerpo'];
	$salesorderinformation['styleno'] = $data['style'];
	$conn->close();
	return $salesorderinformation;
}

function getMLInformation($salesorder,$itemcode){
	$conn = new ErpDbConn;
	$libObj = new ErpLibraryDecoder();

	$mlinformation = array();
	
	$sql = "SELECT * FROM erp_fabricmaterialline WHERE materiallistid IN(SELECT materiallistid FROM erp_salesorder WHERE docnumber = '$salesorder') AND itemcode='$itemcode'";
	$data = json_decode( $conn->sqlToJson($sql), true )[0];

	// $mlinformation['construction'] = $libObj->libraryCodeToDescDecoder('construction', $data['construction']);
	$mlinformation['developmentstatus']      = $data['developmentstatus'];
	$mlinformation['reffrompvsdevelopment']  = $data['reffrompvsdevelopment'];
	$mlinformation['swatchreference']        = $data['swatchreference'];
	$mlinformation['pricerequisitionnumber'] = $data['pricerequisitionnumber'];
	$mlinformation['currency']               = $data['currency'];
	$mlinformation['unitprice']              = $data['unitprice'];
	$mlinformation['yarnply']                = $data['yarnply'];
	$mlinformation['yarncount']              = $data['yarncount'];
	$mlinformation['yarnbrand']              = $data['yarnbrand'];
	$mlinformation['supplieryarncode']       = $data['supplieryarncode'];
	$mlinformation['cuttablewidth']          = $data['cuttablewidth'];
	$mlinformation['colorcategory']          = $data['colorcategory'];
	$mlinformation['instructionfortextile']  = $data['instructionfortextile'];
	$mlinformation['designid']  			 = $data['designid'];
	$conn->close();
	return $mlinformation;

}

function getSOInformation($rrnumber){
	$conn = new ErpDbConn;

	$soinfo = array();
	$sql = "SELECT salesorder FROM erp_rrlines WHERE rrnumber = '$rrnumber'";
	$salesorder = json_decode( $conn->sqlToJson($sql), true )[0]['salesorder'];

	$sql = "SELECT docdate, projectionorderrefno, season, formtype FROM erp_salesorder WHERE docnumber = '$salesorder'";
	$data = json_decode( $conn->sqlToJson($sql), true )[0];
	$soinfo['docdate'] = $data['docdate'];
	$soinfo['projectionorderrefno'] = $data['projectionorderrefno'];
	$soinfo['season'] = $data['season'];
	$soinfo['formtype'] = $data['formtype'];

	$conn->close();
	return $soinfo;
}
	
function getRRInformation($rrnumber){
	$conn = new ErpDbConn;

	$rrinfo = array();
	$sql = "SELECT * FROM erp_rrlines WHERE rrnumber = '$rrnumber'";
	$data = json_decode( $conn->sqlToJson($sql), true )[0];

	
	$rrinfo['requirednetqty'] = $data['requirednetqty'];
	$rrinfo['iduom']          = $data['iduom'];
	$rrinfo['dlvbrktext']     = $data['dlvbrktext'];

	$conn->close();
	return $rrinfo;
}
	




/*
 * Check if we have docnumber
 */
if (!isset($_GET['doctype']) || !isset($_GET['docnumber'])) {
  die("doctype and iddocument required");
}
$docnumber = $_GET['docnumber'];

amendent:
$doctype    = $_GET['doctype'];
$formtype = (isset($_GET['formtype'])) ? $_GET['formtype'] : "";

/*
 * Get json data for this document and decode
 */
$printDocObj = new PrintDoc($doctype, $formtype);
$docdefine = $printDocObj->docdefine;
$docdata = $printDocObj->_readDoc($docnumber, $docdefine);
// echo $docdata;
$docdata  = json_decode($docdata, true);
$formtype = $docdata['formtype'];
$previousPONumber = $docdata['previousponumber'];

/**
 * Update docdefine by formtype
 */
$printDocObj = new PrintDoc($doctype, $formtype);
// customize
$docdefine = $printDocObj->docdefine;
$docdefine = json_decode($docdefine, true);
$docdefine['header']['docnumber']['fielddesc'] = 'PO Number';
$docdefine['header']['formtype']['fielddesc'] = 'PO Type';
$docdefine['header']['orderplacingdate']['fielddesc'] = 'Order Placement Date';
$docdefine['header']['orderreferenceno']['fielddesc'] = 'Order Reference No.';
$docdefine['header']['season']['fielddesc'] = 'Season/Program';
$docdefine['header']['requestor']['fielddesc'] = 'Requestor';
$docdefine = json_encode($docdefine);
$printDocObj->docdefine = $docdefine;

/*
 * include printdocdefine file
 */
require_once 'printdocdefine-po.php';
$printdocdefine = printdocdefine($doctype, $formtype);

/**
 * Passing json data
 */

// load SO info
$rrnumber = $docdata['lines'][0]['rrnumber'];
$soinfo = getSOInformation($rrnumber);
// $docdata['orderplacingdate'] = $soinfo['docdate'];
$docdata['orderreferenceno'] = $soinfo['projectionorderrefno'];
$docdata['season'] = $soinfo['season'];
$docdata['salesordertype'] = $soinfo['formtype'];

$libObj = new ErpLibraryDecoder();
$docdata['company'] = $libObj->libraryCodeToDescDecoder('Company', $docdata['company']);
$docdata['endcustomer'] = $libObj->libraryCodeToDescDecoder('Buyer', $docdata['endcustomer']);

// load some specification form itemcode table 
$doclines = $docdata['lines'];
unset($docdata['lines']);

$newdoclines = array();
foreach ($doclines as $index => $curline) {
	$newline = $curline;

	// $itemcode   = $curline['itemcode'];
	// $itemtype   = $curline['itemtype'];
	// $salesorder = $curline['salesorder'];
	// $rrnumber   = $curline['rrnumber'];

	// $salesOrderInformation = getSalesOrderInformation($salesorder,$itemcode);
	// $newline['endcustomerpono'] = $salesOrderInformation['endcustomerpono'];
	// $newline['styleno'] = $salesOrderInformation['styleno'];
	
	// $rrInformation                      = getRRInformation($rrnumber);
	// $newline['requirednetqty']          = $rrInformation['requirednetqty'];
	// // $newline['iduom']                   = $rrInformation['iduom'];
	// $newline['dlvbrktext']              = $rrInformation['dlvbrktext'];
	
	// $mlInformation                      = getMLInformation($salesorder,$itemcode);
	// $newline['developmentstatus']       = $mlInformation['developmentstatus'];
	// $newline['reffrompvsdevelopment']   = $mlInformation['reffrompvsdevelopment'];
	// $newline['swatchreference']         = $mlInformation['swatchreference'];
	// $newline['pricerequisitionnumber']  = $mlInformation['pricerequisitionnumber'];
	// $newline['currency']                = $mlInformation['currency'];
	// $newline['unitprice']               = $mlInformation['unitprice'];
	// $newline['supplierreferencenumber'] = $mlInformation['supplierreferencenumber'];
	// $newline['yarnply']                 = $mlInformation['yarnply'];
	// $newline['yarncount']               = $mlInformation['yarncount'];
	// $newline['yarnbrand']               = $mlInformation['yarnbrand'];
	// $newline['supplieryarncode']        = $mlInformation['supplieryarncode'];
	// $newline['cuttablewidth']           = $mlInformation['cuttablewidth'];
	// $newline['colorcategory']           = $mlInformation['colorcategory'];
	// $newline['instructionfortextile']   = $mlInformation['instructionfortextile'];
	// $newline['designid']   				= $mlInformation['designid'];

	// $itemSpecifications             = getItemSpecifications($itemcode, $itemtype);
	// $newline['construction']        = $itemSpecifications['construction'];
	// $newline['composition']         = $itemSpecifications['composition'];
	// $newline['gsm']                 = $itemSpecifications['gsm'];
	// $newline['openortube']          = $itemSpecifications['open_tube'];
	// $newline['color']               = $itemSpecifications['color'];
	// $newline['fabricdesigntype']    = $itemSpecifications['fabricdesigntype'];
	// // $newline['iduom']               = $itemSpecifications['iduom'];
	// $newline['fullfabricwidth']     = $itemSpecifications['fullfabricwidth'];
	// $newline['functinalproperties'] = $itemSpecifications['specialtreatment'];
	// $newline['ytem']				= $itemSpecifications['ytem'];
	// $newline['attachingmethod']		= $itemSpecifications['attachingmethod'];
	// $newline['membranelamination']	= $itemSpecifications['membranelamination'];
	// $newline['epi_ppi']				= $itemSpecifications['epi_ppi'];
	// $newline['subcategory']			= $itemSpecifications['subcategory'];
	// $newline['numply']				= $itemSpecifications['numply'];
	// $newline['lengthandwidth']		= $itemSpecifications['lengthandwidth'];
	// $newline['itemcodestr']         = $itemSpecifications['itemcodestr'];
	array_push($newdoclines, $newline);
}

$docdata['lines'] = $newdoclines;

$docdata = json_encode($docdata);
$printdocdefine = json_encode($printdocdefine);

// 1. Get default print format by using getDefaultPrintFormat function
// 2. Print page by using printPage

// 1. Get default print format by using getDefaultPrintFormat function
$printParams = $printDocObj->getDefaultPrintFormat($docdata, $docdefine, $printdocdefine);
// 2. Print page by using printPage
$printDocObj->printPage($printParams);

if($previousPONumber != ''){
	$docnumber = $previousPONumber;
	goto amendent;
}
?>