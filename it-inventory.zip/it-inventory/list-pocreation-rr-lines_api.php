<?php
session_start();
$directory = __DIR__ ;
require_once $_SERVER["DOCUMENT_ROOT"] . '/includes/configli.php';         // mysql connections
require_once __DIR__ . "/classes/myclassautoloader.php";
/**
* ThisListAPI class
*/
class ThisListAPI
{	
	public $conn;
	public $queryResult;
	public $sql;
	public $dbname;

	public $rrstatusTransaltor = array(
		'0' => 'New',
		'1' => 'Allocated',
		'2' => 'Sent for Recalculation',
		'3' => 'PO Created',
		'4' => 'PO Sent (Executed)',		
		'5' => 'WO Created',
		'6' => 'WO Sent (Executed)',
		'7' => 'Partially Consumed',
		'8' => 'Consumed',
		'9' => 'Closed',
		'10' => 'Frozen',
		'11' => 'Cancelled',
	);

	public function __construct($dbnum = 1) {
		if ($dbnum === '2') {
			$this->conn = new ErpDbConn('2');
			$this->dbname = "erpprod_bulbul";
		} else {
			$this->conn = new ErpDbConn;
			$this->dbname = "erpprod";
		}
	}

	function getListData($params) {

		$fieldArray = array(
			'idlines'                      => '`rr`.`idlines`',
			'rrnumber'                     => '`rr`.`rrnumber`',
			'rrtype'                       => '`rr`.`rrtype`',
			'rrstatus'                     => '`rr`.`rrstatus`',
			'parentrrnumber'               => '`rr`.`parentrrnumber`',
			'powonumber'                   => '`rr`.`powonumber`',
			'company'                      => '`rr`.`company`',
			'endcustomer'                  => '`rr`.`endcustomer`',
			'itemtype'                     => '`rr`.`itemtype`',
			'itemcode'                     => '`rr`.`itemcode`',
			'itemdescription'              => '`rr`.`itemdescription`',
			'requiredgrossqty'             => '`rr`.`requiredgrossqty`',
			
			'allocatedqty'                 => '`rr`.`allocatedqty`',
			'actualdeductionqty'           => '`rr`.`actualdeductionqty`',
			'requirednetqty'               => '`rr`.`requirednetqty`',
			
			'iduom'                        => '`rr`.`iduom`',
			'sewingstartdate'              => '`rr`.`sewingstartdate`',
			'sewingfinisheddate'           => '`rr`.`sewingfinisheddate`',
			'sewingperiod'                 => '`rr`.`sewingperiod`',
			'fabricusageperday'            => '`rr`.`fabricusageperday`',
			'processbeforesewing'          => '`rr`.`processbeforesewing`',
			'processaftersewing'           => '`rr`.`processaftersewing`',
			'fabricinhousedate'            => '`rr`.`fabricinhousedate`',
			'salesorder'                   => '`rr`.`salesorder`',
			'ldcslnumber'                  => '`rr`.`ldcslnumber`',
			'salesorderdeliverylinenumber' => '`rr`.`salesorderdeliverylinenumber`',
					
			'bomdocnumber'                 => '`rr`.`bomdocnumber`',
			'bomlinenumber'                => '`rr`.`bomlinenumber`',
			'cpdocnumber'                  => '`rr`.`cpdocnumber`',
			'isrrfreezed'                  => '`rr`.`isrrfreezed`',
		);
		$groupArray = array(
			'idlines'       => 'idlines',
		);
		$whereClauses = array(
			"(1=1)",
			"((`rr`.`rrstatus` = '1' AND `rr`.`linestatus` = '1') OR (`rr`.`rrstatus` = '3' AND `rr`.`linestatus` = '1'))",
		);		

		//filtering rrtype
		if($params['rrtype'] == 'Direct'){
			array_push($whereClauses, "(`rr`.`rrtype`='Direct')");
		}else{
			array_push($whereClauses, "(`rr`.`rrtype` IN ('Projection','Confirmed'))");
		}
		
		// Process field clause
		$fieldClause = array();
		foreach ($fieldArray as $fieldKey => $fieldValue) {
			array_push($fieldClause, $fieldValue . ' AS `' . $fieldKey . '`');
		}
		$fieldClause = implode(' , ', $fieldClause);

		// Process group clause
		$groupClause = array();
		foreach ($groupArray as $groupField) {
			array_push($groupClause, $fieldArray[$groupField]);
		}
		$groupClause = implode(' , ', $groupClause);

		// Process where clause
		$searchParams = $params;
		unset($searchParams['docnumber']);
		unset($searchParams['doctype']);
		unset($searchParams['formtype']);
		unset($searchParams['docviewflag']);
		unset($searchParams['autoLineFill_Save_Edit']);
		
		unset($searchParams['showLimit']);
		unset($searchParams['pageNum']);
		unset($searchParams['reqType']);		
		unset($searchParams['output']);		
		unset($searchParams['print']);		
		unset($searchParams['_']);		
		if (isset($searchParams) && count($searchParams) > 0) {
			foreach ($searchParams as $paramkey => $paramvalue) {
				if($paramvalue == "") unset($searchParams[$paramkey]);
			}
            foreach ($searchParams as $paramkey => $paramvalue) {
              // $compositeClauses = array("1=1",);
              $compositeClauses = array();
              $compositeParamkey = explode("__", $paramkey);
              $compositeParamVal = explode(",__", $paramvalue);

              if(sizeof($compositeParamkey) > 1 && sizeof($compositeParamVal) > 1 ){
                foreach ($compositeParamkey as $key => $fieldname) {
                	$fieldvalue = $compositeParamVal[$key];
                	if($fieldvalue == ""){
                		continue;
                	} else if(strpos($fieldvalue, '_to_') !== false){
						$from_to_dates = explode('_to_', $fieldvalue);
						$form_date = $from_to_dates[0];
						$to_date = $from_to_dates[1];
						array_push($compositeClauses, "( $fieldArray[$fieldname] BETWEEN '$form_date' AND '$to_date')");
	                } else {
	                  	array_push($compositeClauses, "( $fieldArray[$fieldname] LIKE '%" . $fieldvalue. "%')");
	                }  	
                }
                $compositeClause = '(' . implode(' AND ', $compositeClauses) .')';
                array_push($whereClauses, $compositeClause);

              } else if(sizeof($compositeParamkey) > 1){
                foreach ($compositeParamkey as $key => $fieldname) {
                  array_push($compositeClauses, "( $fieldArray[$fieldname] LIKE '%" . $paramvalue . "%')");
                }
                $compositeClause = '(' . implode(' OR ', $compositeClauses) . ')';
                array_push($whereClauses, $compositeClause);

              } else{
              	if(strpos($paramvalue, '_to_') !== false){ // date field search
              		$from_to_dates = explode('_to_', $paramvalue);
              		$form_date = $from_to_dates[0];
              		$to_date = $from_to_dates[1];
              		array_push($whereClauses, "( $fieldArray[$paramkey] BETWEEN '$form_date' AND '$to_date')");
              	} else {									 // normal field search
              		array_push($whereClauses, "( $fieldArray[$paramkey] LIKE '%" . $paramvalue . "%')");
              	}
              }
            }
		}
		$whereClause = implode(' AND ', $whereClauses);


  		$sql = <<<EOF
SELECT
  $fieldClause
FROM
  `erp_rrlines` `rr`
WHERE $whereClause
EOF;
// return $sql;

		/**
		 * Pagination work
		 * Very important to set the page number first.
		 */
		$pageNum = (!isset($params['pageNum'])) ? 1 : intval($params['pageNum']);
		/**
		 * Number of results displayed per page 	by default its 10.
		 */
		$showLimit =  ($params["showLimit"] <> "" && is_numeric($params["showLimit"]) ) ? intval($params["showLimit"]) : 10;

		/**
		 * Get the total number of rows in the table
		 */
		$countSql = $sql ;
		// $queryResult = $this->conn->query($countSql);
		// $queryRowsNum = $queryResult->num_rows;
		// -------- Count row sql prepare
		// 1. Plain SQL 
		// $countSql = "SELECT COUNT(*)  FROM " . strstr($countSql, 'FROM'); 
		//***We use it plain SQL//But we can not use it because in select clause can have subquery

		// 2. Can have sub query in select tag
		$tableParts = explode("\r\n", $countSql);
		$countSql = "";
		foreach ($tableParts as $indx => $part) {
			if($indx == 0 || $indx == 1) continue;
			$countSql .= $part;
		}
		$countSql =  "SELECT COUNT(*) AS numrows " . $countSql;

		// $countSql = "SELECT COUNT(*) AS numrows FROM (" . $countSql . ") AS ct";
		// return $countSql;
		// $countSql = substr($countSql, 0, stripos($countSql,'GROUP BY'));
		// -------- Count row sql prepare end
		$queryResult = $this->conn->query($countSql);
		$queryRowsNum = $queryResult->fetch_assoc()['numrows'];	

		
		/**
	    * if no record found then, apply
	    */
	    if($queryRowsNum == 0){
		   $tableParts = explode("\r\n", $sql);
		   $mainTableName = $tableParts[3];

		   $tableParts = explode("WHERE", $sql);
		   $joinedSql = substr($sql, 0,strripos($sql, 'WHERE'));
		   // $joinedSql = $tableParts[0] . $tableParts[1] . $tableParts[2] . $tableParts[3];
		   $maxidSql= "SELECT @last_id := MAX(idlines) FROM $mainTableName";
		   $fakeSql = "$joinedSql WHERE idlines = @last_id"; 
		   $this->conn->query($maxidSql);
		   $queryResult = $this->conn->query($fakeSql);
		   // echo "maxidSql -- " . $maxidSql . "<br/><br/> fakeSql -- " . $fakeSql;
		   $data = array();
			while ( $rows = $queryResult->fetch_assoc() ) {
			  array_push($data, $rows);
			}

			$returnJson = "";
			$returnArray = array();
			$returnArray['listData']     = $data;
			$returnArray['noResult']     = true;
			$returnArray['queryRowsNum'] = $queryRowsNum;
			$returnArray['showLimit']    = $showLimit; // per page limit
			$returnArray['pageNum']      = 0;
			$returnArray['lastPageNum']  = 0;
			$returnJson = json_encode($returnArray);
			return $returnJson;
		}

		/**
		 * Calculate the lastPageNum page based on total number of rows and rows per page. 
		 */
		$lastPageNum = ceil($queryRowsNum/$showLimit); 

		/**
		 * this makes sure the page number isn't below one, or more than our maximum pages 
		 */
		if ($pageNum < 1) { 
		  $pageNum = 1; 
		} elseif ($pageNum > $lastPageNum)  { 
		  $pageNum = $lastPageNum; 
		}
		$lowerLimit = ($pageNum - 1) * $showLimit;

		// $sql2 = " SELECT * FROM tbl_pagination WHERE 1 LIMIT ". ($lowerLimit)." ,  ". ($showLimit). " ";
		$sql = $sql . " LIMIT ". ($lowerLimit)." ,  ". ($showLimit). " ";

		$queryResult = $this->conn->query($sql);
		$lnddcObj = new ErpLibraryDecoder();
		$data = array();
		while ( $rows = $queryResult->fetch_assoc() ) {
			$rows['rrstatus'] = $this->rrstatusTransaltor[$rows['rrstatus']];
			// libray data decoder start
			$company = $rows['company'];
			$customer = $rows['customer'];
			$endcustomer = $rows['endcustomer'];

			$rows['company'] = $lnddcObj->libraryCodeToDescDecoder('company', $company);
			$rows['customer'] = $lnddcObj->libraryCodeToDescDecoder('Buyer', $customer);
			$rows['endcustomer'] = $lnddcObj->libraryCodeToDescDecoder('Buyer', $endcustomer);
			// libray data decoder end		
			array_push($data, $rows);
		}


		if (isset($params['output']) && $params['output'] == 'table') {
		return '<html><head>
		  <style type="text/css">
		  /*keep html line-breaks within one cell*/
		  br {
		      mso-data-placement:same-cell;
		  }
		  body {
		      font-family : monospace;
		      font-size : small;
		  }
		  table {
		      border: solid 1px;
		      border-collapse: collapse;
		  }
		  td {
		      border : solid 1px;
		      border-color : lightgray;
		  }
		  </style>
		</head><body>' . $this->conn->sqlToTable($sql) . '</body></html>';
		$this->conn->close();
		} else if (isset($params['print']) && $params['print'] == 'sql'){
			echo $sql;
		} else {

			$returnJson = "";
			$returnArray = array();

			$returnArray['listData']     = $data;
			$returnArray['noResult']     = false;
			$returnArray['queryRowsNum'] = $queryRowsNum;
			$returnArray['showLimit']    = $showLimit; // per page limit
			$returnArray['pageNum']      = $pageNum;
			$returnArray['lastPageNum']  = $lastPageNum;

			$returnJson = json_encode($returnArray);
			$this->conn->close();
			return $returnJson;

		}


	}

	function sendtoAllocatedRR($data){
		$returnJson = new stdClass();

		$data    = json_decode($data, true);
		$idlines = $data['idlines'];
		$idline  = "'" . implode("','",$idlines) . "'";

		$sql         = "UPDATE erp_rrlines SET linestatus = '0', rrstatus = '1', powonumber = ''  WHERE idlines IN($idline)";
		$queryResult = $this->conn->query($sql);

		if($queryResult){
			$returnJson->result = 'success';
		} else {
			$returnJson->result = 'fail';
		}
		$this->conn->close();
		return json_encode($returnJson);

	}	

/**
 * [isAllRRCheckedInSameItemcodeAndSOLine description]
 * @param  [json]  $data [selected rr lines]
 * @return json object [if all rrlines select in same ldcslnumber and item code then return success else return fail with remaining RR]
 */
	function isAllRRCheckedInSameItemcodeAndSOLine($data){
		$returnJson = new stdClass();

		$data    = json_decode($data, true);
		$rrlines = $data['rrlines'];

		$rrnumbers = $rrlines['rrnumber'];
		$itemcodes = $rrlines['itemcode'];
		$ldcslnumbers = $rrlines['ldcslnumber'];

		$noOfLinesInDB = array();
		$checkArray = array();
		foreach ($rrnumbers as $key => $value) {
			$itemcode    = $itemcodes[$key];
			$ldcslnumber = $ldcslnumbers[$key];

			$identifier = $itemcode. "-" .$ldcslnumber;

			if(array_key_exists($identifier, $checkArray)){
				$values = $checkArray[$identifier]['sysrrnumber'];
				array_push($values, $value);
				$checkArray[$identifier]['sysrrnumber'] =  $values ;
			}else{
				$values = array();
				array_push($values, $value);
				$checkArray[$identifier]['sysrrnumber'] =  $values ;
			}
			
		}		

		$dbCheckArray = array();
		foreach ($rrnumbers as $key => $value) {
			$itemcode    = $itemcodes[$key];
			$ldcslnumber = $ldcslnumbers[$key];

			$identifier = $itemcode. "-" .$ldcslnumber;

			if(array_key_exists($identifier, $dbCheckArray)){

			}else{
				$sql = "SELECT rrnumber FROM erp_rrlines WHERE rrstatus='1' AND linestatus='1' AND itemcode='$itemcode' AND ldcslnumber='$ldcslnumber'";
				$queryResult = $this->conn->query($sql);
				$rrnumbers = array();
				while($row = $queryResult->fetch_assoc()){
					$rrnumbers[] = $row[rrnumber];
				}

				$checkArray[$identifier]['dbrrnumber']  =  $rrnumbers ;
				$checkArray[$identifier]['itemcode']    =  $itemcode ;
				$checkArray[$identifier]['ldcslnumber'] =  $ldcslnumber ;

				//data insert only for check
				$dbCheckArray[$identifier] = $rrnumbers ;
			}
			
		}

		$failArray = array();
		$failItemcode = array();
		$failLdcslnumber = array();
		foreach ($checkArray as $key => $value) {
			$sysrrnumber = $checkArray[$key]['sysrrnumber'];
			$dbrrnumber  = $checkArray[$key]['dbrrnumber'];

			$arrayDiff = array_diff($dbrrnumber, $sysrrnumber);

			$arrayDiff = array_values($arrayDiff);
			$rrString = implode(",", $arrayDiff);

			if($rrString != ""){
				$failArray[] = $rrString;
				$failItemcode[] = $itemcode;
				$failLdcslnumber[] = $ldcslnumber;
			}
			
		}

		if(sizeof($failArray) > 0){
			$returnJson->result = 'fail';
			$returnJson->rr = $failArray;
			$returnJson->itemcode = $failItemcode;
			$returnJson->ldcslnumber = $failLdcslnumber;
		}else{
			$returnJson->result = 'success';
		}

		return json_encode($returnJson);

	}


	function getBlanketPO($searchParams){
	    $conn = new ErpDbConn;
	  
	    $rrnumber = $searchParams['rrnumber'];
	    $sql = "SELECT * FROM erp_rrlines WHERE rrnumber IN(SELECT parentrrnumber FROM erp_rrlines WHERE rrnumber='$rrnumber')";

	   	$result =  $conn->sqlToJson($sql);
	    $conn->close();

	   	return $result;

	}		


}


/**
 * Routing ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 */
if ( basename(__FILE__) == basename($_SERVER["SCRIPT_FILENAME"]) ) {
    // called directly
	if ( $_SERVER['REQUEST_METHOD'] == 'GET' ) {

		if(isset($_GET['reqType'])){

			$reqType = $_GET['reqType'];
			$listObj  = new ThisListAPI();

			if($reqType == 'getListData') {
				$params = $_GET;
				$returnData = $listObj->getListData($params);
				echo $returnData;
			}


			if($reqType == 'getBlanketPO') {

				$returnData = $listObj->getBlanketPO($_GET);
				echo $returnData;

			}

		}


	} else if( $_SERVER['REQUEST_METHOD'] == 'POST' ){
	
		if(isset($_POST['reqType'])){

			$reqType = $_POST['reqType'];
			$listObj  = new ThisListAPI();

			if($reqType == "saveDoc"){

				$docobj = $_POST['docobj'];
				$returnData = $listObj->saveDoc($docobj);
				echo $returnData;
			}

			if($reqType == "sendtoAllocatedRR"){

				$data = $_POST['data'];
				$returnData = $listObj->sendtoAllocatedRR($data);
				echo $returnData;
			}

			if($reqType == "isAllRRCheckedInSameItemcodeAndSOLine"){

				$data = $_POST['data'];
				$returnData = $listObj->isAllRRCheckedInSameItemcodeAndSOLine($data);
				echo $returnData;
			}


		}


	}

} else {
    // included/required

}
?>