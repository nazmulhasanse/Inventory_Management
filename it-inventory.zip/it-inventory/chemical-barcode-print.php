<?php
require_once $_SERVER["DOCUMENT_ROOT"] . '/includes/user.cookies.php';    // check user login
require_once $_SERVER["DOCUMENT_ROOT"] . '/includes/config.php';          // mysql connections
require_once $_SERVER["DOCUMENT_ROOT"] . '/includes/user-privilege.php';  // privilege function
// check privilege (keep module and section empty to skip privilege check)
$module = "";
$section = "";
$privilege = userPrivileges($module, $section);
if (!$privilege['R']) { header("Location: ../user/no-permission.php"); exit();}


$formTitle = 'Chemical Barcode Print';
$pageTittle= 'Chemical Barcode Print';
// $mainHTML  = 'html/listerp.html';
// $mainJS    = 'js/list-fabric-swatch.js';
// $customJS  = 'js/list-fabric-swatch-customization.js';
$apiURL    = 'list-fabric-swatch_api.php';
$formId    = 'searchForm';

$module = "";
$section = "";
$privilege_sm = json_encode(userPrivileges($module,$section));

$upperBtn = '<div id="upperButtonBar" style="height:50px;">';
$upperBtn .='</div>';

$formTitle= "Chemical Barcode Print";

if(isset($_GET['itemlot']) && $_GET['itemlot'] !=''){
	$itemlot = $_GET['itemlot'];
}else{
	$itemlot = '';
}



?>

<!DOCTYPE HTML>
<html>
<head>
	<?php require_once($_SERVER["DOCUMENT_ROOT"] . "/includes/head.php") ;?>
	<title><?php echo $formTitle;?></title>
	<link rel="stylesheet" type="text/css" href="css/listerp.css">
	<link rel="stylesheet" type="text/css" href="css/list-ma.css">
	<link rel="stylesheet" type="text/css" href="css/material-button.css">
</head>
<body class="right-sidebar">

<!-- Header Wrapper -->
<div id="header-wrapper">
<div class="container">
<div class="row">
<div class="12u">
<!-- Header -->
	<header id="header">
		<?php 
		include_once($_SERVER["DOCUMENT_ROOT"] . "/includes/mainmenu.php");
		?>
	</header>
</div>
</div>
</div>
</div>

<!-- Main Wrapper -->
<div id="main-wrapper">
<div class="container">
<div class="row">
	<div class="12u skel-cell-important">
        <!-- Content -->
        <div id="content">
        <article class="last">
    <!-- HEADLINES -->
    	<div class="headline1"><a href="documents-home.php">Home</a></div> &nbsp;&nbsp;|
        <div class="headline2"><?php echo $formTitle;?></div> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<!-- LINKS -->
        <br><br><br>

<div id="upperButtonBar" style="height:50px;">

	<div id="listSuccessWarningErrorDiv">
		<div id="listInfoDiv"><i class="material-icons">info</i><span id="listInfoMsg"></span><span class="close" onclick="closeISWEMsg(this)"><i class="material-icons">clear</i></span></div>
		<div id="listSuccessDiv"><i class="material-icons">done</i><span id="listSuccessMsg"></span><span class="close" onclick="closeISWEMsg(this)"><i class="material-icons">clear</i></span></div>
		<div id="listWarningDiv"><i class="material-icons">warning</i><span id="listWarningMsg"></span><span class="close" onclick="closeISWEMsg(this)"><i class="material-icons">clear</i></span></div>
		<div id="listErrorDiv"><i class="material-icons">clear</i><span id="listErrorMsg"></span><span class="close" onclick="closeISWEMsg(this)">&times;</span></div>
	</div>
</div>
<!-- PAGE CONTENTS -->
<?php
include $mainHTML;
?>
		<form id="barcodePrint">
			<table class="no_border">
				<tbody>
					<tr><th>Internal Lot</th><td>:</td><td><input id="itemlot"></td></tr>
					<tr><th>IP Address</th><td>:</td><td><input id="ipaddress"></td></tr>
					<tr><th>Quantity of labels to print</th><td>:</td><td><input id="printcopies"></td></tr>
					<tr><td></td><td></td><td><input type="button" class="btn-blue" value="Print" title="Print Sample Barcode" id="btnBarcodePrint" style="display: inline-block;"></td></tr>
				</tbody>
			</table>
		</form>
		</article>
		</div>
	</div>

</div>
</div>
</div>

<style type="text/css">
</style>

<!-- Footer Wrapper -->
<div id="footer-wrapper">
	<?php include_once($_SERVER["DOCUMENT_ROOT"] . "/includes/footer.php") ;?>
</div>
<script type="text/javascript" src="/js/fancybox/jquery.fancybox.js"></script>
<script type="text/javascript" src="api/client_api.js"></script>
<!-- <script type="text/javascript" src="<?php echo $mainJS.'?t=' .time(); ?>"></script>	 -->
<!-- <script type="text/javascript" src="<?php echo $customJS .'?t='. time(); ?>"></script>	 -->
<script type="text/javascript">

function closeISWEMsg(thisf){
  var parentId = $(thisf).parent().attr('id');
  $(thisf).closest('div').css({'display':'none'});
  $(thisf).closest('div').find('#listSuccessMsg').text('');
}

$(document).ready(function() {


function printLabel(){
  $('#barcodePrint').find('#ipaddress').val("10.1.24.90");
  $('#barcodePrint').find('#printcopies').val("1");
  $('#barcodePrint').find('#itemlot').val(<?php echo $itemlot; ?>);


  $('#btnBarcodePrint').click(function(){
    var ipaddress = $('#barcodePrint #ipaddress').val();
  	var itemlot = $('#barcodePrint #itemlot').val();
  	var printcopies = $('#barcodePrint #printcopies').val();
    var passParams = {};
    passParams['itemlot'] = itemlot;
    passParams['ipaddress'] = ipaddress;
    passParams['printcopies'] = printcopies;

    $.ajax({
      type: "GET",
      url: '/labeling/chemicalbarcode_print.php',
      data: passParams,
      success: function() {
      	var cloneDiv = $('#listSuccessDiv').clone();
        cloneDiv.css({'display':'block'})
          .insertBefore('#listSuccessDiv')
          .find('#listSuccessMsg').text('Chemical Barcode Printed');
      }
    });

  });

}

printLabel();
});	
</script>
</body>
</html>