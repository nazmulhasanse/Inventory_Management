<?php
/*
* Define printdoc header
* Define printdoc lines
* Define printdoc NB
* Define printdoc signature
* Define printdoc gatepass
*/
function printdocdefine($doctype , $formtype) {	

	if ($doctype == 'MX') {

		$printdocheader = array(
			1 => array( 'docnumber', 'docdate'),
			2 => array( 'vehicleno', 'lockno'),
			3 => array( 'drivername', 'drivermobileno'),
		);

		$printdoclines = array(
			'#'          => 'serialno',
			'Item'       => array( 'itemcode' , 'itemdescription'),
			'References' => array( 'itemlot', 'trackingno'),
			'Qty'        => array( 'totallotqty', 'iduom'),
		);

		$printdoclines = array(
			'#'         => 'serialno',
			'Item Type' => 'itemtype',
			'Item Code' => 'itemcode',
			'Item Lot'  => 'itemlot',
			'Serial'    => 'serial',
			'Quantity'  => 'tnxquantity',
			'Size'      => 'size',
		);

		$printgatepass = array(
			'#'         => 'serialno',
			'Item Type' => 'itemtype',
			'Item Code' => 'itemcode',
			'Item Lot'  => 'itemlot',
			'Serial'    => 'serial',
			'Quantity'  => 'tnxquantity',
			'Size'      => 'size',
			'Remarks'   => ''

		);

		$printsignature = array('Receiver Signature', 'Security Incharge', 'Store Officer', 'Authorized Signature');
		$nettotalline = array("total"=>"total", "totalgarmentqty" => "totalgarmentqty", "totalcartonqty" => "totalcartonqty");




		//------------ variation based on form type
		$formtittle = "Goods Delivery Notes";
		$subFormTittle = "Default";	
		switch ($formtype) {
			case 'export':
				$subFormTittle = "For: Export";	
				break;
			case 'wms_issuetodepartment':
				$subFormTittle = "issue to department";	
				break;					
			default:
				break;
		}

		$printFormatStructure = array(
			'formTittle'       => $formtittle,
			'hasDocSubTittle'  => true,
			'subFormTittle'    => $subFormTittle,
			'hasHeadTable'     => true,
			'hasLineTable'     => true,
			'hasNetTotalTable' => true,
			'hasNotesTable'    => true,
			'note' 			   => 'N.B: Please receive the above goods in proper condition and sign the duplicate copy and return',
			'hasSignTable'     => true,
			'hasGatePassTable' => true,
 			'headertable'      => $printdocheader1,
			'linetable'        => $printdoclines,
			'nettolaltable'    => $nettotalline,
			'gatepasstable'    => $printgatepass,
			'signaturetable'   => $printsignature

		);	
		return $printFormatStructure;

	} else if($doctype == 'TI' && $formtype == 'TI'){

		$printdocheader = array(
			1 => array( 'section', 'department', 'contactnumber'),
			2 => array( 'name', 'employeeid', 'designation'),
			3 => array( 'domainid', 'username', 'useremail'),
		);

		$printdoclines =  array(
			'Inventory ID'  => 'inventoryid',
			'Serial No.'    => 'serialnumber',
			'PC Type'       => 'laptopordesktop',
			'Purchase Date' => 'purchasedate',
			'Brand'         => 'brand',
			'Model'         => 'model',
			'Hard Disk'     => 'hdd',
			'Processor'     => 'processor',
			'RAM'           => 'ram',
			'Remarks'       => 'remarks',
		);


		$formtittle = "ICT Inventory";

		$terms = "<b>Terms & Conditions:</b> The IT department must ensure and enforce to obey IT policy to protect company information. The IT department is responsible to continuously update this document to reflect advancements in available practices or tools, aiming for a high level of information security compatible with our company. Non-cooperation with the enforcement of this license shall be treated very seriously and management shall be informed for the appropriate administrative actions.";

		$terms = "<b>Terms & Conditions:</b> The IT department must ensure and enforce to obey IT policy to protect company information.";

		$printFormatStructure = array(
			'formTittle'       => $formtittle,
			'hasDocSubTittle'  => false,
			'subFormTittle'    => $subFormTittle,
			'hasHeadTable'     => true,
			'hasLineTable'     => true,
			'hasNetTotalTable' => false,
			'hasNotesTable'    => true,
			'note' 			   => $terms,
			'hasSignTable'     => true,
			'hasGatePassTable' => false,
 			'headertable'      => $printdocheader,
			'linetable'        => $printdoclines,
		);	
		
		return $printFormatStructure;

	}else if($doctype == 'CR' && $formtype == 'CR'){


		$printdocheader = array(
			1 => array( 'company', 'docnumber', 'isbudgeted', 'isreplacement', 'isnew'),
			2 => array( 'trackingnumber', 'section', 'budget', 'utilized', 'balance'),

		);

		$printdoclines = array(
			'#'                => 'linenumber',
			'Item Description' => 'itemdescription',
			'UOM'              => 'iduom',
			'Qty'              => 'quantity',
			'Unit Price'       => 'unitprice',
			'Amount'           => 'amount',
			'Useful Life'      => 'usefullife',
			'In house Period'  => 'inhouseperiod',
		);

		$formtittle = "Capex";


		$printFormatStructure = array(
			'formTittle'       => $formtittle,
			'hasDocSubTittle'  => false,
			// 'subFormTittle'    => $subFormTittle,
			'hasHeadTable'     => true,
			'hasLineTable'     => true,
			'hasNetTotalTable' => false,
			'hasNotesTable'    => false,
			'note' 			   => 'N.B: Please read the above information carefully before sign the printout copy.',
			'hasSignTable'     => true,
			'hasGatePassTable' => false,
 			'headertable'      => $printdocheader,
			'linetable'        => $printdoclines,
			// 'nettolaltable'    => $nettotalline,
			// 'gatepasstable'    => $printgatepass,
			// 'signaturetable'   => $printsignature
		);	
		
		return $printFormatStructure;

	
	} else {

		$printdocheader = array(
			1 => array( 'docnumber', 'company', 'docdate'),
			2 => array( 'username', 'department', 'section'),
	

		);

		$printdoclines = array(
			'#'              => 'linenumber',
			'Description'    => 'itemdescription',
			'UOM'            => 'iduom',
			'Quantiy'        => 'quantity',
			'Unit price'     => 'unitprice',
			'Amount'         => 'amount',
			'Useful life'    => 'usefullife',
			'Inhouse Period' => 'inhouseperiod',
		);


		$formtittle = "ICT XXX";

		$printFormatStructure = array(
			'formTittle'       => $formtittle,
			'hasDocSubTittle'  => true,
			'subFormTittle'    => $subFormTittle,
			'hasHeadTable'     => true,
			'hasLineTable'     => false,
			'hasNetTotalTable' => false,
			'hasNotesTable'    => true,
			'note' 			   => 'N.B: Please read the above information carefully before sign the printout copy.',
			'hasSignTable'     => true,
			'hasGatePassTable' => false,
 			'headertable'      => $printdocheader,
			'linetable'        => $printdoclines,
			'nettolaltable'    => $nettotalline,
			'gatepasstable'    => $printgatepass,
			'signaturetable'   => $printsignature

		);	
		
		return $printFormatStructure;



	} 


}


?>