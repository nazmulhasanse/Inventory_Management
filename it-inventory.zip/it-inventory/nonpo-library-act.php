<?php
ob_start();
require_once '../includes/user.cookies.php';    // check user login
require_once '../includes/config.php';          // mysql connections
require_once '../includes/database_lib.php';    // mysqli connection & db-functions
require_once '../includes/user-privilege.php';  // privilege function

// check privilege (keep module and section empty to skip privilege check)
$module = "pdm";
$section = "library";
$privilege = userPrivileges($module, $section);
// if (!$privilege['R']) { header("Location: ../user/no-permission.php"); exit();}
?>


<?php require_once("../includes/head.php") ;?>

<?php
	// $SECTION = "PDM";
	// $ELEMENT = "Library";

	include_once("../includes/mainmenu.php");

	// page view permission	: this page for create and edit
	// if (!in_array($rank_level, $EditPermission_Group) && !in_array($user_id, $EditPermission_User)) {
	// 	header("Location: ../user/no-permission.php");
	// 	exit();
	// }
?>

<?php
if (!isset($_GET['library'])) {
	header("location: nonpo-library.php");
	exit();
}


$library = $_GET['library'];

if (isset($_GET['id'])) {	// edit or delete
	
	$id = $_GET['id'];

	if (isset($_GET['action']) && $_GET['action'] == 'delete') {	// delete

		if($library == 'nonpo_itemname'){
			$result= mysql_query("DELETE FROM `nonpo_itemname_library` WHERE id=$id", $db1_connection);
		}else{
			$result= mysql_query("DELETE FROM `mrd_library` WHERE id=$id", $db1_connection);
		}
		

		if ($result===TRUE) {
			header("location: nonpo-library.php?library=$library");exit();
		}
		else
			echo "Error deleting row";
	} elseif(isset($_POST['submit_edit'])) {	// edit
		
		$description = $_POST['description'];
		$code = $_POST['code'];
		$zone = $_POST['zone'];
		$abbrdesc = $_POST['abbrdesc'];

		if($library == 'nonpo_itemname'){
			$sqlCheck = "SELECT count(*) AS `rowcount` FROM `nonpo_itemname_library` WHERE ItemName='$code' AND `id`!='$id'";
		}else{
			$sqlCheck = "SELECT count(*) AS `rowcount` FROM `mrd_library` WHERE Code='$code' AND LibraryName='$library' AND `id`!='$id'";
		}
		$checkResult = mysql_query($sqlCheck, $db1_connection);
		$checkRows = mysql_fetch_array($checkResult);
		$rowCount =  $checkRows['rowcount'];
		if($rowCount > 0){
			die("Duplicate Code can not update into same Library. Code: ".$code. " Library Name: ".$library);
			header("location: nonpo-library.php?library=$library");exit();	
		}

		if($library == 'nonpo_itemname'){
			$sql="UPDATE `nonpo_itemname_library` SET  `ItemName`='$code', `Type`='$abbrdesc' WHERE `id`='$id'";
		}else{
			$sql="UPDATE `mrd_library` SET `Description`='$description', `Code`='$code', `Zone`='$zone', `abbrdesc`='$abbrdesc' WHERE `LibraryName`='$library' AND `id`='$id'";
		}
	    $result = mysql_query($sql, $db1_connection) or die("Could not update".mysql_error());
	    header("location: nonpo-library.php?library=$library");exit();
	}
	
}

if (isset($_POST['submit_add'])) {	// add
	if (isset($_POST['library'])) {
		$library = $_POST['library'];
	}
	$code = $_POST['code'];
	$description=$_POST['description'];
	$zone = $_POST['zone'];
	$abbrdesc = $_POST['abbrdesc'];

	if($code == ''){
		echo "Blank Code can not be insert into Library.";
		header("location: nonpo-library.php?library=$library");exit();
	}

	$sqlCheck = "SELECT count(*) AS `rowcount` FROM `mrd_library` WHERE Code='$code' AND LibraryName='$library'";
	$checkResult = mysql_query($sqlCheck, $db1_connection);
	$checkRows = mysql_fetch_array($checkResult);
	$rowCount =  $checkRows['rowcount'];
	if($rowCount > 0){
		die("Duplicate Code can not insert into same Library. Code: ".$code. " Library Name: ".$library);
		header("location: nonpo-library.php?library=$library");exit();	
	} 


	if($library == 'nonpo_itemname'){
		$sqlCheck = "SELECT count(*) AS `rowcount` FROM `nonpo_itemname_library` WHERE ItemName='$code'";
		$checkResult = mysql_query($sqlCheck, $db1_connection);
		$checkRows = mysql_fetch_array($checkResult);
		$rowCount =  $checkRows['rowcount'];
		if($rowCount > 0){
			die("Duplicate Code can not insert into same Library. Code: ".$code. " Library Name: ".$library);
			header("location: nonpo-library.php?library=$library");exit();	
		} 
		$sql = "INSERT INTO `nonpo_itemname_library`(ItemName, Type) VALUES ('$code','$abbrdesc')";
	}else{
		$sql = "INSERT INTO `mrd_library`(LibraryName, Code, Description, Zone, abbrdesc) VALUES ('$library', '$code', '$description', '$zone', '$abbrdesc')";
	}

	
	// echo "$sql";exit();
	
	$result = mysql_query($sql, $db1_connection) or die($sql . "<br>" . mysql_error());

	if ($result===TRUE) {
		header("location: nonpo-library.php?library=$library");exit();

	}
	else
		echo "Error Inserting new data";
}


?>