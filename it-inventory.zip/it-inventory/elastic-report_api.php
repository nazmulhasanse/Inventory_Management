<?php
session_start();
$directory = __DIR__ ;
require_once $_SERVER["DOCUMENT_ROOT"] . '/includes/configli.php';         // mysql connections
require_once __DIR__ . "/classes/myclassautoloader.php";
/**
* ThisListAPI class
*/
class ThisListAPI
{	
	public $conn;
	public $queryResult;
	public $sql;
	public $dbname;



	public $docstatusTransaltor = array(
			'0' => 'Entered',
			'1' => 'Approved by Section Head',
			'2' => 'Approved by Dept. Head',
			'3' => 'Approved by COO',
			'4' => 'Approved by CEO',
			'5' => 'Completed',
			'9' => 'Cancelled',
		);

	public function __construct($dbnum = 1) {
		if ($dbnum === '2') {
			$this->conn = new ErpDbConn('2');
			$this->dbname = "erpprod_bulbul";
		} else {
			$this->conn = new ErpDbConn;
			$this->dbname = "erpprod";
		}
	}

	

	function getNextDocNumber($counterName){
	    $conn = new ErpDbConn;
	    $sql = "SELECT prefix, nextnumber from erp_counter where countername='$counterName'";
	    $prefix        = json_decode($conn->sqlToJson($sql), true)[0]['prefix'];
	    $currentdocnum = json_decode($conn->sqlToJson($sql), true)[0]['nextnumber'];

	    $sql = "UPDATE erp_counter SET nextnumber=(nextnumber+1) where countername='$counterName'";
	    $qresult = $conn->query($sql);

	    if($qresult){
	        return $prefix . "-".$currentdocnum;
	    }
	}

	function getListData($params) {

		$fieldArray = array(
			'idlines'        => '`A`.`idlines`',
			'CompanyName'    => '`A`.`CompanyName`',
			'Buyer'          => '`A`.`Buyer`',
			'SupplierName'   => '`A`.`SupplierName`',
			'LocalForeign'   => '`A`.`LocalForeign`',
			'Status'         => '`A`.`Status`',
			'MasterReff'     => '`A`.`MasterReff`',
			'TKNumber'       => '`A`.`TKNumber`',
			'ProjectNo'      => '`A`.`ProjectNo`',
			'Orderdate'      => '`A`.`Orderdate`',
			'Program'        => '`A`.`Program`',
			'Price'          => '`A`.`Price`',
			'CurrencyName'   => '`A`.`CurrencyName`',
			'OrderUOM'       => '`A`.`OrderUOM`',
			'OrderQty'       => '`A`.`OrderQty`',
			'OrderValue'     => '(`A`.`OrderQty` * `A`.`Price`)',
			'SupplierRcvQty' => '`A`.`SupplierRcvQty`',
			'PendingRcvQty'  => '(`A`.`OrderQty` - `A`.`SupplierRcvQty`)',
			'StockQty'       => '`A`.`StockQty`',
			'StockUOM'       => '`A`.`StockUOM`',
			'StockValue'     => '(`A`.`StockQty` * `A`.`Price`)',
			'Description'    => '`A`.`Description`',			
		);

		$groupArray = array(
			// 'inventoryid'       => '`ti`.`inventoryid`',
		);

		$whereClauses = array(
			// "(`B`.`Action` = 'Received Form Elastic Supplier')",
			"(1=1)",
		);
		
		
		



		
		// Process field clause
		$fieldClause = array();
		foreach ($fieldArray as $fieldKey => $fieldValue) {
			if($fieldValue == 'virtual'){
				array_push($fieldClause, "''" . ' AS `' . $fieldKey . '`');
			}else{
				array_push($fieldClause, $fieldValue . ' AS `' . $fieldKey . '`');
			}
		}
		$fieldClause = implode(' , ', $fieldClause);

		// Process group clause
		$groupClause = array();
		foreach ($groupArray as $groupField) {
			array_push($groupClause, $fieldArray[$groupField]);
		}
		$groupClause = implode(' , ', $groupClause);



		// Process where clause
		$searchParams = $params;
		unset($searchParams['showLimit']);
		unset($searchParams['pageNum']);
		unset($searchParams['reqType']);		
		unset($searchParams['output']);		
		unset($searchParams['print']);
		unset($searchParams['sMsg']);		
		unset($searchParams['eMsg']);		
		unset($searchParams['wMsg']);
		unset($searchParams['_']);

		// unset($searchParams['rrtype']);		
		if (isset($searchParams) && count($searchParams) > 0) {
			foreach ($searchParams as $paramkey => $paramvalue) {
				if($paramvalue == "") unset($searchParams[$paramkey]);
			}
            foreach ($searchParams as $paramkey => $paramvalue) {
              // $compositeClauses = array("1=1",);
              $compositeClauses = array();
              $compositeParamkey = explode("__", $paramkey);
              $compositeParamVal = explode(",__", $paramvalue);

              if(sizeof($compositeParamkey) > 1 && sizeof($compositeParamVal) > 1 ){
                foreach ($compositeParamkey as $key => $fieldname) {
                	$fieldvalue = $compositeParamVal[$key];
                	if($fieldvalue == ""){
                		continue;
                	} else if(strpos($fieldvalue, '_to_') !== false){
						$from_to_dates = explode('_to_', $fieldvalue);
						$form_date = $from_to_dates[0];
						$to_date = $from_to_dates[1];
						array_push($compositeClauses, "( $fieldArray[$fieldname] BETWEEN '$form_date' AND '$to_date')");
	                } else {
	                  	array_push($compositeClauses, "( $fieldArray[$fieldname] LIKE '%" . $fieldvalue. "%')");
	                }  	
                }
                $compositeClause = '(' . implode(' AND ', $compositeClauses) .')';
                array_push($whereClauses, $compositeClause);

              } else if(sizeof($compositeParamkey) > 1){
                foreach ($compositeParamkey as $key => $fieldname) {
                  array_push($compositeClauses, "( $fieldArray[$fieldname] LIKE '%" . $paramvalue . "%')");
                }
                $compositeClause = '(' . implode(' OR ', $compositeClauses) . ')';
                array_push($whereClauses, $compositeClause);

              } else{
              	if(strpos($paramvalue, '_to_') !== false){ // date field search
              		$from_to_dates = explode('_to_', $paramvalue);
              		$form_date = $from_to_dates[0];
              		$to_date = $from_to_dates[1];
              		array_push($whereClauses, "( $fieldArray[$paramkey] BETWEEN '$form_date' AND '$to_date')");
              	} else if(in_array($paramkey, $exactSearchArray)){ // field exact search
              		
              		array_push($whereClauses, "( $fieldArray[$paramkey] = '" . $paramvalue . "')");

              	} else if($paramkey == 'purchasemode' && $paramvalue == 'blank'){ // blank field search
              		
              		array_push($whereClauses, "( $fieldArray[$paramkey] = '')");

              	} else {									 // normal field search

              		array_push($whereClauses, "( $fieldArray[$paramkey] LIKE '%" . $paramvalue . "%')");
              	}
              }
            }
		}
		$whereClause = implode(' AND ', $whereClauses);



  		$sql = <<<EOF
SELECT 
	$fieldClause
FROM
    erpprod.erp_view_elastic_report5 AS A 
WHERE $whereClause
EOF;

// return $sql;
		/**
		 * Pagination work
		 * Very important to set the page number first.
		 */
		$pageNum = (!isset($params['pageNum'])) ? 1 : intval($params['pageNum']);
		/**
		 * Number of results displayed per page 	by default its 10.
		 */
		$showLimit =  ($params["showLimit"] <> "" && is_numeric($params["showLimit"]) ) ? intval($params["showLimit"]) : 20;

		/**
		 * Get the total number of rows in the table
		 */
		$countSql = $sql ;
		// $queryResult = $this->conn->query($countSql);
		// $queryRowsNum = $queryResult->num_rows;
		// -------- Count row sql prepare
		// 1. Plain SQL 
		// $countSql = "SELECT COUNT(*)  FROM " . strstr($countSql, 'FROM'); 
		//***We use it plain SQL//But we can not use it because in select clause can have subquery

		// 2. Can have sub query in select tag
		$tableParts = explode("\n", $countSql);
		$countSql = "";
		foreach ($tableParts as $indx => $part) {
			if($indx == 0 || $indx == 1) continue;
			$countSql .= $part;
		}
		$countSql =  "SELECT ".$fieldArray['idlines']." AS numrows " . $countSql;

		// return $countSql;
		// $countSql = "SELECT COUNT(*) AS numrows FROM (" . $countSql . ") AS ct";
		// return $countSql;
		// $countSql = substr($countSql, 0, stripos($countSql,'GROUP BY'));
		// -------- Count row sql prepare end
		$queryResult = $this->conn->query($countSql);
		$queryRowsNum = $queryResult->num_rows;


		/**
	    * if no record found then, apply
	    */
	    if($queryRowsNum == 0){
		   $tableParts = explode("\n", $sql);
		   $mainTableName = $tableParts[3];

		   $tableParts = explode("WHERE", $sql);
		   $joinedSql = substr($sql, 0,strripos($sql, 'WHERE'));
		   // $joinedSql = $tableParts[0] . $tableParts[1] . $tableParts[2] . $tableParts[3];
		   $maxidSql= "SELECT @last_id := MAX(`A`.`idlines`) FROM $mainTableName";
		   $fakeSql = "$joinedSql WHERE `A`.`idlines` = @last_id"; 
		   $this->conn->query($maxidSql);
		   $queryResult = $this->conn->query($fakeSql);
		   // echo "maxidSql -- " . $maxidSql . "<br/><br/> fakeSql -- " . $fakeSql;
		   $data = array();
			while ( $rows = $queryResult->fetch_assoc() ) {
			  array_push($data, $rows);
			}

			$returnJson = "";
			$returnArray = array();
			$returnArray['listData']     = $data;
			$returnArray['noResult']     = true;
			$returnArray['queryRowsNum'] = $queryRowsNum;
			$returnArray['showLimit']    = $showLimit; // per page limit
			$returnArray['pageNum']      = 0;
			$returnArray['lastPageNum']  = 0;
			$returnJson = json_encode($returnArray);
			return $returnJson;
		}

		/**
		 * Calculate the lastPageNum page based on total number of rows and rows per page. 
		 */
		$lastPageNum = ceil($queryRowsNum/$showLimit); 

		/**
		 * this makes sure the page number isn't below one, or more than our maximum pages 
		 */
		if ($pageNum < 1) { 
		  $pageNum = 1; 
		} elseif ($pageNum > $lastPageNum)  { 
		  $pageNum = $lastPageNum; 
		}
		$lowerLimit = ($pageNum - 1) * $showLimit;

		// $sql2 = " SELECT * FROM tbl_pagination WHERE 1 LIMIT ". ($lowerLimit)." ,  ". ($showLimit). " ";
		// $sql = $sql . " LIMIT ". ($lowerLimit)." ,  ". ($showLimit). " ";
		$listSql = $sql . " LIMIT ". ($lowerLimit)." ,  ". ($showLimit). " ";
		if( isset($params['output']) && $params['output'] == 'ExportToExcel'){
			// $listSql = $sql . " LIMIT 2000 "; // hardcode limit 2000
			$listSql = $sql . " LIMIT 10000 "; // hardcode limit 2000
		}

		$queryResult = $this->conn->query($listSql);

		$lnddcObj = new ErpLibraryDecoder();
		
		$data = array();

		while ( $rows = $queryResult->fetch_assoc() ) {

			$rows = $this->clean($rows);

			$rows['Price']          = number_format($rows['Price'],4);
			$rows['OrderQty']       = number_format($rows['OrderQty'],4);
			$rows['SupplierRcvQty'] = number_format($rows['SupplierRcvQty'],4);
			$rows['PendingRcvQty']  = number_format($rows['PendingRcvQty'],4);
			$rows['StockQty']       = number_format($rows['StockQty'],4);
			$rows['StockValue']     = number_format($rows['StockValue'],4);
			$rows['OrderValue']     = number_format($rows['OrderValue'],4);
			$rows['Orderdate']      = substr($rows['Orderdate'], 0, 10);

			array_push($data, $rows);
		}


		if (isset($params['output']) && $params['output'] == 'table') {
		return '<html><head>
		  <style type="text/css">
		  /*keep html line-breaks within one cell*/
		  br {
		      mso-data-placement:same-cell;
		  }
		  body {
		      font-family : monospace;
		      font-size : small;
		  }
		  table {
		      border: solid 1px;
		      border-collapse: collapse;
		  }
		  td {
		      border : solid 1px;
		      border-color : lightgray;
		  }
		  </style>
		</head><body>' . $this->conn->sqlToTable($sql) . '</body></html>';
		$this->conn->close();
		} else if (isset($params['print']) && $params['print'] == 'sql'){
			echo $sql;
		} else if (isset($params['output']) && $params['output'] == 'ExportToExcel'){
			$this->exportToExcel($data);
		}  else {

			$returnJson = "";
			$returnArray = array();

			$returnArray['listData']     = $data;
			$returnArray['noResult']     = false;
			$returnArray['queryRowsNum'] = $queryRowsNum;
			$returnArray['showLimit']    = $showLimit; // per page limit
			$returnArray['pageNum']      = $pageNum;
			$returnArray['lastPageNum']  = $lastPageNum;

			$returnJson = json_encode($returnArray);
			$this->conn->close();
			return $returnJson;

		}


	}


	public function clean($row){
		$newRow = array();
		foreach ($row as $key => $value) {
			$string = $value;
			// $string = str_replace(' ', '-', $string); // Replaces all spaces with hyphens.
			$value = preg_replace('/[^A-Za-z0-9\-. _]/', '', $string); // Removes special chars.
			$newRow[$key] = $value;
		}
		return $newRow;
	}


	

	

	public function exportToExcel($data){
		$tableHeadKeyTranslator = array(
			'CompanyName'    => 'Company', 
			'SupplierName'   => 'Supplier', 
			'ProjectNo'      => 'Work Order', 
			'MasterReff'     => 'Master Ref#', 
			'TKNumber'       => 'Tracking#', 
			'Orderdate'      => 'Order Date', 
			'Program'        => 'Season', 
			'LocalForeign'   => 'Local/Foreign', 
			'Description'    => 'Item Description', 
			'UnitPrice'      => 'Unit Price', 
			'CurrencyName'   => 'Currency', 
			'CartonType'     => 'Carton Type', 
			'SupplierRcvQty' => 'Received Qty From Supplier', 
			'PendingRcvQty'  => 'Pending Received Qty', 
			'StockQty'       => 'Stock Qty', 
			'StockUOM'       => 'Stock UOM', 
			'StockValue'     => 'Stock Value', 
			'OrderQty'       => 'Order Qty', 
			'OrderValue'     => 'Order Value',
			'OrderUOM'       => 'Order UOM',
		);

		$title = "Elastic";
		$xls = new ExcelXml($title);
		$xls->home();

		$xls->newRow();
		foreach ($data[0] as $key => $value) {
			if(isset($tableHeadKeyTranslator[$key])) $key = $tableHeadKeyTranslator[$key];
			$column = nl2br($key);
			if($key == 'idlines'){
				continue;
			}else{
				$xls->labelHeader($column);
			}
		}
		$xls->endRow();

		foreach ($data as $indx => $thisLine) {
			$xls->newRow();
			foreach ($thisLine as $key => $value) {
				$column = nl2br($value);
				if($key == 'Orderdate'){
					$xls->date(substr($column, 0, 10));
				}else if($key == 'Price' || $key == 'OrderQty' || $key == 'OrderValue' || $key == 'SupplierRcvQty' || $key == 'PendingRcvQty' || $key == 'StockQty' || $key == 'StockValue'){
					$xls->number(number_format($column, 4));
				}else if($key == 'idlines'){
					continue;
				}else{
					$xls->label($column);
				}
			}
			$xls->endRow();
		}
		$xls->send();
	}

	

	function libraryCodeDecoder($name, $value){
		$conn = new ErpDbConn;

		if($name == 'CompanyName'){
			$sql    = "SELECT Description  FROM mrd_library WHERE LibraryName = 'company' AND Code = '$value' LIMIT 1";
			$result = $conn->query($sql);
			$row    = $result->fetch_assoc();
			$string = $row['Description'];
		}

		$conn->close();

		return $string; 
	}


	function getReplenishedbBy($rrnumber){
		$conn = new ErpDbConn;
		$sql = "SELECT rrstatus, linestatus, recalculationbit FROM erp_rrlines WHERE rrnumber = '$rrnumber'";
		$result = $conn->query($sql);
		$row = $result->fetch_assoc();
		$rrstatus = $row['rrstatus'];
		$linestatus = $row['linestatus'];
		$recalculationbit = $row['recalculationbit'];

		$replenishedby = '';
		if($rrstatus == '5' || $rrstatus == '6' || $linestatus == '3'){
			$replenishedby = 'Reprocessing WO';
		} else if($rrstatus == '1' || $rrstatus == '3' || $rrstatus == '4'){
			$replenishedby = 'PO';
		} elseif($rrstatus == '2'){
			$replenishedby = 'Alternate Item';
		} elseif($rrstatus == '5' || $rrstatus == '6' || $linestatus == '3'){
			$replenishedby = 'Reprocessing WO';
		} elseif($rrstatus == '13'){
			$replenishedby = 'Old Sttock';
		} else {
			$replenishedby = '';
		}

		return $replenishedby;
	}




	function getUnderProjectionSO($salesorder,$itemcode){
		$conn = new ErpDbConn;
		$sql = "SELECT distinct(salesorder) FROM erp_bom WHERE salesorder IN (SELECT distinct(docnumber) FROM erp_salesorder WHERE parentdocnumber='$salesorder') AND itemcode = '$itemcode'";
		$result = $conn->query($sql);

		$underprojectionso = "";

		while($row = $result->fetch_assoc()){
		$underprojectionso .= $row['docnumber'] ."</br>";
		}

		return $underprojectionso;
	}

	function getformtypeFromSO($salesorder){
		$conn = new ErpDbConn;
		$sql = "SELECT formtype FROM erp_salesorder WHERE docnumber = '$salesorder'";
		$result = $conn->query($sql);
		$row = $result->fetch_assoc();

		$formtype = $row['formtype'];

		return $formtype;
	}

/**
 * [isAllRRCheckedInSameItemcodeAndSOLine description]
 * @param  [json]  $data [selected rr lines]
 * @return json object [if all rrlines select in same ldcslnumber and item code then return success else return fail with remaining RR]
 */
	function isAllRRCheckedInSameItemcodeAndSOLine($data){
		$returnJson = new stdClass();

		$data    = json_decode($data, true);
		$rrlines = $data['rrlines'];

		$rrnumbers = $rrlines['rrnumber'];
		$itemcodes = $rrlines['itemcode'];
		$ldcslnumbers = $rrlines['ldcslnumber'];

		$noOfLinesInDB = array();
		$checkArray = array();
		foreach ($rrnumbers as $key => $value) {
			$itemcode    = $itemcodes[$key];
			$ldcslnumber = $ldcslnumbers[$key];

			$identifier = $itemcode. "-" .$ldcslnumber;

			if(array_key_exists($identifier, $checkArray)){
				$values = $checkArray[$identifier]['sysrrnumber'];
				array_push($values, $value);
				$checkArray[$identifier]['sysrrnumber'] =  $values ;
			}else{
				$values = array();
				array_push($values, $value);
				$checkArray[$identifier]['sysrrnumber'] =  $values ;
			}
			
		}		

		$dbCheckArray = array();
		foreach ($rrnumbers as $key => $value) {
			$itemcode    = $itemcodes[$key];
			$ldcslnumber = $ldcslnumbers[$key];

			$identifier = $itemcode. "-" .$ldcslnumber;

			if(array_key_exists($identifier, $dbCheckArray)){

			}else{
				$sql = "SELECT rrnumber FROM erp_rrlines WHERE rrstatus='1' AND linestatus='1' AND itemcode='$itemcode' AND ldcslnumber='$ldcslnumber'";
				$queryResult = $this->conn->query($sql);
				$rrnumbers = array();
				while($row = $queryResult->fetch_assoc()){
					$rrnumbers[] = $row[rrnumber];
				}

				$checkArray[$identifier]['dbrrnumber']  =  $rrnumbers ;
				$checkArray[$identifier]['itemcode']    =  $itemcode ;
				$checkArray[$identifier]['ldcslnumber'] =  $ldcslnumber ;

				//data insert only for check
				$dbCheckArray[$identifier] = $rrnumbers ;
			}
			
		}

		$failArray = array();
		$failItemcode = array();
		$failLdcslnumber = array();
		foreach ($checkArray as $key => $value) {
			$sysrrnumber = $checkArray[$key]['sysrrnumber'];
			$dbrrnumber  = $checkArray[$key]['dbrrnumber'];

			$arrayDiff = array_diff($dbrrnumber, $sysrrnumber);

			$arrayDiff = array_values($arrayDiff);
			$rrString = implode(",", $arrayDiff);

			if($rrString != ""){
				$failArray[] = $rrString;
				$failItemcode[] = $itemcode;
				$failLdcslnumber[] = $ldcslnumber;
			}
			
		}


		if(sizeof($failArray) > 0){
			$returnJson->result = 'fail';
			$returnJson->rr = $failArray;
			$returnJson->itemcode = $failItemcode;
			$returnJson->ldcslnumber = $failLdcslnumber;
		}else{
			$returnJson->result = 'success';
		}

		return json_encode($returnJson);

	}

	function sendtoAllocatedRR($data){
		$returnJson = new stdClass();

		$data    = json_decode($data, true);
		$idlines = $data['idlines'];
		$idline  = "'" . implode("','",$idlines) . "'";

		$sql         = "UPDATE erp_rrlines SET linestatus = '0', rrstatus = '1', powonumber = ''  WHERE idlines IN($idline)";
		$queryResult = $this->conn->query($sql);

		if($queryResult){
			$returnJson->result = 'success';
		} else {
			$returnJson->result = 'fail';
		}
		$this->conn->close();
		return json_encode($returnJson);

	}


	function getProcurer($params){
		$conn = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		// $data = array();

		$sql = "SELECT PurchaseMode FROM `ref_purchasemode_nonpo` WHERE PurchaseMode is not null";
		$queryResult = $conn->query($sql);

		$arrayPurchaseMode = array();
		while( $row = $queryResult->fetch_assoc() ){
			$arrayPurchaseMode[] = $row['PurchaseMode'];
		}

		

		$data = array(
			'purchasemode' => json_encode($arrayPurchaseMode),
		);
	    $conn->close();

	   	return json_encode($data);
	}	


	function setProcurer($idlines,$procurer){
		$conn = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$idlines = json_decode($idlines);
		$whereIdlines = "'" . implode("','", $idlines) . "'";


		$sql = "UPDATE erp_nonpo SET purchasemode='$procurer' WHERE idlines IN($whereIdlines)";

		$queryResult = $conn->query($sql);


		$sqlUpdateIdlines = "SELECT idlines FROM erp_nonpo WHERE idlines IN($whereIdlines) AND purchasemode != '' AND suppliername != '' AND unitprice != '' AND currency != ''";
		$queryResultIdlines = $conn->query($sqlUpdateIdlines);

		$updStatusIdlines = array();
		while($row = $queryResultIdlines->fetch_assoc()){
			$updStatusIdlines[] = $row['idlines'];
		}

		$idlinesUpdStatus ="'" .implode("','", $updStatusIdlines). "'";
		$updSql = "UPDATE erp_nonpo SET linestatus='1' WHERE idlines IN($idlinesUpdStatus)";
		$queryResultUpd = $conn->query($updSql);

		return $queryResult;

		// if($queryResult){
		// 	$returnJSON->result = 'success';
		// }

		// return $returnJSON;
	}









}


/**
 * Routing ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 */
if ( basename(__FILE__) == basename($_SERVER["SCRIPT_FILENAME"]) ) {
    // called directly
	if ( $_SERVER['REQUEST_METHOD'] == 'GET' ) {

		if(isset($_GET['reqType'])){

			$reqType = $_GET['reqType'];
			$listObj  = new ThisListAPI();

			if($reqType == 'getListData') {
				$params = $_GET;
				$returnData = $listObj->getListData($params);
				echo $returnData;
			}


			if($reqType == 'exportListData') {
				$params = $_GET;
				$params['output'] = 'ExportToExcel';
				$returnData = $listObj->getListData($params);
				echo $returnData;
			}

			if($reqType == 'getProcurer') {
				$params = $_GET;
				$returnData = $listObj->getProcurer($params);
				echo $returnData;
			}


		}


	} else if( $_SERVER['REQUEST_METHOD'] == 'POST' ){
	
		if(isset($_POST['reqType'])){

			$reqType = $_POST['reqType'];
			$listObj  = new ThisListAPI();

			if($reqType == "saveDoc"){

				$docobj = $_POST['docobj'];
				$returnData = $listObj->saveDoc($docobj);
				echo $returnData;
			}

			if($reqType == "isAllRRCheckedInSameItemcodeAndSOLine"){

				$data = $_POST['data'];
				$returnData = $listObj->isAllRRCheckedInSameItemcodeAndSOLine($data);
				echo $returnData;
			}
			
			if($reqType == "sendtoAllocatedRR"){

				$data = $_POST['data'];
				$returnData = $listObj->sendtoAllocatedRR($data);
				echo $returnData;
			}
			
			if($reqType == "setProcurer"){

				$idlines = $_POST['idlines'];
				$procurer =  $_POST['procurer'];
				$returnData = $listObj->setProcurer($idlines,$procurer);
				echo $returnData;
			}
		}


	}

} else {
    // included/required

}
?>