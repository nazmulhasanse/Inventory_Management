<?php
session_start();
$directory = __DIR__ ;
// require_once __DIR__ . "/classes/config.php";
require_once $_SERVER["DOCUMENT_ROOT"] . '/includes/configli.php';// mysql connections
require_once __DIR__ . "/classes/myclassautoloader.php";
/*
 * If called directly from web, then do some routing
 * otherwise, don't execute any code, just define the functions
 */
if (basename(__FILE__) == basename($_SERVER["SCRIPT_FILENAME"])) {
  // called directly
  $doctype  = $_GET['doctype'];
  $formtype = $_GET['formtype'];
  // $crudmode = $_GET['crudmode'];
  $crudmode = (isset($_GET['crudmode'])) ? $_GET['crudmode'] : '' ;

  if ($doctype == 'MX') {
    $genericDocument = new ErpDocumentMX();

  } elseif ($doctype == 'MY') {
    $genericDocument = new ErpDocumentMY();

  } elseif ($doctype == 'PO' && $formtype == 'PO') {
    $genericDocument      = new ErpDocumentPO();

  } elseif ($doctype == 'PO' && $formtype == 'ACS') {
    $genericDocument      = new ErpDocumentPOACS();

  } elseif ($doctype == 'PO' && $formtype == 'ELS') {
    $genericDocument      = new ErpDocumentPOELS();

  } elseif ($doctype == 'PO' && $formtype == 'CTN') {
    $genericDocument      = new ErpDocumentPOCTN();

  } elseif ($doctype == 'PR' && $formtype == 'PR') {
    $genericDocument      = new ErpDocumentPR();

  } elseif ($doctype == 'CR' && $formtype == 'CR') {
    $genericDocument      = new ErpDocumentCR();

  } elseif ($doctype == 'TI' && $formtype == 'TI') {
    $genericDocument      = new ErpDocumentTI();

  } elseif ($doctype == 'IPO' && $formtype == 'IPO') {
    $genericDocument      = new ErpDocumentIPO();

  } elseif ($doctype == 'PR' && $formtype == 'ACS') {
    $genericDocument      = new ErpDocumentPRACS();

  } elseif ($doctype == 'PR' && $formtype == 'ELS') {
    $genericDocument      = new ErpDocumentPRELS();

  } elseif ($doctype == 'PR' && $formtype == 'CTN') {
    $genericDocument      = new ErpDocumentPRCTN();

  } elseif ($doctype == 'GRN'){
    $genericDocument      = new ErpDocumentNonPoGRN();

  } elseif ($doctype == 'TF'){
    $genericDocument      = new ErpDocumentNonPoTF();
    
  } elseif ($doctype == 'BILL'){
    $genericDocument      = new ErpDocumentIctBill();
    
  } elseif ($doctype == 'HBILL'){
    $genericDocument      = new ErpDocumentIctBillHeader();
    
  }




  echo json_encode($genericDocument->formStructure($doctype, $formtype, $crudmode), JSON_PRETTY_PRINT);
} else {
  // included/required
}
?>