<?php

// ini_set('display_errors', '1');
// ini_set('display_startup_errors', '1');
// error_reporting(E_ALL);
require_once $_SERVER["DOCUMENT_ROOT"] . '/includes/user.cookies.php';    // check user login
require_once $_SERVER["DOCUMENT_ROOT"] . '/includes/config.php';          // mysql connections
require_once $_SERVER["DOCUMENT_ROOT"] . '/includes/user-privilege.php';  // privilege function
// check privilege (keep module and section empty to skip privilege check)
include_once("resource/session/session-cheking.php");

  $db = new mysqli($db1_hostname, $db1_username, $db1_password, $db1_dbname);

  $empid = $_GET['empid'];


   $employeeInfo =  $db->query("SELECT * FROM employee_info where employeeID='$empid'");

   $rowemployee = $employeeInfo->fetch_assoc();

  $units =  $rowemployee['units'];

  $companyInfo =  $db->query("SELECT * FROM company_library where unit='$units'");

   $rowcompany = $companyInfo->fetch_assoc();

   $ict_inventory =  $db->query("SELECT * FROM erp_ict_inventory where employeeid='$empid'");

   $inventory_data = $ict_inventory->fetch_assoc();

    $ict_inventory_active =  $db->query("SELECT * FROM erp_ict_inventory where employeeid='$empid' and docstatus='1'");

     $ict_inventory_check =  $db->query("SELECT * FROM erp_ict_inventory where employeeid='$empid' and docstatus='1'");

     $inventory_check = $ict_inventory_check->fetch_assoc();

     


   $ict_inventory_log =  $db->query("SELECT * FROM ( SELECT *  FROM erpprod.erp_ict_inventory_log WHERE employeeid='$empid' AND returntype !='' ORDER BY lastlineupdatetime DESC) AS ordered_data GROUP BY serialnumber; ");


$ict_inventory_log_check =  $db->query("SELECT * FROM ( SELECT *  FROM erpprod.erp_ict_inventory_log WHERE employeeid='$empid' AND returntype !='' ORDER BY lastlineupdatetime DESC) AS ordered_data GROUP BY serialnumber; ");

$inventory_log_check = $ict_inventory_log_check->fetch_assoc();

     


    $ict_inventory_accessory =  $db->query("SELECT * FROM erp_ict_inventory_accessory where badge='$empid' Order By actiontype ASC");

date_default_timezone_set('Asia/Dhaka');


?>


<html lang="en">

<meta charset="utf-8">
<style type="text/css">
<head>
body{
background-color:;
}
.tr_f{ color:#fff; font-size:12px; text-transform:uppercase !important;}
#printableArea{
margin: 0 auto;
width: 850px;

}
table{

}
#linetable {
 /*   width: 19.3cm;
    min-width: 19.3cm;
    font-size: 8pt;
    border-collapse: collapse;*/
}
#linetable td {
    border: 1pt solid black;
}

.linetable_td {
    vertical-align: text-top;
    text-align: center;
    overflow: hidden;
    padding: 5pt 3pt 3pt 3pt;
}

#linetable th {
    border: 1pt solid black;
}

.print .linetable_td2{
	font-size: 11.5px;
	padding: 2px;
}



</style>
 <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
   <script src="https://docraptor.com/docraptor-1.0.0.js"></script>
<script>

   // $("#btnPrint").live("click", function () {
   //          var divContents = $("#printableArea").html();
   //          var printWindow = window.open('', '', 'height=400,width=770');
   //          printWindow.document.write('<html><head><title></title>');
   //          printWindow.document.write('</head><body >');
   //          printWindow.document.write(divContents);
   //          printWindow.document.write('</body></html>');
   //          printWindow.document.close();
   //          printWindow.print();
   //      });
   //       var downloadPDF = function() {
   //    DocRaptor.createAndDownloadDoc("#printableArea", {
   //      test: true, // test documents are free, but watermarked
   //      type: "pdf",
   //      document_content: document.querySelector('html').innerHTML, // use this page's HTML
   //      // document_content: "<h1>Hello world!</h1>",               // or supply HTML directly
   //      // document_url: "http://example.com/your-page",            // or use a URL
   //      // javascript: true,                                        // enable JavaScript processing
   //      // prince_options: {
   //      //   media: "screen",                                       // use screen styles instead of print styles
   //      // }
   //    })
   //  }

$(document).ready(function () {
    window.print();
});


</script>
</head>
    <body>

<!-- 
        <table width="725" border="0" cellspacing="0" cellpadding="0" style="">
 
    <tr>
        <td height="30" align="right" valign="middle"><button id="btnPrint">Print</button>&nbsp;&nbsp;&nbsp;&nbsp;   


     

    </td>
        
    </tr>
</table> -->

   <div id="printableArea">

   	 <div id="min-body" style="min-height: 900px;">
        <!-- <center><h2 style="margin-top: -5px;"></?php echo $rowcompany['company_name']; ?> </h2></center> -->
          <center><h2 style="margin-top: -5px;"> USER LOG SHEET </h2></center>

        <!-- <center><p style="margin-top: -18px;"></?php echo $rowcompany['address']; ?></p></center> -->


  <table width="845" align="center" cellpadding="0" cellspacing="0" class="shawdow">
  
  <tr>
    <td height="22">Section</td><td style="width:15px;"> : </td><td>  <?php echo $inventory_data['section']; ?></td>
    <td height="22">Name</td><td style="width:15px;"> : </td><td>  <?php echo $rowemployee['name']; ?></td>
    <td height="22">Domain</td><td style="width:15px;"> : </td><td>  <?php echo $inventory_data['domainid']; ?></td>
  
  </tr>
  
  <tr>
    <td height="22">Department</td><td>: </td><td>  <?php echo $inventory_data['department']; ?> </td>
    <td height="22">Employee ID.</td><td>: </td><td>  <?php echo $inventory_data['employeeid']; ?></td>
    <td height="22">Username</td><td>: </td><td>  </td>
   </tr>
  <tr>
    <td height="22">Mobile no.</td><td>: </td><td>  <?php echo $inventory_data['contactnumber']; ?> </td>
    <td height="22">Designation</td><td>: </td><td>   <?php echo $inventory_data['designation']; ?></td>
    <td height="22">Liz Mail</td><td>: </td><td>  <?php echo $inventory_data['useremail']; ?></td>
 </tr>
</table>
<br>


<table class="print" id="linetable" width="840" border="1" align="center" cellpadding="0" cellspacing="0" >
	<thead>
		<tr style="font-size: 13px;padding: 5px;"><th>Inventory ID</th>
			<th>Serial No.</th>
			<th>PC Type</th>
			<th>Purchase Date</th>
			<th>Brand</th>
			<th>Model</th>
			<th>Hard Disk</th>
			<th>Processor</th>
			<th>RAM</th>
			<th>Status</th>
		</tr>
	</thead>
	<tbody>

<?php

        while($data_ICT = $ict_inventory_active->fetch_assoc()){

  ?>

		<tr>
			<td class="linetable_td" style="font-size: 12px;padding-left: 5px;padding-right: 2px;"><?php echo $data_ICT['inventoryid']; ?></td>
			<td class="linetable_td" style="font-size: 12px;padding-left: 5px;padding-right: 2px;"><?php echo $data_ICT['serialnumber']; ?></td>
			<td class="linetable_td" style="font-size: 12px;padding-left: 5px;padding-right: 2px;"><?php echo $data_ICT['laptopordesktop']; ?></td>
			<td class="linetable_td" style="font-size: 12px;padding-left: 5px;padding-right: 2px;"><?php echo $data_ICT['purchasedate']; ?></td>
			<td class="linetable_td" style="font-size: 12px;padding-left: 5px;padding-right: 2px;"><?php echo $data_ICT['brand']; ?></td>
			<td class="linetable_td" style="font-size: 12px;padding-left: 5px;padding-right: 2px;"><?php echo $data_ICT['model']; ?></td>
			<td class="linetable_td" style="font-size: 12px;padding-left: 5px;padding-right: 2px;">

				<?php echo $data_ICT['hdd']; ?>
				
					<?php if(!empty($data_ICT['addtionalharddisk'])){  ?> 
	

					<?php echo " & "; echo $data_ICT['addtionalharddisk']; ?>

				<?php } ?> 

			</td>
			<td class="linetable_td" style="font-size: 12px;padding-left: 5px;padding-right: 2px;"><?php echo $data_ICT['processor']; ?></td>
			<td class="linetable_td" style="font-size: 12px;padding-left: 5px;padding-right: 2px;"><?php echo $data_ICT['ram']; ?></td>
			<td class="linetable_td" style="font-size: 12px;padding-left: 5px;padding-right: 2px;">

				<?php if($data_ICT['docstatus'] == '0'){  ?> 

					On Hand

				<?php } elseif($data_ICT['docstatus'] == '1'){  ?>

					Allocated

				<?php } ?>



			</td>
			
		</tr>
<?php 

	} 

?>


<?php

if($inventory_check['inventoryid']==$inventory_log_check['inventoryid']){



}else{

        while($data_ICT_log = $ict_inventory_log->fetch_assoc()){

  ?>

		<tr>
			<td class="linetable_td" style="font-size: 12px;padding-left: 5px;padding-right: 2px;"><?php echo $data_ICT_log['inventoryid']; ?></td>
			<td class="linetable_td" style="font-size: 12px;padding-left: 5px;padding-right: 2px;"><?php echo $data_ICT_log['serialnumber']; ?></td>
			<td class="linetable_td" style="font-size: 12px;padding-left: 5px;padding-right: 2px;"><?php echo $data_ICT_log['laptopordesktop']; ?></td>
			<td class="linetable_td" style="font-size: 12px;padding-left: 5px;padding-right: 2px;"><?php echo $data_ICT_log['purchasedate']; ?></td>
			<td class="linetable_td" style="font-size: 12px;padding-left: 5px;padding-right: 2px;"><?php echo $data_ICT_log['brand']; ?></td>
			<td class="linetable_td" style="font-size: 12px;padding-left: 5px;padding-right: 2px;"><?php echo $data_ICT_log['model']; ?></td>
			<td class="linetable_td" style="font-size: 12px;padding-left: 5px;padding-right: 2px;">

				<?php echo $data_ICT_log['hdd']; ?>
				
					<?php if(!empty($data_ICT_log['addtionalharddisk'])){  ?> 
	

					<?php echo " & "; echo $data_ICT_log['addtionalharddisk']; ?>

				<?php } ?> 

			</td>
			<td class="linetable_td" style="font-size: 12px;padding-left: 5px;padding-right: 2px;"><?php echo $data_ICT_log['processor']; ?></td>
			<td class="linetable_td" style="font-size: 12px;padding-left: 5px;padding-right: 2px;"><?php echo $data_ICT_log['ram']; ?></td>
			<td class="linetable_td" style="font-size: 12px;padding-left: 5px;padding-right: 2px;">

				<?php if($data_ICT_log['returntype'] == '1'){  ?> 

					In Servicing

				<?php } elseif($data_ICT_log['returntype'] == '2'){  ?>

					Damaged

				<?php } elseif($data_ICT_log['returntype'] == '3'){  ?>

					User Resigned

			<?php } elseif($data_ICT_log['returntype'] == '4'){  ?>

				Returned to IT

				<?php } ?> 
					

				</td>
			
		</tr>
<?php 

	}
}

?>

	</tbody>
</table>

<br>

<table  class="print" id="linetable" width="840" border="1" align="center" cellpadding="0" cellspacing="0" >
	<thead style="font-size: 12px;padding: 5px;">
		<tr><th class="linetable_td2">SL No.</th>
			<th class="linetable_td2">Item Name</th>
			<th class="linetable_td2">Serial No.</th>
			<th class="linetable_td2">Accessory ID.</th>
			<th class="linetable_td2">Brand</th>	
			<th class="linetable_td2">Model</th>			
			<th class="linetable_td2">Receiving Date</th>
			<th class="linetable_td2">User Sign</th>
			<th class="linetable_td2">Returning Date</th>
			<th class="linetable_td2">User Sign</th>
			<th class="linetable_td2">Status</th>
		</tr>
	</thead>
	<tbody>

<?php
		
		$sl = 1;

        while($data_accessory = $ict_inventory_accessory->fetch_assoc()){

  ?>

		<tr>
			<td class="linetable_td2"><center><?php echo $sl++; ?></center></td>
			<td class="linetable_td2" style="font-size: 12px;padding-left: 5px;padding-right: 2px;"><?php echo $data_accessory['itemtype']; ?></td>
			<td class="linetable_td2" style="font-size: 12px;padding-left: 5px;padding-right: 2px;"><?php echo $data_accessory['serialnumber']; ?></td>
			<td class="linetable_td2" style="width: 100px;font-size: 12px;padding-left: 5px;padding-right: 2px;"><?php echo $data_accessory['accessory_id']; ?></td>
			<td class="linetable_td2" style="font-size: 12px;padding-left: 5px;padding-right: 2px;"><?php echo $data_accessory['Brand']; ?></td>
			<td class="linetable_td2" style="font-size: 12px;padding-left: 5px;padding-right: 2px;"><?php echo $data_accessory['Model']; ?></td>
			<td class="linetable_td2">
				<?php 

				if(!empty( $data_accessory['actiondatetime'])){
					
				 $rdatetime = $data_accessory['actiondatetime'];

				    // Remove "PM" from the timestamp
				    $rdatetime = str_replace(' PM', '', $rdatetime);

				    $date = new DateTime($rdatetime);
				    $dateValue = $date->format('Y-m-d');

				    echo $dateValue;
				    
				}else{


				}		
						?></td>
			<td class="linetable_td2" style="width: 70px;"></td>
			<td class="linetable_td2"></td>
			<td class="linetable_td2" style="width: 70px;"></td>
			<td class="linetable_td2" style="font-size: 12px;padding-left: 5px;padding-right: 5px;">
				
				<?php if($data_accessory['actiontype'] == '01'){  ?> 

					Allocated

				<?php } elseif($data_accessory['actiontype'] == '02'){  ?>

					Released

				<?php } elseif($data_accessory['actiontype'] == '03'){  ?>

					Damaged

			<?php } elseif($data_accessory['actiontype'] == '04'){  ?>

				Lost

			<?php } elseif($data_accessory['actiontype'] == '05'){  ?>

				Broken

		<?php } elseif($data_accessory['actiontype'] == '06'){  ?>

				Stolen

		<?php } elseif($data_accessory['actiontype'] == '07'){  ?>

				In Servicing

	<?php } elseif($data_accessory['actiontype'] == '08'){  ?>

				Allocated as Backup

	<?php } elseif($data_accessory['actiontype'] == '09'){  ?>

				Assign to Location


	<?php } elseif($data_accessory['actiontype'] == '00'){  ?>

		On-Hand


	<?php }?>  

			</td>
			
		</tr>
		<?php 

			}          
			$varLineTable = "";
              for($i=1; $i<=26-$sl; $i++){
	                $varLineTable .= "<tr>";
	                for($j=1; $j<=11; $j++){
	                    $varLineTable .= "<td style='height:25px'></td>";
	                }
	                $varLineTable .= "</tr>";
	            }

                $varLineTable .= "</tbody>";
                $varLineTable .= "</table>";                    

                echo  $varLineTable;

?>


</div>

<center><p style="font-size:17px; margin-top: 50px; margin-bottom: 40px;"><b>Terms & Conditions:</b> The IT department must ensure and enforce to obey IT policy to protect company information.</p></center>

<br>
<table width="850" border="0" align="center" cellpadding="0" cellspacing="0" class="shawdow">
   <tr>
       <td style="padding-left: 10px;" height="23">.............................................</td>
       <td style="width:290px;"></td>
       <td style="padding-left: 10px;" height="23">.............................................</td>
    </tr>
     <tr>
        <td style="padding-left: 10px;" height="23">Signature of Log Employee</td>
        <td></td>
        <td style="padding-left: 10px;" height="23">Signature of ICT Inventory </td>
        
    </tr>


</table>

</div>
<div id="editor"></div>


    

<!--Add External Libraries - JQuery and jspdf-->
<script src="https://code.jquery.com/jquery-1.12.3.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/0.9.0rc1/jspdf.min.js"></script>
<script type="text/javascript">

</script>
</body>
</html>