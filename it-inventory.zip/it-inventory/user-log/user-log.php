<?php  

 require_once $_SERVER["DOCUMENT_ROOT"] . '/includes/user.cookies.php';    // check user login
require_once $_SERVER["DOCUMENT_ROOT"] . '/includes/config.php';          // mysql connections
require_once $_SERVER["DOCUMENT_ROOT"] . '/includes/user-privilege.php';  // privilege function
// check privilege (keep module and section empty to skip privilege check)
include_once("resource/session/session-cheking.php");

  $db = new mysqli($db1_hostname, $db1_username, $db1_password, $db1_dbname);



          if(isset($_POST["submit"]))
          {


        $employeeID = $_POST['employeeID'];

       // $my_array = isset($_POST['accessories']) ? $_POST['accessories'] : array();
      
       // $is_empty = false;
       // foreach($my_array as $element) {
       //    if(empty($element)) {
       //       $is_empty = true;
       //       break;
       //    }
       // }



           $querysitemnature =  $db->query("SELECT * FROM erp_ict_inventory where employeeid='$employeeID' ");

            $row = $querysitemnature->fetch_assoc();

           $employeeid = $row['employeeid'];

       if(!empty($employeeid)) {

        
          // window.location.href="inventory-user-log-print.php?empid=' . $employeeid . '";


        echo ('<SCRIPT LANGUAGE="JavaScript">
    
           window.open("inventory-user-log-print.php?empid=' . $employeeid . '", "_blank");

            </SCRIPT>');
               
            }
            else{
            echo ('<SCRIPT LANGUAGE="JavaScript">
            window.alert("Please check Employee ID")
            </SCRIPT>');
            }

        }


 ?>


<!DOCTYPE HTML>
<html>
<head>
    <?php require_once($_SERVER["DOCUMENT_ROOT"] . "/includes/head.php") ;?>
    <title>User Log Sheet</title>

    <link rel="stylesheet" type="text/css" href="css/listerp.css">
    <link rel="stylesheet" type="text/css" href="css/list-yourname.css">
    <link rel="stylesheet" type="text/css" href="css/material-button.css">
    <link rel="stylesheet" type="text/css" href="plugin/msgPop.css">

    <style type="text/css">
        #coustomtbl td{
  border: 1px solid #ddd;
  padding: 8px;
}


    </style>
</head>
<body class="right-sidebar">

<!-- Header Wrapper -->
<div id="header-wrapper">
<div class="container">
<div class="row">
<div class="12u">
<!-- Header -->
    <header id="header">
        <?php 
        include_once($_SERVER["DOCUMENT_ROOT"] . "/includes/mainmenu.php");
        ?>
    </header>
</div>
</div>
</div>
</div>

   

<!-- Main Wrapper -->
<div id="main-wrapper">
<div class="container">
<div class="row">
    <div class="12u skel-cell-important">
        <!-- Content -->
        <div id="content">
        <article class="last">
                <!-- HEADLINES -->

                    <div class="headline1"><a href="/it-inventory/">Home - </a></div>   
                     <div class="headline1"><a href="/it-inventory/list-inventory.php">IT Inventory List - </a></div>   
                    <div class="headline1"><a href="/it-inventory/list-inventory-log.php">IT Inventory History - </a></div> 
                    <div class="headline1">User Log Sheet</div> 
            <!-- LINKS -->
                    
                    <br><br><br>
                    <div id='tabsalesorder'></div>   
                    <!-- <br><br><br> -->
                    <div id="upperButtonBar" style="height:50px;">
                  
                   
            <!-- PAGE CONTENTS -->

                <form method="post" id="create_inventory" action="">

            <!-- /.box-header -->
            <div class="box-body pad">

              <table>
                
              <tr>
                <td style=""> 
                     <div class="form-group">

                      <label for="title">Employee ID: </label>

                    </div>
                    </td>
               <td>
                    <div class="form-group">
                        <input class="form-control" id="employeeID" type="text" name="employeeID" required>
                     </div>
                </td>

                <td>
                   <div class="form-group">
                   <button type="submit" name="submit" class="button">Print Log Sheet</button>
                   </div>
                </td>

              </tr>
               
              </table>

</form>


                </div>
        </article>
        </div>
    </div>

</div>
</div>
<br><br><br><br>
</div>



<br><br><br><br>
</div>

<br><br><br><br><br><br><br><br><br><br><br><br>
<!-- Footer Wrapper -->
<div id="footer-wrapper">
    <?php include_once($_SERVER["DOCUMENT_ROOT"] . "/includes/footer.php") ;?>
</div>


<script type="text/javascript">

       // $(document).ready(function() {
       //          $('#Requisitionlinerr').on('click', function() {

       //              var Requisitionline = this.value;

       //           alert(Requisitionline);
       //              $.ajax({
       //                  url: "auto_load_from.php",
       //                  type: "POST",
       //                  data: {
       //                      Requisitionline: Requisitionline
       //                  },
       //                  cache: false,
       //                  success: function(result) {
       //                      $("#itinvetory").html(result);
       //                  }
       //              });
       //          });
       //      });


    

  </script>




</body>
</html>



