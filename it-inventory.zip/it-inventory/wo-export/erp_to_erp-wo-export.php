<?php
// require_once '../classes/autoloader.php';
require_once $_SERVER["DOCUMENT_ROOT"] . '/includes/configli.php';
// require_once '../connector_cnf/db2cnf.php';

require_once $_SERVER['DOCUMENT_ROOT'] . '/erp-nonpo/wo-export/classes/myclassautoloader.php';

// ------- Set up the environment according to how the script is being called

$debugmode = false; // if debugmode is true, then write data in Database, other wise not write in database
$connectorRunMode = true; // if connectorRunMode is true then execute connector program code

// $debugmode = true; 
// $connectorRunMode = false; 

$connectorCallingTime = date('Y-m-d H:i:s', time());
echo "Connector Calling Time-->". $connectorCallingTime . "<br><br>";



if($connectorRunMode){
    // 1. Collect data
    // 2. Process data
    //    --- Valid data
    // 3. Write data
    //    --- Valid data
    $returnJSON = new stdClass();
    $mysqlConn = new ErpInterface();
    

    // 1. Collect data
    $imprtObj = new ERPToERPWOExport();
    $imprtObj->debugmode = $debugmode;
    echo "Deduging Mode --> " . $imprtObj->debugmode;

    $WO_lines = $imprtObj->collectDataNSalesOrder();
    $NPO_lines = $imprtObj->collectDataNonpoProject();
    // Print data

    //2. Proccess Data
    $processData = $imprtObj->processData($WO_lines, $NPO_lines); // encode/decode and prepare object
    $processStatus = $processData['status'];
    if($processStatus != 'success') continue;
        
    // 3. Data writing
    $insertWO = $processData['insertWO'];
    $deleteWO = $processData['deleteWO'];
    $writeStatus = $imprtObj->writeData($insertWO, $deleteWO);
    if($writeStatus == 'success'){
    } else {  // writeStatus = fail
    }

    $imprtObj->close(); // close connection
    $mysqlConn->close(); // close connection


    echo "\n\n<br><br> ----- Last line executed -----------\n\n";

}
?>