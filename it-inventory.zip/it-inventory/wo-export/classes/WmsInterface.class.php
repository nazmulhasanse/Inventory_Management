<?php
class WmsInterface {

  public $conn;
  public $result;
  public $sql;
  public $queries = array();
  public $returnJSON;
  public $stid;
  public $rows = array();

  public function __construct($returnObj) {
    $this->returnJSON = $returnObj;
    $this->conn       = oci_connect('WMS_ERP', '123', '//10.96.68.11/orcl');
    //Check connection
    if ($this->conn->connect_error) {
      error_log("Failed to connect to database! " . $this->conn->connect_error, 0);
      die("Connection failed: " . $this->conn->connect_error);
    } else {
      echo "success";
    }
    return;
  }

  public function __destruct() {
    if (isset($this->stid)) {
      oci_free_statement($this->stid);
    }
    oci_close($this->conn);
  }

  public function query($sql) {
    $this->stid = oci_parse($this->conn, $sql);
    oci_execute($this->stid);
    if (substr($sql, 0, 6) == 'SELECT') {
      while (($row = oci_fetch_array($this->stid, OCI_ASSOC + OCI_RETURN_NULLS)) != false) {
        array_push($this->rows, $row);
      }
    } else {
//
    }
  }

  public function resultToArray() {
    $returnArray = array();
    foreach ($this->rows as $row) {
      array_push($returnArray, $row);
    }
    return $returnArray;
  }

  public function resultToTable() {
    $returnArray = array();
    $header      = "";
    foreach ($this->rows as $row) {
      $column = array();
      if ($header == "") {
        foreach ($row as $key => $value) {
          $column[] = $key;
        }
        $header = "<tr><th>" . join("</th><th>", $column) . "</th></tr>";
      }

      $column = array();
      foreach ($row as $key => $value) {
        $column[] = nl2br($value);
      }
      $returnArray[] = "<td>" . join("</td><td>", $column) . "</td>";
    }
    return "<table>
    " . $header . "
    <tr>" . join("</tr>
    <tr>", $returnArray) . "</tr>
  </table>";
  }

  public function loadQueries($queries) {
    $this->queries = $queries;
  }

  public function buildQueries($wms_list, $wms_lines) {
    $orcl_query = <<<EOF
      INSERT INTO "ERP_LIST"
      ("DOCACTION","SENDER","RECEIVER","DOCTYPE","COMPANY","DOCNUMBER","DOCTIME","SYNC","CREATETIME", "CREATEDBY","OTHERBARCODE","REMARKS",
      "FORMTYPE","SENDLOCATION","RECVLOCATION","PARTNERNAME","PARTNERADDRESS","INVOICENUMBER","CHALLANNUMBER","CONTAINERNUMBER","URGENCY",
      "PRODUCTIONFLOOR","BUYERNAME","DELIVERYADDRESS","REQUESTERBADGE","REQUESTEDDELIVERYTIME") VALUES (
      $wms_list->DOCACTION,
      $wms_list->SENDER,
      $wms_list->RECEIVER,
      $wms_list->DOCTYPE,
      $wms_list->COMPANY,
      $wms_list->DOCNUMBER,
      $wms_list->DOCTIME,
      $wms_list->SYNC,
      $wms_list->CREATETIME,
      $wms_list->CREATEDBY,
      $wms_list->OTHERBARCODE,
      $wms_list->REMARKS,
      $wms_list->FORMTYPE,
      $wms_list->SENDLOCATION,
      $wms_list->RECVLOCATION,
      $wms_list->PARTNERNAME,
      $wms_list->PARTNERADDRESS,
      $wms_list->INVOICENUMBER,
      $wms_list->CHALLANNUMBER,
      $wms_list->CONTAINERNUMBER,
      $wms_list->URGENCY,
      $wms_list->PRODUCTIONFLOOR,
      $wms_list->BUYERNAME,
      $wms_list->DELIVERYADDRESS,
      $wms_list->REQUESTERBADGE,
      $wms_list->REQUESTEDDELIVERYTIME
      )
EOF;
    array_push($this->queries, $orcl_query);

    foreach ($wms_lines as $wms_line) {
      $orcl_query = <<<EOF
      INSERT INTO "ERP_LINE"
      ("DOCNUMBER","LINENUMBER","ITEMCODE","OTHERBARCODE","DESCRIPTIONLINE1","DESCRIPTIONLINE2","QUALITYCLASS","LOTBATCHNUMBER","SERIAL",
        "QUANTITY","UOM","SYSMSG","WORKORDER","TRACKINGNO","MASTERREFERENCE","LIZORDERSL","BUYERPO","ITEMDESCRIPTION","ELEMENTUOM",
        "QUALITYINSTRUCTION","LOTTOTALQUANTITY","LOTTOTALELEMENTCOUNT","ELEMENTCOUNT") VALUES (
      $wms_line->DOCNUMBER,
      $wms_line->LINENUMBER,
      $wms_line->ITEMCODE,
      $wms_line->OTHERBARCODE,
      $wms_line->DESCRIPTIONLINE1,
      $wms_line->DESCRIPTIONLINE2,
      $wms_line->QUALITYCLASS,
      $wms_line->LOTBATCHNUMBER,
      $wms_line->SERIAL,
      $wms_line->QUANTITY,
      $wms_line->UOM,
      $wms_line->SYSMSG,
      $wms_line->WORKORDER,
      $wms_line->TRACKINGNO,
      $wms_line->MASTERREFERENCE,
      $wms_line->LIZORDERSL,
      $wms_line->BUYERPO,
      $wms_line->ITEMDESCRIPTION,
      $wms_line->ELEMENTUOM,
      $wms_line->QUALITYINSTRUCTION,
      $wms_line->LOTTOTALQUANTITY,
      $wms_line->LOTTOTALELEMENTCOUNT,
      $wms_line->ELEMENTCOUNT
      )
EOF;
      array_push($this->queries, $orcl_query);
    }

    $this->returnJSON->query = $this->queries;
  }

  /**
   * Execute the SQL queries but don't commit
   */
  public function runQueries() {
    foreach ($this->queries as $orcl_query) {
      error_log("ERP to WMS Insert Query--->" . $orcl_query);
      $this->stid = oci_parse($this->conn, $orcl_query);
      // $r = oci_execute($this->stid, OCI_DEFAULT);
      // error_log($orcl_query);
      $r = oci_execute($this->stid, OCI_NO_AUTO_COMMIT);
      if (!$r) {
        $e = oci_error($this->stid);
        // rollback changes to both tables
        oci_rollback($this->conn);
        array_push($this->returnJSON->errormsgs, $e['message']);
        // trigger_error(htmlentities($e['message']), E_USER_ERROR);
        return false;
      }
    }
    return true;
  }

  public function commit() {
    $r = oci_commit($this->conn);
    if (!$r) {
      $e = oci_error($this->stid);
      array_push($this->returnJSON->errormsgs, 'Error commiting changes to WMS.');
      array_push($this->returnJSON->errormsgs, $e['message']);
      // trigger_error(htmlentities($e['message']), E_USER_ERROR);
      $this->returnJSON->result = 'error';
      return false;
    } else {
      $this->returnJSON->result = 'success';
      return true;
    }
  }
}
/* Oracle table structure
ERP_LIST
Name                           Null     Type
------------------------------ -------- --------
DOCACTION                      NOT NULL CHAR(1)
SENDER                         NOT NULL CHAR(3)
RECEIVER                       NOT NULL CHAR(3)
DOCTYPE                        NOT NULL CHAR(8)
COMPANY                                 CHAR(3)
DOCNUMBER                               CHAR(30)
DOCTIME                                 DATE
SYNC                           NOT NULL NUMBER
CREATETIME                              DATE
CREATEDBY                      NOT NULL CHAR(30)
OTHERBARCODE                            CHAR(30)
REMARKS                                 CHAR(30)

ERP_LINE
Name                           Null     Type
------------------------------ -------- --------
DOCNUMBER                      NOT NULL CHAR(30)
LINENUMBER                     NOT NULL NUMBER
ITEMCODE                                CHAR(30)
OTHERBARCODE                            CHAR(30)
DESCRIPTIONLINE1                        CHAR(40)
DESCRIPTIONLINE2                        CHAR(40)
QUALITYCLASS                            NUMBER
LOTBATCHNUMBER                          CHAR(30)
SERIAL                                  CHAR(30)
QUANTITY                                NUMBER
UOM                                     CHAR(30)
WEIGHT                                  NUMBER
SRCDOCNUMBER                            CHAR(30)
SRCLINENUMBER                           NUMBER
LOCATION                                CHAR(30)
PALLET                                  CHAR(30)
BIN                                     CHAR(7)
INBDATE                                 DATE
SYSMSG                                  CHAR(30)
 */
?>