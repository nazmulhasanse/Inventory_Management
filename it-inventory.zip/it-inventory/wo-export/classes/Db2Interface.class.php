<?php
/**
* Author: Al-Mamun
* Date: 2017-04-05
*/
class  Db2Interface
{

	public $conn;
	public $result;
	public $stmt;
	public $sql;
	public $queries = array();
	public $returnJSON;
	public $rows = array();

	private $servername;
	private $username;
	private $password;
	private $dbname;

	
	public function __construct(){
		$database = 'NOWTST';
		// $serverIP = $_SERVER['SERVER_ADDR'];		
		$serverIP = $GLOBALS['SERVER_ADDR'];		
		if($serverIP == '10.1.2.21'){
			// $database = 'NOWLIZ';
		}
		$user     = 'db2admin';
		$password = 'atlante@liz1';
		$hostname = '10.1.2.49';
		$port     = 50000;

		$conn_string = "DRIVER={IBM DB2 ODBC DRIVER};DATABASE=$database;" .
		  "HOSTNAME=$hostname;PORT=$port;PROTOCOL=TCPIP;UID=$user;PWD=$password;";
		$conn = db2_connect($conn_string, '', '');

		if ($conn) {
			$this->conn = $conn;
		    // echo "Connection succeeded.";
		    // db2_close($conn);
		} else {
		    echo "Connection failed DB2";
		}

	}

	public function __destruct() {
		if (isset($this->conn)) {
			db2_close($this->conn);
		}
	}

	// encapsulate the query function of mysqli
	public function query($sql) {
		$this->sql    = $sql;
		$this->stmt = db2_exec($this->conn, $sql, array('cursor' => DB2_SCROLLABLE));
		return $this->stmt;
	}

	/**
	* Execute the SQL queries but don't commit
	*/
	public function runQueries($queries) {
		$this->queries = $queries;
		foreach ($this->queries as $db2_query) {
			$this->sql    = $db2_query;
			$r = db2_exec($this->conn, $this->sql, array('cursor' => DB2_SCROLLABLE));
	  		if (!$r) {
	  			echo "fail db2 query " . $this->sql;
	  			echo "<br>\n <b>Error Code: </b>" . db2_stmt_error();
	  			echo "<br>\n <b>Error Message: </b> " . db2_stmt_errormsg();	  			
	    		// $e = oci_error($this->stid);
	    		// rollback changes to both tables
	    		// oci_rollback($this->conn);
	    		// array_push($this->returnJSON->errormsgs, $e['message']);
	    		return false;
	  		}
		}
		return true;
	}


	public function begin_transaction($flags = null, $name = null) {
		if ($name != null) {
			return $this->conn->begin_transaction($flags, $name);
		} elseif ($flags != null) {
			return $this->conn->begin_transaction($flags);
		} else {
			return $this->conn->begin_transaction();
		}
	}

	public function autocommit($mode) {
		return $this->conn->autocommit($mode);
	}

	public function commit($flags = null, $name = null) {
		if ($name != null) {
			return $this->conn->commit($flags, $name);
		} elseif ($flags != null) {
			return $this->conn->commit($flags);
		} else {
			return $this->conn->commit();
		}
	}



	public function close() {
		$closereturn = db2_close($this->conn);    
		unset($this->conn);
		return $closereturn;
	}


	public function resultToArray($queryResult = null) {
		if ($queryResult === null) {
			$queryResult = $this->result;
		}
		$returnArray = array();
		while ($row = db2_fetch_assoc($queryResult)) {
			array_push($returnArray, $row);
		}
		return $returnArray;
	}

	public function resultToJson($queryResult = null) {
		if ($queryResult === null) {
		  $queryResult = $this->result;
		}
		$returnArray = array();
		while ($row = db2_fetch_assoc($queryResult)) {
		  array_push($returnArray, $row);
		}
		return json_encode(self::utf8ize($returnArray)); // static function utf8ize() solves JSON_ERROR_UTF8 error while encoding
	}

	public function sqlToJson($sql) {
		// For use in API
		// $queryResult = $this->conn->query($sql);
		$queryResult = db2_exec($this->conn, $sql, array('cursor' => DB2_SCROLLABLE));

		if (db2_num_rows($queryResult) > 0) {
			$returnJSON = self::resultToJson($queryResult);
		} else {
			//http_response_code(204);
			$returnJSON = "";
		}

		return $returnJSON;
	}

  	public function rowsToTable($rows) {
	    $returnArray = array();
	    $header      = "";
	    foreach ($rows as $indx => $row) {
	      $column = array();
	      if ($header == "") {
	        foreach ($row as $key => $value) {
	          $column[] = $key;
	        }
	        $header = "<tr><th>" . join("</th><th>", $column) . "</th></tr>";
	      }

	      $column = array();
	      foreach ($row as $key => $value) {
	        $column[] = nl2br($value);
	      }
	      $returnArray[] = "<td>" . join("</td><td>", $column) . "</td>";
	    }
	    return "<table>
	    " . $header . "
	    <tr>" . join("</tr>
	    <tr>", $returnArray) . "</tr>
	  </table>";

   	}

  	public function resultToTable($queryResult) {
	    if ($queryResult === null) {
	      $queryResult = $this->result;
	    }

	    $returnArray = array();
	    $header      = "";
	    while ($row = db2_fetch_assoc($queryResult)) {
	      $column = array();
	      if ($header == "") {
	        foreach ($row as $key => $value) {
	          $column[] = $key;
	        }
	        $header = "<tr><th>" . join("</th><th>", $column) . "</th></tr>";
	      }

	      $column = array();
	      foreach ($row as $key => $value) {
	        $column[] = nl2br($value);
	      }
	      $returnArray[] = "<td>" . join("</td><td>", $column) . "</td>";
	    }
	    return "<table>
	    " . $header . "
	    <tr>" . join("</tr>
	    <tr>", $returnArray) . "</tr>
	  </table>";
   	}

	public function sqlToTable($sql) {
		// For use in API
		$stmt = db2_exec($this->conn, $sql, array('cursor' => DB2_SCROLLABLE));
		$rows = db2_num_rows($stmt);
		if ($rows > 0) {
			$returnJSON = self::resultToTable($stmt);
		} else {
			//http_response_code(204);
			$returnJSON = "";	
		}
		return $returnJSON;
	}

	static function utf8ize($mixed) {
		if (is_array($mixed)) {
			foreach ($mixed as $key => $value) {
				$mixed[$key] = self::utf8ize($value);
			}
		} else if (is_string($mixed)) {
			return utf8_encode($mixed);
		}
		return $mixed;
	}


	public function trimElements($array){
		$returnArray = array();
		foreach ($array as $key => $value) {
			$returnArray[$key] = trim($value);
		}
		return $returnArray;
	}



	// public function rollBack(){
	// }

 //    public function loadQueries(){
 //    }

}
?>