<?php
/**
* Author AKL
* Date: 2020-03-15
*/
class ERPToERPWOExport extends ErpInterface
{
    
    public $debugmode = false;

    public function __construct(){
        parent::__construct();
        // calling parent constructor 
        // for getting connection
    }
    public function __destruct(){
    }

    public function collectDataNSalesOrder(){

$erp_sql = <<<EOF
SELECT 
    code, creationdatetime, creationuser
FROM
    erp_nsalesorder_line
    GROUP BY code
    ORDER BY idlines DESC 
EOF;
        if($this->debugmode) echo $erp_sql;
        $queryResult = $this->query($erp_sql);
        $data = $this->resultToArray($queryResult);
        return $data;

    }    

    public function collectDataNonpoProject(){

$erp_sql = <<<EOF
SELECT 
    projectcode
FROM
    erp_nonpo_project
    WHERE creationuser = 'system'
    GROUP BY projectcode
    ORDER BY idlines DESC   
EOF;
        if($this->debugmode) echo $erp_sql;
        $queryResult = $this->query($erp_sql);
        $data = $this->resultToArray($queryResult);
        return $data;

    }

    public function processData($WO_lines, $NPO_lines){

        $today = date('Y-m-d H:i:s', time());
        $WO_lines   = (object) $WO_lines;
        $NPO_lines   = (object) $NPO_lines;

                
        $WO_linesArray = array();
        foreach ($WO_lines as $lines) {
            foreach ($lines as $fieldname => $fieldvalue) {
                if($fieldname == 'code'){
                    array_push($WO_linesArray, $fieldvalue);  
                }
            }
        }        

        $NPO_linesArray = array();
        foreach ($NPO_lines as $lines) {
            foreach ($lines as $fieldname => $fieldvalue) {
                array_push($NPO_linesArray, $fieldvalue);
            }
        }

        $insertWO = array_diff($WO_linesArray,$NPO_linesArray);
        $deleteWO = array_diff($NPO_linesArray,$WO_linesArray);

        $processData = array(
            'status'   => 'success',
            'insertWO' => $insertWO,
            'deleteWO' => $deleteWO,
        );
        return $processData;

    }

    public function writeData($insertWO, $deleteWO){
        $today = date('Y-m-d H:i:s', time());
        $returnJSON            = new stdClass();
        $returnJSON->errormsgs = array();


        foreach ($insertWO as $fieldvalue) {
            if($fieldvalue == null) continue;
            $mysql_query = "INSERT INTO erp_nonpo_project (projectcode, projectname, costcenter, costdepartment, creationdatetime, creationuser) VALUES ('$fieldvalue', '$fieldvalue', 'Procurement', 'Supply Chain', '$today', 'system');";
            $queryResult = $this->query($mysql_query);
            if(!$queryResult){
                echo "<br>fail query - " . $mysql_query;
                return 'fail';
            }
        }        

        foreach ($deleteWO as $fieldvalue) {
            if($fieldvalue == null) continue;
            $mysql_query = "DELETE FROM erp_nonpo_project WHERE projectcode = '$fieldvalue';";
            $queryResult = $this->query($mysql_query);
            if(!$queryResult){
                echo "<br>fail query - " . $mysql_query;
                return 'fail';
            }
        }

        return 'success';

    }


    

}



?>