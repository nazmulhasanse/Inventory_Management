<?php
/**
 * Author: Al-Mamun
 * Date: 2018-04-18
 *
 * Purpose:
* NOW API for all common method
* and retrieve common data
*/
class NOWAPI extends Db2Interface
{
	public $query;
	public $queries = array();

	function __construct(){
		parent::__construct();
	}

    public function decodeCustomer($CustomerCode){
    	if($CustomerCode == '' || $CustomerCode == null) return '';
        $CustomerDesc = '';

        $db2_sql = "
            SELECT 
                p.CUSTOMERSUPPLIERCOMPANYCODE,
                p.CUSTOMERSUPPLIERTYPE,
                p.CUSTOMERSUPPLIERCODE,
                p.ORDERBUSINESSPARTNERNUMBERID,
                b.LEGALNAME1
            FROM
                DB2ADMIN.ORDERPARTNER p
                    LEFT JOIN
                DB2ADMIN.BUSINESSPARTNER b ON p.ORDERBUSINESSPARTNERNUMBERID = b.NUMBERID
            WHERE
                p.CUSTOMERSUPPLIERCODE = '$CustomerCode'
            FETCH FIRST 1 ROW ONLY
        ";

        $queryResult = $this->query($db2_sql);
        if (db2_num_rows($queryResult) > 0) {
            $row = db2_fetch_assoc($queryResult);
            $row = $this->trimElements($row);
            $CustomerDesc = $row['LEGALNAME1'];
            return $CustomerDesc;
        }
        return $CustomerDesc;
    }

    public function decodePaymentMethod($PaymentMethodCode){
        $PaymentMethodDesc = '';
        $db2_sql = "
            SELECT 
                COMPANYCODE,
                DIVISIONCODE,
                ALLOWEDDIVISIONS,
                CODE,
                LONGDESCRIPTION,
                SHORTDESCRIPTION,
                SEARCHDESCRIPTION
            FROM
                DB2ADMIN.PAYMENTMETHOD
            WHERE
                COMPANYCODE = '001' AND CODE = '$PaymentMethodCode'
        ";

        $data = $this->sqlToJson($db2_sql);
        $CustomerDesc = json_decode($data, true)[0]['SHORTDESCRIPTION'];
        return $CustomerDesc;
    }

    public function decodeAgent($AgentCode){
        $AgentDesc = '';
        $db2_sql = "
            SELECT 
                COMPANYCODE,
                DIVISIONCODE,
                ALLOWEDDIVISIONS,
                CODE,
                LONGDESCRIPTION,
                SHORTDESCRIPTION,
                SEARCHDESCRIPTION
            FROM
                DB2ADMIN.AGENT
            WHERE
                COMPANYCODE = '001' AND CODE = '$AgentCode'
        ";
        $data = $this->sqlToJson($db2_sql);
        $AgentDesc = json_decode($data, true)[0]['SHORTDESCRIPTION'];
        return $AgentDesc;
    }


    public function getSalesOrderCommision($SALESORDERCOMPANYCODE, $SALESORDERCOUNTERCODE, $SALESORDERCODE, $AGENTCODE){
        if($SALESORDERCOMPANYCODE == '' || $SALESORDERCOMPANYCODE == null) return '';
        if($SALESORDERCOUNTERCODE == '' || $SALESORDERCOUNTERCODE == null) return '';
        if($SALESORDERCODE == '' || $SALESORDERCODE == null) return '';
        if($AGENTCODE == '' || $AGENTCODE == null) return '';

        $CommisionValue = 1;

        $db2_sql = "
        SELECT 
            SALESORDERCOMPANYCODE,
            SALESORDERCOUNTERCODE,
            SALESORDERCODE,
            AGENTCODE,
            NUMBERID,
            SEQUENCE,
            COMMISSIONTYPE,
            COMMISSIONVALUE
        FROM
            DB2ADMIN.SALESORDERCOMMISSION
        WHERE
            SALESORDERCOMPANYCODE = '$SALESORDERCOMPANYCODE'
                AND SALESORDERCOUNTERCODE = '$SALESORDERCOUNTERCODE'
                AND SALESORDERCODE = '$SALESORDERCODE'
                AND AGENTCODE = '$AGENTCODE'
        ";

        $data = $this->sqlToJson($db2_sql);
        $CommisionValue = json_decode($data, true)[0]['COMMISSIONVALUE'];
        return $CommisionValue;

    }

    public function getProductGroupFamilies($COMPANYCODE, $ITEMTYPECODE, $SUBCODE01, $SUBCODE02, $SUBCODE03, $SUBCODE04, $SUBCODE05){
        if($COMPANYCODE == '' || $COMPANYCODE == null) return '';
        if($ITEMTYPECODE == '' || $ITEMTYPECODE == null) return '';
        if($SUBCODE01 == '' || $SUBCODE01 == null) return '';
        if($SUBCODE02 == '' || $SUBCODE02 == null) return '';

        if($ITEMTYPECODE == 'GPK'){
            $SUBCODE05 = '';
        } else if($ITEMTYPECODE == 'GPC'){
            $SUBCODE04 = '';
            $SUBCODE05 = '';
        }

        // check exceptinal for subcode
        // need to check atmost one
        $FamilyGrpCode = '';

        $db2_sql = "
        SELECT 
            COMPANYCODE,
            ITEMTYPECODE,
            SUBCODE01,
            SUBCODE02,
            SUBCODE03,
            SUBCODE04,
            SUBCODE05,
            SUBCODE06,
            SUBCODE07,
            SUBCODE08,
            SUBCODE09,
            SUBCODE10,
            FAMILYGRPCOMPANYCODE,
            FAMILYGRPCODE
        FROM
            DB2ADMIN.PRODUCT
        WHERE
            COMPANYCODE = '$COMPANYCODE' 
                AND ITEMTYPECODE = '$ITEMTYPECODE'
                AND SUBCODE01 = '$SUBCODE01'
                AND SUBCODE02 = '$SUBCODE02'
                AND SUBCODE03 = '$SUBCODE03'
                AND SUBCODE04 = '$SUBCODE04'
                AND SUBCODE05 = '$SUBCODE05'
        ";


        $data = $this->sqlToJson($db2_sql);
        $FamilyGrpCode = json_decode($data, true)[0]['FAMILYGRPCODE'];
        return $FamilyGrpCode;

    }

    public function getOrderPartnerBrandCode($ORDPRNCSMSUPPLIERCOMPANYCODE, $ORDPRNCUSTOMERSUPPLIERTYPE, $ORDPRNCUSTOMERSUPPLIERCODE, $CODE){

        if($ORDPRNCSMSUPPLIERCOMPANYCODE == '' || $ORDPRNCSMSUPPLIERCOMPANYCODE == null) return '';
        if($ORDPRNCUSTOMERSUPPLIERTYPE == '' || $ORDPRNCUSTOMERSUPPLIERTYPE == null) return '';
        if($ORDPRNCUSTOMERSUPPLIERCODE == '' || $ORDPRNCUSTOMERSUPPLIERCODE == null) return '';
        if($CODE == '' || $CODE == null) return '';

        $OrderPartnerBrandCode = '';

        $db2_sql = "
		SELECT 
		    ORDPRNCSMSUPPLIERCOMPANYCODE,
		    ORDPRNCUSTOMERSUPPLIERTYPE,
		    ORDPRNCUSTOMERSUPPLIERCODE,
		    CODE,
		    LONGDESCRIPTION,
		    SHORTDESCRIPTION,
		    SEARCHDESCRIPTION
		FROM
		    DB2ADMIN.ORDERPARTNERBRAND
		WHERE
		    ORDPRNCSMSUPPLIERCOMPANYCODE = '$ORDPRNCSMSUPPLIERCOMPANYCODE'
		        AND ORDPRNCUSTOMERSUPPLIERTYPE = '$ORDPRNCUSTOMERSUPPLIERTYPE'
		        AND ORDPRNCUSTOMERSUPPLIERCODE = '$ORDPRNCUSTOMERSUPPLIERCODE'
		        AND CODE = '$CODE'
        ";


        $data = $this->sqlToJson($db2_sql);
        $OrderPartnerBrandCode = json_decode($data, true)[0]['SHORTDESCRIPTION'];
        return $OrderPartnerBrandCode;

    }


    public function readNOWADDTData($UNIQUEID){
        $ADGB = new stdClass();
        if($UNIQUEID == '' || $UNIQUEID == null) return $ADGB;

        $db2_sql = "
        SELECT 
            UNIQUEID,
            NAMEENTITYNAME,
            NAMENAME,
            FIELDNAME,
            KEYSEQUENCE,
            SHARED,
            DATATYPE,
            VALUESTRING,
            VALUEINT,
            VALUEBOOLEAN,
            VALUEDATE,
            VALUEDECIMAL,
            VALUELONG,
            VALUETIME,
            VALUETIMESTAMP,
            ABSUNIQUEID
        FROM
            DB2ADMIN.ADSTORAGE
        WHERE
            UNIQUEID = '$UNIQUEID'
        ";
        $queryResult = $this->query($db2_sql);
        if (db2_num_rows($queryResult) > 0) {
            $ADData = $this->resultToArray($queryResult);
            foreach ($ADData as $indx => $thisLine) {
                $thisLine = $this->trimElements($thisLine);

                $FIELDNAME = $thisLine['FIELDNAME'];
                $VALUESTRING = $thisLine['VALUESTRING'];
                $VALUEDATE = $thisLine['VALUEDATE'];
                $VALUEBOOLEAN = $thisLine['VALUEBOOLEAN'];

                if($VALUESTRING != '' && $VALUESTRING != null){
                    $ADGB->$FIELDNAME = $VALUESTRING;
                } else if($VALUEDATE != '' && $VALUEDATE != null){
                    $ADGB->$FIELDNAME = $VALUEDATE;
                } else if($VALUEBOOLEAN != '' && $VALUEBOOLEAN != null){
                    $ADGB->$FIELDNAME = $VALUEBOOLEAN;
                }
                
            }

        }
        return $ADGB;

    }



    public function decodeAddress($UNIQUEID, $CODE){
        if($UNIQUEID == '' || $UNIQUEID == null) return '';
        if($CODE == '' || $CODE == null) return '';

        $db2_sql = "
        SELECT 
            UNIQUEID,
            CODE,
            ADDRESSTYPE,
            ADDRESSEE,
            COUNTRYCODE,
            ADDRESSLINE1,
            ADDRESSLINE2,
            ADDRESSLINE3,
            ADDRESSLINE4,
            ADDRESSLINE5,
            POSTALCODE,
            TOWN,
            DISTRICT,
            ABSUNIQUEID
        FROM
            DB2ADMIN.ADDRESS
        WHERE
            UNIQUEID = '$UNIQUEID' AND CODE = '$CODE'
        ";

        $data = $this->sqlToJson($db2_sql);
        $AddressDesc = json_decode($data, true)[0]['ADDRESSLINE1'];
        return $AddressDesc;

    }

    public function retrieveProductInfo($ProductSpecGB){
        // organize data
        if( isset($ProductSpecGB->ITEMTYPEAFICODE) ){
            $ProductSpecGB->ITEMTYPECODE = $ProductSpecGB->ITEMTYPEAFICODE;
        }

        if($ProductSpecGB->ITEMTYPECODE == '' || $ProductSpecGB->ITEMTYPECODE == null) return false;
        if($ProductSpecGB->SUBCODE01 == '' || $ProductSpecGB->SUBCODE01 == null) return false;
        if($ProductSpecGB->SUBCODE02 == '' || $ProductSpecGB->SUBCODE02 == null) return false;
        if($ProductSpecGB->SUBCODE03 == '' || $ProductSpecGB->SUBCODE03 == null) return false;

        $COMPANYCODE  = '001';
        $ITEMTYPECODE = $ProductSpecGB->ITEMTYPECODE;
        $SUBCODE01    = $ProductSpecGB->SUBCODE01;
        $SUBCODE02    = $ProductSpecGB->SUBCODE02;
        $SUBCODE03    = $ProductSpecGB->SUBCODE03;
        $SUBCODE04    = $ProductSpecGB->SUBCODE04;
        $SUBCODE05    = $ProductSpecGB->SUBCODE05;
        $SUBCODE06    = $ProductSpecGB->SUBCODE06;
        $SUBCODE07    = $ProductSpecGB->SUBCODE07;
        $SUBCODE08    = $ProductSpecGB->SUBCODE08;
        $SUBCODE09    = $ProductSpecGB->SUBCODE09;
        $SUBCODE10    = $ProductSpecGB->SUBCODE10;

        if($ITEMTYPECODE == 'GPK'){
            $SUBCODE05 = '';
        } else if($ITEMTYPECODE == 'GPC'){
            $SUBCODE04 = '';
            $SUBCODE05 = '';
        }

        $productGB    = new stdClass();

        $db2_sql = "
        SELECT 
            COMPANYCODE,
            ITEMTYPECODE,
            SUBCODE01,
            SUBCODE02,
            SUBCODE03,
            SUBCODE04,
            SUBCODE05,
            SUBCODE06,
            SUBCODE07,
            SUBCODE08,
            SUBCODE09,
            SUBCODE10,
            LONGDESCRIPTION,
            SHORTDESCRIPTION,
            SEARCHDESCRIPTION,            
            FAMILYGRPCOMPANYCODE,
            FAMILYGRPCODE
        FROM
            DB2ADMIN.PRODUCT
        WHERE
            COMPANYCODE = '$COMPANYCODE' 
                AND ITEMTYPECODE = '$ITEMTYPECODE'
                AND SUBCODE01 = '$SUBCODE01'
                AND SUBCODE02 = '$SUBCODE02'
                AND SUBCODE03 = '$SUBCODE03'
                AND SUBCODE04 = '$SUBCODE04'
                AND SUBCODE05 = '$SUBCODE05'
                AND SUBCODE06 = '$SUBCODE06'
                AND SUBCODE07 = '$SUBCODE07'
                AND SUBCODE08 = '$SUBCODE08'
                AND SUBCODE09 = '$SUBCODE09'
                AND SUBCODE10 = '$SUBCODE10'
        ";

        // echo "<br><br>Product Spec" . $db2_sql;
        $data = $this->sqlToJson($db2_sql);
        $productGB = json_decode($data)[0];
        return $productGB;

    }



}
?>