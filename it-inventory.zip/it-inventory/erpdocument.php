<?php
$directory = __DIR__ ;
require_once $_SERVER["DOCUMENT_ROOT"] . '/includes/configli.php'; // mysql connections
require_once $_SERVER['DOCUMENT_ROOT'] . "/includes/user.cookies.php";
require_once $_SERVER['DOCUMENT_ROOT'] . "/includes/user-privilege.php";
require_once __DIR__ . "/classes/myclassautoloader.php";
// include_once 'url-history.php';

// check privilege (keep module and section empty to skip privilege check)
$module    = "";
$section   = "";
$privilege = userPrivileges($module, $section);
if (!$privilege['R']) {header("Location: ../user/no-permission.php");exit();}

if (isset($_GET['doctype'])) {
  $doctype = $_GET['doctype'];
}
if (isset($_GET['formtype'])) {
  $formtype = $_GET['formtype'];
} else {
  $formtype = 'default';
}


if ($doctype == 'MX') {
    $form      = new ErpDocumentMX();
} else if($doctype == 'SO'){
    $form      = new ErpDocumentSO();
    $homePageLink = 'documents-home.php';
    $listlink = '/erp-apparel/list-so.php?formtype='.$formtype;
    $listtitle = 'Sales Order';
} else if($doctype == 'PO' && $formtype == 'PO'){

    $form      = new ErpDocumentPO();

    $homePageLink = 'documents-home.php';
    
    $listlink = '';
    $listtitle = 'Purchase Order';

} else if($doctype == 'PO' && $formtype == 'ACS'){

    $form      = new ErpDocumentPOACS();

    $homePageLink = 'documents-home.php';
    
    $listlink = '';
    $listtitle = 'Purchase Order';

} else if($doctype == 'PO' && $formtype == 'ELS'){

    $form      = new ErpDocumentPOELS();

    $homePageLink = 'documents-home.php';
    
    $listlink = '';
    $listtitle = 'Purchase Order';

} else if($doctype == 'PO' && $formtype == 'CTN'){

    $form      = new ErpDocumentPOCTN();

    $homePageLink = 'documents-home.php';
    
    $listlink = '';
    $listtitle = 'Purchase Order';

} else if($doctype == 'GRN'){

    $form      = new ErpDocumentNonPoGRN();

    $homePageLink = 'documents-home.php';
    
    $listlink = '';
    $listtitle = 'Goods Receipt Note';

} else if($doctype == 'TF'){

    $form      = new ErpDocumentNonPoTF();

    $homePageLink = 'documents-home.php';
    
    $listlink = '';
    $listtitle = 'Transfer Document';

} else if($doctype == 'PR' && $formtype == 'PR'){
      
    $form      = new ErpDocumentPR();

    $homePageLink = 'documents-home.php';
    
    $listlink = '/erp-nonpo/list-rr-po-wo-creation.php';
    $listtitle = 'Purchase Requisition';
} else if($doctype == 'CR' && $formtype == 'CR'){
      
    $form      = new ErpDocumentCR();

    $homePageLink = 'inv_documents-home.php';
    
    $listlink = '/erp-nonpo/list-requisition.php';
    $listtitle = 'Capex Requisition';
} else if($doctype == 'TI' && $formtype == 'TI'){
      
    $form      = new ErpDocumentTI();

    $homePageLink = '/it-inventory/';
    
    $listlink = '/it-inventory/list-inventory.php';
    $listtitle = 'INT Inventory';
} else if($doctype == 'IPO' && $formtype == 'IPO'){
      
    $form      = new ErpDocumentIPO();

    $homePageLink = 'inv_documents-home.php';
    
    $listlink = '/erp-nonpo/list-int-po.php';
    $listtitle = 'INT PO List';
} else if($doctype == 'PR' && $formtype == 'ACS'){
      
    $form      = new ErpDocumentPRACS();

    $homePageLink = 'documents-home.php';
    
    $listlink = '/erp-nonpo/list-rr-po-wo-creation.php?itemtype=ELS';
    $listtitle = 'Purchase Requisition';
} else if($doctype == 'PR' && $formtype == 'ELS'){
      
    $form      = new ErpDocumentPRELS();

    $homePageLink = 'documents-home.php';
    
    $listlink = '/erp-nonpo/list-rr-po-wo-creation.php?itemtype='.$formtype;
    $listtitle = 'Purchase Requisition';
} else if($doctype == 'PR' && $formtype == 'CTN'){
      
    $form      = new ErpDocumentPRCTN();

    $homePageLink = 'documents-home.php';
    
    $listlink = '/erp-nonpo/list-rr-po-wo-creation.php?itemtype='.$formtype;
    $listtitle = 'Purchase Requisition';
} else if($doctype == 'BILL'){
      
    $form      = new ErpDocumentIctBill();

    $homePageLink = '/erp-nonpo/ict-billing-home.php';
    
    $listlink = '/erp-nonpo/list-ict-bills.php';
    $listtitle = 'ICT Billing List';
} else if($doctype == 'HBILL'){
      
    $form      = new ErpDocumentIctBillHeader();

    $homePageLink = '/erp-nonpo/ict-billing-home.php';
    
    $listlink = '/erp-nonpo/list-ict-bills.php';
    $listtitle = 'ICT Billing List';
}  else {
  // redirect to error page
  // echo "erpdocument.php: received unknown doctype " . $doctype;
  // exit();
}

$viewFlag = '';
if(isset($_GET['viewflag']) && $_GET['viewflag'] != ''){
  $viewFlag = $_GET['viewflag'];
}
$formStructure = $form->formStructure($doctype, $formtype, $viewFlag);

// page tittle replace if docnumber have in URL
if(isset($_GET['docnumber']) && $_GET['docnumber'] != ""){
  $pageTittle = $_GET['docnumber'] . ' ' . $form->formTitle;
} else if(isset($_GET['materiallistid']) && $_GET['materiallistid'] != ""){
  $pageTittle = $_GET['materiallistid'] . ' ' . $form->formTitle;
} else {
  $pageTittle = 'New - '. $form->formTitle;
}

/**
 * Back button work
 */
$_URL_PREVIOUS = '';
if(!isset($_SESSION['_URL_CURRENT'])){
  $_SESSION['_URL_CURRENT'] = basename($_SERVER['REQUEST_URI']);
  $_SESSION['_URL_PREVIOUS'] = $_URL_PREVIOUS;
}
if($_SESSION['_URL_CURRENT'] == basename($_SERVER['REQUEST_URI'])){ // if user reload this page
  $_URL_PREVIOUS = $_SESSION['_URL_PREVIOUS'];
}
$backButton = '<button type="button" class="btnReadMode mBtoA btn-generic" title="Home" onclick="javascript:window.location.href='. "'" .$_URL_PREVIOUS . "'" .'" style="display: inline-block;"><img class="valign" src="img/back.png" width="30" height="25"></button>';  
?>
<!DOCTYPE HTML>
<html>
<?php
echo "<head>";
require_once $_SERVER['DOCUMENT_ROOT'] . "/includes/head.php";
echo "    <title>$pageTittle</title>";
echo "</head>";
?>


<body class="right-sidebar">

<!-- Header Wrapper -->
<div id="header-wrapper">
<div class="container">
<div class="row">
<div class="12u">
<!-- Header -->
  <header id="header">
    <?php include_once $_SERVER['DOCUMENT_ROOT'] . "/includes/mainmenu.php";?>
    <link rel="stylesheet" href="<?php echo $form->URL_DOCCSS; ?>"/>
    <link rel="stylesheet" type="text/css" href="css/custom-button.css">
  </header>
</div>
</div>
</div>
</div>

<!-- Main Wrapper -->
<div id="main-wrapper">
<div class="container">
<div class="row">
  <div class="12u skel-cell-important">
    <!-- Content -->
    <div id="content">
    <article class="last">
<!-- LINKS -->
    <div id="upperLinkBar" style="display:block; margin-top:-3pt;">
        <a href="<?php echo $homePageLink;?>" class="valign" style="">Home</a> &nbsp;|&nbsp;
      <?php if($doctype == "FM"){?>
        <a href="<?php echo $listlink;?>" class="valign" style="">List of <?php echo $listtitle;?></a> &nbsp;|&nbsp;
        <!-- <a href="<?php echo $listlink1;?>" class="valign" style="">List of <?php echo $listtitle1;?></a> &nbsp;|&nbsp; -->
        <!-- <a href="<?php echo $listlink2;?>"  target="_blank" class="valign" style="">List of <?php echo $listtitle2;?></a> &nbsp;|&nbsp; -->
      <?php } else{?>
        <a href="<?php echo $listlink;?>" class="valign" style="">List of <?php echo $listtitle;?></a> &nbsp;|&nbsp;
      <?php }?>

      <!-- <a href="<?php echo $form->URL_DOCDOCSEARCH . "?doctype=" . $doctype. "&formtype=" . $formtype; ?>"><b>List</b> of <?php echo $form->formTitle; ?></a> &nbsp;|&nbsp; -->
      <?php
      if (userPrivileges('', '') && $doctype == "SO" && $formtype != 'under_projection') {
        // echo "<a href='$form->URL_DOCDOCFORM&formtype=$formtype'><b>Create New</b> $form->formTitle</a>";
      }
      ?>
    </div>
    <br>

<!-- PAGE CONTENTS -->
<?php
if($doctype == 'FM'){
echo <<<php
  <div id="docHeaderButton">
  </div>
  <br/>
  <div id="formCaptionX" style="display:block;">
    <div class="wX40 text_left"></div>
    <div class="wX20 text_center">
      <span id="spandocnumberX"></span>
    </div>
    <div class="wX40 text_right">
      <span id="spandocstatusX"></span>
    </div>
    <div class="clearfix"></div>
  </div>

  <div id="docHeaderContainer">
  <br>
  <div id="docHeaderInfo">
  </div>
  <!-- if exist not mandatory -->
  </div>
php;

echo <<<php
      <ul class="tabs" data-persist="true">
            <li><a href="#view1">Fabric  List</a></li>
      </ul>
      <div class="tabcontents">
          <div id="view1">

php;
$form->buildForm();
echo <<<php
          </div>
php;
// $form->buildForm();
echo <<<php
php;
} else {

  $form->buildForm();

}
?>

    </article>
    </div>
  </div>
</div>
</div>
</div>


<style type="text/css">
#ghostbar {
  width:3px;
  background-color:#000;
  opacity:0.5;
  position:absolute;
  cursor: col-resize;
  z-index:999
}
</style>


<!-- Footer Wrapper -->
<div id="footer-wrapper">
  <?php include_once $_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php";?>
</div>

<script type="text/javascript" src="/js/fancybox/jquery.fancybox.js"></script>
<script type="text/javascript" src="/js/erp_lib.js"></script>
<script type="text/javascript" src="api/client_api.js"></script>
<script type="text/javascript" src="<?php echo $form->URL_MAINJS . '?v=2019-06-20'; ?>"></script>
<script type="text/javascript" src="<?php echo $form->URL_DOCJS . '?v=2020-11-03'; ?>"></script>
<script type="text/javascript" src="<?php echo $form->URL_DOCJS_CUSTOMIZATION . '?v=2020-11-03'; ?>"></script>
<script type="text/javascript">
var interval;
interval = setInterval(checkFormIsFullyLoaded, 50000); // 50 second

$( document ).ready( function() {
  var _ERP_DOCACRONYM = '<?php echo $form->_ERP_DOCACRONYM; ?>';
  var _URL_DOCUMENTAPI = '<?php echo $form->_URL_DOCUMENTAPI; ?>';
  var _URL_DOCDEFINEAPI = '<?php echo $form->_URL_DOCDEFINEAPI; ?>';
  var _ERP_DOCTYPE = '<?php echo $form->_ERP_DOCTYPE; ?>';
  erpdocument.processForm( '#<?php echo $form->formId; ?>', _ERP_DOCTYPE, _URL_DOCUMENTAPI, _URL_DOCDEFINEAPI);
} );

function checkFormIsFullyLoaded(){
  clearInterval(interval);

  var x =  document.getElementById('erpFormProcessingOverlay-body');
  if (typeof(x) != 'undefined' && x != null){ // exists. // fail to load form  
    var formERP = document.getElementById('formERP');
    formERP.setAttribute("style", "display: none;");

    var y = document.getElementById('erpFormProcessingOverlay');
    y.innerHTML = '<div style="text-align:center;">\
      <span style="font-weight:bold; color:orange; font-size:17px;"><i class="material-icons">warning</i>Failed to load document form. Click below button for load from again</span><br><br>\
      <button type="button" class="btn-blue" onclick="return location.reload();" >Click here to load document form again</button>\
      </div>';
  } else {
      // form loaded successfully
  } 
}
</script>

</body>
</html>