<?php
session_start();
$directory = __DIR__ ;
require_once $_SERVER["DOCUMENT_ROOT"] . '/includes/configli.php';         // mysql connections
require_once __DIR__ . "/classes/myclassautoloader.php";
/**
* ThisListAPI class
*/
class ThisListAPI
{	
	public $conn;
	public $queryResult;
	public $sql;
	public $dbname;

	public $rrStatusTransaltor = array(
		'0' => 'New',
		'1' => 'Allocated',
		'2' => 'Sent for Recalculation',
		'3' => 'PO Created',
		'4' => 'PO Sent',		
		'5' => 'WO Created',
		'6' => 'WO Sent',
		'7' => 'Partially Consumed',
		'8' => 'Consumed',
		'9' => 'Closed',
		'10' => 'Frozen',
		'11' => 'Cancelled',
		'12' => 'Partially Inhoused',
		'13' => 'Inhoused',
		'901'=> 'Archived',
		);

	public $poStatusTransaltor = array(
      '0' => 'Entered',
      '1' => 'Sent to Textile',
      '2' => 'Sent to NOW',
      '100K' => 'Fake'
      );

	public $rrFieldTranslator = array(
		'company' => 'Division',
		'endcustomer' => 'End Customer',
		'itemtype' => 'Item Type',
		'itemcode' => 'Item Code',
		'itemdescription' => 'Item Description',
		'requiredgrossqty' => 'Required Qty',
		'requirednetqty' => 'Required Net Qty',
		'iduom' => 'UOM',
		'pieceqty' => 'Piece Qty',
		'totalpieceqty' => 'Total Piece Qty',
		'sewingstartdate' => 'Sewing Start Date',
		'sewingfinisheddate' => 'Sewing Finished Date',
		'outputperlineperday' => 'Output per Line per Day',
		'processbeforesewing' => 'Process Before Sewing',
		'processaftersewing' => 'Process After Sewing',
		'bomdocnumber' => 'BOM No.',
		'bomlinenumber' => 'BOM Line No.',
		'previousitemcode' => 'previousitemcode',
		'previousfmdocnumber' => 'previousfmdocnumber',
		'cpdocnumber' => 'CP No.',
		'ldcslnumber' => 'Sales Order Item Line No.',
		'salesorder' => 'Sales Order',
		'rrtype' => 'rrtype',
		'unitprice' => 'unitprice',
		'pricerequisitionnumber' => 'pricerequisitionnumber',
		'fmdocnumber' => 'fmdocnumber',
		'projectionfmdocnumber' => 'projectionfmdocnumber',
		'cplineno' => 'CP Line No.',
		'designid' => 'Design ID',
	);


	public $lineStatusTransaltor = array(
		// '0' => 'New',
		// '1' => '',
		// '2' => '',
		// '3' => 'Sent for reprocessing',
		// '4' => 'Sent for re-calculation',

		'0' => '', // if rrstatus = 1 and linestatus = 0, then its newly created by stock allocation
		'1' => 'Sent to PO creation',
		'2' => '',
		'3' => 'Sent for re-processing',
		'4' => 'Sent for re-calculation',
		'5' => '',
		);


	public function __construct($dbnum = 1) {
		if ($dbnum === '2') {
			$this->conn = new ErpDbConn('2');
			$this->dbname = "erpprod_bulbul";
		} else {
			$this->conn = new ErpDbConn;
			$this->dbname = "erpprod";
		}
	}

	function getNextDocNumber($counterName){
	    $conn = new ErpDbConn;
	    $sql = "SELECT prefix, nextnumber from erp_counter where countername='$counterName'";
	    $prefix        = json_decode($conn->sqlToJson($sql), true)[0]['prefix'];
	    $currentdocnum = json_decode($conn->sqlToJson($sql), true)[0]['nextnumber'];

	    $sql = "UPDATE erp_counter SET nextnumber=(nextnumber+1) where countername='$counterName'";
	    $qresult = $conn->query($sql);

	    if($qresult){
	        return $prefix . "-".$currentdocnum;
	    }
	}

	function getListData($params) {

		$fieldArray = array(
			'idlines'                      => '`rr`.`idlines`',
			'recalculationbit'			   => '`rr`.`recalculationbit`',
			'rrnumber'                     => '`rr`.`rrnumber`',
			'rrtype'                       => '`rr`.`rrtype`',
			'rrstatus'                     => '`rr`.`rrstatus`',
			// 'linestatus'				   => '`rr`.`linestatus`',
			'salesorder'                   => '`rr`.`salesorder`',
			'powonumber'                   => '`rr`.`powonumber`',
			'powolinenumber'               => '`rr`.`powolinenumber`',
			'postatus'               	   => 'virtual',
			'parentrrnumber'               => '`rr`.`parentrrnumber`',
			'company'                      => '`rr`.`company`',
			'endcustomer'                  => '`rr`.`endcustomer`',
			'colorcategory'                => '`rr`.`colorcategory`',
			'designid'                	   => '`rr`.`designid`',
			'itemtype'                     => '`rr`.`itemtype`',
			'itemcode'                     => '`rr`.`itemcode`',
			'itemdescription'              => '`rr`.`itemdescription`',
			'requiredgrossqty'             => '`rr`.`requiredgrossqty`',
			'actualdeductionqty'           => 'virtual',
			'requirednetqty'               => 'virtual',

			'deliverybreakdown'            => 'virtual',
			'dlvbrktext'                   => '`rr`.`dlvbrktext`',
			'previousinfo'                 => '`rr`.`previousinfo`',
			'iduom'                        => '`rr`.`iduom`',
			'ldcslnumber'                  => '`rr`.`ldcslnumber`',

			'replenishedby'            	   => 'virtual',
			'underprojectionso'            => 'virtual',
					
			'bomdocnumber'                 => '`rr`.`bomdocnumber`',
			'bomlinenumber'                => '`rr`.`bomlinenumber`',
			'cpdocnumber'                  => '`rr`.`cpdocnumber`',
			'isrrfreezed'                  => '`rr`.`isrrfreezed`',
			'origin'                       => '`rr`.`origin`',
			'projectionsalesorder'         => '`rr`.`projectionsalesorder`',
			
			'publishedplannedeta'          => '`rr`.`publishedplannedeta`',
			'publishedplannedqty'          => '`rr`.`publishedplannedqty`',	

		);

		$groupArray = array(
			'idlines'       => 'idlines',
		);
		
		$whereClauses = array(
			"(1=1)",
			"(`rr`.`rrstatus` != '901')",
			"(`rr`.`mergeorsplit` = '0')",
		);		
		
		// Process field clause
		$fieldClause = array();
		foreach ($fieldArray as $fieldKey => $fieldValue) {
			if($fieldValue == 'virtual'){
				array_push($fieldClause, "''" . ' AS `' . $fieldKey . '`');
			}else{
				array_push($fieldClause, $fieldValue . ' AS `' . $fieldKey . '`');
			}
		}
		$fieldClause = implode(' , ', $fieldClause);

		// Process group clause
		$groupClause = array();
		foreach ($groupArray as $groupField) {
			array_push($groupClause, $fieldArray[$groupField]);
		}
		$groupClause = implode(' , ', $groupClause);

		// applying custom rules
		// if(isset($params['salesorder'])){
			$salesorder = $params['salesorder'];
			// $sql = "SELECT formtype, parentdocnumber FROM erp_salesorder WHERE docnumber = '$salesorder'";
			// $queryResult = $this->conn->query($sql);
			// $row = $queryResult->fetch_assoc();
			// $formtype = $row['formtype'];

			// if($formtype == 'under_projection'){
			// 	$projectionsalesorder = $row['parentdocnumber'];
				// array_push($whereClauses, "((`rr`.`salesorder`='".$params['salesorder']."') OR (`rr`.`salesorder` = '$projectionsalesorder'))");
				array_push($whereClauses, "(`rr`.`salesorder`='".$params['salesorder']."' OR `rr`.`salesorder` IN (SELECT docnumber FROM erp_salesorder WHERE parentdocnumber='".$params['salesorder']."'))");
				// unset($params['salesorder']);					
			// }			
		// }

		// Process where clause
		$searchParams = $params;
		unset($searchParams['showLimit']);
		unset($searchParams['pageNum']);
		unset($searchParams['reqType']);		
		unset($searchParams['output']);		
		unset($searchParams['print']);
		unset($searchParams['sMsg']);		
		unset($searchParams['eMsg']);		
		unset($searchParams['wMsg']);
		unset($searchParams['_']);

		unset($searchParams['salesorder']);		
		unset($searchParams['rrtype']);		
		if (isset($searchParams) && count($searchParams) > 0) {
			foreach ($searchParams as $paramkey => $paramvalue) {
				if($paramvalue == "") unset($searchParams[$paramkey]);
			}
            foreach ($searchParams as $paramkey => $paramvalue) {
              // $compositeClauses = array("1=1",);
              $compositeClauses = array();
              $compositeParamkey = explode("__", $paramkey);
              $compositeParamVal = explode(",__", $paramvalue);

              if(sizeof($compositeParamkey) > 1 && sizeof($compositeParamVal) > 1 ){
                foreach ($compositeParamkey as $key => $fieldname) {
                	$fieldvalue = $compositeParamVal[$key];
                	if($fieldvalue == ""){
                		continue;
                	} else if(strpos($fieldvalue, '_to_') !== false){
						$from_to_dates = explode('_to_', $fieldvalue);
						$form_date = $from_to_dates[0];
						$to_date = $from_to_dates[1];
						array_push($compositeClauses, "( $fieldArray[$fieldname] BETWEEN '$form_date' AND '$to_date')");
	                } else {
	                  	array_push($compositeClauses, "( $fieldArray[$fieldname] LIKE '%" . $fieldvalue. "%')");
	                }  	
                }
                $compositeClause = '(' . implode(' AND ', $compositeClauses) .')';
                array_push($whereClauses, $compositeClause);

              } else if(sizeof($compositeParamkey) > 1){
                foreach ($compositeParamkey as $key => $fieldname) {
                  array_push($compositeClauses, "( $fieldArray[$fieldname] LIKE '%" . $paramvalue . "%')");
                }
                $compositeClause = '(' . implode(' OR ', $compositeClauses) . ')';
                array_push($whereClauses, $compositeClause);

              } else{
              	if(strpos($paramvalue, '_to_') !== false){ // date field search
              		$from_to_dates = explode('_to_', $paramvalue);
              		$form_date = $from_to_dates[0];
              		$to_date = $from_to_dates[1];
              		array_push($whereClauses, "( $fieldArray[$paramkey] BETWEEN '$form_date' AND '$to_date')");
              	} else {									 // normal field search
              		array_push($whereClauses, "( $fieldArray[$paramkey] LIKE '%" . $paramvalue . "%')");
              	}
              }
            }
		}
		$whereClause = implode(' AND ', $whereClauses);


		      //----------------- Buyer Privilege Start-----------------------------
      // $buyerPrivilege = json_decode($_SESSION['buyerprivilege2'], true);
      // $countBuyerNumber = count($buyerPrivilege);
      // if($countBuyerNumber == 0){
      //   $buyerPrivilege = "";
      // } else {
      //   $buyerPrivilege = "'" . implode("', '", $buyerPrivilege) . "'";
      //   $buyerPrivilege = " AND `rr`.`endcustomer` IN ($buyerPrivilege)"; // change here
      // }
      //----------------- Buyer Privilege End-------------------------------
      $whereClause .= $buyerPrivilege;


  		$sql = <<<EOF
SELECT
  $fieldClause
FROM
  `erp_rrlines` `rr`
WHERE $whereClause
GROUP BY $groupClause
ORDER BY FIELD(`rr`.`rrtype`, 'projection', 'under_projection'), idlines desc
EOF;
// return $sql;

		/**
		 * Pagination work
		 * Very important to set the page number first.
		 */
		$pageNum = (!isset($params['pageNum'])) ? 1 : intval($params['pageNum']);
		/**
		 * Number of results displayed per page 	by default its 10.
		 */
		$showLimit =  ($params["showLimit"] <> "" && is_numeric($params["showLimit"]) ) ? intval($params["showLimit"]) : 10;

		/**
		 * Get the total number of rows in the table
		 */
		$countSql = $sql ;
		$queryResult = $this->conn->query($countSql);
		$queryRowsNum = $queryResult->num_rows;
		/**
	    * if no record found then, apply
	    */
	    if($queryRowsNum == 0){
		   $tableParts = explode("\n", $sql);
		   $mainTableName = $tableParts[3];

		   // $tableParts = explode("WHERE", $sql);
		   // $joinedSql = substr($sql, 0,strripos($sql, 'WHERE'));
		   $joinedSql = $tableParts[0] . $tableParts[1] . $tableParts[2] . $tableParts[3];
		   $maxidSql= "SELECT @last_id := MAX(idlines) FROM $mainTableName";
		   $fakeSql = "$joinedSql WHERE idlines = @last_id"; 
		   $this->conn->query($maxidSql);
		   // return $fakeSql;
		   $queryResult = $this->conn->query($fakeSql);
		   // echo "maxidSql -- " . $maxidSql . "<br/><br/> fakeSql -- " . $fakeSql;
		   $data = array();
			while ( $rows = $queryResult->fetch_assoc() ) {
			  array_push($data, $rows);
			}

			$returnJson = "";
			$returnArray = array();
			$returnArray['listData']     = $data;
			$returnArray['noResult']     = true;
			$returnArray['queryRowsNum'] = $queryRowsNum;
			$returnArray['showLimit']    = $showLimit; // per page limit
			$returnArray['pageNum']      = 0;
			$returnArray['lastPageNum']  = 0;
			$returnJson = json_encode($returnArray);
			return $returnJson;
		}

		/**
		 * Calculate the lastPageNum page based on total number of rows and rows per page. 
		 */
		$lastPageNum = ceil($queryRowsNum/$showLimit); 

		/**
		 * this makes sure the page number isn't below one, or more than our maximum pages 
		 */
		if ($pageNum < 1) { 
		  $pageNum = 1; 
		} elseif ($pageNum > $lastPageNum)  { 
		  $pageNum = $lastPageNum; 
		}
		$lowerLimit = ($pageNum - 1) * $showLimit;

		// $sql2 = " SELECT * FROM tbl_pagination WHERE 1 LIMIT ". ($lowerLimit)." ,  ". ($showLimit). " ";
		$sql = $sql . " LIMIT ". ($lowerLimit)." ,  ". ($showLimit). " ";

		$queryResult = $this->conn->query($sql);
		$lnddcObj = new ErpLibraryDecoder();
		$data = array();
		while ( $rows = $queryResult->fetch_assoc() ) {

			// if($rows['rrstatus'] == 1 && $rows['linestatus'] == '0'){
			// 	$rows['linestatus'] = 'Newly Created';
			// } else {
			// 	$rows['linestatus'] = $this->lineStatusTransaltor[$rows['linestatus']];
			// }

			$rows['rrstatus'] = $this->rrStatusTransaltor[$rows['rrstatus']];

			// libray data decoder start
			$company = $rows['company'];
			$customer = $rows['customer'];
			$endcustomer = $rows['endcustomer'];

			$rows['company'] = $lnddcObj->libraryCodeToDescDecoder('company', $company);
			$rows['customer'] = $lnddcObj->libraryCodeToDescDecoder('Buyer', $customer);
			$rows['endcustomer'] = $lnddcObj->libraryCodeToDescDecoder('Buyer', $endcustomer);
			// libray data decoder end		

			$rows['replenishedby'] = $this->getReplenishedbBy($rows['rrnumber']);

			$rows['actualdeductionqty'] = $this->getInhousedQty($rows['rrnumber'],$rows['requiredgrossqty']);

			$rows['requirednetqty'] = ($rows['requiredgrossqty']-$rows['actualdeductionqty']);

			if($rows['rrtype'] == 'projection'){
				$rows['underprojectionso'] = $this->getUnderProjectionSO($rows['salesorder'],$rows['itemcode']);
			}else{
				$rows['underprojectionso'] = '----';
			}

			if($rows['powonumber'] != ''){
				$rows['postatus'] = $this->getPOStatus($rows['powonumber']);
			}else{
				$rows['postatus'] = '';
			}

			array_push($data, $rows);
		}


		if (isset($params['output']) && $params['output'] == 'table') {
		return '<html><head>
		  <style type="text/css">
		  /*keep html line-breaks within one cell*/
		  br {
		      mso-data-placement:same-cell;
		  }
		  body {
		      font-family : monospace;
		      font-size : small;
		  }
		  table {
		      border: solid 1px;
		      border-collapse: collapse;
		  }
		  td {
		      border : solid 1px;
		      border-color : lightgray;
		  }
		  </style>
		</head><body>' . $this->conn->sqlToTable($sql) . '</body></html>';
		$this->conn->close();
		} else if (isset($params['print']) && $params['print'] == 'sql'){
			echo $sql;
		} else {

			$returnJson = "";
			$returnArray = array();

			$returnArray['listData']     = $data;
			$returnArray['noResult']     = false;
			$returnArray['queryRowsNum'] = $queryRowsNum;
			$returnArray['showLimit']    = $showLimit; // per page limit
			$returnArray['pageNum']      = $pageNum;
			$returnArray['lastPageNum']  = $lastPageNum;

			$returnJson = json_encode($returnArray);

			//call po line no update in fabric table for stock update
			// $this->polineUpdate();

			$this->conn->close();
			return $returnJson;

		}


	}

 	function polineUpdate(){
 		$conn = new ErpDbConn;
 		$sql = "UPDATE tnx_fabricordersummary_mother m, erp_rrlines r, erp_purchaseorder p SET m.POLineNumber = p.doclinenumber
				WHERE
				r.fabrictrackingno = m.FabricTrackingNo
				AND r.rrnumber = p.rrnumber
				AND r.powonumber != ''
				AND r.powonumber IS NOT NULL";
		$conn->query($sql);
		$conn->close();
		return 0;
 	}	

	function getPOInfo($rrnumber){
		$conn = new ErpDbConn;

		$poinfo = array();
		$sql = "SELECT docnumber,doclinenumber,formtype FROM erp_purchaseorder WHERE rrnumber = '$rrnumber'";
		$data = json_decode( $conn->sqlToJson($sql), true )[0];
		$poinfo['docnumber'] = $data['docnumber'];
		$poinfo['doclinenumber'] = $data['doclinenumber'];
		$poinfo['formtype'] = $data['formtype'];

		$conn->close();
		return $poinfo;
	}

	function getInhousedQty($rrnumber,$requiredgrossqty){
		$conn = new ErpDbConn;


		//PO Created
		$sqlPO = "SELECT doclinenumber FROM erp_purchaseorder WHERE rrnumber='$rrnumber'";
		$result = $conn->query($sqlPO);
		$queryRowsNum = $result->num_rows;
		if($queryRowsNum > 0){
			$polinenumber = $result->fetch_assoc()['doclinenumber'];
			$sqlFM = "SELECT FabricTrackingNo FROM tnx_fabricordersummary_mother WHERE POLineNumber='$polinenumber'";
			$queryResult = $conn->query($sqlFM);
			$queryRowsNumFM = $queryResult->num_rows;
			if($queryRowsNumFM == 0){
				return '---';
			}
			$fabricTrackingNo = $queryResult->fetch_assoc()['FabricTrackingNo'];

			// $sqlFC = "SELECT IFNULL(SUM(Qty),0) AS `inhousedqty` FROM txn_fabricrcvissue_child WHERE FabTrackingNo='$fabricTrackingNo'";
			$sqlFCPlus = "SELECT IFNULL(SUM(Qty),0) AS `inhousedqty` FROM txn_fabricrcvissue_child WHERE FabTrackingNo='$fabricTrackingNo' AND Action IN('Received from Foreign Fabric Supplier','Received from DYE Subcontractor')";
			$sqlFCMinus = "SELECT IFNULL(SUM(Qty),0) AS `inhousedqty` FROM txn_fabricrcvissue_child WHERE FabTrackingNo='$fabricTrackingNo' AND Action IN('Return to Fabric Supplier')";
			$queryResultPlus = $conn->query($sqlFCPlus);
			$queryResultMinus = $conn->query($sqlFCMinus);
			$quantityPlus = $queryResultPlus->fetch_assoc()['inhousedqty'];
			$quantityMinus = $queryResultMinus->fetch_assoc()['inhousedqty'];
			$quantity = ($quantityPlus-$quantityMinus);
			if($quantity <= 0){
				return '---';
			}


			if($quantity<$requiredgrossqty){
				$sqlRRStatus = "UPDATE erp_rrlines set rrstatus='12' where rrnumber='$rrnumber'";
				$queryResult = $conn->query($sqlRRStatus);
			}else{
				$sqlRRStatus = "UPDATE erp_rrlines set rrstatus='13' where rrnumber='$rrnumber'";
				$queryResult = $conn->query($sqlRRStatus);
			}
			return $quantity;

		}

		$sqlRR = "SELECT rrstatus,linestatus FROM erp_rrlines WHERE rrnumber='$rrnumber' AND rrstatus='13'";
		$queryResult = $conn->query($sqlRR);
		$queryRowsNum = $queryResult->num_rows;

		//Inhoused RR Status
		if($queryRowsNum > 0){
			$sqlFC = "SELECT IFNULL(SUM(Qty),0) AS `inhousedqty` FROM txn_fabricrcvissue_child WHERE rrnumber='$rrnumber' GROUP BY rrnumber";
			$queryResult = $conn->query($sqlFC);
			$quantity = $queryResult->fetch_assoc()['inhousedqty'];
			return $quantity;
		}else{
			return '---';
		}

	}

	function getUnderProjectionSO($salesorder,$itemcode){
		$conn = new ErpDbConn;
		$sql = "SELECT distinct(salesorder) FROM erp_bom WHERE salesorder IN (SELECT distinct(docnumber) FROM erp_salesorder WHERE parentdocnumber='$salesorder') AND itemcode = '$itemcode'";
		$result = $conn->query($sql);

		$underprojectionso = "";

		while($row = $result->fetch_assoc()){
			$underprojectionso .= $row['docnumber'] ."</br>";
		}

		return $underprojectionso;
	}	

	function getPOStatus($powonumber){
		$conn = new ErpDbConn;
		$sql = "SELECT docstatus FROM erp_purchaseorder WHERE docnumber='$powonumber' limit 1";
		$result = $conn->query($sql);
		$row = $result->fetch_assoc();

		return $this->poStatusTransaltor[$row['docstatus']];
	}
	
	function getReplenishedbBy($rrnumber){
		$conn = new ErpDbConn;
		$sql = "SELECT rrstatus, linestatus, recalculationbit, powonumber FROM erp_rrlines WHERE rrnumber = '$rrnumber'";
		$result = $conn->query($sql);
		$row = $result->fetch_assoc();
		$rrstatus = $row['rrstatus'];
		$linestatus = $row['linestatus'];
		$recalculationbit = $row['recalculationbit'];
		$powonumber = $row['powonumber'];

		$replenishedby = '';
		if($rrstatus == '13' && $recalculationbit =='0'){ 
			$replenishedby = 'Old Stock';
		}elseif($recalculationbit == '1' || $recalculationbit == '2'){
			$replenishedby = 'Alternate Item';
		} elseif($rrstatus == '5' || $rrstatus == '6' || $linestatus == '3'){
			$replenishedby = 'Reprocessing WO';
		} elseif($rrstatus == '1' || $linestatus == '0'){
			$replenishedby = 'PO';
		} elseif($rrstatus == '3' || $rrstatus == '4' || $powonumber !=''){
			$replenishedby = 'PO';
		} else {
			$replenishedby = '';
		}

		return $replenishedby;
	}


	function setFabricInhouseDate($data){
		$returnJson = new stdClass();

		$postData = json_decode($data, true);
		$fabricinhousedate = $postData['fabricinhousedate'];
		$idlines = $postData['idlines'];

		$sql = "UPDATE erp_rrlines SET fabricinhousedate = '$fabricinhousedate' WHERE idlines = '$idlines'";
		// return $sql;
		$result = $this->conn->query($sql);
		if($result){
			$returnJson->result = 'success';
		} else {
			$returnJson->result = 'fail';
		}
		return json_encode($returnJson);
	}



	function sendForPOWO($idlines,$linestatus,$replenishedby){
		$returnJson = new stdClass();

		$idlines = json_decode($idlines, true);
		$linestatus = json_decode($linestatus, true);
		$replenishedby = json_decode($replenishedby, true);
		foreach ($idlines as $key => $rridlines) {
			$rrlinestatus = $linestatus[$key];
			$rrreplenishedby = $replenishedby[$key];
			if($rrreplenishedby == 'PO'){
				$rrlinestatus = '1';
			}elseif($rrreplenishedby == 'Reprocessing WO'){
				$rrlinestatus = '2';
			}
			$sql = "UPDATE erp_rrlines SET linestatus = '$rrlinestatus',rrstatus ='1' WHERE idlines = '$rridlines'";
			error_log($sql. "prosenjit");
			$queryResult = $this->conn->query($sql);
		}


		if($queryResult){
			$returnJson->result = 'success';
		} else {
			$returnJson->result = 'fail';
		}
		$this->conn->close();
		return json_encode($returnJson);

	}

	function insertMergeRRLines($linedata){
		$conn = new ErpDbConn;
		$returnJSON            = new stdClass();
  		$returnJSON->errormsgs = array();

		$linedata = json_decode($linedata,true);

		$idlines  = $linedata['idlines'];
		$rrnumber = $this->getNextDocNumber('counter_RR');
		$fieldArray = array(
				'rrtype'              => 'rrtype',                                    
				'lineentrytime'       => 'lineentrytime',                             
				'salesorder'          => 'salesorder' ,                               
				'company'             => 'company',                                   
				'endcustomer'         => 'endcustomer',                               
				'itemtype'            => 'itemtype',                                  
				'itemcode'            => 'itemcode',                                  
				'itemdescription'     => 'itemdescription',                           
				'requiredgrossqty'    => 'SUM(requiredgrossqty)',                     
				'allocatedqty'        => 'SUM(allocatedqty)',                         
				'actualdeductionqty'  => 'SUM(actualdeductionqty)',                   
				'requirednetqty'      => 'SUM(requirednetqty)' ,                      
				'iduom'               => 'iduom',                                     
				'allocatedqtyconfirm' => 'SUM(allocatedqtyconfirm)',                  
				'sewingstartdate'     => 'MIN(sewingstartdate)',                      
				'sewingfinisheddate'  => 'MAX(sewingfinisheddate)',                   
				'processbeforesewing' => 'processbeforesewing',                       
				'processaftersewing'  => 'processaftersewing',                        
				'fabricinhousedate'   => 'fabricinhousedate' ,                        
				'cpdocnumber'         => "group_concat(cpdocnumber separator ',')" ,  
				'bomdocnumber'        => "group_concat(bomdocnumber separator ',')", 
				'bomlinenumber'       => "group_concat(bomlinenumber separator ',')", 
				'ldcslnumber'         => "group_concat(ldcslnumber separator ',')", 
				
				'sewingperiod'        => "DATEDIFF(MAX(sewingfinisheddate),MIN(sewingstartdate))" ,
				'fabricusageperday'   => "(SUM(requiredgrossqty)/DATEDIFF(MAX(sewingfinisheddate),MIN(sewingstartdate)))" ,
		);

		// Process field clause
		$insertFieldClause = array();
		$selectFieldClause = array();

		foreach ($fieldArray as $fieldKey => $fieldValue) {
			array_push($selectFieldClause, $fieldValue );
			array_push($insertFieldClause, $fieldKey );
		}

		$selectFieldClause = implode(' , ', $selectFieldClause);
		$insertFieldClause = implode(' , ', $insertFieldClause);

		$sql = "INSERT INTO erp_rrlines (rrnumber,$insertFieldClause) SELECT '$rrnumber',$selectFieldClause FROM erp_rrlines WHERE idlines IN($idlines) GROUP BY itemcode";


		$result = $conn->query($sql);

		if(!$result){
			array_push($returnJSON->errormsgs, "Error, $sql");
			$conn->close();
			return $returnJSON;
		}else if($result){
			$sql = "UPDATE erp_rrlines SET mergeorsplit='1' WHERE idlines IN($idlines)";
			$result = $conn->query($sql);
			$conn->close();
			return $result;
		} 
	}

	function insertSplitRRLines($linedata){
		$conn = new ErpDbConn;
		$returnJSON            = new stdClass();
  		$returnJSON->errormsgs = array();

		$linedata = json_decode($linedata,true);

		$grossqty = array();
		$inhousedate = array();
		$requiredgrossqty = $linedata['splitlines']['grossqty'];
		$fabricinhousedate = $linedata['splitlines']['inhousedate'];

		$idlines    = $linedata['idlines'];

		$sql = "SELECT * FROM erp_rrlines WHERE idlines='$idlines'";
		$result = $conn->query($sql);
		$sql = array();
		
		for($i=0 ; $i< sizeof($requiredgrossqty) ; $i++){
			$insertCol = array();
			$insertVal = array();

			foreach ($result as $index => $row) {
				foreach ($row as $key => $value) {
					if($key == 'fabricinhousedate'){
						$insertCol[] = $key;
						$insertVal[] = $fabricinhousedate[$i];
					}else if($key == 'requiredgrossqty'){
						$insertCol[] = $key;
						$insertVal[] = $requiredgrossqty[$i];
					}else if($key == 'idlines'){
					}else if($key == 'rrnumber'){
						$insertCol[] = $key;
						$insertVal[] = $this->getNextDocNumber('counter_RR');
					}else{
						$insertCol[] = $key;
						$insertVal[] = $value;
					}
				}
			}
			$column = implode(",", $insertCol);
			$colValue = "'" . implode("','", $insertVal) . "'";
			$sql[] = "INSERT INTO erp_rrlines ($column) VALUES($colValue)";
		}	

		$result = false;
		foreach ($sql as $key => $singleSql) {
			$result = $conn->query($singleSql);
		}

		if($result){
			$sql = "UPDATE erp_rrlines SET mergeorsplit='2' WHERE idlines IN($idlines)";
			$result = $conn->query($sql);
			$conn->close();
			return $result;
		}
	}


	function getSOInfo($params){
		$conn = new ErpDbConn;
		$salesorder = $params['salesorder'];

		$sql = "SELECT docnumber,formtype,endcustomer,company FROM erp_salesorder WHERE docnumber='$salesorder' GROUP BY docnumber";
		$result = $conn->query($sql);
		$row = $result->fetch_assoc();

		$lnddcObj           = new ErpLibraryDecoder();
		$company            = $row['company'];
		$endcustomer        = $row['endcustomer'];
		$row['company']     = $lnddcObj->libraryCodeToDescDecoder('Company', $company);
		$row['endcustomer'] = $lnddcObj->libraryCodeToDescDecoder('Buyer', $endcustomer);
		
		return json_encode($row);
	}

	function unallocateStock($data){
		$returnJson = new stdClass();

		$data    = json_decode($data, true);
		$idlines = $data['idlines'];
		$rrnumber = $data['rrnumber'];
		$projectnumber = $data['salesorder'];
		
		$idline  = "'" . implode("','",$idlines) . "'";
		$rrnumber  = "'" . implode("','",$rrnumber) . "'";
		$projectnumber  = "'" . implode("','",$rrnumber) . "'";

		if(!isset($data['rrnumber'])) return;
		if(!isset($data['salesorder'])) return;
		if($rrnumber == '') return;
		if($projectnumber == '') return;

		// $sqlDel    = "DELETE FROM erp_bulk_allocation WHERE rridlines IN($idline)";
		$sqlDel    = "DELETE FROM txn_fabricrcvissue_child WHERE projectnumber = '$projectnumber' AND rrnumber IN ($rrnumber)";

		$sqlUpdate = "UPDATE erp_rrlines SET rrstatus = 0, allocatedqty='0', actualdeductionqty='0',requirednetqty=requiredgrossqty WHERE idlines IN($idline)";

		$queryResultUpdate = $this->conn->query($sqlUpdate);
		$queryResultDel    = $this->conn->query($sqlDel);
		if($queryResultDel){
			$returnJson->result = 'success';
		} else {
			$returnJson->result = 'fail';
		}
		$this->conn->close();
		return json_encode($returnJson);

	}


	function getBulkAllocation($params){

		$fieldArray = array(
			'idlines'         => '`blk`.`rridlines`',
			'rrnumber'        => '`blk`.`rrnumber`',
			'itemtype'        => '`blk`.`itemtype`',
			'itemcode'        => '`blk`.`itemcode`',
			'itemdescription' => '`blk`.`itemdescription`',
			'fabricwidth'     => 'virtual',
			'itemlot'         => '`blk`.`itemlot`',
			'quantity'        => '`blk`.`quantity`',
			'deductionqty'    => '`blk`.`deductionqty`',
			'iduom'           => '`blk`.`iduom`',
			'whlocation'      => '`blk`.`whlocation`',
			'binlocation'     => '`blk`.`binlocation`',
			'endcustomer'     => '`blk`.`endcustomer`',
		);
		$groupArray = array(
			// 'idlines'       => 'idlines',
			// 'itemlot'       => 'itemlot',
		);
		$whereClauses = array(
			"(1=1)",
			"(`blk`.`recalculationbit` = '1')",
		);		


		// Process field clause
		$fieldClause = array();
		foreach ($fieldArray as $fieldKey => $fieldValue) {
			if($fieldValue == 'virtual'){
				array_push($fieldClause, "''" . ' AS `' . $fieldKey . '`');
			}else{
				array_push($fieldClause, $fieldValue . ' AS `' . $fieldKey . '`');
			}
		}
		$fieldClause = implode(' , ', $fieldClause);

		// Process group clause
		$groupClause = array();
		foreach ($groupArray as $groupField) {
			array_push($groupClause, $fieldArray[$groupField]);
		}
		$groupClause = implode(' , ', $groupClause);	

		// Process where clause		
		$searchParams = $params;
		unset($searchParams['reqType']);
		unset($searchParams['_']);		
		
		unset($searchParams['rrtype']);		
		if (isset($searchParams) && count($searchParams) > 0) {
			foreach ($searchParams as $paramkey => $paramvalue) {
				if($paramvalue == "") unset($searchParams[$paramkey]);
			}
			foreach ($searchParams as $paramkey => $paramvalue) {
				array_push($whereClauses, "( $fieldArray[$paramkey] = '" . $paramvalue . "')");
			}
		}
		$whereClause = implode(' AND ', $whereClauses);	


  		$sql = <<<EOF
SELECT
  $fieldClause
FROM
  `erp_bulk_allocation` `blk`
WHERE $whereClause
EOF;
// return $sql;
// 
		$queryResult = $this->conn->query($sql);
		$lnddcObj = new ErpLibraryDecoder();
		$data = array();
		while ( $rows = $queryResult->fetch_assoc() ) {
			$itemcodeInfo = $this->getItemCodeInformation($rows['itemcode']);
			$rows['fabricwidth'] = $itemcodeInfo['diameter'];
			array_push($data, $rows);
		}
		$returnArray['listData']     = $data;
		$this->conn->close();
		return json_encode($returnArray);

	}


	function getItemCodeInformation($itemcode){
		$sql = "SELECT * FROM mrd_item_codes WHERE ItemCode='$itemcode'";
		$result = $this->conn->query($sql);
		$row = $result->fetch_assoc();
		return $row;
	}


	function getRRLineTablePopup($params){

		$fieldArray = array(
			'idlines'          				=> '`rr`.`idlines`',
			'rrnumber'          			=> '`rr`.`rrnumber`',
			// 'rrtype'          				=> '`rr`.`rrtype`',
			// 'rrstatus'          			=> '`rr`.`rrstatus`',
			'company'           			=> '`rr`.`company`',
			'endcustomer'           		=> '`rr`.`endcustomer`',
			'itemtype' 						=> '`rr`.`itemtype`',
			'itemcode'          			=> '`rr`.`itemcode`',
			'itemdescription'        		=> '`rr`.`itemdescription`',
			'requiredgrossqty'           	=> '`rr`.`requiredgrossqty`',
			// 'allocatedqty' 				    => '`rr`.`allocatedqty`',
			'actualdeductionqty' 			=> '`rr`.`actualdeductionqty`',
			'requirednetqty' 			    => '`rr`.`requirednetqty`',
			'iduom' 						=> '`rr`.`iduom`',
			// 'sewingstartdate'          		=> '`rr`.`sewingstartdate`',
			// 'sewingfinisheddate'          	=> '`rr`.`sewingfinisheddate`',
			// 'processbeforesewing' 		    => '`rr`.`processbeforesewing`',
			// 'processaftersewing' 		    => '`rr`.`processaftersewing`',
			// 'sewingperiod'        			=> '`rr`.`sewingperiod`',
			// 'fabricusageperday' 			=> '`rr`.`fabricusageperday`',
			'salesorder' 					=> '`rr`.`salesorder`',
			// 'ldcslnumber' 					=> '`rr`.`ldcslnumber`',
			// 'bomdocnumber'          		=> '`rr`.`bomdocnumber`',
			// 'cpdocnumber'          			=> '`rr`.`cpdocnumber`',
			// 'fabricinhousedate'          	=> '`rr`.`fabricinhousedate`',
		);
		$groupArray = array(
			'idlines'       => 'idlines',
		);
		$whereClauses = array(
			"(1=1)",
			// "(`inv`.`company` = 'LFI')",
		);		

		// Process field clause
		$fieldClause = array();
		foreach ($fieldArray as $fieldKey => $fieldValue) {
			if($fieldValue == 'virtual'){
				array_push($fieldClause, "''" . ' AS `' . $fieldKey . '`');
			}else{
				array_push($fieldClause, $fieldValue . ' AS `' . $fieldKey . '`');
			}
		}
		$fieldClause = implode(' , ', $fieldClause);

		// Process group clause
		$groupClause = array();
		foreach ($groupArray as $groupField) {
			array_push($groupClause, $fieldArray[$groupField]);
		}
		$groupClause = implode(' , ', $groupClause);	

		// Process where clause		
		$searchParams = $params;
		unset($searchParams['reqType']);
		unset($searchParams['_']);		
		
		unset($searchParams['rrtype']);		
		if (isset($searchParams) && count($searchParams) > 0) {
			foreach ($searchParams as $paramkey => $paramvalue) {
				if($paramvalue == "") unset($searchParams[$paramkey]);
			}
			foreach ($searchParams as $paramkey => $paramvalue) {
				array_push($whereClauses, "( $fieldArray[$paramkey] = '" . $paramvalue . "')");
			}
		}
		$whereClause = implode(' AND ', $whereClauses);	


  		$sql = <<<EOF
SELECT
  $fieldClause
FROM
  `erp_rrlines` `rr`
WHERE $whereClause
GROUP BY $groupClause
EOF;
// return $sql;
// 
		$queryResult = $this->conn->query($sql);
		$lnddcObj = new ErpLibraryDecoder();
		$data = array();
		while ( $rows = $queryResult->fetch_assoc() ) {
			$rows['rrstatus'] = $this->rrStatusTransaltor[$rows['rrstatus']];
			// libray data decoder start
			$company = $rows['company'];
			$endcustomer = $rows['endcustomer'];

			$rows['company'] = $lnddcObj->libraryCodeToDescDecoder('company', $company);
			$rows['endcustomer'] = $lnddcObj->libraryCodeToDescDecoder('Buyer', $endcustomer);

			$itemcodeInfo = $this->getItemCodeInformation($rows['itemcode']);
			$rows['fabricwidth'] = $itemcodeInfo['diameter'];
			array_push($data, $rows);
		}
		$returnArray['listData']     = $data;
		$this->conn->close();
		return json_encode($returnArray);

	}



	function getRRDeliveryLineWise($params){

		$fieldArray = array(
			'idlines'          				=> '`rr`.`idlines`',
			'rrnumber'          			=> '`rr`.`rrnumber`',
			'salesorder' 					=> '`rr`.`salesorder`',
			'ldcslnumber' 					=> '`rr`.`ldcslnumber`',
			// 'rrtype'          				=> '`rr`.`rrtype`',
			// 'rrstatus'          			=> '`rr`.`rrstatus`',
			// 'company'           			=> '`rr`.`company`',
			// 'endcustomer'           		=> '`rr`.`endcustomer`',
			'itemtype' 						=> '`rr`.`itemtype`',
			'itemcode'          			=> '`rr`.`itemcode`',
			'itemdescription'        		=> '`rr`.`itemdescription`',
			'requiredgrossqty'           	=> 'SUM(`rr`.`requiredgrossqty`)',
			// 'allocatedqty' 				    => '`rr`.`allocatedqty`',
			// 'actualdeductionqty' 			=> '`rr`.`actualdeductionqty`',
			// 'requirednetqty' 			    => '`rr`.`requirednetqty`',
			'iduom' 						=> '`rr`.`iduom`',
			'sewingstartdate'          		=> '`rr`.`sewingstartdate`',
			'sewingfinisheddate'          	=> '`rr`.`sewingfinisheddate`',
			'processbeforesewing' 		    => '`rr`.`processbeforesewing`',
			'processaftersewing' 		    => '`rr`.`processaftersewing`',
			'sewingperiod'        			=> '`rr`.`sewingperiod`',
			'fabricusageperday' 			=> '`rr`.`fabricusageperday`',
			'cplineno' 						=> '`rr`.`cplineno`',
			// 'bomdocnumber'          		=> '`rr`.`bomdocnumber`',
			// 'cpdocnumber'          			=> '`rr`.`cpdocnumber`',
			// 'fabricinhousedate'          	=> '`rr`.`fabricinhousedate`',
		);
		$groupArray = array(
			'cplineno'      => 'cplineno',
		);
		$whereClauses = array(
			"(1=1)",
			// "(`inv`.`company` = 'LFI')",
		);		

		// Process field clause
		$fieldClause = array();
		foreach ($fieldArray as $fieldKey => $fieldValue) {
			if($fieldValue == 'virtual'){
				array_push($fieldClause, "''" . ' AS `' . $fieldKey . '`');
			}else{
				array_push($fieldClause, $fieldValue . ' AS `' . $fieldKey . '`');
			}
		}
		$fieldClause = implode(' , ', $fieldClause);

		// Process group clause
		$groupClause = array();
		foreach ($groupArray as $groupField) {
			array_push($groupClause, $fieldArray[$groupField]);
		}
		$groupClause = implode(' , ', $groupClause);	

		// Process where clause		
		$searchParams = $params;
		unset($searchParams['reqType']);
		unset($searchParams['_']);		
		
		unset($searchParams['rrtype']);		
		if (isset($searchParams) && count($searchParams) > 0) {
			foreach ($searchParams as $paramkey => $paramvalue) {
				if($paramvalue == "") unset($searchParams[$paramkey]);
			}
			foreach ($searchParams as $paramkey => $paramvalue) {
				array_push($whereClauses, "( $fieldArray[$paramkey] = '" . $paramvalue . "')");
			}
		}
		$whereClause = implode(' AND ', $whereClauses);	


  		$sql = <<<EOF
SELECT
  $fieldClause
FROM
  `erp_rrlines_dlvlinewise` `rr`
WHERE $whereClause
GROUP BY $groupClause
EOF;
// return $sql;
// 
		$queryResult = $this->conn->query($sql);
		$lnddcObj = new ErpLibraryDecoder();
		$data = array();
		while ( $rows = $queryResult->fetch_assoc() ) {
			$rows['rrstatus'] = $this->rrStatusTransaltor[$rows['rrstatus']];
			// libray data decoder start
			$company = $rows['company'];
			$endcustomer = $rows['endcustomer'];

			// $rows['company'] = $lnddcObj->libraryCodeToDescDecoder('company', $company);
			// $rows['endcustomer'] = $lnddcObj->libraryCodeToDescDecoder('Buyer', $endcustomer);

			$itemcodeInfo = $this->getItemCodeInformation($rows['itemcode']);
			$rows['fabricwidth'] = $itemcodeInfo['diameter'];
			array_push($data, $rows);
		}
		$returnArray['listData']     = $data;
		$this->conn->close();
		return json_encode($returnArray);

	}

	function getBOMInformation($params){
		$rrnumber = $params['rrnumber'];
		$sql = "SELECT doclinenumber,consumption,processloss,endcustomer,style FROM erp_bom WHERE doclinenumber IN(SELECT bomlinenumber FROM erp_rrlines WHERE rrnumber='$rrnumber')";
		$result = $this->conn->query($sql);
		
		$lnddcObj = new ErpLibraryDecoder();
		$data = array();
		while ( $rows = $result->fetch_assoc() ) {
			$endcustomer = $rows['endcustomer'];

			$rows['endcustomer'] = $lnddcObj->libraryCodeToDescDecoder('Buyer', $endcustomer);

			array_push($data, $rows);
		}

		return json_encode($data);

	}

	function sendForRecalculation($data){
		$returnJson = new stdClass();
		$username = $_SESSION['USERNAME'];

		date_default_timezone_set('Asia/Dhaka');
		$requestdate = date('Y-m-d h:i:s', time());

		$rrnumber = json_decode($data, true);
		$sql = "UPDATE erp_rrlines SET rrstatus = '2',bommoduleflag='1',recalrequester='$username',recalrequestdate='$requestdate' WHERE rrnumber = '$rrnumber'";
		$queryResult = $this->conn->query($sql);

		if($queryResult){
			$returnJson->result = 'success';
		} else {
			$returnJson->result = 'fail';
		}
		$this->conn->close();
		return json_encode($returnJson);

	}



	function saveDeliveryLine($docdata){
		$conn = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		
		$docobj = json_decode($docdata, true);
		$doclins = $docobj['lines'];
		$dlvbrktext = $docobj['dlvbrktext'];
		$rrnumber;
		unset($docobj['lines']);
		unset($docobj['dlvbrktext']);

		$delWhere="";
		$sql_array = array();
		$hcolumnFields = array();
		$hfieldValues = array();


		foreach ($docobj as $fieldname => $fieldvalue) {
			$hcolumnFields[] = $fieldname;
			$hfieldValues[] = $fieldvalue;

			if($fieldname == 'rrnumber'){
				$delWhere = $fieldname ." = '". $fieldvalue ."'";
				$rrnumber = $fieldvalue;
			}
		}

		// process lines
		foreach ($doclins as $index => $line) {

			$columnFields = array();
			$fieldValues = array();
			foreach ($line as $fieldname => $fieldvalue) {
				$columnFields[] = "`".$fieldname."`";
				$fieldValues[] = $fieldvalue;

			}
			// push header data in line
			foreach ($hcolumnFields as $index => $fieldname) {
				$columnFields[] = "`".$fieldname."`";
				$fieldValues[]  = $hfieldValues[$index];		
			}		

			$columnFields = implode(", ", $columnFields);
			$fieldValues  = "'" . implode("','", $fieldValues) . "'";

			$sql = "INSERT INTO erp_powodeliverylinebreakdown ($columnFields) VALUES($fieldValues)";
			$sql_array[] = $sql;
			// error_log('Prosenjit '.$sql);

		}
		$updateWhere = $delWhere;
		//delete old data
		$sqlDelete = "DELETE FROM erp_powodeliverylinebreakdown WHERE $delWhere";
		$result = $conn->query($sqlDelete);
		// Execute Query
		foreach ($sql_array as $key => $sql) {
			// error_log('Prosenjit ' . $sql);
			$result = $conn->query($sql);	  
			if(!$result){
				array_push($returnJSON->errormsgs, "Error, $sql");
				return $returnJSON;
			}
		}
		//update line status
		$sqlUpdate = "UPDATE erp_rrlines SET dlvbrktext='$dlvbrktext' WHERE $updateWhere";
		$result = $conn->query($sqlUpdate);

		//updateDocStatusUsingLineStatus(idlines,linestatus,docstatus)
		if($result){
			$returnJSON->dlvbrktext = $dlvbrktext;
		}	
      	$conn->close();
		return json_encode($returnJSON);

	}

	function readPOWODeliveryLine($rrnumber){
		$conn = new ErpDbConn;

		$fieldnames = ['lineno','deliverydate','quantity'];
		$fieldnames  = implode(",", $fieldnames);

		// get the header info in docobj
		$sql = "SELECT $fieldnames
		  FROM  erp_powodeliverylinebreakdown
		  WHERE rrnumber = '$rrnumber'";
		// return $sql;
		$result = $conn->query($sql);
		if($result->num_rows == 0) return '';
		
		$lines  = array();
		while ($row = $result->fetch_assoc()) {
			array_push($lines, $row);
		}

		$docobj = $lines;
		return json_encode($docobj);

	}	


	function getRRMrp($mrpSalesorder){
		$conn = new ErpDbConn;

		$sql = "SELECT company, endcustomer, itemtype, itemcode, designid, rrtype, itemdescription, SUM(requiredgrossqty) AS requiredgrossqty , SUM(requirednetqty) AS requirednetqty, iduom, sewingstartdate, sewingfinisheddate, processbeforesewing, processaftersewing, bomdocnumber, bomlinenumber, previousitemcode, previousfmdocnumber, cpdocnumber, ldcslnumber, salesorder, unitprice, pricerequisitionnumber, fmdocnumber, projectionfmdocnumber, cplineno, GROUP_CONCAT(distinct(rrstatus) SEPARATOR ',') AS rrstatus,rrnumber, powonumber, powolinenumber FROM  erp_rrlines WHERE salesorder = '$mrpSalesorder' AND rrstatus!='901' GROUP BY designid";

		$this->rrExplotion($sql);
	}

	function rrExplotion($sql){
		$conn = new ErpDbConn;
		$resultOfRR = $conn->query($sql);
		// echo ($conn->sqlToJson($sql));

		if($resultOfRR->num_rows == 0) return '';
		while($checkRRLines = $resultOfRR->fetch_assoc()){


			$isnotInhousedRR = 0;
			$isInhousedRR = 0;
			$inhousedQty = 0;

			$itemcode = $checkRRLines['itemcode'];
			$designid = $checkRRLines['designid'];
			$salesorder = $checkRRLines['salesorder'];

			if(strpos($checkRRLines['rrstatus'], ',')){
				$rrstatusArray = explode(',', $checkRRLines['rrstatus']);
				foreach ($rrstatusArray as $key => $value) {

					if($value == '12' || $value == '13'){
						$isInhousedRR = '1';

					}else if($value != '12' && $value != '13'){
						$isnotInhousedRR = '1';
					}
				}

			}else{
				$value = $checkRRLines['rrstatus'];
				if($value == '12' || $value == '13'){
					$isInhousedRR = '1';

				}else if($value != '12' && $value != '13'){
					$isnotInhousedRR = '1';
				}
			}


			$rrnumberOld = "";
			$rrnumberInhoused ="";
			$requiredgrossqtyInhoused = 0;
			$rrstatusInhoused = '0';
			$generatedRRStatus = 'old';
			// if($isnotInhousedRR == '1'){
				$sql = "SELECT SUM(requiredgrossqty) AS requiredgrossqty,rrnumber FROM  erp_rrlines WHERE salesorder = '$salesorder' AND rrstatus NOT IN('12','13','901') AND designid='$designid' GROUP BY designid";
				$result = $conn->query($sql);
				$row = $result->fetch_assoc();
				$rrnumberOld = $row['rrnumber'];
				$requiredgrossqty = $row['requiredgrossqty'];
				$inhousedQty = number_format((float)($checkRRLines['requiredgrossqty'] - $requiredgrossqty), 2, '.', '');

				$generatedRRStatus = 'old';

				$sqlInhouse = "SELECT SUM(requiredgrossqty) AS `requiredgrossqty`,GROUP_CONCAT(rrnumber SEPARATOR ',') AS `rrnumber`, GROUP_CONCAT(rrstatus SEPARATOR ',') AS `rrstatus`, GROUP_CONCAT(requiredgrossqty SEPARATOR ',') AS `rrindqty`,GROUP_CONCAT(powonumber SEPARATOR ',') AS `powonumber`,GROUP_CONCAT(powolinenumber SEPARATOR ',') AS `powolinenumber` FROM  erp_rrlines WHERE salesorder = '$salesorder' AND rrstatus IN('12','13') AND rrstatus!='901' AND designid='$designid' GROUP BY salesorder,designid";
				$resultInhouse = $conn->query($sqlInhouse);
				$rowInhouse = $resultInhouse->fetch_assoc();
				$rrnumberInhoused = $rowInhouse['rrnumber'];
				$requiredgrossqtyInhoused = $rowInhouse['requiredgrossqty'];
				$rrstatusInhoused = $rowInhouse['rrstatus'];
				$rrIndQtyInhoused = $rowInhouse['rrindqty'];
				$rrPOInhoused = $rowInhouse['powonumber'];
				$rrPOLineInhoused = $rowInhouse['powolinenumber'];

			// }


		// if($result->num_rows == 0) return '';
		
		
			$sqlofRR = "
	            SELECT 
	                bm.company AS company,
	                bm.endcustomer AS endcustomer,
	                bm.itemtype AS itemtype,
	                bm.itemcode AS itemcode,
	                bm.designid AS designid,
	                bm.itemdescription AS itemdescription,
	                SUM((bm.tnxqty*cp.pieceqty)/cp.totalpieceqty) AS requiredgrossqty,
	                SUM((bm.tnxqty*cp.pieceqty)/cp.totalpieceqty) AS requirednetqty,
	                bm.iduom AS iduom,
	                SUM(cp.pieceqty) AS pieceqty,
	                SUM(cp.totalpieceqty) AS totalpieceqty,
	                cp.sewingstartdate AS sewingstartdate,
	                cp.sewingfinisheddate AS sewingfinisheddate,
	                cp.outputperlineperday AS outputperlineperday,
	                cp.processbeforesewing AS processbeforesewing,
	                cp.processaftersewing AS processaftersewing,
	                GROUP_CONCAT(distinct(bm.docnumber) SEPARATOR ',') AS bomdocnumber,
	                GROUP_CONCAT(distinct(bm.doclinenumber) SEPARATOR ',') AS bomlinenumber,
	                bm.previousitemcode AS previousitemcode,
	                bm.previousfmdocnumber AS previousfmdocnumber,
	                GROUP_CONCAT(distinct(cp.docnumber) SEPARATOR ',') AS cpdocnumber,
	                GROUP_CONCAT(distinct(bm.ldcslnumber) SEPARATOR ',') AS ldcslnumber,
	                cp.salesorder AS salesorder,
	                cp.formtype AS rrtype,
	                bm.unitprice AS unitprice,
	                bm.pricerequisitionnumber AS pricerequisitionnumber,
	                bm.fmdocnumber AS fmdocnumber,
	                bm.projectionfmdocnumber AS projectionfmdocnumber,
	                GROUP_CONCAT(distinct(cp.doclinenumber) SEPARATOR ',') AS cplineno
	            FROM
	                erp_bom bm
	                    JOIN
	                erp_capacityplan cp 
	                ON bm.ldcslnumber = cp.ldcslnumber
	            WHERE
	            bm.linestatus != '13'
	            AND
	            cp.salesorder = '$salesorder'
	            AND
	            bm.designid = '$designid'
	            GROUP BY cp.salesorder, bm.designid
	            ";


	            $queryResult = $conn->query($sqlofRR);
	            $rowRRbomcp = $queryResult->fetch_assoc();
	            $cplinenoSearch = $rowRRbomcp['cplineno'];
	            $cplinenoSearch = explode(",", $cplinenoSearch);
	            $cplinenoSearch = "'". implode("','", $cplinenoSearch). "'";
		    
		    $rowRRbomcp['colorcategory'] = $this->getColorCategory($rowRRbomcp['itemcode'],$rowRRbomcp['salesorder']);
		    $checkRRLines['colorcategory'] = $rowRRbomcp['colorcategory'];

	        $rowRRbomcp['requiredgrossqty'] = number_format((float)$rowRRbomcp['requiredgrossqty'], 2, '.', '');
	        $rowRRbomcp['requirednetqty'] = $rowRRbomcp['requiredgrossqty'];
	        
	        // get sewing period
	        $date1 = new DateTime($rowRRbomcp['sewingstartdate']);
	        $date2 = new DateTime($rowRRbomcp['sewingfinisheddate']);
	        $sewingperiod = $date2->diff($date1)->format("%a");
	        $sewingperiod = (int)($sewingperiod+1);   

	        //get sales order delivery line no
	        $salesorderdeliverylinenumber = $this->getSalesorderdeliverylinenumber($rowRRbomcp['cplineno'],$rowRRbomcp['ldcslnumber']);  
			$rowRRbomcp['sewingperiod'] = $sewingperiod;

	        // calculate fabric usage
	        $fabricusageperday = $rowRRbomcp['requiredgrossqty']/$rowRRbomcp['sewingperiod'];

			$rowRRbomcp['salesorderdeliverylinenumber'] = $salesorderdeliverylinenumber;
			$rowRRbomcp['fabricusageperday'] = $fabricusageperday;

			$generatedRRStatus = 'old';
			$rrstatusNew = array();
    		$rrqtyNew = array();

	        if($isInhousedRR == '1' && $isnotInhousedRR != '1'){
	        	//quantity increase
	        	//only exist inhoused rr
	        	if($rowRRbomcp['requiredgrossqty']>$checkRRLines['requiredgrossqty']){
	        		$checkRRLines['requiredgrossqty'] = ($rowRRbomcp['requiredgrossqty']-$checkRRLines['requiredgrossqty']);
	        		$checkRRLines['requiredgrossqty'] = number_format((float)$checkRRLines['requiredgrossqty'], 2, '.', '');
	        		$checkRRLines['requirednetqty'] = $checkRRLines['requiredgrossqty'];
	        		$checkRRLines['fabricusageperday'] = $rowRRbomcp['requiredgrossqty']/$rowRRbomcp['sewingperiod'];
	        		$checkRRLines['rrstatus'] = '0';
	        		$checkRRLines['linestatus'] = '0';
	        		$generatedRRStatus = 'new';

	        	}else if($rowRRbomcp['requiredgrossqty']<$checkRRLines['requiredgrossqty']){
	        		//quantity decrease
	        		$checkRRLines['rrnumber'] = $rrnumberOld;
		        	$requiredgrossqtyCheck = $rowRRbomcp['requiredgrossqty'] - $inhousedQty;
		        	$requiredgrossqtyCheck = number_format((float)$requiredgrossqtyCheck, 2, '.', '');

		        	if($requiredgrossqtyCheck <= 0){
		        		$checkRRLines['rrnumber'] = $rrnumberInhoused;
		        		$checkRRLines['rrstatus'] = $rrstatusInhoused;
		        		$checkRRLines['requiredgrossqty'] = number_format((float)$requiredgrossqtyInhoused, 2, '.', '');
		        		$checkRRLines['requirednetqty']   = $checkRRLines['requiredgrossqty'];
		        		$rowRRbomcp['requiredgrossqty'] = number_format((float)$rowRRbomcp['requiredgrossqty'], 2, '.', '');
		        		$rowRRbomcp['requirednetqty']   = $rowRRbomcp['requiredgrossqty'];

		        		if(strpos($rrnumberInhoused, ',')){
		        			$difference = $inhousedQty - $rowRRbomcp['requiredgrossqty'];
							$rrnumberInhoused = explode(',', $rrnumberInhoused);
							$rrstatusInhoused = explode(',', $rrstatusInhoused);
							$rrIndQtyInhoused = explode(',', $rrIndQtyInhoused);
							$rrPOInhoused = explode(',', $rrPOInhoused);
							$rrPOLineInhoused = explode(',', $rrPOLineInhoused);

							foreach ($rrnumberInhoused as $key => $value) {
						    	$rrPreviousQty[$value] = $rrIndQtyInhoused[$key];
						    	if($rrIndQtyInhoused[$key] <= $difference){
						    		$rrqtyNew[$value] = 0;
						    		$difference = $difference -$rrIndQtyInhoused[$key];
						    		if($difference < 0) $difference = 0;
						    	}else{
						    		$rrqtyNew[$value] = $rrIndQtyInhoused[$key]- $difference;
						    	}
						    	
						    	$rrstatusNew[$value] = $rrstatusInhoused[$key];
						    	$rrInhousedPO[$value] = $rrPOInhoused[$key];
						    	$rrInhousedPOLine[$value] = $rrPOLineInhoused[$key];
						    }
		        		}
	        		}
	        	}
	        }else if($isInhousedRR == '1' && $isnotInhousedRR == '1'){

	        	$checkRRLines['rrnumber'] = $rrnumberOld;
	        	$requiredgrossqtyCheck = $rowRRbomcp['requiredgrossqty'] - $inhousedQty;
	        	$requiredgrossqtyCheck = number_format((float)$requiredgrossqtyCheck, 2, '.', '');

	        	if($requiredgrossqtyCheck <= 0){
	        		$checkRRLines['rrnumber'] = $rrnumberInhoused;
	        		$checkRRLines['rrstatus'] = $rrstatusInhoused;
	        		$checkRRLines['requiredgrossqty'] = number_format((float)$requiredgrossqtyInhoused, 2, '.', '');
	        		$checkRRLines['requirednetqty']   = $checkRRLines['requiredgrossqty'];
	        		$rowRRbomcp['requiredgrossqty'] = number_format((float)$rowRRbomcp['requiredgrossqty'], 2, '.', '');
	        		$rowRRbomcp['requirednetqty']   = $rowRRbomcp['requiredgrossqty'];

	        		if(strpos($rrnumberInhoused, ',')){
	        			$difference = $inhousedQty - $rowRRbomcp['requiredgrossqty'];
						$rrnumberInhoused = explode(',', $rrnumberInhoused);
						$rrstatusInhoused = explode(',', $rrstatusInhoused);
						$rrIndQtyInhoused = explode(',', $rrIndQtyInhoused);
						$rrPOInhoused = explode(',', $rrPOInhoused);
						$rrPOLineInhoused = explode(',', $rrPOLineInhoused);

						foreach ($rrnumberInhoused as $key => $value) {
							$rrPreviousQty[$value] = $rrIndQtyInhoused[$key];
					    	if($rrIndQtyInhoused[$key] <= $difference){
					    		$rrqtyNew[$value] = 0;
					    		$difference = $difference -$rrIndQtyInhoused[$key];
					    		if($difference < 0) $difference = 0;
					    	}else{
					    		$rrqtyNew[$value] = $rrIndQtyInhoused[$key]- $difference;
					    		
					    	}
					    	
					    	$rrstatusNew[$value] = $rrstatusInhoused[$key];
					    	$rrInhousedPO[$value] = $rrPOInhoused[$key];
						    $rrInhousedPOLine[$value] = $rrPOLineInhoused[$key];
					    }
	        		}

	        		$deletedTime = date('Y-m-d H:i:s', time());
	        		$insertRR = "INSERT INTO erp_rrlines_deleted SELECT *,'$deletedTime' FROM erp_rrlines WHERE rrnumber='$rrnumberOld'";
	        		$insertRRresult = $conn->query($insertRR);
	        		$deleteRR = "DELETE FROM erp_rrlines WHERE rrnumber='$rrnumberOld'";
	        		$deleteRRresult = $conn->query($deleteRR);
	        	}else{
	        		$checkRRLines['requiredgrossqty'] = $checkRRLines['requiredgrossqty'] - $inhousedQty;
	        		$checkRRLines['requiredgrossqty'] = number_format((float)$checkRRLines['requiredgrossqty'], 2, '.', '');
	        		$checkRRLines['requirednetqty']   = $checkRRLines['requiredgrossqty'];
	        		$rowRRbomcp['requiredgrossqty'] = $rowRRbomcp['requiredgrossqty'] - $inhousedQty;
	        		$rowRRbomcp['requiredgrossqty'] = number_format((float)$rowRRbomcp['requiredgrossqty'], 2, '.', '');
	        		$rowRRbomcp['requirednetqty']   = $rowRRbomcp['requiredgrossqty'];
	        	}

	        	$checkRRLines['fabricusageperday'] = $checkRRLines['requiredgrossqty']/$checkRRLines['sewingperiod'];
	        	$rowRRbomcp['fabricusageperday'] = $rowRRbomcp['requiredgrossqty']/$rowRRbomcp['sewingperiod'];
	        }

	        $checkRRLines['isrrfreezed'] = '888';


			$changeInfo = "";
			$previousRR = "";
			$data = array();
			$checkRRLines['requiredgrossqty'] = number_format((float)$checkRRLines['requiredgrossqty'], 2, '.', '');
			$rrPreviousInfoRQ = number_format((float)$checkRRLines['requiredgrossqty'], 2, '.', '');

			foreach ($checkRRLines as $key => $value) {
				if($key == 'rrnumber' && $generatedRRStatus == 'new'){
					$previousRR = $value;
					$checkRRLines[$key] = $this->getNextDocNumber('counter_RR');
					$rrnumber = $checkRRLines[$key];
				}else if($key == 'rrnumber' && $generatedRRStatus == 'old'){
					$rrnumber = $value;
				}else if(array_key_exists($key, $rowRRbomcp) && $generatedRRStatus != 'new'){
					if($value != $rowRRbomcp[$key]){
						$changeInfo .=  $this->rrFieldTranslator[$key] . " : " . $value . ' ';
						$checkRRLines[$key] = $rowRRbomcp[$key];
					}
				}else if($key == 'idlines'){
					unset($checkRRLines[$key]);
				}else{

				}
			}

			$data = $checkRRLines;
			$data['previousinfo'] = $changeInfo;
			$data['origin'] = 'MRP Explosion';

			// if($changeInfo == '') continue;

			if(strpos($rrnumber, ',') && $generatedRRStatus == 'old'){
				$rrnumber = explode(',', $rrnumber);
				$sql = array();
				$oldData = $data;
				foreach ($rrnumber as $key => $value) {
					$previousRRQty = $data['requiredgrossqty'];
					$data['requiredgrossqty'] = $rrqtyNew[$value];
					$data['requirednetqty'] = $rrqtyNew[$value];
					$data['rrstatus'] = $rrstatusNew[$value];
					$data['powonumber'] = $rrInhousedPO[$value];
					$data['powolinenumber'] = $rrInhousedPOLine[$value];
					$data['rrnumber'] = $value;
					$data['previousinfo'] = str_replace($rrPreviousInfoRQ, $rrPreviousQty[$value] , $oldData['previousinfo']);

					$array_keys = array_keys($data);
					$array_values = array_values($data);

					$array_keys = implode(", ", $array_keys);
					$array_values = "'" . implode("','", $array_values) . "'";

					$sql[] = "INSERT INTO erp_rrlines($array_keys) VALUES($array_values)";
				}
				$rrnumber = implode("','", $rrnumber);

			}else{
				$array_keys = array_keys($data);
				$array_values = array_values($data);

				$array_keys = implode(", ", $array_keys);
				$array_values = "'" . implode("','", $array_values) . "'";

				$sql = "INSERT INTO erp_rrlines($array_keys) VALUES($array_values)";
			}
			
			// echo $sql . "<br>";
			// return;

			if($generatedRRStatus == 'old'){
				$sqlDel = "DELETE FROM erp_rrlines WHERE rrnumber IN('$rrnumber')";
				// echo $sqlDel. "<br>";
				$queryResult1 = $conn->query($sqlDel);
				$sqlUpdateRR = "UPDATE erp_rrlines SET isrrfreezed='888' WHERE designid='$designid' AND salesorder='$salesorder' AND isrrfreezed='1'";
				// echo $sqlUpdateRR. "<br>";
				$queryResult4 = $conn->query($sqlUpdateRR);

				if(is_array($sql)){
					foreach ($sql as $key => $value) {
						$queryResult2 = $conn->query($value);
						// echo $value. "<br>";
					}
				}else{
					$queryResult2 = $conn->query($sql);
					// echo $sql. "<br>";
				}

			// return;

				$sqlDeliveryDel = "DELETE FROM erp_rrlines_dlvlinewise WHERE designid='$designid' AND salesorder='$salesorder'";
				$queryResult3 = $conn->query($sqlDeliveryDel);
				$this->createRRLines_dlvLineWise($salesorder,$designid);

			}else if($generatedRRStatus == 'new'){
				$sqlUpdateRR = "UPDATE erp_rrlines SET isrrfreezed='0' WHERE designid='$designid' AND salesorder='$salesorder'";
				$queryResult4 = $conn->query($sqlUpdateRR);
				
				$queryResult1 = $conn->query($sql);
				$sqlDeliveryDel = "DELETE FROM erp_rrlines_dlvlinewise WHERE designid='$designid' AND salesorder='$salesorder'";
				$queryResult3 = $conn->query($sqlDeliveryDel);

				$this->createRRLines_dlvLineWise($salesorder,$designid);
			}
        
		}

		$this->updateBOMCPLine($salesorder);

        return $this->reRunButtonVisibility($salesorder);

	}	


	function updateItemCodeInMLnBOM($salesorder){

	    $conn = new ErpDbConn;
	    $productObj = new ProductCode();
	    $itemcodeObj = new FullItemCode();

	    $sql = "SELECT * FROM erp_bom WHERE salesorder='$salesorder'";
	    // echo $sql;
	    $queryResult = $conn->query($sql);

	    while ($rows = $queryResult->fetch_assoc()) {


	        $searchProductResult = $productObj->preProcesSearchProductCode_InchCheck($rows['itemtype'], $rows);

	        $searchItemCodeResult = $itemcodeObj->preProcesSearchFullItemCode_InchCheck($rows['itemtype'], $rows);

	        $this->setunsetProductCode($rows,$searchProductResult);
	        $this->setunsetFullItemCode($rows,$searchItemCodeResult);
	    }
	    $conn->close();

	}



	function setunsetProductCode($params, $searchProductResult){
	    $conn = new ErpDbConn;
	    $doclinenumber = $params['doclinenumber'];
	    $fmdocnumber = $params['fmdocnumber'];

	    $productcode = $searchProductResult['productcode'];
	    if($searchProductResult['productcode'] == '' || $searchProductResult['productcode'] == null){
	        $sql = "UPDATE erp_bom SET productcode = '' WHERE doclinenumber = '$doclinenumber'";
	        $conn->query($sql);
	        $sql = "UPDATE erp_fabricmaterialline SET productcode = '' WHERE docnumber = '$fmdocnumber'";
	        $conn->query($sql);
	            
	    } else if($searchProductResult['productcode'] != '' && $searchProductResult['productcode'] != null){
	        $sql = "UPDATE erp_bom SET productcode = '$productcode' WHERE doclinenumber = '$doclinenumber'";
	        $conn->query($sql);
	        $sql = "UPDATE erp_fabricmaterialline SET productcode = '$productcode' WHERE docnumber = '$fmdocnumber'";
	        $conn->query($sql);
	    }

	    $conn->close();


	}   

	function setunsetFullItemCode($params, $searchItemCodeResult){
	    $conn = new ErpDbConn;
	    $doclinenumber = $params['doclinenumber'];
	    $fmdocnumber = $params['fmdocnumber'];

	    $itemcode = $searchItemCodeResult['itemcode'];
	    $itemdescription = $searchItemCodeResult['itemdescription'];
	    if($searchItemCodeResult['itemcode'] == '' || $searchItemCodeResult['itemcode'] == null){
	        $sql = "UPDATE erp_bom SET itemcode = '', itemdescription = '' WHERE doclinenumber = '$doclinenumber'";
	        $conn->query($sql);

	        $sql = "UPDATE erp_fabricmaterialline SET itemcode = '', itemdescription = '' WHERE docnumber = '$fmdocnumber'";
	        $conn->query($sql);

	    } else if($searchItemCodeResult['itemcode'] != '' && $searchItemCodeResult['itemcode'] != null){
	        $sql = "UPDATE erp_bom SET itemcode = '$itemcode', itemdescription = '$itemdescription' WHERE doclinenumber = '$doclinenumber'";
	        $conn->query($sql);

	        $sql = "UPDATE erp_fabricmaterialline SET itemcode = '$itemcode', itemdescription = '$itemdescription' WHERE docnumber = '$fmdocnumber'";
	        $conn->query($sql);
	    }

	    $conn->close();


	}   

	function checkItemCodeINBOM($salesorder){
		$conn = new ErpDbConn;

		$sql = "SELECT salesorder FROM erp_bom WHERE salesorder='$salesorder' AND linestatus!='13'";
	    $result = $conn->query($sql);
	    $allRows = $result->num_rows;

	    $sqlhvItemCode = "SELECT salesorder FROM erp_bom WHERE salesorder='$salesorder' AND linestatus!='13' AND itemcode !=''";
	    $resulthvItemCode = $conn->query($sqlhvItemCode);
	    $allhvItemCodeRows = $resulthvItemCode->num_rows;

	    if($allRows == $allhvItemCodeRows){
	        return true;
	    }else{
	        return false;
	    }
	}


	function addItemCode($addItemCodeSalesorder){
		$conn = new ErpDbConn;

		$this->updateItemCodeInMLnBOM($addItemCodeSalesorder);

		$sqlofRR = "
	            SELECT 
	                bm.company AS company,
	                bm.endcustomer AS endcustomer,
	                bm.itemtype AS itemtype,
	                bm.itemcode AS itemcode,
	                bm.designid AS designid,
	                bm.itemdescription AS itemdescription,
	                SUM((bm.tnxqty*cp.pieceqty)/cp.totalpieceqty) AS requiredgrossqty,
	                SUM((bm.tnxqty*cp.pieceqty)/cp.totalpieceqty) AS requirednetqty,
	                bm.iduom AS iduom,
	                cp.sewingstartdate AS sewingstartdate,
	                cp.sewingfinisheddate AS sewingfinisheddate,
	                cp.processbeforesewing AS processbeforesewing,
	                cp.processaftersewing AS processaftersewing,
	                GROUP_CONCAT(distinct(bm.docnumber) SEPARATOR ',') AS bomdocnumber,
	                GROUP_CONCAT(distinct(bm.doclinenumber) SEPARATOR ',') AS bomlinenumber,
	                bm.previousitemcode AS previousitemcode,
	                bm.previousfmdocnumber AS previousfmdocnumber,
	                GROUP_CONCAT(distinct(cp.docnumber) SEPARATOR ',') AS cpdocnumber,
	                GROUP_CONCAT(distinct(bm.ldcslnumber) SEPARATOR ',') AS ldcslnumber,
	                cp.salesorder AS salesorder,
	                cp.formtype AS rrtype,
	                bm.unitprice AS unitprice,
	                bm.pricerequisitionnumber AS pricerequisitionnumber,
	                bm.fmdocnumber AS fmdocnumber,
	                bm.projectionfmdocnumber AS projectionfmdocnumber,
	                GROUP_CONCAT(distinct(cp.doclinenumber) SEPARATOR ',') AS cplineno
	            FROM
	                erp_bom bm
	                    JOIN
	                erp_capacityplan cp 
	                ON bm.ldcslnumber = cp.ldcslnumber
	            WHERE
	            bm.linestatus != '13'
	            AND
	            cp.salesorder = '$addItemCodeSalesorder'
	            GROUP BY cp.salesorder, bm.designid
	            ";


	    // return $sqlofRR;
        $queryResult = $conn->query($sqlofRR);
        while($rowRRbomcp = $queryResult->fetch_assoc()){
	        $salesorder = $rowRRbomcp['salesorder'];
	        $itemcode   = $rowRRbomcp['itemcode'];
	        $designid   = $rowRRbomcp['designid'];

	        $rrCreation = $this->checkItemCodeINBOM($salesorder);
	        if(!$rrCreation){
	        	continue;
	        }

	        $rowRRbomcp['origin'] = 'MRP Explosion';

	        $rowRRbomcp['colorcategory'] = $this->getColorCategory($itemcode,$salesorder);

	        $sqlExistRR = "SELECT rrnumber FROM erp_rrlines WHERE salesorder='$salesorder' AND designid='$designid'";
	        $resultExistRR = $conn->query($sqlExistRR);
			if($resultExistRR->num_rows == 0){
				$rowRRbomcp['rrnumber'] = $this->getNextDocNumber('counter_RR');
				// $rowRRbomcp['rrtype'] = $rowRRbomcp['formtype'];
				unset($rowRRbomcp['formtype']);
				$columns = array_keys($rowRRbomcp);
				$values = array_values($rowRRbomcp);

				$columns = implode(',', $columns);
				$values = "'" . implode("','", $values) . "'";

				$sqlInsertRR = "INSERT INTO erp_rrlines($columns) VALUES($values)";
				$queryResultRR = $conn->query($sqlInsertRR);

				$this->createRRLines_dlvLineWise($salesorder,$designid);
			}else{
				$sql = "SELECT company, endcustomer, itemtype, itemcode, designid, rrtype, itemdescription, SUM(requiredgrossqty) AS requiredgrossqty , SUM(requirednetqty) AS requirednetqty, iduom, sewingstartdate, sewingfinisheddate, processbeforesewing, processaftersewing, bomdocnumber, bomlinenumber, previousitemcode, previousfmdocnumber, cpdocnumber, ldcslnumber, salesorder, unitprice, pricerequisitionnumber, fmdocnumber, projectionfmdocnumber, cplineno, GROUP_CONCAT(distinct(rrstatus) SEPARATOR ',') AS rrstatus,rrnumber, powonumber, powolinenumber FROM  erp_rrlines WHERE salesorder = '$salesorder' AND designid='$designid' AND rrstatus!='901' GROUP BY designid";
				// return $sql;

				$this->rrExplotion($sql);
			}

			
		}
        
        

	}	
	



	function getColorCategory($itemcode,$salesorder){
	    $conn = new ErpDbConn;
	    $sql = "
	        SELECT 
	            m.style,
	            c.itemcode,
	            c.colorcategory
	        FROM
	            erpprod.erp_garmentid m
	                LEFT JOIN
	            erpprod.erp_fabricmaterialline c ON m.docnumber = c.materiallistid
	        WHERE
	            m.ldcslnumber LIKE '%$salesorder%'
	                AND c.itemcode = '$itemcode'
	        ";
	        
	    $queryResult = $conn->query($sql);
	    $colorcategory = $queryResult->fetch_assoc()['colorcategory'];
	    return $colorcategory;
	}

	/**
	 * [getSalesorderdeliverylinenumber description]
	 * @return [string] [sales order delivery line]
	 */
	function getSalesorderdeliverylinenumber($cplineno,$ldcslnumber){
	    $conn = new ErpDbConn;
	    $sql = "SELECT * FROM erp_salesorderdeliveryline WHERE ldcslnumber='$ldcslnumber' AND deliverylinenumber='$cplineno'";
	    $queryResult = $conn->query($sql);
	    $row = $queryResult->fetch_assoc();
	    return $row['subdoclinenumber'];
	}


	function updateBOMCPLine($salesorder){
		$conn = new ErpDbConn;
	    $sqlBOM = "UPDATE erp_bom SET isrrcreated='1',frozenstatus='888' WHERE salesorder='$salesorder'";
	    $queryResult = $conn->query($sqlBOM);

	    $sqlCP = "UPDATE erp_capacityplan SET isrrcreated='1',frozenstatus='888' WHERE salesorder='$salesorder'";
	    $queryResult = $conn->query($sqlCP);

	    $sqlSO = "UPDATE erp_salesorder SET islinefreezed='0', cpfreezestatus='0', frozenforotherinfo = '0' WHERE docnumber='$salesorder'";
	    $queryResult = $conn->query($sqlSO);
	    
	    $conn->close();
	}

	/**
	 * [getProjectionInformation description]
	 * @param  [type] $projectionfmdocnumber [get rrnumber and idlines with projection fmdocnumber]
	 * @return [array]  [rrnumber and idlines]
	 */
	function getProjectionInformation($ldcslnumber){
	    $conn = new ErpDbConn;
	    $sql = "SELECT parentdocnumber,parentldcslnumber FROM erp_salesorder WHERE ldcslnumber='$ldcslnumber' limit 1";
	    $queryResult = $conn->query($sql);
	    $row = $queryResult->fetch_assoc();
	    return $row;
	}	

	function getProjectionItemLineInformation($ldcslnumber){
	    $conn = new ErpDbConn;
	    $sql = "SELECT parentdocnumber,parentldcslnumber FROM erp_salesorder WHERE ldcslnumber='$ldcslnumber' limit 1";
	    $queryResult = $conn->query($sql);
	    $row = $queryResult->fetch_assoc();
	    return $row;
	}	

	/**
	 * [getNominatedSupplierInformation description]
	 * @param  [type] $fmdocnumber [get nominated supplier info with fmdocnumber]
	 * @return [array]  [nominated supplier info]
	 */
	function getNominatedSupplierInformation($fmdocnumber){
	    $conn = new ErpDbConn;
	    $sql = "SELECT nominatedsuppliername,nominatedsupplieraddress,supplierreferencenumber,paymentterm,deliveryterm FROM erp_fabricmaterialline WHERE docnumber='$fmdocnumber'";
	    $queryResult = $conn->query($sql);
	    $row = $queryResult->fetch_assoc();
	    return $row;
	}


	// function createRRLines_dlvLineWise($genRRnumber,$cplinenoSearch,$generatedRRStatus,$itemcode){
	function createRRLines_dlvLineWise($salesorder,$designid){

	    $ldcslnumbers = array();
	    $conn = new ErpDbConn;
	    $sql = "
	            SELECT 
	                bm.company AS company,
	                bm.endcustomer AS endcustomer,
	                bm.itemtype AS itemtype,
	                bm.itemcode AS itemcode,
	                bm.designid AS designid,
	                bm.itemdescription AS itemdescription,
	                bm.tnxqty AS requiredgrossqty,
	                bm.iduom AS iduom,
	                cp.pieceqty AS pieceqty,
	                cp.totalpieceqty AS totalpieceqty,
	                cp.sewingstartdate AS sewingstartdate,
	                cp.sewingfinisheddate AS sewingfinisheddate,
	                cp.outputperlineperday AS outputperlineperday,
	                cp.processbeforesewing AS processbeforesewing,
	                cp.processaftersewing AS processaftersewing,
	                bm.docnumber AS bomdocnumber,
	                bm.doclinenumber AS bomlinenumber,
	                bm.previousitemcode AS previousitemcode,
	                bm.previousfmdocnumber AS previousfmdocnumber,
	                cp.docnumber AS cpdocnumber,
	                bm.ldcslnumber AS ldcslnumber,
	                cp.salesorder AS salesorder,
	                cp.formtype AS formtype,
	                cp.allocatedlinesnumber AS allocatedlinesnumber,
	                cp.shipmentdate AS shipmentdate,
	                bm.unitprice AS unitprice,
	                bm.pricerequisitionnumber AS pricerequisitionnumber,
	                bm.fmdocnumber AS fmdocnumber,
	                bm.projectionfmdocnumber AS projectionfmdocnumber,
	                cp.doclinenumber AS cplineno,
	                cp.linenumber AS subdocline
	            FROM
	                erp_bom bm
	                    JOIN
	                erp_capacityplan cp 
	                ON bm.ldcslnumber = cp.ldcslnumber
	            WHERE
	            bm.linestatus != '13'
	            AND
	            cp.salesorder='$salesorder'
	            AND 
	            bm.designid = '$designid'
	            ";
	     // return $sql;
	    $queryResult = $conn->query($sql);

	    $formtypeTranslator = array(
	        'projection'       => 'projection', 
	        'under_projection' => 'confirmed', 
	        'direct'           => 'direct'
	    );
	    $ldcslnumber = "";
	    $queryResult_RR = "";

	    while ($row = $queryResult->fetch_assoc()) {
	        
	        $salesorder             = $row["salesorder"];
	        $itemcode               = $row["itemcode"];
	        $designid               = $row["designid"];
	        // $rrnumber               = $genRRnumber;
	        $rrtype                 = $row["formtype"];
	        $rrstatus               = '0';
	        $company                = $row["company"];
	        $endcustomer            = $row["endcustomer"];
	        $itemtype               = $row["itemtype"];
	        $itemdescription        = $row["itemdescription"];
	        $requiredgrossqty       = $row["requiredgrossqty"];
	        $iduom                  = $row["iduom"];
	        $pieceqty               = $row["pieceqty"];
	        $totalpieceqty          = $row["totalpieceqty"];
	        $sewingstartdate        = $row["sewingstartdate"];
	        $sewingfinisheddate     = $row["sewingfinisheddate"];
	        $outputperlineperday    = $row["outputperlineperday"];
	        $processbeforesewing    = $row["processbeforesewing"];
	        $processaftersewing     = $row["processaftersewing"];
	        $bomdocnumber           = $row["bomdocnumber"];
	        $bomlinenumber          = $row["bomlinenumber"];
	        $previousitemcode       = $row["previousitemcode"];
	        $previousfmdocnumber    = $row["previousfmdocnumber"];
	        $cpdocnumber            = $row["cpdocnumber"];
	        $ldcslnumber            = $row["ldcslnumber"];
	        $formtype               = $row["formtype"];
	        $unitprice              = $row["unitprice"];
	        $pricerequisitionnumber = $row["pricerequisitionnumber"];
	        $fmdocnumber            = $row["fmdocnumber"];
	        $projectionfmdocnumber  = $row["projectionfmdocnumber"];
	        $cplineno               = $row["cplineno"];
	        $subdocline             = $row["subdocline"];
	        $allocatedlinesnumber   = $row["allocatedlinesnumber"];
	        $shipmentdate   		= $row["shipmentdate"];

	        
	        //get projection rr information
	        $projectionRRstatus = 100;
	        if($rrtype == 'under_projection'){
	            $projectionItemLineSalesOrderInfo = getProjectionItemLineInformation($ldcslnumber);
	            $projectionSalesOrder     = $projectionItemLineSalesOrderInfo['parentdocnumber'];
	            $projectionldcslnumber    = $projectionItemLineSalesOrderInfo['parentldcslnumber'];
	        }else{
	            $parentidlines   = '';
	            $parentrrnumber  = '';
	        }

	        //get nominated supplier information
	        $nominatedsuppliername    = '';        
	        $nominatedsupplieraddress = '';            
	        $supplierreferencenumber  = '';            
	        $paymentterm              = '';        
	        $deliveryterm             = ''; 
	        if($fmdocnumber != ''){
	            $nominatedSupplierInfo     = $this->getNominatedSupplierInformation($fmdocnumber);
	            $nominatedsuppliername     = $nominatedSupplierInfo['nominatedsuppliername'];           
	            $nominatedsupplieraddress  = $nominatedSupplierInfo['nominatedsupplieraddress'];            
	            $supplierreferencenumber   = $nominatedSupplierInfo['supplierreferencenumber'];         
	            $paymentterm               = $nominatedSupplierInfo['paymentterm'];         
	            $deliveryterm              = $nominatedSupplierInfo['deliveryterm'];            
	        }

	        // change requiredgrossqty
	        $requiredgrossqty = ((float)$requiredgrossqty * (float)$pieceqty)/(float)$totalpieceqty;


	        // get sewing period
	        $date1 = new DateTime($sewingstartdate);
	        $date2 = new DateTime($sewingfinisheddate);
	        $sewingperiod = $date2->diff($date1)->format("%a");
	        $sewingperiod = (int)($sewingperiod+1);   

	        //get sales order delivery line no
	        $salesorderdeliverylinenumber = $this->getSalesorderdeliverylinenumber($subdocline,$ldcslnumber);  

	        // calculate fabric usage
	        $fabricusageperday = $requiredgrossqty/$sewingperiod;
	        
	        $ldcslnumbers[]      = $ldcslnumber;

	        
	        $sql = "
	        INSERT INTO erp_rrlines_dlvlinewise 
	        (
	        rrtype, 
	        rrstatus, 
	        company,
	        endcustomer, 
	        itemtype, 
	        itemcode, 
	        designid,
	        itemdescription, 
	        requiredgrossqty, 
	        iduom, 
	        sewingstartdate, 
	        sewingfinisheddate, 
	        sewingperiod,
	        fabricusageperday,
	        processbeforesewing,
	        processaftersewing,
	        bomdocnumber, 
	        bomlinenumber, 
	        cpdocnumber, 
	        ldcslnumber, 
	        salesorder,
	        unitprice,
	        pricerequisitionnumber,
	        previousitemcode,
	        previousfmdocnumber,
	        fmdocnumber,
	        projectionfmdocnumber,
	        projectionsalesorder,
	        projectionldcslnumber,
	        nominatedsuppliername,
	        nominatedsupplieraddress,
	        supplierreferencenumber,
	        paymentterm,
	        deliveryterm,
	        salesorderdeliverylinenumber,
	        allocatedlinesnumber,
	        shipmentdate,
	        cplineno
	        ) 
	        VALUES 
	        (
	        '$rrtype', 
	        '$rrstatus', 
	        '$company', 
	        '$endcustomer', 
	        '$itemtype', 
	        '$itemcode', 
	        '$designid', 
	        '$itemdescription', 
	        '$requiredgrossqty', 
	        '$iduom', 
	        '$sewingstartdate', 
	        '$sewingfinisheddate', 
	        '$sewingperiod',
	        '$fabricusageperday',
	        '$processbeforesewing', 
	        '$processaftersewing', 
	        '$bomdocnumber', 
	        '$bomlinenumber', 
	        '$cpdocnumber', 
	        '$ldcslnumber', 
	        '$salesorder',
	        '$unitprice',
	        '$pricerequisitionnumber',
	        '$previousitemcode',
	        '$previousfmdocnumber',
	        '$fmdocnumber',
	        '$projectionfmdocnumber',
	        '$projectionSalesOrder',
	        '$projectionldcslnumber',
	        '$nominatedsuppliername',
	        '$nominatedsupplieraddress',
	        '$supplierreferencenumber',
	        '$paymentterm',
	        '$deliveryterm',
	        '$salesorderdeliverylinenumber',
	        '$allocatedlinesnumber',
	        '$shipmentdate',
	        '$cplineno'
	        )
	        ";
	        // echo "string" . $sql . "<br/>";
	        $queryResult_RR = $conn->query($sql);	

	        // need to update BOM and CP
	        if($queryResult_RR){
	            $sql = "UPDATE erp_bom SET isrrcreated = '1' WHERE ldcslnumber = '$ldcslnumber'";
	            $conn->query($sql);
	            $sql = "UPDATE erp_capacityplan SET isrrcreated = '1' WHERE ldcslnumber = '$ldcslnumber'";
	            $conn->query($sql);        
	        }        

	    }   



	}


	function checkAllBomLineConfirmed($salesorder){
		$conn = new ErpDbConn;

		$checkAllBOMCreated = "SELECT ldcslnumber FROM erp_salesorder WHERE docnumber='$salesorder'";
		$resultCheckBOM = $conn->query($checkAllBOMCreated);
		while($row = $resultCheckBOM->fetch_assoc()){
			$ldcslnumber = $row['ldcslnumber'];
			$sqlBOM = "SELECT ldcslnumber FROM erp_bom WHERE ldcslnumber='$ldcslnumber'";
			$resultBOM = $conn->query($sqlBOM);
			$noofrowsbom = $resultBOM->num_rows;
			if($noofrowsbom == 0) return false;

			$sqlCP = "SELECT ldcslnumber FROM erp_capacityplan WHERE ldcslnumber='$ldcslnumber'";
			$resultCP = $conn->query($sqlCP);
			$noofrowscp = $resultCP->num_rows;
			if($noofrowscp == 0) return false;

		}

		$sql = "SELECT ldcslnumber FROM erp_bom WHERE ldcslnumber IN(SELECT ldcslnumber FROM erp_salesorder WHERE docnumber='$salesorder') AND linestatus!='13'";
		$result = $conn->query($sql);
		$allRows = $result->num_rows;

		$sqlConfirm = "SELECT ldcslnumber FROM erp_bom WHERE ldcslnumber IN(SELECT ldcslnumber FROM erp_salesorder WHERE docnumber='$salesorder') AND linestatus='1' AND linestatus!='13'";
		$resultConfirm = $conn->query($sqlConfirm);
		$allConfirmRows = $resultConfirm->num_rows;

		$sqlCP = "SELECT ldcslnumber FROM erp_capacityplan WHERE ldcslnumber IN(SELECT ldcslnumber FROM erp_salesorder WHERE docnumber='$salesorder')";
		$resultCP = $conn->query($sqlCP);
		$allRowsCP = $resultCP->num_rows;

		$sqlConfirmCP = "SELECT ldcslnumber FROM erp_capacityplan WHERE ldcslnumber IN(SELECT ldcslnumber FROM erp_salesorder WHERE docnumber='$salesorder') AND docstatus='1'";
		$resultConfirmCP = $conn->query($sqlConfirmCP);
		$allConfirmRowsCP = $resultConfirmCP->num_rows;

		if($allRows == $allConfirmRows && $allRowsCP == $allConfirmRowsCP){
			return true;
		}else{
			return false;
		}
	}


	function reRunButtonVisibility($salesorder){
		$conn = new ErpDbConn;
		$sqlBOM = "SELECT salesorder FROM erp_bom WHERE salesorder='$salesorder' AND linestatus!='13' AND frozenstatus NOT IN('0','888')";
		$sqlBOMRRCreated = "SELECT salesorder FROM erp_bom WHERE salesorder='$salesorder' AND linestatus!='13' AND frozenstatus NOT IN('0','888') AND linestatus='1' AND itemcode!=''";

		$resultBOM = $conn->query($sqlBOM);
		$resultBOMRRCreated = $conn->query($sqlBOMRRCreated);

		$bomRowsNum = $resultBOM->num_rows;
		$bomRRCreatedRowsNum = $resultBOMRRCreated->num_rows;

		$sqlCP = "SELECT salesorder FROM erp_capacityplan WHERE salesorder='$salesorder' AND frozenstatus NOT IN('0','888')";
		$sqlCPRRCreated = "SELECT salesorder FROM erp_capacityplan WHERE salesorder='$salesorder' AND docstatus='1' AND frozenstatus NOT IN('0','888')";

		$resultCP = $conn->query($sqlCP);
		$resultCPRRCreated = $conn->query($sqlCPRRCreated);

		$cpRowsNum = $resultCP->num_rows;
		$cpRRCreatedRowsNum = $resultCPRRCreated->num_rows;

		$isBomCPLineConfirmed = $this->checkAllBomLineConfirmed($salesorder);

		if(($bomRowsNum == $bomRRCreatedRowsNum) && ($cpRowsNum == $cpRRCreatedRowsNum) && $bomRowsNum != 0 && $cpRowsNum != 0 && $isBomCPLineConfirmed){
			$flag = true;
		}else{
			$flag = false;
		}

		return json_encode($flag);		
	}

	function checkDeliveryLineQty($bomlinenumber,$cplineno,$requiredgrossqty){
		$conn = new ErpDbConn;
		$sql = "SELECT IFNULL(requiredgrossqty,0) AS requiredgrossqty FROM erp_rrlines_dlvlinewise WHERE bomlinenumber='$bomlinenumber' AND cplineno='$cplineno'";
		$queryResult = $conn->query($sql);
		$row = $queryResult->fetch_assoc();
		$queryRowsNum = $queryResult->num_rows;

		$requiredgrossqtyOld = $row['requiredgrossqty'];
		if($queryRowsNum == 0) return 0;
		

		return $requiredgrossqtyOld;
	}


	function updatePOFlag($salesorder){
		$conn = new ErpDbConn;

		$sql = "UPDATE erp_purchaseorder SET ispoautoupdateflag='1' WHERE salesorder='$salesorder'";
		$queryResult = $conn->query($sql);
		$conn->close();

		return;
	}
	
}






/**
 * Routing ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 */
if ( basename(__FILE__) == basename($_SERVER["SCRIPT_FILENAME"]) ) {
    // called directly
	if ( $_SERVER['REQUEST_METHOD'] == 'GET' ) {

		if(isset($_GET['reqType'])){

			$reqType = $_GET['reqType'];
			$listObj  = new ThisListAPI();

			if($reqType == 'getListData') {
				$params = $_GET;
				$returnData = $listObj->getListData($params);
				echo $returnData;
			}

			if($reqType == 'getSOInfo') {
				$params = $_GET;
				$returnData = $listObj->getSOInfo($params);
				echo $returnData;
			}

			if($reqType == 'getBulkAllocation') {
				$params = $_GET;
				$returnData = $listObj->getBulkAllocation($params);
				echo $returnData;
			}

			if($reqType == 'getRRLineTablePopup') {
				$params = $_GET;
				$returnData = $listObj->getRRLineTablePopup($params);
				echo $returnData;
			}	

			if($reqType == 'getRRDeliveryLineWise') {
				$params = $_GET;
				$returnData = $listObj->getRRDeliveryLineWise($params);
				echo $returnData;
			}	

			if($reqType == 'getBOMInformation') {
				$params = $_GET;
				$returnData = $listObj->getBOMInformation($params);
				echo $returnData;
			}

			if($reqType == 'readPOWODeliveryLine') {

				$rrnumber = $_GET['rrnumber'];
				$returnData = $listObj->readPOWODeliveryLine($rrnumber);
				echo $returnData;
			}

			if($reqType == 'getRRMrp') {

				$salesorder = $_GET['salesorder'];
				$returnData = $listObj->getRRMrp($salesorder);
				echo $returnData;
			}

			if($reqType == 'addItemCode') {

				$salesorder = $_GET['salesorder'];
				$returnData = $listObj->addItemCode($salesorder);
				echo $returnData;
			}			

			if($reqType == 'reRunButtonVisibility') {

				$salesorder = $_GET['salesorder'];
				$returnData = $listObj->reRunButtonVisibility($salesorder);
				echo $returnData;
			}
		}


	} else if( $_SERVER['REQUEST_METHOD'] == 'POST' ){
	
		if(isset($_POST['reqType'])){

			$reqType = $_POST['reqType'];
			$listObj  = new ThisListAPI();

			if($reqType == "saveDoc"){

				$docobj = $_POST['docobj'];
				$returnData = $listObj->saveDoc($docobj);
				echo $returnData;
			}

			if($reqType == "insertMergeRRLines"){

				$returnData = $listObj->insertMergeRRLines($_POST['data']);
				echo $returnData;
			}

			if($reqType == "insertSplitRRLines"){

				$returnData = $listObj->insertSplitRRLines($_POST['data']);
				echo $returnData;
			}

			if($reqType == "setFabricInhouseDate"){

				$data = $_POST['data'];
				$returnData = $listObj->setFabricInhouseDate($data);
				echo $returnData;
			}

			if($reqType == "saveDeliveryLine"){
			
				$docobj = $_POST['docobj'];
				$returnData = $listObj->saveDeliveryLine($docobj);
				echo $returnData;
			}

			if($reqType == "unallocateStock"){

				$data = $_POST['data'];
				$returnData = $listObj->unallocateStock($data);
				echo $returnData;
			}

			if($reqType == "sendForRecalculation"){

				$data = $_POST['data'];
				$returnData = $listObj->sendForRecalculation($data);
				echo $returnData;
			}


			if($reqType == "sendForPOWO"){

				$idlines = $_POST['idlines'];
				$linestatus = $_POST['linestatus'];
				$replenishedby = $_POST['replenishedby'];
				$returnData = $listObj->sendForPOWO($idlines,$linestatus,$replenishedby);
				echo $returnData;
			}
			
			if($reqType == "updatePOFlag"){

				$salesorder = $_POST['salesorder'];
				$returnData = $listObj->updatePOFlag($salesorder);
				echo $returnData;
			}

		}


	}

} else {
    // included/required

}
?>