<?php
require_once $_SERVER["DOCUMENT_ROOT"] . '/includes/configli.php'; // mysql connections
require_once __DIR__ . "/classes/myclassautoloader.php";
/*
 * If called directly from web, then do some routing
 * otherwise, don't execute any code, just define the functions
 */
if (basename(__FILE__) == basename($_SERVER["SCRIPT_FILENAME"])) {
  // called directly
  $crudmode =  (isset($_GET['crudmode'])) ? $_GET['crudmode'] : '' ;
  $formtype = $_GET['formtype'];
  $doctype  = $_GET['doctype'];

  if ($doctype == 'MX') {
    $genericDocument = new ErpDocumentMX();

  } elseif ($doctype == 'XX') {
    $genericDocument = new ErpDocListNameXX();

  } elseif ($doctype == 'FL') {
    $genericDocument = new ErpDocumentFL();

  } elseif ($doctype == 'DR') {
    $genericDocument = new ErpDocumentDR($doctype, $formtype);

  } elseif ($doctype == 'RR') {
    $genericDocument = new ErpDocListRR($doctype, $formtype);

  } elseif ($doctype == 'BOM') {
    $genericDocument = new ErpDocListBOM($doctype, $formtype);

  }


  echo json_encode($genericDocument->formStructure($doctype, $formtype, $crudmode), JSON_PRETTY_PRINT);
} else {
  // included/required
}
?>