<?php
/*
* Define printdoc header
* Define printdoc lines
* Define printdoc NB
* Define printdoc signature
* Define printdoc gatepass
*/
function printdocdefine($doctype , $formtype) {	

	if ($doctype == 'MX') {

		$printdocheader = array(
			1 => array( 'docnumber', 'docdate'),
			2 => array( 'vehicleno', 'lockno'),
			3 => array( 'drivername', 'drivermobileno'),
		);

		$printdoclines = array(
			'#'          => 'serialno',
			'Item'       => array( 'itemcode' , 'itemdescription'),
			'References' => array( 'itemlot', 'trackingno'),
			'Qty'        => array( 'totallotqty', 'iduom'),
		);

		$printdoclines = array(
			'#'         => 'serialno',
			'Item Type' => 'itemtype',
			'Item Code' => 'itemcode',
			'Item Lot'  => 'itemlot',
			'Serial'    => 'serial',
			'Quantity'  => 'tnxqty',
			'Size'      => 'size',
		);

		$printgatepass = array(
			'#'         => 'serialno',
			'Item Type' => 'itemtype',
			'Item Code' => 'itemcode',
			'Item Lot'  => 'itemlot',
			'Serial'    => 'serial',
			'Quantity'  => 'tnxqty',
			'Size'      => 'size',
			'Remarks'           => ''

		);

		$printsignature = array('Receiver Signature', 'Security Incharge', 'Store Officer', 'Authorized Signature');
		$nettotalline = array("total"=>"total", "totalgarmentqty" => "totalgarmentqty", "totalcartonqty" => "totalcartonqty");




		//------------ variation based on form type
		$formtittle = "Goods Delivery Notes";
		$subFormTittle = "Default";	
		switch ($formtype) {
			case 'export':
				$subFormTittle = "For: Export";	
				break;
			case 'wms_issuetodepartment':
				$subFormTittle = "issue to department";	
				break;					
			default:
				break;
		}

		$printFormatStructure = array(
			'formTittle'       => $formtittle,
			'hasDocSubTittle'  => true,
			'subFormTittle'    => $subFormTittle,
			'hasHeadTable'     => true,
			'hasLineTable'     => true,
			'hasNetTotalTable' => true,
			'hasNotesTable'    => true,
			'note' 			   => 'N.B: Please receive the above goods in proper condition and sign the duplicate copy and return',
			'hasSignTable'     => true,
			'hasGatePassTable' => true,
 			'headertable'      => $printdocheader,
			'linetable'        => $printdoclines,
			'nettolaltable'    => $nettotalline,
			'gatepasstable'    => $printgatepass,
			'signaturetable'   => $printsignature

		);	
		return $printFormatStructure;

	} else if ($doctype == 'PO') {

		$printdocheader = array(
			1 => array('formtype',  'docnumber','docdate', 'company'),
			// 1 => array( 'docnumber', 'previousponumber', 'docdate'),
			// 2 => array( 'salesordertype', 'endcustomer'),
			// 3 => array( 'company', 'requestor'),
		);

		$printdoclines = array(
			'#'          => 'serialno',
			'Item'       => array( 'itemcode' , 'itemdescription'),
			'References' => array( 'itemlot', 'trackingno'),
			'Qty'        => array( 'totallotqty', 'iduom'),
		);

		$printdoclines = array(
			// '#'        => 'serialno',
			'PO Line No.' => 'doclinenumber',
			'linestatus'  => 'linestatus',
			
			'Currency'    => 'currency',
			'Unit Price'  => 'unitprice',
		);


		$printsignature = array('Receiver Signature', 'Security Incharge', 'Store Officer', 'Authorized Signature');
		$nettotalline = array("total"=>"total", "totalgarmentqty" => "totalgarmentqty", "totalcartonqty" => "totalcartonqty");

		$printgatepass = array(
			'#'         => 'serialno',
			'Item Type' => 'itemtype',
			'Item Code' => 'itemcode',
			'Item Lot'  => 'itemlot',
			'Serial'    => 'serial',
			'Quantity'  => 'tnxqty',
			'Size'      => 'size',
			'Remarks'   => ''

		);



		//------------ variation based on form type
		$formtittle = "Goods Delivery Notes";
		$subFormTittle = "Default";	
		switch ($formtype) {
			case 'export':
				$subFormTittle = "For: Export";	
				break;
			case 'wms_issuetodepartment':
				$subFormTittle = "issue to department";	
				break;					
			default:
				break;
		}

		$printFormatStructure = array(
			'formTittle'       => $formtittle,
			'hasDocSubTittle'  => false,
			'subFormTittle'    => $subFormTittle,
			'hasHeadTable'     => true,
			'hasLineTable'     => true,
			'hasNetTotalTable' => false,
			'hasNotesTable'    => false,
			'note' 			   => 'N.B: Please receive the above goods in proper condition and sign the duplicate copy and return',
			'hasSignTable'     => false,
			'hasGatePassTable' => false,
			'hasPaymentAndDeliveryTermTable' => true,
 			'headertable'      => $printdocheader,
			'linetable'        => $printdoclines,
			'nettolaltable'    => $nettotalline,
			'signaturetable'   => $printsignature,
			'gatepasstable'    => $printgatepass,

		);	
		return $printFormatStructure;

	} else {

		$printdocheader = array(
			1 => array( 'docnumber', 'docdate'),
			2 => array( 'vehicleno', 'lockno'),
			3 => array( 'drivername', 'drivermobileno'),
		);

		$printdoclines = array(
			'#'          => 'serialno',
			'Item'       => array( 'itemcode' , 'itemdescription'),
			'References' => array( 'itemlot', 'trackingno'),
			'Qty'        => array( 'totallotqty', 'iduom'),
		);

		$printdoclines = array(
			'#'         => 'serialno',
			'Item Type' => 'itemtype',
			'Item Code' => 'itemcode',
			'Item Lot'  => 'itemlot',
			'Serial'    => 'serial',
			'Quantity'  => 'tnxqty',
			'Size'      => 'size',
		);

		$printgatepass = array(
			'#'         => 'serialno',
			'Item Type' => 'itemtype',
			'Item Code' => 'itemcode',
			'Item Lot'  => 'itemlot',
			'Serial'    => 'serial',
			'Quantity'  => 'tnxqty',
			'Size'      => 'size',
			'Remarks'           => ''

		);

		$printsignature = array('Receiver Signature', 'Security Incharge', 'Store Officer', 'Authorized Signature');
		$nettotalline = array("total"=>"total", "totalgarmentqty" => "totalgarmentqty", "totalcartonqty" => "totalcartonqty");




		//------------ variation based on form type
		$formtittle = "Goods Delivery Notes";
		$subFormTittle = "Default";	
		switch ($formtype) {
			case 'export':
				$subFormTittle = "For: Export";	
				break;
			case 'wms_issuetodepartment':
				$subFormTittle = "issue to department";	
				break;					
			default:
				break;
		}

		$printFormatStructure = array(
			'formTittle'       => $formtittle,
			'hasDocSubTittle'  => true,
			'subFormTittle'    => $subFormTittle,
			'hasHeadTable'     => true,
			'hasLineTable'     => true,
			'hasNetTotalTable' => true,
			'hasNotesTable'    => true,
			'note' 			   => 'N.B: Please receive the above goods in proper condition and sign the duplicate copy and return',
			'hasSignTable'     => true,
			'hasGatePassTable' => true,
 			'headertable'      => $printdocheader,
			'linetable'        => $printdoclines,
			'nettolaltable'    => $nettotalline,
			'gatepasstable'    => $printgatepass,
			'signaturetable'   => $printsignature

		);	
		return $printFormatStructure;

	}



}


?>