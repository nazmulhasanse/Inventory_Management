<?php
require_once $_SERVER["DOCUMENT_ROOT"] . '/includes/user.cookies.php';    // check user login
require_once $_SERVER["DOCUMENT_ROOT"] . '/includes/config.php';          // mysql connections
require_once $_SERVER["DOCUMENT_ROOT"] . '/includes/user-privilege.php';  // privilege function
// check privilege (keep module and section empty to skip privilege check)
$module = "";
$section = "";
$privilege = userPrivileges($module, $section);
if (!$privilege['R']) { header("Location: ../user/no-permission.php"); exit();}


$formTitle = 'PO Lines List';
$pageTittle= 'PO Lines List';
$mainHTML  = 'html/listerp.html';
$mainJS    = 'js/list-erp.js?t=2017-10-15';
$customJS  = 'js/list-ub-po-lines.js?t=2017-10-15';
$apiURL    = 'list-ub-po-lines_api.php';
$formId    = 'searchForm';

$module = "";
$section = "";
$privilege_sm = json_encode(userPrivileges($module,$section));
?>

<!DOCTYPE HTML>
<html>
<head>
    <?php require_once($_SERVER["DOCUMENT_ROOT"] . "/includes/head.php") ;?>
    <title><?php echo $formTitle;?></title>
    
    <!-- for cache delete - keep it one week start -->
    <!-- apply date 2017-06-06 -->
    <meta http-equiv='cache-control' content='no-cache'>
    <meta http-equiv='expires' content='0'>
    <meta http-equiv='pragma' content='no-cache'>
    <!-- for cache delete - keep it one week end -->

    <link rel="stylesheet" type="text/css" href="css/listerp.css">
    <link rel="stylesheet" type="text/css" href="css/list-yourname.css?t=2017-10-15">
    <link rel="stylesheet" type="text/css" href="css/material-button.css">
    <link rel="stylesheet" type="text/css" href="plugin/msgPop.css">
</head>
<body class="right-sidebar">

<!-- Header Wrapper -->
<div id="header-wrapper">
<div class="container">
<div class="row">
<div class="12u">
<!-- Header -->
    <header id="header">
        <?php 
        include_once($_SERVER["DOCUMENT_ROOT"] . "/includes/mainmenu.php");
        ?>
    </header>
</div>
</div>
</div>
</div>

<!-- Main Wrapper -->
<div id="main-wrapper">
<div class="container">
<div class="row">
    <div class="12u skel-cell-important">
        <!-- Content -->
        <div id="content">
        <article class="last">
    <!-- HEADLINES -->
        <div class="headline1"><a href="/erp-apparel/documents-home.php?m=po">Home</a> - </div>   
        <div class="headline2"><?php echo $formTitle;?></div> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<!-- LINKS -->
        <a href="list-inv-stock.php">Inventory Stock</a> &nbsp;|&nbsp; 
        <a href="#">xxxxx</a>
        <br><br>
<!-- PAGE CONTENTS -->
<div id="upperButtonBar" style="height:0px;">
    <!-- <input type="button" class="btn-grey" value="Action Button" title="Action Button" onclick="ERPLIST.actionButton();" style="display: inline-block;"> -->
</div>   

<div id="blanketPOLinesDiv"></div>

<br/><br/>
<span style="font-size: 20px;"><b>Under Blanket PO lines</b></span>
<?php
include $mainHTML;
?>
        </article>
        </div>
    </div>

</div>
</div>
</div>


<!-- Footer Wrapper -->
<div id="footer-wrapper">
    <?php include_once($_SERVER["DOCUMENT_ROOT"] . "/includes/footer.php") ;?>
</div>
<script type="text/javascript" src="plugin/fancybox/source/jquery.fancybox.js"></script>
<script type="text/javascript" src="plugin/msgPop.js"></script>
<script type="text/javascript" src="api/client_api.js?t=2017-10-15"></script>
<script type="text/javascript" src="<?php echo $mainJS; ?>"></script>   
<script type="text/javascript" src="<?php echo $customJS; ?>"></script> 
<script type="text/javascript">
$(document).ready(function() {
    var apiURL = '<?php echo $apiURL;?>';
    //                  show,   page,   api_url
    ERPLIST.getListData(10,     1,      apiURL);

    //get RR line table using idlines
    ERPLIST.getBlanketPOLineTable();

}); 
</script>
</body>
</html>