<?php
$directory = __DIR__ ;
require_once __DIR__ . "/classes/config.php";
require_once $_SERVER['DOCUMENT_ROOT'] . "/includes/user.cookies.php";
require_once $_SERVER['DOCUMENT_ROOT'] . "/includes/user-privilege.php";
require_once __DIR__ . "/classes/myclassautoloader.php";

// check privilege (keep module and section empty to skip privilege check)
$module    = "";
$section   = "";
$privilege = userPrivileges($module, $section);
if (!$privilege['R']) {header("Location: ../user/no-permission.php");exit();}

if (isset($_GET['doctype'])) {
  $doctype = $_GET['doctype'];
}
if (isset($_GET['formtype'])) {
  $formtype = $_GET['formtype'];
} else {
  $formtype = 'default';
}


if ($doctype == 'MX') {
    $form      = new ErpDocumentMX();
} else if($doctype == 'MY'){
    $form      = new ErpDocumentMY();
} else if($doctype == 'MZ'){
    $form      = new ErpDocumentMZ();
} else if($doctype == 'NM'){
    $form      = new ErpDocumentNM();
} else if($doctype == 'T5'){
    $form      = new ErpDocumentT5();
} else if($doctype == 'T6'){
    $form      = new ErpDocumentT6();
} else if($doctype == 'SO'){
    $form      = new ErpDocumentSO();
} else if($doctype == 'CP'){
    $form      = new ErpDocumentCP();
} else if($doctype == 'TI'){
    $form      = new ErpDocumentTI();
} else if($doctype == 'IPO'){
    $form      = new ErpDocumentIPO();
} else {
  // redirect to error page
  // echo "erpdocument.php: received unknown doctype " . $doctype;
  // exit();
}

$formStructure = $form->formStructure($doctype, $formtype, '');
?>
<!DOCTYPE HTML>
<html>
<?php
echo "<head>";
require_once $_SERVER['DOCUMENT_ROOT'] . "/includes/head.php";
echo "    <title>$form->formTitle</title>";
echo "</head>";
?>
<body class="right-sidebar">

<!-- Header Wrapper -->
<div id="header-wrapper">
<div class="container">
<div class="row">
<div class="12u">
<!-- Header -->
  <header id="header">
    <?php include_once $_SERVER['DOCUMENT_ROOT'] . "/includes/mainmenu.php";?>
    <link rel="stylesheet" href="<?php echo $form->URL_DOCCSS; ?>"/>
  </header>
</div>
</div>
</div>
</div>

<!-- Main Wrapper -->
<div id="main-wrapper">
<div class="container">
<div class="row">
  <div class="12u skel-cell-important">
    <!-- Content -->
    <div id="content">
    <article class="last">
<!-- LINKS -->
    <a href="documents-home.php">Home</a> &nbsp;|&nbsp;
    <a href="list-bom.php">BOM List</a> &nbsp;|&nbsp;
    <br><br>

<?php
$docnumber = $_GET['docnumber'];
echo <<<php
    <div id="formCaption">
        <div class="w40 text_left">$form->formTitle  $docnumber</div>
        <div class="w20 text_center">
            <span id="spandocnumber"></span>
        </div>
        <div class="w40 text_right">
            <span id="spandocstatus"></span>
        </div>
        <div class="clearfix"></div>
    </div>

    <div id="docHeaderContainer"></div>
    <div id="docLinesContainer"></div>
php;
?>
    
    </article>
    </div>
  </div>
</div>
</div>
</div>

<style type="text/css">
#formCaption {
    font-size: 24px;
    font-weight: bold;
    color: black;
    border-bottom: 1px solid #000000;
    padding-bottom: 10px;
    margin-bottom: 20px;
}



/*List Table Design CSS Start*/
#listTable thead {
    /*background-color : #E5E5E5;*/
    background-color : #f1f1f1; /*Datatables*/
}
#listTable th {
    font-size: 9pt;
    font-weight: normal;
    color: #555555;
}
#listTable tr:nth-child(even) {
    /*background-color : #EEEEEE;*/
    background-color: #f9f9f9; /*Datatables*/
}
#listTable th,
#listTable td {
    /*border         : none;*/
    border: 1px solid #ddd;
    padding        : 3px;
    text-align     : left;
    vertical-align : top;
}
#listTable>tbody>tr>td {
    padding: 8px;
    line-height: 1.42857143;
    vertical-align: top;
    border-top: 1px solid #ddd;
}
/*List Table Design CSS End*/
</style>


<!-- Footer Wrapper -->
<div id="footer-wrapper">
  <?php include_once $_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php";?>
</div>

<script type="text/javascript" src="/js/fancybox/jquery.fancybox.js"></script>
<script type="text/javascript" src="/js/erp_lib.js"></script>
<script type="text/javascript" src="api/client_api.js"></script>
<script type="text/javascript" src="js/erpdocview.js"></script>
<script type="text/javascript" src="<?php echo $form->URL_DOCVIEWJS; ?>"></script>
<script type="text/javascript">
  $( document ).ready( function() {
    var _ERP_DOCACRONYM = '<?php echo $form->_ERP_DOCACRONYM; ?>';
    var _URL_DOCUMENTAPI = '<?php echo $form->_URL_DOCUMENTAPI; ?>';
    var _URL_DOCDEFINEAPI = '<?php echo $form->_URL_DOCDEFINEAPI; ?>';
    erpdocument.processForm( '#<?php echo $form->formId; ?>', _ERP_DOCACRONYM, _URL_DOCUMENTAPI, _URL_DOCDEFINEAPI);
  } );
</script>

</body>
</html>