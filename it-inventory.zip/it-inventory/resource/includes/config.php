<?php
// ERP existing Database
$db1_hostname = "10.1.2.13";
$db1_username = 'root';
$db1_password = 'R00Tr@@!';
$db1_dbname   = "erpprod";

// New database
$db2_hostname = "10.1.2.13";
$db2_username = "root";
$db2_password = "root";
$db2_dbname   = "erpprod_bulbul";

$db1_connection = mysql_connect($db1_hostname, $db1_username, $db1_password);
$db2_connection = mysql_connect($db2_hostname, $db2_username, $db2_password, $db2_dbname, true);

mysql_select_db($db1_dbname, $db1_connection);
mysql_select_db($db2_dbname, $db2_connection);

// if (PHP_SAPI == 'cli') {
//   require_once __DIR__ . '/../classes/autoloader.php';
//   // $_SERVER is only set if run by the web server, so for CLI we need to use __DIR__
//   // but for that, this file must be on the same path as the classes
// } else {
//   require_once $_SERVER['DOCUMENT_ROOT'] . "classes/autoloader.php";
// }

?>