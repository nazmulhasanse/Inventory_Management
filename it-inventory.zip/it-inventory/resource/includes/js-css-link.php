<script src="/js/jquery-2.1.3.min.js"></script>
<script src="/js/jquery-ui.min.js"></script>	
<script src="/admin/resource/js/jquery.msgPop.js" language="javascript" type="text/javascript"></script>
<link href="/css/jquery-ui.min.css" rel="stylesheet">

<link rel="stylesheet" href="/admin/resource/css/msgPop.css" /><!--==for display toast message required link == and requored min 1.11.1-->
<link rel="stylesheet" type="text/css" href="/admin/resource/css/fab.css" />
<link rel="stylesheet" type="text/css" href="/admin/resource/css/custom-button.css">		
