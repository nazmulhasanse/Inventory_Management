<?php
/*-******************************
 *	Author: Al-Mamun
 * 	API Name: user-privilege_api
 * 	Created Date: 2015-11-11
 *-******************************/
// connect database
session_start();
require_once $_SERVER["DOCUMENT_ROOT"] . "/admin/resource/includes/config.php";
require_once $_SERVER["DOCUMENT_ROOT"] . "/includes/database_lib.php";
require_once $_SERVER["DOCUMENT_ROOT"] . "/includes/database_lib2.php";
require_once $_SERVER["DOCUMENT_ROOT"] . "/includes/user-privilege.php";

//------------- API Parent Class[It will be inherit by child class]-----------------------
abstract class BaseClass
{
	//---------- variable declaration --------
	protected $validKey = true;	
	protected $conn2 = "";
	protected $conn1 = "";
	protected $tableColumnName = "";
	protected $tableColumnValue = "";

	//-- message declaration
	protected $type1 = "success::";
	protected $type2 = "warning::";
	protected $type3 = "error::";

	protected $s_msg1 = "success::Query result found successfully";	// success message
	protected $s_msg2 = " privilegeID created successfully.";
	protected $s_msg3 = "success::PrivilegeID successfully assigned to the user.";
	protected $s_msg4 = " username created successfully.";
	protected $s_msg5 = " user's password updated successfully";
	protected $s_msg6 = "success:: username deleted successfully";
	protected $s_msg7 = "success::Privilege removed successfully";
	protected $s_msg8 = " privilege ID deleted successfully";
	protected $s_msg9 = " Privilege request deleted successfully.";
	protected $s_msg10 = "success::Approved successfully. assigned privilegeID->";
	protected $s_msg11 = "success::Your rquest for privilege submitted successfully.";
	protected $s_msg12 = "success::Your multiple request for privilege submitted successfully.";
	protected $s_msg13 = " New user deleted successfully.";
	protected $s_msg14 = " username successfully declared to the usertype ";

	protected $w_msg1 = "warning::Query result not found.";			// warning message
	protected $w_msg2 = "warning::Please create username before assigning privilege.";	
	protected $w_msg3 = "warning::Already exist this privilege. Privilege ID number: ";
	protected $w_msg4 = "warning::Search with wrong http method or params.";
	protected $w_msg5 = "warning::Already exist this username. Please change username.";
	protected $w_msg6 = "warning::Already assigned this privilege ID.";
	protected $w_msg7 = "warning::Privilege ID You entered is not valid. Please enter valid privilegeID.";
	protected $w_msg8 = "warning::username You entered is not valid. Please enter valid username.";
	protected $w_msg9  = "warning::Already declared this usertype for this user.";
	protected $w_msg10  = " username failed to declare the usertype ";

	protected $e_msg1 = "error:: Error occured.";					// error message
	protected $e_msg2 = "error::Error! Please fillup all field.";
	protected $e_msg3 = "error::this privilege was not availble.";

	//-- required array declaration
	protected $validSearchKey = array("username", "badge", "idprivilege", "module", "section", "privilege", "tsdKeyName", "nsKeyValue", "read", "tsdUsername", "tsdIdprivilege", "tsdMSP","badge", "autocomplete", "LibraryName");
	protected $searchArr = array();
	protected $searchKeyArr = array();
	protected $dataArrP = array();
	protected $columnName = array();	//----------->these are need to remove
	protected $columnValue = array();	//----------->these are need to remove

	//-- table query 
	protected $mrd_SQL_1 = "SELECT * FROM ";
	protected $mrd_users_SQL_1 = "SELECT * FROM `mrd_users` WHERE ";
	protected $mrd_users_SQL_2 = "SELECT * FROM `mrd_users` WHERE username = ";

	protected $mrd_users_IN_SQL = "INSERT INTO `mrd_users`";
	protected $mrd_users_UP_SQL = "UPDATE `mrd_users` SET ";
	protected $mrd_users_DE_SQL = "DELETE FROM `mrd_users` WHERE username = ";

	protected $mrd_privilege_SQL_1 = "SELECT * FROM `mrd_privilege` ";
	protected $mrd_privilege_SQL_2 = "SELECT * FROM `mrd_privilege` WHERE ";
	protected $mrd_privilege_SQL_3 = "SELECT * FROM `mrd_privilege` WHERE idprivilege = ";
	protected $mrd_privilege_IN_SQL = "INSERT INTO `mrd_privilege`";
	protected $mrd_privilege_DE_SQL = "DELETE FROM `mrd_privilege` WHERE idprivilege = ";

	protected $mrd_users_privileg_IN_SQL = "INSERT INTO `mrd_users_privilege`(username, idprivilege) ";
	protected $mrd_users_privilege_DE_SQL_1 = "DELETE FROM `mrd_users_privilege` WHERE ";	
	protected $mrd_users_privilege_DE_SQL_2 = "DELETE FROM `mrd_users_privilege` WHERE idprivilege = ";	

	protected $mrd_user_prv_request_IN_SQL = "INSERT INTO `mrd_users_privilege_request` ";	
	protected $mrd_user_prv_request_UP_SQL_1 = "UPDATE `mrd_users_privilege_request` SET flag = 'new' WHERE badge IS NOT NULL AND TRIM(badge) <> ''";	
	protected $mrd_user_prv_request_UP_SQL_2 = "UPDATE `mrd_users_privilege_request` t1 INNER JOIN `mrd_users` t2 ON t1.badge = t2.badge SET t1.flag = 'exist_user' WHERE t1.badge IS NOT NULL AND TRIM(t1.badge) <> ''";	
	protected $mrd_user_prv_request_DE_SQL = "DELETE FROM `mrd_users_privilege_request` WHERE id_request = ";	

	protected $mrd_users_feedback_mail_IN_SQL = "INSERT INTO `mrd_users_feedback_mail`"; 
	protected $mrd_users_feedback_mail_DE_SQL = "DELETE FROM `mrd_users_feedback_mail` WHERE id_sl = ";	
	
	protected $joinTableSQL_1 = "SELECT * FROM `mrd_privilege`, `mrd_users_privilege` WHERE mrd_privilege.idprivilege = mrd_users_privilege.idprivilege AND ";
	protected $joinTableSQL_2 = "SELECT * FROM `mrd_privilege`, `mrd_users_privilege` WHERE mrd_privilege.idprivilege = mrd_users_privilege.idprivilege AND username = ";
	protected $joinTableSQL_3 = "SELECT * FROM `mrd_privilege`, `mrd_users_privilege` WHERE mrd_privilege.idprivilege = mrd_users_privilege.idprivilege AND mrd_privilege.idprivilege = ";
	
	protected $mrd_employee_basicinfo_IN_SQL = "INSERT INTO `mrd_employee_basicinfo`";
	//---------- method defination -----------
	/**
	 * this parent constructor will conn1ct the database
	 */
	function __construct()
	{	//---- conn1ct to database ----
		$this->conn1 = connectOrDie();
		$this->conn2 = connectOrDie2();		
	}
	/**
	 * this function create and insert new privilege
	 * according to given value.
	 * @return [type] [return last created privilege ID]
	 */
	protected function privilegeWorkProcessor(){

		$privilegeType = "";
		$privilege = strtoupper($this->dataArrP['privilege']);

		if(strpos($privilege, 'R') === 0)$privilegeType = "reader";
		if(strpos($privilege, 'U') !== false)$privilegeType = "editor";
		if(strpos($privilege, 'C') !== false)$privilegeType = "moderator";
		if(strpos($privilege, "D") !== false)$privilegeType = "administrator";

		$this->tableColumnName = implode(", ", $this->columnName);
		$this->tableColumnValue = implode(", ", $this->columnValue);

		$sql = $this->mrd_privilege_IN_SQL."($this->tableColumnName, privilegetype) values($this->tableColumnValue, '$privilegeType')";	
		$result = $this->conn2->query($sql);
		$lastInsertedPrvID = $this->conn2->insert_id;
		if($result){
			return $lastInsertedPrvID;
		}
	}
}

//------------- API Child Class->1[Only Read Operation]-----------------------------------
class readOperation extends BaseClass {

	//--------- variable declaration ----------
	private $flag_dataRead = false;			// read operation by given table name
	private $flag_dataReadWQ = false;
	private $flag_autocomplete = false;
	private $flag_username = false; 		// search only by username
	private $flag_badge = false;			// search by badge

	private $flag_tsdUsername = false;
	private $flag_tsdIdprivilege = false;
	
	//--------- method defination -------------
	public function __construct($searchArr){

		parent::__construct();
		$this->searchArr = $searchArr;
		$this->searchKeyArr = array_keys($searchArr);
		if(count(array_diff($this->searchKeyArr, $this->validSearchKey)) != 0){
			$this->validKey = false;
		}

		if(array_key_exists("read", $this->searchArr) && count($this->searchArr) == 1){
			$this->flag_dataRead = true;
		}
		if(array_key_exists("read", $this->searchArr) && count($this->searchArr) == 2){
			$this->flag_dataReadWQ = true;
		}		
		else if (array_key_exists("autocomplete", $this->searchArr) && count($this->searchArr) == 3) {
			$this->flag_autocomplete = true;
		}
		else if(array_key_exists("badge", $this->searchArr) && count($this->searchArr) == 1){
			$this->flag_badge = true; 			// search by badge
		}
		else if (array_key_exists("username", $this->searchArr) && count($this->searchArr) == 1) {
			$this->flag_username = true; 		// search by only username
		}
		else if(array_key_exists("tsdUsername", $this->searchArr)){
			$this->flag_tsdUsername = true;
		}
		else if(array_key_exists("tsdIdprivilege", $this->searchArr)){
			$this->flag_tsdIdprivilege = true;
		}
		//---otherwise search by u, m, s, p[may be single or combine]--> from input field
		//---or from table
	}

    public function __call($name, $arguments){	
    	// ----- magic method for implement method overloading ----
    	if(!$this->validKey){
        		return $this->w_msg4;
        }
        // in future it help to implement method overloading if needed
        if ($name === 'readData'){	
			if(count($arguments) === 0){
			    return $this->readDataByParam($this->searchArr);
			}        
        }
    }
    /**
     * This function return the data according
     * to search parameter value.
     * @param  [type] $searchArr [this are associated search array]
     * @return [type]            [json data]
     */
    private function readDataByParam($searchArr){	

    	$sql = "";
    	$wheres = array();
		foreach ($searchArr as $key => $value) {
			if ($key != "tsdMSP") {
				$wheres[] = ($key == 'module' || $key == 'section' || $key == 'privilege' || $key == 'username' || $key == 'badge') ? "$key LIKE '%$value%'" : "$key = '$value'";
			}
		}	
		/**
		 * Read operation by given table name[read-->table name]
		 */
    	if($this->flag_dataRead){
    		
    		$tableName = $searchArr['read'];
    		$sql = $this->mrd_SQL_1."`$tableName`";

    		$result = sqlToJson2($sql);
			return $result; 
    	}
    	/**
    	 * Read operation by given table name with filter data[read-->table name, q-->filter param]
    	 */
    	if($this->flag_dataReadWQ){
    		$tableName = $searchArr['read'];
    		$wheres = array();
    		foreach ($searchArr as $key => $value) {
    			if($key != "read"){
    				$wheres[] = "$key = '$value'";
    			}
    		}
    		$sql = $this->mrd_SQL_1."`$tableName` WHERE ". implode(" AND ", $wheres);
    		// echo $sql;
    		$result = sqlToJson($sql);
			return $result; 
    	}    	
    	/**
    	 * Read data for autocomplete input field
    	 */
    	if($this->flag_autocomplete){
    	}
		/**
		 * Read operation by badge name
		 */    	
    	if($this->flag_badge){

    		$sql = $this->mrd_users_SQL_1 . implode(" AND ", $wheres);
    		$result = sqlToJson2($sql);
    		return $result;
    	}
		/**
		 * Read operation by only username
		 */    	
		if($this->flag_username){		//---search by only username
			$sql = $this->mrd_users_SQL_1 . implode(" AND ", $wheres);
			$result = sqlToJson2($sql);
			return $result; 
		}    	
    	if($this->flag_tsdUsername){
    		$username = $searchArr['username'];
    		$sql = $this->joinTableSQL_2."'$username'";

    		$result = sqlToJson2($sql);
			return $result; 
    	}
    	if($this->flag_tsdIdprivilege){
    		$idprivilege = $searchArr['idprivilege'];
    		$sql = $this->joinTableSQL_3."'$idprivilege'";

    		$result = sqlToJson2($sql);
			return $result; 
    	}    	
		//------ search by u, m, s, p, id[may be single or combine][input field or from table]
		$selectedTable = (array_key_exists("username", $this->searchArr)) ? $this->joinTableSQL_1 : $this->mrd_privilege_SQL_2 ;
		$sql = $selectedTable . implode(" AND ", $wheres); 
		$result = sqlToJson2($sql);
		return $result; 	
    }

}

//------------------------ API Child Class->2[Create-Update-Delete Operation]-----------------------
class cudOperation extends BaseClass
{
	//--------- variable declaration ----------
	private $selectedTable = "";
	public $objActionLog = "";

	//--------- method defination -------------
	/**
	 * this function select the required table for operation
	 * @param [type] $detector [this param is main key to select the table]
	 */
	function __construct($detector)
	{	parent::__construct();
		$this->objActionLog = new ActionLog();

		$this->selectedTable = ($detector == "createUser") ? $this->mrd_users_IN_SQL : "none" ;
		$this->selectedTable = ($detector == "updateUser") ? $this->mrd_users_UP_SQL : $this->selectedTable;
		$this->selectedTable = ($detector == "deleteUser") ? $this->mrd_users_DE_SQL : $this->selectedTable;
		$this->selectedTable = ($detector == "createPrivilege") ? $this->mrd_privilege_IN_SQL : $this->selectedTable;
		$this->selectedTable = ($detector == "assignExistPrivilege") ? $this->mrd_users_privileg_IN_SQL : $this->selectedTable;
	}
	/**
	 * this function create a new user and return the username
	 * @param  [type] $jsonData [should be json data]
	 * @return [type]           [username]
	 */
	function createUser($jsonData){

		$dataArr = json_decode($jsonData, true);
		$badge = $dataArr['badge'];
		$username = $dataArr['username'];

		$wheres = array();
		$columnNameFEI = array(); 	// column name for employee basicinfo table
		$columnValueFEI = array();	// column value for employee basicinfo table
		$usersTablesKey = array("username", "password", "badge");
		$employeeTablesKey = array("Name", "Category", "badge", "Department", "Section", "username");
		foreach($dataArr as $key => $value){
			if($key == "username"){$wheres[] = "$key = '$value'";}// this is for checking already exist the same username
			if(in_array($key, $usersTablesKey)){	// general
				$this->columnName[] = $key; 
				$this->columnValue[] = ($key == "password") ? "'".md5($value)."'" : "'".$value."'" ;
			}
			if(in_array($key, $employeeTablesKey)){	// only for insert data to employee basic table
				if($key === "badge"){$columnNameFEI[] = "Badge";$columnValueFEI[] = "'".$value."'";}	// the cuz is imployee basic info table's badge column start with upper case letter
				else if($key === "username"){$columnNameFEI[] = "SystemLogin";$columnValueFEI[] = "'".$value."'";}	// the cuz is imployee basic info table's badge column start with upper case letter
				else{$columnNameFEI[] = $key;$columnValueFEI[] = "'".$value."'";}
			}
		}

		$sql = $this->mrd_users_SQL_1 . implode(" AND ", $wheres);
		$result = $this->conn2->query($sql);
		//---check exist same username
		if($result->num_rows>0){
			$this->conn2->close();
			return $this->w_msg5;
		}	

		$this->tableColumnName = implode(", ", $this->columnName);
		$this->tableColumnValue = implode(", ", $this->columnValue);

		$sql = $this->selectedTable."($this->tableColumnName) values($this->tableColumnValue)";	
		$result = $this->conn2->query($sql);
		if($result){
			//============================================
			$tableColumnNameFEI = implode(", ", $columnNameFEI);
			$tableColumnValueFEI = implode(", ", $columnValueFEI);
			// check already exist or not
			$sql = "SELECT * FROM mrd_employee_basicinfo WHERE Badge = '$badge'";
			$result = $this->conn1->query($sql);
			if($result->num_rows>0){
				$sql = "UPDATE mrd_employee_basicinfo SET SystemLogin = '$username' WHERE Badge = '$badge'";
				$result = $this->conn1->query($sql);
				if($result){
					$this->conn2->close();
					$this->objActionLog->registryAction("edit", "user", $dataArr['username']);
					return $this->type1.$dataArr['username'].$this->s_msg4;
				}

			} else {

				$sql = $this->mrd_employee_basicinfo_IN_SQL."($tableColumnNameFEI) values($tableColumnValueFEI)";
				$result = $this->conn1->query($sql);
				if($result){
					$this->conn2->close();
					$this->objActionLog->registryAction("create", "user", $dataArr['username']);
					return $this->type1.$dataArr['username'].$this->s_msg4;
				}				
			}
			//============================================
		}

		$this->conn2->close();
	}

	/**
	 * this function are used to be update user password
	 * @param  [type] $jsonData [should be json data]
	 * @return [type]           [description]
	 */
	function updateUser($jsonData){

		$dataArr = json_decode($jsonData, true);
		$prvUsername = $dataArr['prv_username'];
		// $username = $dataArr['username'];

		if (in_array(null, $dataArr)) {
		    return $this->e_msg2;
		}		

		$sets = array();
		foreach($dataArr as $key => $value){
			if($key != "prv_username"){
				if($key == "password"){
					$passValue = md5($value);
					$sets[] = "$key = '$passValue'";
				}else{
					$sets[] = "$key = '$value'";
				}
			}
		}
		
		$setsValue = implode(", ", $sets);
		$sql = $this->mrd_users_UP_SQL .$setsValue." WHERE username = '$prvUsername'"; 
		$result = $this->conn2->query($sql); 

		if($result){
			$this->conn2->close();
			$this->objActionLog->registryAction("update", "password", $dataArr['prv_username']);
			return $this->type1.$prvUsername.$this->s_msg5;
		}
		$this->conn2->close();
	}
	/**
	 * this function is not used to our current system
	 * @param  [type] $jsonData [description]
	 * @return [type]           [description]
	 */
	function deleteUser($jsonData){

		$dataArr = json_decode($jsonData, true);
		$username = $dataArr['username'];

		$sql = $this->mrd_users_DE_SQL."'$username'";
		$result = $this->conn2->query($sql);
		if($result){
			$this->objActionLog->registryAction("delete", "user", $dataArr['username']);
			$this->conn2->close();
			return $username.$this->s_msg6;
		}
	}
	/**
	 * this function is responsible to create new privilege
	 * @param  [type] $jsonData [description]
	 * @return [type]           [description]
	 */
	function createPrivilege($jsonData){

		$dataArr = json_decode($jsonData, true);
		$this->dataArrP = $dataArr; // for passing data to the parent class

		$wheres = array();
		foreach($dataArr as $key => $value){
			$wheres[] = "$key = '$value'";
			$this->columnName[] = $key; $this->columnValue[] = "'".$value."'";
		}
		
		$sql = $this->mrd_privilege_SQL_2 . implode(" AND ", $wheres); 
		$result = $this->conn2->query($sql);
		//---check exist privilege
		if($result->num_rows>0){
			$row = $result->fetch_assoc();
			$idprivilege = $row['idprivilege'];
			$this->conn2->close();
			return $this->w_msg3.$idprivilege;
		}
		else{
			$idprivilege =  parent::privilegeWorkProcessor();
			$this->conn2->close();
			$this->objActionLog->registryAction("create", "privilege", json_encode(implode(", ", $wheres)));
			return $this->type1.$idprivilege.$this->s_msg2;
		}
			
	}
	/**
	 * this function assign privilege ID to the given username
	 * @param  [type] $privilegeID [description]
	 * @param  [type] $username    [description]
	 * @return [type]              [description]
	 */
	public function assignExistPrivilege($privilegeID, $username){

		//--- need to check valid privilege ID ---
		$sql = $this->mrd_privilege_SQL_3."'$privilegeID'";
		$result = $this->conn2->query($sql);
		if($result->num_rows == 0){
			$this->conn2->close();
			return $this->w_msg7;
		}
		//--- need to check valid user ---
		$sql = $this->mrd_users_SQL_2."'$username'";
		$result = $this->conn2->query($sql);
		if($result->num_rows == 0){
			$this->conn2->close();
			return $this->w_msg8;
		}		
		//----------------------------------------
		$sql = $this->mrd_users_privileg_IN_SQL."values('$username', '$privilegeID')";
		$result = $this->conn2->query($sql);
		if($result){
			$this->conn2->close();
			$this->objActionLog->registryAction("assign", "privilege-id", $privilegeID);
			return $this->s_msg3;
		}
		else
			return $this->w_msg6;
		
	}
	public function declareUserType($username, $usertype){

		//--- need to check valid user ---
		$sql = $this->mrd_users_SQL_2."'$username'";
		$result = $this->conn2->query($sql);
		if($result->num_rows == 0){
			$this->conn2->close();
			return $this->w_msg8;
		}	
		//--- need to check already declare---
		$sql = $this->mrd_users_SQL_1." username = '$username' AND usertype = '$usertype'";
		$result = $this->conn2->query($sql);
		if($result->num_rows > 0){
			$this->conn2->close();
			return $this->w_msg9;
		}	
		//----------------------------------------
		$sql = $this->mrd_users_UP_SQL." usertype = '$usertype' WHERE username = '$username'";
		$result = $this->conn2->query($sql);
		if($result){
			$this->conn2->close();
			$this->objActionLog->registryAction("declare", "usertype", $username);
			return $this->type1.$username.$this->s_msg14.$usertype;
		}
		else{
			return $this->type1.$username.$this->w_msg10.$usertype;
		}
		
	}	
	/**
	 * This function remove or delete privilege.
	 * according to given parameter value.
	 * If parameter username is empty, then it will delete privilege.
	 * Otherwise remove privilege of the given username
	 * @param  [type] $dataArr     [description]
	 * @param  [type] $privilegeID [description]
	 * @param  [type] $username    [description]
	 * @return [type]              [description]
	 */
	function removePrivilege($dataArr, $privilegeID, $username){

		$wheres = array();
		// if(isset($username)){
		if($username !== ""){
			foreach($dataArr as $key => $value){
				$wheres[] = "$key = '$value'";
			}
			$sql = $this->mrd_users_privilege_DE_SQL_1 . implode(" AND ", $wheres); 
			$result = $this->conn2->query($sql);
			if($result){
				$this->objActionLog->registryAction("remove", "privilege", json_encode(implode(", ", $wheres)));
				return $this->s_msg7;
			}

		}else{
			//--- need to delete all user assign this privilegeID
			$sql = $this->mrd_users_privilege_DE_SQL_2 . "'$privilegeID'"; 
			$result = $this->conn2->query($sql);
			if($result){

				$sql = $this->mrd_privilege_DE_SQL."'$privilegeID'";
				$result = $this->conn2->query($sql);
				if($result){
					$this->objActionLog->registryAction("delete", "privilege-id", $privilegeID);
					return $this->type1.$privilegeID.$this->s_msg8;
				}

			}
		}
	}	


	public function declareModuleMaitananceMode($jsonDataObj){
		$jsonDataObj = json_decode($jsonDataObj, true);

		$module = $jsonDataObj['module'];
		$modulemaintanancemsg = $jsonDataObj['modulemaintanancemsg'];
		$modulemaintanancemode = $jsonDataObj['modulemaintanancemode'];
		$moduleMMN = $module . "::maintanancemode";
		// check modulemaintanancemode, if exist then delete
		$sql = "SELECT * FROM `mrd_privilege` WHERE `module` = '$moduleMMN'";
		$result = $this->conn2->query($sql);
		if($result->num_rows>0){
			$sql = "DELETE FROM `mrd_privilege` WHERE `module` = '$moduleMMN'";
			$result = $this->conn2->query($sql);
			$sql = "INSERT INTO mrd_privilege (module, modulemaintanancemode, modulemaintanancemsg) VALUES('$moduleMMN', '$modulemaintanancemode', '$modulemaintanancemsg')";
			$result = $this->conn2->query($sql);

			if($result){
				return $this->type1. " Module Maintanace set successfully";
			}
		} else {

			$sql = "INSERT INTO mrd_privilege (module, modulemaintanancemode, modulemaintanancemsg) VALUES('$moduleMMN', '$modulemaintanancemode', '$modulemaintanancemsg')";
			$result = $this->conn2->query($sql);

			if($result){
				return $this->type1. "  Module Maintanace set successfully";
			}

		}
		
	}

	public function cancelModuleMaitananceMode($jsonDataObj){
		$jsonDataObj = json_decode($jsonDataObj, true);

		$module = $jsonDataObj['module'];
		$moduleMMN = $module . "::maintanancemode";
		// check modulemaintanancemode, if exist then delete
		$sql = "SELECT * FROM `mrd_privilege` WHERE `module` = '$moduleMMN'";
		$result = $this->conn2->query($sql);
		if($result->num_rows>0){
			$sql = "DELETE FROM `mrd_privilege` WHERE `module` = '$moduleMMN'";
			$result = $this->conn2->query($sql);
			if($result){
				return $this->type1. " Module Maintanace delete successfully";
			}
		} else {
			return $this->type1. " No Module Maintanace set yet in this module";
		}
		
	}
	public function declareBuyerPrivilege($jsonDataObj){
		$jsonDataObj = json_decode($jsonDataObj, true);

		$username = $jsonDataObj['username'];
		$buyername = $jsonDataObj['buyername'];

		$sql = "SELECT * FROM `mrd_buyer_privilege` WHERE username = '$username' AND buyername = '$buyername'";
		$result = $this->conn2->query($sql);
		if($result->num_rows > 0){
			return $this->type2. " Already assign this buyer privilege";
		}

		$sql = "INSERT INTO `mrd_buyer_privilege` (username, buyername) VALUES ('$username', '$buyername')";
		$result = $this->conn2->query($sql);
		if($result){
			return $this->type1. " Successfully added buyer privilege";
		}
		
	}
	public function declareCompanyPrivilege($jsonDataObj){
		$jsonDataObj = json_decode($jsonDataObj, true);

		$username = $jsonDataObj['username'];
		$companyname = $jsonDataObj['companyname'];

		$sql = "SELECT * FROM `mrd_company_privilege` WHERE username = '$username' AND companyname = '$companyname'";
		$result = $this->conn2->query($sql);
		if($result->num_rows > 0){
			return $this->type2. " Already assign this company privilege";
		}

		$sql = "INSERT INTO `mrd_company_privilege` (username, companyname) VALUES ('$username', '$companyname')";
		$result = $this->conn2->query($sql);
		if($result){
			return $this->type1. " Successfully added company privilege";
		}

	}



}

//--------------------------- API Class->3[Request privilege Handler]----------------------------------
class requestPrivilegeHandler extends BaseClass
{	
	public $objActionLog = "";
	//---------- method defination ----------
	function __construct($detector){	
		parent::__construct();
		$this->objActionLog = new ActionLog();
	}
	/**
	 * This function receive the privilege request
	 * and insert it to the database
	 * @param  [type] $jsonData [description]
	 * @return [type]           [description]
	 */
	function receiveRequestPrivilegeHandler($jsonData){
		$result = "";
		$dataArr = json_decode($jsonData, true);

		$dataC = json_decode($jsonData);//---detect multiple login request
		$requestorArr = $dataC->requestor;
		if(is_array($requestorArr)){
			$dataArrK = array_keys($dataArr);			//-- array inside array
			$dataArrWK = array_values($dataArr);		//-- nine row of array[one dimensional], each row has array with one dimensional

			$subDataArrF = $dataArrWK[0];
			$sizeOfSubDataArr = count($subDataArrF);

			for ($j=0; $j < $sizeOfSubDataArr ; $j++) { 

				$columnValue = array();
				for($i = 0; $i<count($dataArrWK); $i++){
					$subDataArr = $dataArrWK[$i];
					$columnValue[] = "'".$subDataArr[$j]."'";
				}

				$tableColumnName = implode(", ", $dataArrK);
				$tableColumnValue = implode(", ", $columnValue);
				$sql = $this->mrd_user_prv_request_IN_SQL."($tableColumnName) values($tableColumnValue)";	
				$result = $this->conn2->query($sql);			
			}	
			if($result){
				$sql = $this->mrd_user_prv_request_UP_SQL_1;
				$this->conn2->query($sql);								
				$this->conn2->close();
				return $this->s_msg12;
			}
		}			
		else{							//---single request
			// $dataArr = json_decode($jsonData, true);
			foreach($dataArr as $key => $value){
				$columnName[] = $key; $columnValue[] = "'".$value."'";
			}

			$tableColumnName = implode(", ", $columnName);
			$tableColumnValue = implode(", ", $columnValue);
			$sql = $this->mrd_user_prv_request_IN_SQL."($tableColumnName) values($tableColumnValue)";	
			$result = $this->conn2->query($sql);
			if($result){
				$sql = $this->mrd_user_prv_request_UP_SQL_1;
				$this->conn2->query($sql);						
				$this->conn2->close();
				return $this->s_msg11;
			}
		}
		
	}
	/**
	 * This function delete privilege request
	 * accordin to given request id.
	 * @param  [type] $jsonData [description]
	 * @return [type]           [description]
	 */
	function deleteRequestPrivilegeHandler($jsonData){

		$dataArr = json_decode($jsonData, true);
		$idrequest = $dataArr['idrequest'];

		$sql = $this->mrd_user_prv_request_DE_SQL."'$idrequest'";
		$result = $this->conn2->query($sql);

		if($result){
			// $this->objActionLog->registryAction("delete", "privilege-request", $idrequest);
			return $this->type1.$idrequest.$this->s_msg9;
		}
	}
	function deleteCreatedNewUserHandler($jsonData){

		$dataArr = json_decode($jsonData, true);
		$idSl = $dataArr['idSl'];

		$sql = $this->mrd_users_feedback_mail_DE_SQL."'$idSl'";
		$result = $this->conn2->query($sql);

		if($result){
			// $this->objActionLog->registryAction("delete", "created-new user", $idSl);
			return $this->type1.$idSl.$this->s_msg13;
		}
	}	
	/**
	 * This function approve the privilege request.
	 * If privilege is not availabe, the it create new privilege
	 * and assign it to the username.
	 * @param  [type] $jsonData [description]
	 * @return [type]           [description]
	 */
	function approveRequestPrivilegeHandler($jsonData){
		$wheres = array();

		$dataArr = json_decode($jsonData, true);
		//--- need to check username exist or not
		$username = $dataArr['username'];
		$sql = $this->mrd_users_SQL_2."'$username'";
		$result = $this->conn2->query($sql);

		if($result->num_rows>0){
			//--- exist username//--- then need to check exist privilege
			foreach($dataArr as $key => $value){
				if($key != "requestor" && $key != "username"){
					$wheres[] = "$key = '$value'";
					$this->columnName[] = $key; $this->columnValue[] = "'".$value."'";
				}
			}
			$sql = $this->mrd_privilege_SQL_2 . implode(" AND ", $wheres); 
			$result = $this->conn2->query($sql);

			//--- Checking exist privilege ID
			if($result->num_rows>0){
				//--- exist privilege ID//--- just need to asign
				$row = $result->fetch_assoc();
				$idprivilege = $row['idprivilege'];
				$obj5 = new cudOperation("p");
				$returnMsg = $obj5->assignExistPrivilege($idprivilege, $username);

				if($returnMsg === $this->s_msg3){ 		//successfully assign
					return $this->s_msg10.$idprivilege;	//---------------- test-OK
				}else{
					return $returnMsg;
				}
			}
			else{
				//--- not exist privilege ID//--- need to create and then assign
				//--- these will be handle by admin, not by user
				// $createdPrvrivilegeID =  parent::privilegeWorkProcessor();
				return $this->e_msg3;
			}
		}
		else{
			//--- not exist username//--- need to create username before
			$this->conn2->close();	
			return $this->w_msg2;
		}
			
	}

	function refreshRequestPrivilegeData($jsonData){

		$dataArr = json_decode($jsonData, true);
		$demoUsername = $dataArr['demoUsername'];
		$realUsername = $dataArr['realUsername'];

	 	$mrd_user_prv_request_UP_SQL_2 = "UPDATE `mrd_users_privilege_request` SET username = '$realUsername', flag = 'exist_user' WHERE username = '$demoUsername'";	
	 	$sql = $mrd_user_prv_request_UP_SQL_2;
	 	$result = $this->conn2->query($sql);

	 	if($result){
	 		return "success:: refreshRPD successfully.";
	 	}

	}
	function insertDataIntoFeedbackMailTable($jsonData){
		$dataArr = json_decode($jsonData, true);
		$columnName = implode(', ', array_keys($dataArr));
		$columnValue = "'".implode("','", array_values($dataArr))."'";

		$sql = $this->mrd_users_feedback_mail_IN_SQL."($columnName)"." values($columnValue)";
		$result = $this->conn2->query($sql);
		if($result){
			return "success::successfully insert data to feedback mail table";
		}
	}

	function sendMailToNewUser($jsonData){

		$dataArr = json_decode($jsonData, true);
		$to = $dataArr['to'];
		$from = $dataArr['from'];
		$cUsername = $dataArr['username'];
		$cPassword = $dataArr['password'];
		$comments = $dataArr['comments'];

		$subject = "Notification";
		$msg = $from.$cUsername.$cPassword.$comments;

		$mail = mail($to, $subject, $msg);
		if($mail){
			return "success::mail send successfully";
		}
		else{
			return $this->type3.$comments."send fail";
		}
	}
}

//------------------ API Class->4[Privilege Checker for Operation]---------------------------------
class PrivilegeCheker extends BaseClass
{
	function __construct()
	{
		parent::__construct();
	}
	public function privilegeCheker(){
		$module = "admin";
		$section = "";
		$privilege = userPrivileges($module, $section);
		return $privilege;
	}
}
//-------------------------------------------------------------------------------------------------

/**
* Action log class to keep track
*/
class ActionLog extends BaseClass
{
	function __construct() {
		parent::__construct();
	}
	function registryAction($action, $case = "", $reference = ""){

		$reference = mysql_real_escape_string( $reference );

		$username = $_SESSION["USERNAME"];
		$today = date('Y-m-d H:i:s', time());

		$sql = "INSERT INTO tnx_action_log (`Time`, `username`, `Action` , `Case`, `Reference`, `page_id`) 
				VALUES ('$today' , '$username' , '$action' , '$case' , '$reference', '')";
				//                   mamun        add         user      tarik
		
	 	$result = $this->conn2->query( $sql );
	}

}









//------------------------------ Routing to use specific function ----------------------------------
if ( basename(__FILE__) == basename($_SERVER["SCRIPT_FILENAME"]) ) {
    // called directly
    if($_SERVER['REQUEST_METHOD'] == 'GET'){ 	

		$obj = new readOperation($_GET);
		$jsonData = $obj->readData();

		echo $jsonData;
	}

	else if( $_SERVER['REQUEST_METHOD'] == 'POST' ) {

		if(isset($_POST['req_action'])){

			$reqAction = $_POST['req_action'];
			$jsonDataObj = $_POST['jsonData'];

			$obj = new PrivilegeCheker();
			$privilege = $obj->privilegeCheker();


			if($reqAction == "createUser"){

				$obj = new cudOperation($reqAction);
				$returnData = $obj->createUser($jsonDataObj);
				echo $returnData;
			}
			if($reqAction == "deleteUser"){
				if($privilege['D']){
					$obj = new cudOperation($reqAction);
					$returnData = $obj->deleteUser($jsonDataObj);
					echo $returnData;
				}
				else{echo "error::You are not right person for this operation";}
			}
			if($reqAction == "updateUser"){

				$obj = new cudOperation($reqAction);
				$returnData = $obj->updateUser($jsonDataObj);
				echo $returnData;
			}				
			if ($reqAction == "createPrivilege") {

				$obj = new cudOperation($reqAction);
				$returnData = $obj->createPrivilege($jsonDataObj);
				echo $returnData;
			}
			if ($reqAction == "assignExistPrivilege") {
				
				$dataArr = json_decode($jsonDataObj, true);
				$privilegeID = $dataArr['idprivilege'];
				$username = $dataArr['username'];

				$obj = new cudOperation($reqAction);
				$returnData = $obj->assignExistPrivilege($privilegeID, $username);
				echo $returnData;
			}
			if($reqAction == "declareUserType"){

				$dataArr = json_decode($jsonDataObj, true);
				$username = $dataArr['username'];
				$usertype = $dataArr['usertype'];

				$obj = new cudOperation($reqAction);
				$returnData = $obj->declareUserType($username, $usertype);
				echo $returnData;				
			}
			if($reqAction == "declareModuleMaitananceMode"){

				$obj = new cudOperation($reqAction);
				$returnData = $obj->declareModuleMaitananceMode($jsonDataObj);
				echo $returnData;				
			
			}
			if($reqAction == "cancelModuleMaitananceMode"){

				$obj = new cudOperation($reqAction);
				$returnData = $obj->cancelModuleMaitananceMode($jsonDataObj);
				echo $returnData;				
			
			}
			if($reqAction == "declareBuyerPrivilege"){

				$obj = new cudOperation($reqAction);
				$returnData = $obj->declareBuyerPrivilege($jsonDataObj);
				echo $returnData;				
			
			}
			if($reqAction == "declareCompanyPrivilege"){

				$obj = new cudOperation($reqAction);
				$returnData = $obj->declareCompanyPrivilege($jsonDataObj);
				echo $returnData;				
			
			}
			if ($reqAction == "removePrivilege") {
				
				if($privilege['D']){
					$dataArr = json_decode($jsonDataObj, true);
					$username = "";
					$privilegeID = $dataArr['idprivilege'];
					$obj = new cudOperation($reqAction);

					if($dataArr['username'] != ""){
						$username = $dataArr['username'];
						$returnData = $obj->removePrivilege($dataArr, $privilegeID, $username);
						
					}else{
						$returnData = $obj->removePrivilege($dataArr, $privilegeID, $username);
					}
					echo $returnData;
				}else{echo "error::You are not right person for this operation";}	
				
			}
			//---------- request for privilege routing ------------
			if ($reqAction == "requestPrivilege") {

				$obj = new requestPrivilegeHandler($reqAction);
				$returnData = $obj->receiveRequestPrivilegeHandler($jsonDataObj);
				echo $returnData;
			}
			if ($reqAction == "deleteRP") { // delete request privilege

				$obj = new requestPrivilegeHandler($reqAction);
				$returnData = $obj->deleteRequestPrivilegeHandler($jsonDataObj);
				echo $returnData;
			}			
			if ($reqAction == "approveRP") { // approve request privilege

				$obj = new requestPrivilegeHandler($reqAction);
				$returnData = $obj->approveRequestPrivilegeHandler($jsonDataObj);
				echo $returnData;
			}
			if ($reqAction == "refreshRPD") { // approve request privilege

				$obj = new requestPrivilegeHandler($reqAction);
				$returnData = $obj->refreshRequestPrivilegeData($jsonDataObj);
				echo $returnData;
			}
			if ($reqAction == "insertNewUserIFT") { // approve request privilege

				$obj = new requestPrivilegeHandler($reqAction);
				$returnData = $obj->insertDataIntoFeedbackMailTable($jsonDataObj);
				echo $returnData;
			}
			if ($reqAction == "deleteCNU") { // delete created new user

				$obj = new requestPrivilegeHandler($reqAction);
				$returnData = $obj->deleteCreatedNewUserHandler($jsonDataObj);
				echo $returnData;
			}
			if ($reqAction == "sendMailToNewUser") { // delete created new user

				$obj = new requestPrivilegeHandler($reqAction);
				$returnData = $obj->sendMailToNewUser($jsonDataObj);
				echo $returnData;
			}														
			//--------------------------------------------

		}

	}

} else {
    // included/required
}
//---------------------------------------------------------------------------------------------------
?>