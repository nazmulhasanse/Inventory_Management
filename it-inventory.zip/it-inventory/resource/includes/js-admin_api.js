<script language="javascript" type="text/javascript">
//--- Setting toast message property-----------------
MsgPop.displaySmall = true;
MsgPop.position = "top-right";
//--- Global Variable Declaration[by default] -------
var mAsync 	= 	false;
var mType 	= 	"post";
var mReqType= 	"";
var mUrl 	= 	"resource/includes/user-privilege_api.php";
var mData	= 	"";
var mApiMsgBody         = "";
var mInitialSearchData = "";
var mNextSearchData    = "";
var mWMsg1 = "error::Please fillup all field carefully.";

function jsApiMsgDisplayer(mApiMsgBody){

	var res  = mApiMsgBody.split("::");
	var type = res[0];
	var body = res[1];

	MsgPop.open({
	Type 		:	type,
	Content 	: 	body,
	AutoClose	:	true});

}
function jsApiReturnMsgTypeDetector(apiMsg){
	var resMsg = apiMsg.split("::");
	var msgType = resMsg[0];
	return msgType;
}
//------------------ Json Conversion ----------------	
$.fn.serializeObject = function(){
    var o = {};
    var a = this.serializeArray();
    $.each(a, function() {
        if (o[this.name] !== undefined) {
            if (!o[this.name].push) {
                o[this.name] = [o[this.name]];
            }
            o[this.name].push(this.value || '');
        } else {
            o[this.name] = this.value || '';
        }
    });
    return o;
};
//------------------- Ajax Function ----------------
function jsApiCommunicationHandler(mAsync, mType, mUrl, mReqType, mData){

	var returnData = "";
	var mThisUsername = "";
	mThisUsername = "<?php echo $_SESSION['USERNAME']?>";	
	mData = (mType == "get") ? mData : {req_action: mReqType, jsonData: mData, acUsername:mThisUsername} ; 

	$.ajax({
		async 	: 	mAsync,
		type	: 	mType,
		url 	: 	mUrl,
		data 	: 	mData,
		success	: 	function(data){
			returnData = data;
		},
		error	: 	function(){

		}
	});
	return returnData;
}
function jsApiCleanFormInputField(formId){
	$(formId)[0].reset();
}
function jsApiCleanInputFieldAfterSubmit(formId){
	$('#'+formId)[0].reset();
}
function resetInputField(formId) {
	$(':input','#'+formId)
	 .not(':button, :submit, :reset, :hidden')
	 .val('')
	 .removeAttr('checked')
	 .removeAttr('selected');
}
function jsApiCreateUser(formIdORdata){
	var flagValid = true;
	var flagFormId = false;

	if (formIdORdata instanceof Object == false) {		//Not an object--->form id
		flagFormId = true;
		mData = $('#'+formIdORdata).serializeObject();
		$.each(mData, function(i,item){if(item == ""){flagValid = false;}});	
		if(flagValid){
			mData = JSON.stringify( mData ); 
		}else{return jsApiMsgDisplayer(mWMsg1);}		
	}else{												//an object								
		mData = JSON.stringify( formIdORdata );
	}
	
	mType = 'post';
	mReqType = "createUser";
 	var returnData = jsApiCommunicationHandler(mAsync, mType, mUrl, mReqType, mData);
 	console.log("fire-->createUser-->"+returnData);
 	if(jsApiReturnMsgTypeDetector(returnData) === "success" && flagFormId){jsApiCleanInputFieldAfterSubmit( formIdORdata );}
 	refreshAutoCompleteInputField();
    jsApiMsgDisplayer(returnData);
    return returnData;

}
function jsApiUpdateUser(formId){

	mType = 'post';
	mReqType = "updateUser";
 	mData = JSON.stringify( $('#'+formId).serializeObject());
 	var returnData = jsApiCommunicationHandler(mAsync, mType, mUrl, mReqType, mData);
 	console.log("fire-->updateUser-->"+returnData);
 	jsApiMsgDisplayer(returnData);

}
function jsApiDeleteUser(formId){

	mType = 'post';
	mReqType = "deleteUser";
 	mData = JSON.stringify( $('#'+formId).serializeObject());
 	var returnData = jsApiCommunicationHandler(mAsync, mType, mUrl, mReqType, mData);
 	console.log("fire-->deleteUser-->"+returnData);
 	jsApiMsgDisplayer(returnData);

}	
function jsApiCreatePrivilege(formId){

	mType = 'post';
	mReqType = "createPrivilege";
	mData = JSON.stringify( $('#'+formId).serializeObject());
 	var returnData = jsApiCommunicationHandler(mAsync, mType, mUrl, mReqType, mData);
 	console.log("fire-->createPrivilege-->"+returnData);
 	if(jsApiReturnMsgTypeDetector(returnData) === "success"){jsApiCleanInputFieldAfterSubmit( formId );}
 	refreshAutoCompleteInputField();
 	jsApiMsgDisplayer(returnData);

}
function jsApiAssignExistPrivilege(formId){

	mType = 'post';
	mReqType = "assignExistPrivilege";
	mData = JSON.stringify( $('#'+formId).serializeObject());
 	var returnData = jsApiCommunicationHandler(mAsync, mType, mUrl, mReqType, mData);
 	console.log("fire-->assignExistPrivilege-->"+returnData);
 	if(jsApiReturnMsgTypeDetector(returnData) === "success"){jsApiCleanInputFieldAfterSubmit( formId );}
 	jsApiMsgDisplayer(returnData);

}
function jsApiAssignExistPrivilege2(formId){

	mType = 'post';
	mReqType = "assignExistPrivilege";
	mData = JSON.stringify( $('#'+formId).serializeObject());
 	var returnData = jsApiCommunicationHandler(mAsync, mType, mUrl, mReqType, mData);
 	console.log("fire-->assignExistPrivilege-->"+returnData);
 	if(jsApiReturnMsgTypeDetector(returnData) === "success"){
 		searchHandlerFromTable(celNameUPR, celValueUPR, tsd); 
 		refreshAutoCompleteInputField();
 	}
 	jsApiMsgDisplayer(returnData);

}
function jsApiDeclareUserType(formId){

	mType = 'post';
	mReqType = "declareUserType";
	mData = JSON.stringify( $('#'+formId).serializeObject());
 	var returnData = jsApiCommunicationHandler(mAsync, mType, mUrl, mReqType, mData);
 	console.log("fire-->declareUserType-->"+returnData);
 	if(jsApiReturnMsgTypeDetector(returnData) === "success"){jsApiCleanInputFieldAfterSubmit( formId );}
 	jsApiMsgDisplayer(returnData);

}
function jsApiRemovePrivilege(formId){

	mType = 'post';
	mReqType = "removePrivilege";
	mData = JSON.stringify( $('#'+formId).serializeObject());
 	var returnData = jsApiCommunicationHandler(mAsync, mType, mUrl, mReqType, mData);
 	console.log("fire-->removePrivilege-->"+returnData);
 	jsApiMsgDisplayer(returnData);

}

function jsApiDeclareModuleMaitananceMode(formId){

	mType = 'post';
	mReqType = "declareModuleMaitananceMode";
	mData = JSON.stringify( $('#'+formId).serializeObject());
 	var returnData = jsApiCommunicationHandler(mAsync, mType, mUrl, mReqType, mData);
 	console.log("fire-->DeclareModuleMaitananceMode-->"+returnData);
 	if(jsApiReturnMsgTypeDetector(returnData) === "success"){jsApiCleanInputFieldAfterSubmit( formId );}
 	// alert(returnData);
 	jsApiMsgDisplayer(returnData);

}

function jsApiCancelModuleMaitananceMode(formId){

	mType = 'post';
	mReqType = "cancelModuleMaitananceMode";
	mData = JSON.stringify( $('#'+formId).serializeObject());
 	var returnData = jsApiCommunicationHandler(mAsync, mType, mUrl, mReqType, mData);
 	console.log("fire-->cancelModuleMaitananceMode-->"+returnData);
 	if(jsApiReturnMsgTypeDetector(returnData) === "success"){jsApiCleanInputFieldAfterSubmit( formId );}
 	jsApiMsgDisplayer(returnData);

}

function jsApiDeclareBuyerPrivilege(formId){

	mType = 'post';
	mReqType = "declareBuyerPrivilege";
	mData = JSON.stringify( $('#'+formId).serializeObject());
 	var returnData = jsApiCommunicationHandler(mAsync, mType, mUrl, mReqType, mData);
 	console.log("fire-->declareBuyerPrivilege-->"+returnData);
 	if(jsApiReturnMsgTypeDetector(returnData) === "success"){jsApiCleanInputFieldAfterSubmit( formId );}
 	jsApiMsgDisplayer(returnData);

}

function jsApiDeclareCompanyPrivilege(formId){

	mType = 'post';
	mReqType = "declareCompanyPrivilege";
	mData = JSON.stringify( $('#'+formId).serializeObject());
 	var returnData = jsApiCommunicationHandler(mAsync, mType, mUrl, mReqType, mData);
 	console.log("fire-->declareCompanyPrivilege-->"+returnData);
 	if(jsApiReturnMsgTypeDetector(returnData) === "success"){jsApiCleanInputFieldAfterSubmit( formId );}
 	jsApiMsgDisplayer(returnData);

}




function getDataWithTableName(tableName){

	mType 	= 'get';
	mReqType= "";
	mData 	= "read="+tableName;

 	var returnData = jsApiCommunicationHandler(mAsync, mType, mUrl, mReqType, mData);
 	console.log("fire-->getDataWithTableName-->"+returnData);
 	return returnData;
}			
function jsApiGetDepartment(){
	var deptHTML     	= '<option value="">Select Department</option>';

	mType 	= 'get';
	mReqType= "";
	mData 	= "read="+"mrd_library"+"&"+"LibraryName="+"Emp_Department";

 	var returnData = jsApiCommunicationHandler(mAsync, mType, mUrl, mReqType, mData);
 	//--------- json data processing to get department ----------
 	var parseData = JSON.parse(returnData);
 	var deptOption = new Array();
 	$.each(parseData, function(){
 		$.each(this, function(k, v){
 			if(k == "Description"){
 				if(deptOption.indexOf(v) == -1){
 					deptOption.push(v);
 					deptHTML += '<option value="' + v + '">' + v + '</option>';
 				}
 			}
 		});
 	});
    return deptHTML;
}
function jsApiGetDeptSection(){
	var deptSectionHTML     	= '<option value="">Select Section</option>';

	mType 	= 'get';
	mReqType= "";
	mData 	= "read="+"mrd_library"+"&"+"LibraryName="+"Emp_Section";

 	var returnData = jsApiCommunicationHandler(mAsync, mType, mUrl, mReqType, mData);
 	//--------- json data processing to get department ----------
 	var parseData = JSON.parse(returnData);
 	var secOption = new Array();
 	$.each(parseData, function(){
 		$.each(this, function(k, v){
 			if(k == "Description"){
 				if(secOption.indexOf(v) == -1){
 					secOption.push(v);
 					deptSectionHTML += '<option value="' + v + '">' + v + '</option>';
 				}
 			}
 		});
 	});
    return deptSectionHTML;
}
function jsApiGetModule(username){
	var moduleHTML     	= '<option value="SelectModule">Select Module</option>';

	mType 	= 'get';
	mReqType= "";
	// mData 	= "username="+username+"&"+"module="+"";
	mData = "module="+"";

 	var returnData = jsApiCommunicationHandler(mAsync, mType, mUrl, mReqType, mData);
 	//--------- json data processing to get module ----------
 	var parseData = JSON.parse(returnData);

 	var moduleOption = new Array();
 	$.each(parseData, function(){
 		$.each(this, function(k, v){
 			if(k == "module"){
 				if(moduleOption.indexOf(v) == -1){
 					moduleOption.push(v);
 					moduleHTML += '<option value="' + v + '">' + v + '</option>';
 				}
 			}
 		});
 	});
    return moduleHTML;
}
function jsApiGetSection(username, module){

	var sectionHTML = '<option value="SelectSection">Select Section</option>';

	mType 	= 'get';
	mReqType= "";
 	// mData 	= "username="+username+"&"+"module="+module+"&"+"section="+"";
 	mData 	= "module="+module+"&"+"section="+"";

 	var returnData = jsApiCommunicationHandler(mAsync, mType, mUrl, mReqType, mData);
 	console.log(returnData);
  	//--------- json data processing to get section ----------
 	var parseData = JSON.parse(returnData);

 	var sectionOption = new Array();
 	$.each(parseData, function(){
 		$.each(this, function(k, v){
 			if(k == "section"){
 				if(sectionOption.indexOf(v) == -1){
 					sectionOption.push(v);
 					sectionHTML += '<option value="' + v + '">' + v + '</option>';
 				}
 			}
 		});
 	});
    return sectionHTML;	
}
//----------------------- Password generator code ----------------------------------
var specials = '!@#$%&*_+?';
var lowercase = 'abcdefghijklmnopqrstuvwxyz';
var uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
var numbers = '123456789';
var all = specials + lowercase + uppercase + numbers;
String.prototype.pick = function(min, max) {
    var n, chars = '';
    if (typeof max === 'undefined') {
        n = min;
    } else {
        n = min + Math.floor(Math.random() * (max - min));
    }
    for (var i = 0; i < n; i++) {
        chars += this.charAt(Math.floor(Math.random() * this.length));
    }
    return chars;
};
// Credit to @Christoph: http://stackoverflow.com/a/962890/464744
String.prototype.shuffle = function() {
    var array = this.split('');
    var tmp, current, top = array.length;

    if (top) while (--top) {
        current = Math.floor(Math.random() * (top + 1));
        tmp = array[current];
        array[current] = array[top];
        array[top] = tmp;
    }
    return array.join('');
};
//------------------------------------------------------------------------------
var q = "";
var mColumnName = "username";
var mTablename1 = "mrd_users";
var mTablename2 = "mrd_privilege";
// var mTablename3 = "mrd_buyers";
var mLibraryName = "company";

var reqPrvUsername = '#loginRequestForm #add_new #username';
var usernameField  = '#field_username';
var usernameFieldA = '#field_usernameA';
var usernameFieldD = "#field_usernameD";
var moduleField    = '#field_module';
var sectionField   = '#field_section';
var moduleFieldCP    = '#field_moduleCP';
var sectionFieldCP   = '#field_sectionCP';
var usernamesuggest   = '#uname';

var resUsername = "";
$(function() {
	refreshAutoCompleteInputField();
});

function refreshAutoCompleteInputField(){
	// var resBuyerName = autocompleteGetResourceData2(mTablename3,"buyercode");
 	var resCompanyName = autocompleteGetResourceData3(mLibraryName,"Code");

 	resUsername = autocompleteGetResourceData(mTablename1,"username");
 	$( usernameField ).autocomplete({
 		source: resUsername
 	});
 	$( usernameFieldA ).autocomplete({
 		source: resUsername
 	}); 
 	$( usernameFieldD ).autocomplete({
 		source: resUsername
 	});
 	$( usernamesuggest ).autocomplete({
 		source: resUsername
 	});  		
 	var resModule = autocompleteGetResourceData(mTablename2,"module");
 	$( moduleField ).autocomplete({
 		source: resModule
 	});
 	var resSection = autocompleteGetResourceData(mTablename2,"section");
 	$( sectionField ).autocomplete({
 		source: resSection
 	});	
 	var resModule = autocompleteGetResourceData(mTablename2,"module");
 	$( moduleFieldCP ).autocomplete({
 		source: resModule
 	});
 	var resSection = autocompleteGetResourceData(mTablename2,"section");
 	$( sectionFieldCP ).autocomplete({
 		source: resSection
 	}); 	

 	$( '#field_moduleDMM' ).autocomplete({
 		source: resModule
 	});	
 	$( '#field_moduleCMM' ).autocomplete({
 		source: resModule
 	});	
 	$( '#field_usernameDBP' ).autocomplete({
 		source: resUsername
 	});	
 	$( '#field_usernameDCP' ).autocomplete({
 		source: resUsername
 	});	
 	// $( '#field_buyername' ).autocomplete({
 	// 	source: resBuyerName
 	// });	
 	$( '#field_companyname' ).autocomplete({
 		source: resCompanyName
 	});	
}
function callAutocomplete(){
 	$( reqPrvUsername ).autocomplete({
 		source: resUsername
 	});	
}
function autocompleteGetResourceData(mTablename1, qColumnName){
	var resource = [];
	$.ajax({
	async 	: 	true,
	url: mUrl,
	data: {read:mTablename1},
	success: function( data ) {
		var pData = JSON.parse(data);
		$.each(pData, function(key, value){
			$.each(value, function(k, v){
				  if(k == qColumnName){
				  	if(v.indexOf("::") > 0){
					} else {
					    if(resource.indexOf(v) == -1){
							resource.push(v);
						}
					}
				  }
			});
		});
	},
	error: function(){
	  alert("error occured");
	}
	});
	return resource;
}
function autocompleteGetResourceData2(mTablename1, qColumnName){
	var resource = [];
	$.ajax({
	async 	: 	true,
	url: '/includes/server_api.php',
	data: {tablename:mTablename1, reqType:'read'},
	success: function( data ) {
		var pData = JSON.parse(data);
		$.each(pData, function(key, value){
			$.each(value, function(k, v){
			  if(k == qColumnName){
			    if(resource.indexOf(v) == -1){
					resource.push(v);
				}
			  }
			});
		});
	},
	error: function(){
	  alert("error occured");
	}
	});
	return resource;
}
function autocompleteGetResourceData3(mLibraryName, qColumnName){
	var resource = [];
	$.ajax({
	async 	: 	true,
	url: '/includes/server_api.php',
	data: {libraryname:mLibraryName, reqType:'getLibraryData'},
	success: function( data ) {
		var pData = JSON.parse(data);
		$.each(pData, function(key, value){
			$.each(value, function(k, v){
			  if(k == qColumnName){
			    if(resource.indexOf(v) == -1){
					resource.push(v);
				}
			  }
			});
		});
	},
	error: function(){
	  alert("error occured");
	}
	});
	return resource;
}

function jsApiOnEnter(btnId,e){
    var keycode;
    if (window.event) keycode = window.event.keyCode;
    else if (e) keycode = e.which;
    else return true;

    if (keycode == 13) {
        $("#"+btnId).click();
        return false;
    }
    else{
        return true;
    }
}
</script>