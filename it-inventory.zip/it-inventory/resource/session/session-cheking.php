<?php
ob_start();
session_start();
$username = $_SESSION['USERNAME'];
$password = $_SESSION['password'];

$timeNow = time();
$timePassed = $timeNow - $_SESSION['login_time'];
$userSessionTimeLeft = $_SESSION['userSessionTime'] - $timePassed;

$userSessionTime = $_SESSION['userSessionTime'];
$userWarningBefore = $_SESSION['userWarningBefore'];
include_once('resource/includes/js-css-link-for-sess.php');
?>

<script src="resource/js/md5.js"></script>
<script type="text/javascript" language="javascript">
//----------- Receive user info and session time ----------------------
var jsUsername = "<?php echo $GLOBALS['username'] ?>";
var jsPassword = "<?php echo $GLOBALS['password'] ?>";

var jsUserSessionTime = "<?php echo $GLOBALS['userSessionTimeLeft']?>";
var jsUserWarningBefore = "<?php echo $GLOBALS['userWarningBefore']?>";
//---------------------------------------------------------------------
var nAsync 	= 	true;
var nType 	= 	"";
var nReqType= 	"";
var nUrl 	= 	"";
var nData	= 	"";
var nReloginUrl = "resource/session/relogin.php";
var nSessCheckUrl = "resource/session/session.php";
var nRedirectUrl = "../user/index.php";
//------ custom message display setting --------
var intervalID = 0;
var time = jsUserWarningBefore;
//------ relogin dialog peremater declaration --
var flagSessExpired = false;
var flagOpenRDB = false;
var reloginDialog = "#reloginDB";
var reloginDialogBoxBody1 = '<input id="username" type="hidden" value="<?php echo "$username"; ?>"><input id="password" type="password" placeholder="password" value="">';
	// -- password warning
var reloginDialogBoxBody2 =	"Wrong Password!, Please enter valid password";
	reloginDialogBoxBody2 +='<input id="username" type="hidden"  value="<?php echo "$username"; ?>"><input id="password" type="password" placeholder="password" value="">'; 

var idleTime = 10000;
$(document).ready(function(){

	//---- check username and password are set or not
	if(jsUsername == ""){//--session-expire-->user-reload page[if try]--> redirect to login page
		window.location=nRedirectUrl;
	}
	//--- Message display setting -----
	MsgPop.displaySmall 	= true;
	MsgPop.position 		= "top-right";

	userSessionInfoDisplayerButton();
	//--- relogin dialog --------------
	var reloginDialogBox = $('<div id="reloginDB" title="Re-Login Form"></div>');
    reloginDialogBox.dialog({
		autoOpen: false,
		modal   : true,
		height  : 150,
		width   :  300,
        show 	: {
            effect: "blind",
            duration: 400,
        },
        hide 	: {
            effect: "explode",
            duration: 400
        },
        open 	: function (event, ui) {
        	$(".ui-dialog-titlebar-close").hide(); 
			$(".ui-widget-overlay").css({opacity: 1.0,filter: "Alpha(Opacity=100)",background: "black"});
        	var dBody = $(reloginDB).data('htnlCode');
            $(this).html(dBody);
            // $(this).parents('.ui-dialog-buttonpane button:eq(0)').focus();
            $(this).siblings('.ui-dialog-buttonpane').find('button:eq(0)').focus(); 
        },
	    buttons : {
			"Login":function() {
				var username = $(this).find('#username').val();
				var password = CryptoJS.MD5($(this).find('#password').val()).toString();
				$(this).dialog("close");
				flagOpenRDB = false;
				validUserChecking(username, password);
			},
			"Cancel":function(){
			 	window.location=nRedirectUrl;
			}
	    }        
    });

	//check the user activity every five minutes// var userActivityInterval = setInterval(userActivityDetection, 300000); // 5 minute
    var userActivityInterval = setInterval(userActivityDetection, 30000); // 30 second
    //Increment the idle time counter every minute. // var idleInterval = setInterval(timerIncrement, 60000); // 1 minutes    
    var idleInterval = setInterval(timerIncrement, 3000); // 3 second    
    $(this).mousemove(function (e) {//Zero the idle timer on mouse movement.
        idleTime = 0;
        console.log("idleTime-->"+idleTime);
    });
    $(this).keypress(function (e) {
        idleTime = 0;
         console.log("idleTime-->"+idleTime);
    });
});
function timerIncrement() {
    idleTime = idleTime + 1;	// increments 5 times wthin 5 monutes
}
function userActivityDetection(){
	if(idleTime <= 8){ 			//-->user active within five minute, so need to increment sessionif(idleTime <= 2){ 		//-->user active within five minute, so need to increment session
        autoIncrementSession();
    }
}
function autoIncrementSession(){
	if(!flagSessExpired){
		extendSession();
	}
}
//------------------------------------------
var warningStarted = false;
function showWarningMessages(){	

	if (warningStarted === false){
		warningStarted = true;

		test = MsgPop.open({
		Type 		: 	"warning",
		Content 	:	'Your session is going to expire within <span id="time"></span> seconds!.<br>Please extend your session. Otherwise you need to login again.<br> <button type="submit" onclick="extendSession()" style="float:right;">Extend</button>',
		AutoClose	:	true,
		BeforeOpen	:	function(){
			time = jsUserWarningBefore;  // warning time count
			if(intervalID == 0){
				intervalID = setInterval(function(){
					time-=1;
					$(document.getElementById('time')).html(time);
				},1000);
			}	
		},
		BeforeClose	:	function(){		
			time = jsUserWarningBefore;
			clearInterval(intervalID);
			intervalID = 0;
		},
		AfterClose	:	function(){	
		},				
		CloseTimer	:	(1000*jsUserWarningBefore),// warning time length
		ClickAnyClose:	false,
		HideCloseBtn:	true});
	}
}
//------------- Ajax Function -------------
function communicationToSever(nAsync, nType, nUrl, nReqType, nData){
	$.ajax({
		cache	: 	false,
		type	: 	nType,
		url 	: 	nUrl,
		data : nData,
		success	: 	function(data){
			if(nReqType === "sessCheck"){
				callbackSessionCheck(data);
			}
			else{
				callbackOthers(data, nReqType);
			}			
		},
		error	: 	function(){
			alert("--->error");
		}
	});
}
function callbackSessionCheck(data){
	if(data == "Expiring"){
		showWarningMessages();//-- before session expire
	}
	if(data == "Expired"){
		flagSessExpired = true;
		if(!flagOpenRDB){
			flagOpenRDB = true;
			reloginFunction("firstTime");
		}
	}
	if (data == "notExpired") {
		if ($(reloginDialog).dialog('isOpen')){
			$(reloginDialog).dialog('close');
			flagOpenRDB = false;
		} 
	}	
	console.log("response from server-session-->"+data);
}
function callbackOthers(data, flag){
	if(flag === "extendSession"){
		if(data == "valid-user"){	
			//----------- Reset the variable----------
			flagSessExpired = false;          	
			warningStarted = false;
			clearInterval(sessionCountdownTickerEvent);
			sessionCountdownTime = jsUserSessionTime;
			sessionCountdownTickerEvent = setInterval("sessionCountdownTicker()", 1000);
			//----------------------------------------
			var toastBody = "Your session extended successfully."
			// sessionToastMessage(toastBody);
		}
		else{
			alert("Something are wrong happend!")
		}
	}	
	if(flag === "validUserChecking"){
		if(data == "valid-user"){
			//----------- Reset the variable----------
			flagSessExpired = false;
			warningStarted = false;
			clearInterval(sessionCountdownTickerEvent);
			sessionCountdownTime = jsUserSessionTime;
			sessionCountdownTickerEvent = setInterval("sessionCountdownTicker()", 1000);
			//----------------------------------------
			var toastBody = "Your re-login done successfully.";
			sessionToastMessage(toastBody);
		}
		else{
			flagOpenRDB = true;
			reloginFunction("wrongPassword");
		}
	}
}
//-------------- count down session time by 1 second -------------------
var sessionCountdownTickerEvent = setInterval("sessionCountdownTicker()", 1000);
var sessionCountdownTime = jsUserSessionTime;

function sessionCountdownTicker(){
	if(sessionCountdownTime<0){
		clearInterval(sessionCountdownTickerEvent);
	}
	$("span#sessiontimerText").html(sessionCountdownTime);
	sessionCountdownTime--;
}
function sessionToastMessage(toastBody){
	MsgPop.open({
		Type 		: 	"success",
		Content 	:	toastBody,
		AutoClose	:	true
	});
}
//--------------- session checking function- 2 second por por ------------
var validateSession = setInterval(sessionChecking, 10000);	// in miliseconds
function sessionChecking(){
	nUrl = nSessCheckUrl;
	nReqType = "sessCheck";
	nData = "";
	nType = "GET";
	communicationToSever(nAsync, nType, nUrl, nReqType, nData);	
}
function extendSession(){
	MsgPop.closeAll({ClearEvents:	true});
	var usernameV = jsUsername; 
	var passwordV = jsPassword;

	nUrl = nReloginUrl;
	nReqType = "extendSession";
	nData = {username:usernameV, password:passwordV};
	nType = "POST";
	communicationToSever(nAsync, nType, nUrl, nReqType, nData);
}
//------------- valid user checking function ----------
function validUserChecking(usernameV, passwordV){
	nType = "POST";
	nReqType = "validUserChecking";
	nUrl = nReloginUrl;
	nData = {username:usernameV, password:passwordV};
	communicationToSever(nAsync, nType, nUrl, nReqType, nData);
}
function reloginFunction (flag) {
	if(flag == "firstTime"){
		$(reloginDialog).data('htnlCode', reloginDialogBoxBody1);
		$(reloginDialog).dialog('open');
	}
	else if(flag == "wrongPassword"){
		$(reloginDialog).data('htnlCode', reloginDialogBoxBody2); 
		$(reloginDialog).dialog('open');
	}
}  



function liveUserSessionInfoDisplayer(){
	var htmlCode = "<div id='parent'><div id='usInfo1'>username: <?php echo $GLOBALS['username']; ?></div><br>";
	htmlCode += "<p id='usInfo2'>Given session times is: <?php echo $GLOBALS['userSessionTime']; ?>s; Given warning before: <?php echo $GLOBALS['userWarningBefore'] ?>s</p>";
	htmlCode += "<p id='remtp'>Remaining session time: <span id='sessiontimerText'></span> seconds</p>";
    
    $("<div></div>").attr('class','sessionInfo').appendTo('html');
    $('.sessionInfo').html(htmlCode);
    $('.sessionInfo').css(
    {   'width': '500px', 'height': 'auto', 'position': 'fixed', 'right': '25', 'bottom': '54',
        'background-color': 'white', 'font-size': '20px','padding': '5px', 'text-align': 'center',
        '-webkit-box-shadow': '0px 0px 24px -1px rgba(56, 56, 56, 1)',
        '-moz-box-shadow': '0px 0px 24px -1px rgba(56, 56, 56, 1)',
        'box-shadow': '0px 0px 24px -1px rgba(56, 56, 56, 1)'
    });
    $('div#usInfo1').css({'width': '425px','float': 'left','color': '#20B2AA'});
    $('p#usInfo2').css({'color': '#20B2AA','margin': '0','padding': '0'});  
    $('p#remtp').css({'color': '#B8860B','margin': '0','padding': '0'});    
    $('.sessionInfo').stop().fadeIn(400).delay(3000); 
}
function userSessionInfoDisplayerButton(){
 	var flagSessDetailsOpen = false;
	var btnfabDiv = $('<div  class="button-floating"></div>');
	var btnFAB = ".button-floating";
	$('body').append(btnfabDiv);

	$(btnFAB).click(function() {
	    $(btnFAB).toggleClass( "className" );
	    if (!flagSessDetailsOpen) {
	    	flagSessDetailsOpen = true;
	    	liveUserSessionInfoDisplayer();
	    }
	    else if (flagSessDetailsOpen) {
	    	flagSessDetailsOpen = false;
	    	closeLiveSessionInfo();
	    }
	});
}
function closeLiveSessionInfo(){
	 $('.sessionInfo').stop().fadeOut(500);
}
</script>
