<?php
require_once '../../../includes/config.php'; 
session_start();

	$username = $_POST['username'];
	$password = $_POST['password'];	

	$query = "SELECT * 
				FROM mrd_users 
				WHERE username = '$username' AND password = '$password' ";			
	$result = mysql_query($query, $db2_connection) or die(mysql_error());
	$result_num = mysql_num_rows($result);

	if ($result_num == 1){

			$row = mysql_fetch_array($result);
				
			$_SESSION['USERNAME'] = $username;	//--- Set username session again
			$_SESSION['password'] = $password;	//--- Set password session again
			$_SESSION["USERTYPE"] = $row["usertype"];

			$_SESSION['login_time'] = time(); 	//--- User login time taken from here.

			//------------------------- admin control element ------------------------//
			//------------------------------------------------------------------------//
			$userSessionTime = 3600; 				//--- user session time is 8min (give by us)
			$userWarningBefore = 60;      			//--- given alert before 5s of session expire 

			$_SESSION['userSessionTime'] = $userSessionTime;
			$_SESSION['userWarningBefore'] = $userWarningBefore;
			//------------------------------------------------------------------------//
			//------------------------------------------------------------------------//

		echo "valid-user";
	}
	else{
		echo "invalid-user";
	}
?>