<?php
session_start();

$userSessionTime = $_SESSION['userSessionTime'];	//-- this time is set from login page
$userWarningBefore = $_SESSION['userWarningBefore'];//-- given alert before this amount time


if( !isset( $_SESSION['USERNAME'] ) || time() - $_SESSION['login_time'] > $userSessionTime)
{
    //expired
    echo "Expired";
    session_destroy();
}
else if( !isset( $_SESSION['USERNAME'] ) || time() - $_SESSION['login_time'] > ($userSessionTime-$userWarningBefore))
{
    //expiring....(not expire)
    echo "Expiring";
}
else
{
    //not expired
    echo "notExpired";
}
?>