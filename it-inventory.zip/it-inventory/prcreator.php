<?php
session_start();
require_once $_SERVER["DOCUMENT_ROOT"] . '/includes/user.cookies.php';      // check user login
require_once $_SERVER["DOCUMENT_ROOT"] . '/includes/configli.php';          // mysql connections
require_once $_SERVER["DOCUMENT_ROOT"] . '/includes/user-privilege.php';    // privilege function
require_once __DIR__ . "/classes/myclassautoloader.php";
$thisPageDir = dirname($_SERVER['PHP_SELF']);
$mainPageDir = $thisPageDir;

// check privilege (keep module and section empty to skip privilege check)
$module = "";
$section = "";
$prvlgObj = new UserPrivilege('2');
$privilege = $prvlgObj->userPrivileges($module, $section);
if (!$privilege['R']) { header("Location: ../user/no-permission.php"); exit();}

$btnLookup = '<button type="button" class="btnLookup" title="Click this for look up data" style="margin-left:-3px; color:blue;" onclick="ERPLIST.handleLookup(this);" ><i class="material-icons">search</i></button>';

$itemTypeOption = '<option value="">Select</option>';
$sql= "SELECT Code, Description FROM mrd_library WHERE LibraryName= 'itemtype_PO_NONPO'";
$result = $dbConn1->query($sql);
while($row = $result->fetch_assoc()){
    $Code = $row["Code"];
    $Description = $row["Description"];
    $itemTypeOption .= '<option value="'. $Code .'">'.$Description .'</option>';
}

?>

<!DOCTYPE HTML>
<html>
<head>
	<?php require_once("../includes/head.php") ;?>
	<title>Purchase Requsition Creator</title>

</head>
<body class="right-sidebar">

<!-- Header Wrapper -->
<div id="header-wrapper">
<div class="container">
<div class="row">
<div class="12u">
<!-- Header -->
	<header id="header">
		<?php include_once("../includes/mainmenu.php") ;?> 
	</header>
</div>
</div>
</div>
</div>

<!-- Main Wrapper -->
<div id="main-wrapper">
<div class="container">
<div class="row">
	<div class="12u skel-cell-important">
		<!-- Content -->
		<div id="content">
		<article class="last">
	<!-- HEADLINES -->
		<div class="headline1"></div>	
		<div class="headline2"></div> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<!-- LINKS -->
		<!-- <a href="#">Phasellus quam</a> &nbsp;|&nbsp; 
		<a href="#">More intriguing</a> &nbsp;|&nbsp;
		<a href="#">Phasellus sed nisl</a> &nbsp;|&nbsp;
		<a href="#">vitae risus tristique</a> &nbsp;|&nbsp;
		<a href="#">tristique volutpat</a> &nbsp;|&nbsp;
		<a href="#">Cras rutrum</a> -->

<!-- PAGE CONTENTS -->
		
<!-- TABBED START -->
		<form action="" method="post" id="prcreatorform" name="prcreatorform" onSubmit="return OnSubmitForm()">
		<div class="headline1">Choose Item Type</div>
		<table class="no_border prCreator">
			<br><br><br>
			<tr>
            	<td>Item Type</td>
            	<td>:</td>
          <!--   	<td>
                	<select name="itemtype" id="itemtype" class="select2"><?php echo $itemTypeOption;?></select>
            	</td> -->
            	<td>
                	<input id = "itemtype" type = "text" name = "itemtype" onkeyup="this.value = this.value.toUpperCase();" required><span style="color:red;"> *</span>
            	</td>
            	<td>
                	<?php echo $btnLookup ?><span style= "margin-left: 10pt;" id = "descitemtype"></span>
            	</td>
        	</tr>
		</table>		
				<tr><input class="button" name="submit" type="submit" value="Submit"></tr></br>
	        </form>
<!-- TABBED END -->

		</article>
		</div>
	</div>
	
	</div>
</div>
</div>
</div>

<!-- Footer Wrapper -->
<div id="footer-wrapper">
	<?php include_once("../includes/footer.php") ;?>
</div>
</body>
<link rel="stylesheet" type="text/css" href="css/material-button.css">
<script type="text/javascript" src="js/prcreator.js?t=122vv"></script>
<script type="text/javascript" src="/js/fancybox/jquery.fancybox.js"></script>
<script type="text/javascript" src="api/JsClientAPI.js"></script>
<script type="text/javascript" src="/js/erp_lib.js"></script>
<script type="text/javascript" src="api/client_api.js"></script>

<script type="text/javascript">

</script>

<style type="text/css">
	.button{
		margin-left: 84pt;
		margin-top: 10pt;

	}
	.btnLookup {
        margin-left: -4px;
        color: blue;
        display: inline-block;
        /*border: 1px solid gray;*/
        font-weight: bold;    
        vertical-align: middle;
    }
    .material-icons {
        font-size: 18px;
        font-weight: bold;    
        vertical-align: sub;
    }
</style>

</html>