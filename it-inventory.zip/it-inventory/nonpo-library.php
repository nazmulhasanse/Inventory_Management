<?php
require_once '../includes/user.cookies.php';    // check user login
require_once '../includes/config.php';          // mysql connections
require_once '../includes/database_lib.php';    // mysqli connection & db-functions
require_once '../includes/user-privilege.php';  // privilege function


?>

<!DOCTYPE HTML>
<html>
<head>
	<?php
	require_once("../includes/head.php") ;                                 
	if (isset($_GET['library'])) {
		$libraryH = $_GET['library']; //copied
	} else {
		$libraryH = "Non PO Library";
	}
	?>
	<title><?php echo $libraryH; ?></title>  <!-- Title changes dynamically -->
</head>
<body class="right-sidebar">

<!-- Header Wrapper -->
<div id="header-wrapper">
<div class="container">
<div class="row">
<div class="12u">
<!-- Header -->
	<header id="header">
		<?php include_once("../includes/mainmenu.php") ;?>
	</header>
</div>
</div>
</div>
</div>

<!-- Main Wrapper -->
<div id="main-wrapper">
<div class="container">
<div class="row">
	<div class="10u skel-cell-important">
		<!-- Content -->
		<div id="content">
		<article class="last">
	<!-- HEADLINES -->
		<div class="headline1"></div>	
		<div class="headline2"></div> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

<!-- PAGE CONTENTS -->
		<div class="headline1"><?php echo $libraryH;?></div>	<div class="headline2"></div> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

		<?php if ($privilege_library['C']) {
			echo '<a href="pdm-library.php">Add New Library</a>  &nbsp; &nbsp; ';
		}?>
		
		<?php
		echo "<br><br><b>Choose Library from the list on right side</b>";
		function searchQuery($q) {
			if ($q != '') {
				return " AND ((code LIKE '%$q%') OR (description LIKE '%$q%') OR (zone LIKE '%$q%'))";
			} else {
				return "";
			}
		}

		if (isset($_GET['library'])) {
			if (isset($_GET['q'])) {
				$q = $_GET['q'];
			} else {
				$q = "";
			}

			$library = $_GET['library'];

			if($library != 'nonpo_itemname'){
				$sql = "SELECT * FROM `mrd_library` WHERE `LibraryName` = '$library'" . searchQuery($q) . " ORDER BY id desc";
			}else{
				$sql = "SELECT id,ItemName AS Code,'' AS Description,'' AS Zone,Type AS abbrdesc,ItemNature FROM `nonpo_itemname_library` WHERE 1=1" . searchQuery($q);
			}
			
			$result = mysql_query($sql, $db1_connection);
			
				// $edit_th = "<th>Edit</th>";
			
				// $delete_th = "<th>Delete</th>";

			$libraryTable = "<p class='strong'>Records</p>	<table><tr><th>Code</th>	<th>Description</th>	<th>Zone</th>	<th>AbbrDesc</th> $edit_th	$delete_th</tr>";
			$i = 0;
			while ($row =mysql_fetch_array(($result))) {
				$id = $row['id'];
				$code = $row['Code'];
				$description = $row['Description'];
				$zone = $row['Zone'];
				$abbrdesc = $row['abbrdesc'];
				$code_encoded = urlencode($code);
				
				// $edit_td = "<td><a href='?library=$library&id=$id'><img src='../images/edit.png'</a></td>";

				
				// $delete_td = "<td><a onclick='return confirm(\"You are going to delete a record!\")' href='nonpo-library-act.php?library=$library&id=$id&action=delete'><img src='../images/delete.png'</a></td>";
				
				$libraryTable .= "<tr";
				if ($i % 2 == 0)
					$libraryTable .= " bgcolor=\"#CCCCCC\"";
				$libraryTable .= ">";
		        if (isset($_GET['id']) && $_GET['id'] == $id ) {	// clicked on edit button
		        	$libraryTable .="<form action='nonpo-library-act.php?library=$library&id=$id' method='post'>
		        						<td><input type='text' name='code' value='$code'></td>
		        						<td><input type='text' name='description' value='$description'>
		        						<td><input type='text' name='zone' value='$zone'>
		        						<td><input type='text' name='abbrdesc' value='$abbrdesc'>
		        						<td colspan='2'><input type='submit' name='submit_edit' value='submit'>	
		        						<input onclick='window.location = &quot;?library=$library&quot;' value='Cancel' type='button'></td>
		        					</form>";
		        } else {
        			$libraryTable .="
        			<td>" . $code . "</td>
        			<td>" . $description ."</td>
        			<td>" . $zone . "</td>
        			<td>" . $abbrdesc . "</td>
        			$edit_td
        			$delete_td
        			";
		      	}
		        // <td><a href='nonpo-library-act.php?library=$library&id=$id&action=delete'><img src='../images/delete.png'></a></td>
		        $libraryTable .= "<tr>";
		        $i++;	
		    }
		        	$libraryTable .= "</table>";
		        	$addtype = 'Record';
		} else {
        	$addtype = 'Library';
        	$library = '';
        	$libraryTable = '';
		}
		?>

        <?php
        if (isset($_GET['library'])) {
        	?>	
<!--         	<form  method="get" action=""  id="id">
        		<input name="library" value="<?php echo $library;?>" hidden>
        		<input autofocus size="40" type="text" placeholder='Search here ...' name="q" value ="<?php echo $q;?>"class="global_search" style="margin-top:-20px"> 
        		<input hidden="true" type="submit">
        	</form> -->
        	<?php
        }
        ?>    

	    	<br>
	    	<p class="strong">Add New <?php echo $addtype;?></p>
	    	<form action="nonpo-library-act.php?library=<?php echo $library;?>" method="post">
	    		Library <input placeholder='new library name' name="library" value="<?php echo $library;?>"><br>
	    		Record <input type="text" placeholder='code' name="code">
	    		<input type="text" placeholder='description' name="description">
	    		<input type="text" placeholder='zone' name="zone">
	    		<input type="text" placeholder='abbrdesc' name="abbrdesc">
	    		<input class="button" type="submit" name="submit_add" value="submit">
	    	</form>

	    <?php echo $libraryTable;?>
		</article>
		</div>
	</div>
	<div class="2u">
		<!-- Sidebar -->
		<div id="sidebar">			
			<h2>Non PO Library</h2>			           
			<p><a href='nonpo-library.php?library=NonPOBrand'>Brand</a></p>
			<p><a href='nonpo-library.php?library=NonPOColor'>Color</a></p>
			<p><a href='nonpo-library.php?library=nonpo_itemname'>Item Name</a></p>
			
			<br>
<!-- 			<?php
				echo"<h2>General Library</h2>";
				$liblist = mysql_query("SELECT DISTINCT `LibraryName` FROM mrd_library", $db1_connection); 
				while ($row=mysql_fetch_array(($liblist))) {
					$library = $row['LibraryName'];
					echo "<p><a href='?library=$library'>$library</a></p>";
				}
			?> -->
		</div>
	</div>
</div>
</div>
</div>


<script type="text/javascript">
$(document).ready(function(){
	$.get('/connector_db2_to_erp_base-import/db2_to_erp_usergengrp-import.php', function(response) {
		console.log(response);
	});
});
</script>


<!-- Footer Wrapper -->
<div id="footer-wrapper">
	<?php include_once("../includes/footer.php") ;?>
</div>
</body>
</html>