<?php
/********************************
 **Author: Al-Mamun    **
 **Module Name: document   **
 **Crated date: 2017-01-14 **
 ********************************/
/*
 * Check if we have iddocument
 * Get json data for this document and decode
 * Get the definition from erpdocument_define.php
 * include printdocdefine file
 * Decode data using library (if necessary) and overwrite value
 * Process Barcode
 * Quantity processing for item-lot-element
 * Unset unnecessary line element
 * Getting unique value and re-index array
 * Push calculated total value in line array
 * Draw Head Table
 * Draw Line Table
 * Draw Net Total Table
 * Draw GatePass Table
 * Draw Signature Table
 * Draw Notes Table
 */
session_start();
$directory = __DIR__ ;
require_once __DIR__ . "/classes/config.php";
require_once __DIR__ . "/classes/myclassautoloader.php";

/**
* Print Document Class
*/
class PrintDoc extends GeneralPrintDoc
{
	private $printFormat;
	public $docdefine;
	public $printdocdefine;
	private $printParams = array();

	function __construct($doctype, $formtype){
		/*
		 * Get the definition from erpdocument_define.php
		 */
		$serverUrl = "http://";
		$serverUrl .= $_SERVER["SERVER_NAME"];
		$serverUrl .= ($_SERVER["SERVER_PORT"] != "80") ? ":" . $_SERVER["SERVER_PORT"] : "";

		$rootPath = $_SERVER['DOCUMENT_ROOT'];
		$thisPath = dirname($_SERVER['PHP_SELF']);
		$onlyPath = str_replace($rootPath, '', $thisPath);
		$docdefine = file_get_contents("$serverUrl/$onlyPath/erpdocument_define.php?doctype=$doctype&formtype=$formtype&crudmode=read");
		$this->docdefine = $docdefine;
		// echo $docdefine;
	}

	public function printPage($printParams){

		$pageTittle = $printParams['pageTittle'];
		$company = $printParams['company'];
		$companyAddress = $printParams['companyAddress'];
		$docTittle = $printParams['docTittle'];
		$docSubTittle = $printParams['docSubTittle'];
		$headTable  = $printParams['headTable'];
		$lineTable  = $printParams['lineTable'];
		$notesTable  = $printParams['notesTable'];
		$gatePassPage  = $printParams['gatePassPage'];

echo <<<EOF
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
	<title>$pageTittle</title>
	<link rel="stylesheet" type="text/css" href="css/printdoc.css">
</head>
<body onload="printDiv('printed_content')">

<div id="printed_content">
	<div id="wrapper">
	<!-- //========== Generic Model =========-->
	<div id="div_companyinfo">
	  <p id="div_companyinfo_name">$company</p>
	  <p id="div_companyinfo_address">$companyAddress</p>
	</div>
	<div id="div_doctittle">$docTittle</div>
	<div id="div_docsubtittle">$docSubTittle</div>
	<!-- //========== Generic Model =========-->
	$headTable
	$lineTable
	$notesTable
	$varSignTable

	<div class="newpage">
	$gatePassPage
	</div>


	</div> <!-- wrapper div end -->
</div>  <!-- print content div end -->

<script type="text/javascript">
function printDiv(divName) {
   var printContents = document.getElementById(divName).innerHTML;
   var originalContents = document.body.innerHTML;

   document.body.innerHTML = printContents;
   window.print();
   document.body.innerHTML = originalContents;
}
</script>
</body>
</html>
EOF;

	} 

	function getNotes_printFormat($docdefine, $printdocdefine){
		$doctype    = $_GET['doctype'];
		if ($doctype == 'TI'){

			if ($printdocdefine['hasNotesTable']) {
			  	$varNotesTable = 
			  	'<div id="div_notes">
			      	<p>' . $printdocdefine['note'] . '</p>
			      	<table id="notestable">
			        	<tr>
			          		<td id="notestable_td2"><dt id="notes_dt2"><span></span></dt></td>

			          		<td id="notestable_td2"><dt id="notes_dt2"><span></span></dt></td>

			        	</tr>
			        	<tr>
			          		<td>Signature of Log Employee</td>

			          		<td>Signature of ICT Inventory</td>
			        	</tr>
			     	</table>
			    </div>';


			} else {
			  $varNotesTable = "";
			}

			return $varNotesTable;
		} else {

			if ($printdocdefine['hasNotesTable']) {
			  	$varNotesTable = 
			  	'<div id="div_notes">
			      	<p>' . $printdocdefine['note'] . '</p>
			      	<table id="notestable">
			        	<tr>
			          		<td id="notestable_td2"><dt id="notes_dt2"><span></span></dt></td>
			          		<td id="notestable_td2"><dt id="notes_dt2"><span></span></dt></td>
			          		<td id="notestable_td2"><dt id="notes_dt2"><span></span></dt></td>
			          		<td id="notestable_td2"><dt id="notes_dt2"><span></span></dt></td>
			        	</tr>
			        	<tr>
			          		<td id="notestable_td2">Signature of Section Head</td>
			          		<td id="notestable_td2">Signature of Dept. Head</td>
			          		<td id="notestable_td2">Signature of COO</td>
			          		<td id="notestable_td2">Signature of CEO</td>
			        	</tr>
			     	</table>
			    </div>';
			} else {
			  $varNotesTable = "";
			}

			return $varNotesTable;
		} 

	}

	function getLineTable_printFormat($docdata, $doclines, $docdefine, $printdocdefine){
		$varLineTable = "";

		if($printdocdefine['hasLineTable'] == true){

			$varLineTable .= "</br>";

		  	$lineTableStructure = $printdocdefine['linetable'];

		  	$varLineTable .= "<table class='print' id='linetable'>";
		  	$varLineTable .= "<thead>";
		  	$varLineTable .= "<tr>";
		  	foreach ($lineTableStructure as $columnKey => $columnFields) {
		    	$varLineTable .= "<th>" . $columnKey . "</th>";
		  	}
		  	$varLineTable .= "</thead>";
		  	$varLineTable .= "<tbody>";

		    //========= from data loop =========
		  	foreach ($doclines as $index => $linedata) {
		    	$i = 0;
		    	$varLineTable .= "<tr>";
		    	foreach ($lineTableStructure as $columnKey => $columnFields) {
			      	$i++;
			      	// if columnFields is array then break down			      	
			      	if(is_array($columnFields)){
			      		$varLineTable .=  "<td class='linetable_td' id='linetable_td" . $i . "'>";
				      	// break down td
				      	foreach ($columnFields as $key => $value) {

				        	if (isset($docdefine['lines'][$value]['fielddesc']) && $docdefine['lines'][$value]['fielddesc'] != "") {
				          		$colon = ":"; $pre1  = "<pre>"; $pre2  = "</pre>";
				          		$varLineTable .=   $pre1 . '<b>' . $docdefine['lines'][$value]['fielddesc'] . '</b>' . $colon  . $doclines[$index][$value] . $pre2;
				        	} else {
				          		$colon = ""; $pre1  = ""; $pre2  = "";
				          		$varLineTable .=   $pre1 . $value . $colon  . $doclines[$index][$value] . $pre2;
				        	}
				      	}
			      		$varLineTable .=  "</td>";

			      	} else {
			      		if($columnKey == "#"){
			      			$varLineTable .= ($columnKey == '#') ? "<td class='linetable_td' id='linetable_td" . $i . "'><div class='avoid'>" . sprintf("%03d", ($index + 1)) . "</td>" : "";
			      		} else {
      						$varLineTable .=  "<td class='linetable_td' id='linetable_td" . $i . "'>"  . $linedata[$columnFields] . "</td>";
			      		}
			      	}

			      	$varLineTable .= "";
		    	}
		    	$varLineTable .= "</tr>";
		  	}
		    //========= from data loop =========






		  	$varLineTable .= "<table class='print' id='linetable' >";

		  	$varLineTable .= "<tr style='height:20px'>";
		  	$varLineTable .= "<th colspan='2' ><b>Item Name</b></th>";
		  	$varLineTable .= "<th colspan='2' ><b>Brand/Type</b></th>";
		  	$varLineTable .= "<th colspan='2' ><b>Receiving Date</b></th>";
		  	$varLineTable .= "<th colspan='2' ><b>User Sign</b></th>";
		  	$varLineTable .= "<th colspan='2' ><b>Returning Date</b></th>";
		  	$varLineTable .= "<th colspan='2' ><b>User Sign</b></th>";
		  	$varLineTable .= "<th colspan='2' ><b>Prepared By (Name & Sign)</b></th>";
		  	$varLineTable .= "</tr>";

		  	$varLineTable .= "<tr style='height:20px'>";
			$varLineTable .= "<th colspan='2'>Mouse</th>";
		  	for($k=1; $k<=6; $k++){
			  	$varLineTable .= "<td colspan='2'></td>";
			}
		  	$varLineTable .= "</tr>";

		  	$varLineTable .= "<tr style='height:20px'>";
			$varLineTable .= "<th colspan='2'>Keyboard</th>";
		  	for($k=1; $k<=6; $k++){
			  	$varLineTable .= "<td colspan='2'></td>";
			}
		  	$varLineTable .= "</tr>";
		
		  	$varLineTable .= "<tr style='height:20px'>";
			$varLineTable .= "<th colspan='2'>Monitor</th>";
		  	for($k=1; $k<=6; $k++){
			  	$varLineTable .= "<td colspan='2'></td>";
			}
		  	$varLineTable .= "</tr>";
		
		  	$varLineTable .= "<tr style='height:20px'>";
			$varLineTable .= "<th colspan='2'>Bag</th>";
		  	for($k=1; $k<=6; $k++){
			  	$varLineTable .= "<td colspan='2'></td>";
			}
		  	$varLineTable .= "</tr>";
		
		  	$varLineTable .= "<tr style='height:20px'>";
			$varLineTable .= "<th colspan='2'>IT Policy</th>";
		  	for($k=1; $k<=6; $k++){
			  	$varLineTable .= "<td colspan='2'></td>";
			}
		  	$varLineTable .= "</tr>";

		  	for($i=1; $i<=2; $i++){
			  	$varLineTable .= "<tr style='height:20px'>";
			  	for($j=1; $j<=7; $j++){
			  		$varLineTable .= "<td colspan='2'></td>";
			  	}
			  	$varLineTable .= "</tr>";
			}

		  	$varLineTable .= "</br>";
		  	$varLineTable .= "</tr>";
		  	$varLineTable .= "</table>";
	  
		}
			

		return $varLineTable;

	}

}
	




/*
 * Check if we have docnumber
 */
if (!isset($_GET['doctype']) || !isset($_GET['docnumber'])) {
  die("doctype and iddocument required");
}
$docnumber = $_GET['docnumber'];

amendent:
$doctype    = $_GET['doctype'];
$formtype = (isset($_GET['formtype'])) ? $_GET['formtype'] : "";

/*
 * Get json data for this document and decode
 */
$printDocObj = new PrintDoc($doctype, $formtype);
$docdefine = $printDocObj->docdefine;
$docdata = $printDocObj->_readDoc($docnumber, $docdefine);
$docdata  = json_decode($docdata, true);
$formtype = $docdata['formtype'];

/**
 * Update docdefine by formtype
 */
$printDocObj = new PrintDoc($doctype, $formtype);

/*
 * include printdocdefine file
 */
require_once 'printdocdefine-v5.php';
$printdocdefine = printdocdefine($doctype, $formtype);

/**
 * Passing json data
 */
$docdata = json_encode($docdata);
$printdocdefine = json_encode($printdocdefine);

// 1. Get default print format by using getDefaultPrintFormat function
// 2. Print page by using printPage

// 1. Get default print format by using getDefaultPrintFormat function
$printParams = $printDocObj->getDefaultPrintFormat($docdata, $docdefine, $printdocdefine);
// 2. Print page by using printPage
$printDocObj->printPage($printParams);


?>