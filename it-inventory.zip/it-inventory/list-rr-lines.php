<?php
require_once $_SERVER["DOCUMENT_ROOT"] . '/includes/user.cookies.php';    // check user login
require_once $_SERVER["DOCUMENT_ROOT"] . '/includes/configli.php';        // mysql connections
require_once $_SERVER["DOCUMENT_ROOT"] . '/includes/user-privilege.php';  // privilege function
require_once __DIR__ . "/classes/myclassautoloader.php";
// check privilege (keep module and section empty to skip privilege check)
$module = "";
$section = "";
$privilege = userPrivileges($module, $section);
if (!$privilege['R']) { header("Location: ../user/no-permission.php"); exit();}

$salesOrder = isset($_GET['salesorder']) ? $_GET['salesorder'] : '';

$formTitle = 'All RR under sales order ' . $salesOrder;
$pageTittle= 'All RR under sales order ' . $salesOrder;
$mainHTML  = 'html/listerp.html';

$mainJS    = 'js/list-erp.js?t=2018-03-09';
$mainJS    = 'js/list-doc-erp.js?t=2018-03-09';
// $thisListJS = 'js/list-doc-erp.js?t=' . time();
// $listErpJS  = 'js/list-doc-erp.js?t=2017-10-09';
// $thisListJS = 'js/list-doc-yourname.js?t=2017-10-09';


$customJS  = 'js/list-rr-lines.js?t=2018-03-09';

$apiURL    = 'list-rr-lines_api.php';
$formId    = 'searchForm';

$module = "";
$section = "";
$privilege_sm = json_encode(userPrivileges($module,$section));

$environment = ''; 
if( isset($_GET['rrtype']) && $_GET['rrtype'] == 'Direct'){
    $environment = ' (Direct Environment)';
}
?>

<!DOCTYPE HTML>
<html>
<head>
    <?php require_once($_SERVER["DOCUMENT_ROOT"] . "/includes/head.php") ;?>
    <title><?php echo $formTitle;?></title>
    
    <link rel="stylesheet" type="text/css" href="css/listerp.css">
    <link rel="stylesheet" type="text/css" href="css/material-button.css">
    <link rel="stylesheet" type="text/css" href="plugin/msgPop.css">

    <link rel="stylesheet" type="text/css" href="css/list-doc-erp.css">
    <link rel="stylesheet" type="text/css" href="css/doc-list-erp.css">

</head>
<body class="right-sidebar">

<!-- Header Wrapper -->
<div id="header-wrapper">
<div class="container">
<div class="row">
<div class="12u">
<!-- Header -->
    <header id="header">
        <?php 
        include_once($_SERVER["DOCUMENT_ROOT"] . "/includes/mainmenu.php");
        ?>
    </header>
</div>
</div>
</div>
</div>

<!-- Main Wrapper -->
<div id="main-wrapper">
<div class="container">
<div class="row">
    <div class="12u skel-cell-important">
        <!-- Content -->
        <div id="content">
        <article class="last">
    <!-- HEADLINES -->
        <div class="headline1"><a href="/erp-apparel/documents-home.php?m=rr">Home</a> - </div>   
        <div class="headline2"><?php echo $formTitle;?></div> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<!-- LINKS -->

<!--         <a href="list-allocated-rr-lines.php?rrtype=Direct">Allocated RR List</a> &nbsp;|&nbsp; 
        <a href="list-pocreation-rr-lines.php?rrtype=Direct">PO Creation RR List</a> &nbsp;|&nbsp;
        <a href="list-wocreation-rr-lines.php?rrtype=Direct">WO Creation RR List</a> &nbsp;|&nbsp;
        <a href="list-executed-rr-lines.php?rrtype=Direct">Executed RR List</a> &nbsp;|&nbsp;
        <a href="list-closed-rr-lines.php?rrtype=Direct">Closed RR List</a> &nbsp;|&nbsp;
        <a href="docpo_search.php?doctype=PO?rrtype=Direct">PO/WO Line List</a> &nbsp;|&nbsp;   -->

        <br><br><br>
        <div id='tabsalesorder'></div>   
        <br><br>
        <div id="upperButtonBar" style="height:50px;">
            <input type="button" class="btn-grey" value="Stock Availability Check" title="Stock Availability Check" onclick="LISTDOC.checkStockAvailability();" style="display: inline-block;">
            <input type="button" class="btn-grey" value="Unallocate stock" title="Unallocate stock" onclick="LISTDOC.unallocateStock();" style="display: inline-block;">
            <input type="button" class="btn-grey" value="Send to PO/WO creation List" title="Send to PO/WO creation List" onclick="LISTDOC.sendForPOWO();" style="display: inline-block;">
            <input type="button" class="btn-grey" value="Recalculation Request" title="Recalculation Request" onclick="LISTDOC.sendForRecalculation();" style="display: inline-block;">
            <input type="button" class="btn-grey" value="Acknowledge Cancelation" title="Cancle this Document" onclick="LISTDOC.acknowledgeCancellation();" style="display: inline-block;">
            <input type="button" class="btn-blue" value="Re-run MRP" title="Re-run MRP" id="btnReRun" onclick="LISTDOC.reRunMRP();" style="display: inline-block;">
        </div>
<!-- PAGE CONTENTS -->
<!-- PAGE CONTENTS -->
<div id="headerDataCntr"></div>
<?php
$form = new ErpDocListRR();
$formStructure = $form->formStructure('RR', '', '');
echo <<<php
<div id="listDataCntr">
php;
    $form->buildForm();
echo <<<php
</div>
php;
?>
        </article>
        </div>
    </div>

</div>
</div>
</div>


<!-- Footer Wrapper -->
<div id="footer-wrapper">
    <?php include_once($_SERVER["DOCUMENT_ROOT"] . "/includes/footer.php") ;?>
</div>
<script type="text/javascript" src="plugin/fancybox/source/jquery.fancybox.js"></script>
<script type="text/javascript" src="plugin/msgPop.js"></script>

<script type="text/javascript" src="/js/erp_lib.js"></script>
<script type="text/javascript" src="api/JsClientAPI.js"></script>

<script type="text/javascript" src="api/client_api.js"></script>
<script type="text/javascript" src="<?php echo $mainJS; ?>"></script>   
<script type="text/javascript" src="<?php echo $customJS; ?>"></script> 

<!-- Doc JS -->
<script type="text/javascript" src="<?php echo $form->_URL_MAINJS; ?>"></script>
<script type="text/javascript" src="<?php echo $form->_URL_DOCJS; ?>"></script>

<script type="text/javascript">
$(document).ready(function() {
    var  DOC_DB_SET_READ_KAYFIELD = '<?php echo $form->DOC_DB_SET_READ_KAYFIELD; ?>';
    LISTDOC.passingParams = {
        DOC_DB_SET_READ_KAYFIELD:DOC_DB_SET_READ_KAYFIELD,
    };

    var apiURL = '<?php echo $apiURL;?>';
    //                  show,   page,   api_url
    LISTDOC.getListData(100,        1,      apiURL);

    LISTDOC.getSOTable();
    //success msg show 
    params = jsClient.paramsToObj(window.location.search);
    if(!!params.sMsg && params.sMsg != ''){
        var cloneDiv = $('#listSuccessDiv').clone();
        cloneDiv.css({'display':'block'})
          .insertBefore('#listSuccessDiv')
          .find('#listSuccessMsg').text(params.sMsg);
    }

    // document processing 
    var _URL_MODULEDIR = '<?php echo $form->_URL_MODULEDIR; ?>';
    var _ERP_DOCACRONYM = '<?php echo $form->_ERP_DOCACRONYM; ?>';
    var _URL_DOCUMENTAPI = '<?php echo $form->_URL_DOCUMENTAPI; ?>';
    var _URL_DOCDEFINEAPI = '<?php echo $form->_URL_DOCDEFINEAPI; ?>';
    var _USERNAME = '<?php echo $_SESSION['USERNAME']; ?>';
    var params = { _ERP_DOCACRONYM:_ERP_DOCACRONYM, _URL_DOCUMENTAPI:_URL_DOCUMENTAPI, _URL_DOCDEFINEAPI:_URL_DOCDEFINEAPI, _URL_MODULEDIR:_URL_MODULEDIR, _USERNAME:_USERNAME, DOC_DB_SET_READ_KAYFIELD: DOC_DB_SET_READ_KAYFIELD};
    erpdocument.processForm( '#<?php echo $form->formId; ?>', params); 

    LISTDOC.reRunButtonVisibility();   

}); 
</script>
</body>
</html>