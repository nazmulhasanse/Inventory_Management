<?php
/*
* Define printdoc header
* Define printdoc lines
* Define printdoc NB
* Define printdoc signature
* Define printdoc gatepass
*/
function printdocdefine($doctype , $formtype) {	

	if ($doctype == 'MX') {

		$printdocheader = array(
			1 => array( 'docnumber', 'docdate'),
			2 => array( 'vehicleno', 'lockno'),
			3 => array( 'drivername', 'drivermobileno'),
		);

		$printdoclines = array(
			'#'          => 'serialno',
			'Item'       => array( 'itemcode' , 'itemdescription'),
			'References' => array( 'itemlot', 'trackingno'),
			'Qty'        => array( 'totallotqty', 'iduom'),
		);

		$printdoclines = array(
			'#'         => 'serialno',
			'Item Type' => 'itemtype',
			'Item Code' => 'itemcode',
			'Item Lot'  => 'itemlot',
			'Serial'    => 'serial',
			'Quantity'  => 'tnxquantity',
			'Size'      => 'size',
		);

		$printgatepass = array(
			'#'         => 'serialno',
			'Item Type' => 'itemtype',
			'Item Code' => 'itemcode',
			'Item Lot'  => 'itemlot',
			'Serial'    => 'serial',
			'Quantity'  => 'tnxquantity',
			'Size'      => 'size',
			'Remarks'           => ''

		);

		$printsignature = array('Receiver Signature', 'Security Incharge', 'Store Officer', 'Authorized Signature');
		$nettotalline = array("total"=>"total", "totalgarmentqty" => "totalgarmentqty", "totalcartonqty" => "totalcartonqty");




		//------------ variation based on form type
		$formtittle = "Goods Delivery Notes";
		$subFormTittle = "Default";	
		switch ($formtype) {
			case 'export':
				$subFormTittle = "For: Export";	
				break;
			case 'wms_issuetodepartment':
				$subFormTittle = "issue to department";	
				break;					
			default:
				break;
		}

		$printFormatStructure = array(
			'formTittle'       => $formtittle,
			'hasDocSubTittle'  => true,
			'subFormTittle'    => $subFormTittle,
			'hasHeadTable'     => true,
			'hasLineTable'     => true,
			'hasNetTotalTable' => true,
			'hasNotesTable'    => true,
			'note' 			   => 'N.B: Please receive the above goods in proper condition and sign the duplicate copy and return',
			'hasSignTable'     => true,
			'hasGatePassTable' => true,
 			'headertable'      => $printdocheader,
			'linetable'        => $printdoclines,
			'nettolaltable'    => $nettotalline,
			'gatepasstable'    => $printgatepass,
			'signaturetable'   => $printsignature

		);	
		return $printFormatStructure;

	}else if ($doctype == 'BOM') {

		$printdocheader = array(
			1 => array( 'docnumber', 'docdate'),
			2 => array( 'company', 'salesorder'),
			3 => array( 'endcustomer', 'pieceqty'),
		);

		$printdoclines = array(
			'#'          => 'serialno',
			'Item'       => array( 'itemcode' , 'itemdescription'),
			'References' => array( 'itemlot', 'trackingno'),
			'Qty'        => array( 'totallotqty', 'iduom'),
		);

		$printdoclines = array(
			'#'                               => 'serialno',
			'BOM Line No.'                    => 'doclinenumber',
			'Item Type'                       => 'itemtype',
			'Item Code'                       => 'itemcode',
			'Item Description'                => 'itemdescription',
			'Marker Length per Dozen (Yards)' => 'markerlength',
			'UOM'                             => 'iduom',
			'Quantity'                        => 'tnxquantity',
			'Garment Quantity in Pcs'         => 'garmentquantityinpcs',
			'Size/Size ratio'                 => 'size',
		);

		$printgatepass = array(
			'#'         => 'serialno',
			'Item Type' => 'itemtype',
			'Item Code' => 'itemcode',
			'Item Lot'  => 'itemlot',
			'Serial'    => 'serial',
			'Quantity'  => 'tnxquantity',
			'Size'      => 'size',
			'Remarks'           => ''

		);

		$printsignature = array('Receiver Signature', 'Security Incharge', 'Store Officer', 'Authorized Signature');
		$nettotalline = array("total"=>"total", "totalgarmentqty" => "totalgarmentqty", "totalcartonqty" => "totalcartonqty");




		//------------ variation based on form type
		$formtittle = "Goods Delivery Notes";
		$subFormTittle = "Default";	
		switch ($formtype) {
			case 'export':
				$subFormTittle = "For: Export";	
				break;
			case 'wms_issuetodepartment':
				$subFormTittle = "issue to department";	
				break;					
			default:
				break;
		}

		$printFormatStructure = array(
			'formTittle'       => $formtittle,
			'hasDocSubTittle'  => true,
			'subFormTittle'    => $subFormTittle,
			'hasHeadTable'     => true,
			'hasLineTable'     => true,
			'hasNetTotalTable' => true,
			'hasNotesTable'    => true,
			'note' 			   => 'N.B: Please receive the above goods in proper condition and sign the duplicate copy and return',
			'hasSignTable'     => true,
			'hasGatePassTable' => false,
 			'headertable'      => $printdocheader,
			'linetable'        => $printdoclines,
			'nettolaltable'    => $nettotalline,
			'gatepasstable'    => $printgatepass,
			'signaturetable'   => $printsignature

		);	
		return $printFormatStructure;

	}else if ($doctype == 'PO') {

		$printdocheader = array(
			1 => array( 'suppliername', 'supplieraddress','attention','contactno'),
			2 => array( 'docnumber', 'docdate','podeliverydate', 'purchasemode', 'currency'),
		);

		$printdoclines = array(
			'#'          => 'serialno',
			'Item'       => array( 'itemcode' , 'itemdescription'),
			'References' => array( 'itemlot', 'trackingno'),
			'Qty'        => array( 'totallotqty', 'iduom'),
		);

		$printdoclines = array(
			'#'                    => 'serialno',
			'PR Info' => array('project', 'requisitionlinenumber'),
			'Cost Center' => 'costcenter',
			'Cost Dept' => 'costdept',
			'Item Name'            => 'itemname',
			// 'Item Code'            => 'itemcode',
			// 'Item Description'     => array('itemdescription', 'brand', 'sizeormeasurement', 'color'),
			'Description'     => array('itemdescription', 'brand', 'sizeormeasurement', 'color'),
			// 'Item Description'     => 'itemdescription',
			// 'Brand'                => 'brand',
			// 'Size or Measurement'  => 'sizeormeasurement',
			// 'Color'                => 'color',
			// 'Cost Center'            => 'costcenter',
			// 'Cost Department'      => 'costdept',
			'Order Qty'            => 'orderqty',
			'UOM'                  => 'iduom',
			// 'Currency'             => 'currency',
			'Unit Price'           => 'unitprice',
			'Discount Amount'      => 'discountamount',
			// 'Extra cost'           => 'extracost',
			'Amount'               => 'amount',
			// 'Remarks'              => 'linesremarks',
		);

		$printgatepass = array(
			'#'         => 'serialno',
			'Item Code' => 'itemcode'

		);

		$printsignature = array('Prepared By', 'Checked By', 'Approved By', 'Authorized Signature');
		$nettotalline = array("total"=>"total", "totalgarmentqty" => "totalgarmentqty", "totalcartonqty" => "totalcartonqty");

		// $printsignature = array();
		$nettotalline = array();




		//------------ variation based on form type
		$formtittle = "Goods Delivery Notes";
		$subFormTittle = "Default";	
		switch ($formtype) {
			case 'PO':
				$subFormTittle = "";	
				break;
			case 'wms_issuetodepartment':
				$subFormTittle = "issue to department";	
				break;					
			default:
				break;
		}

		$printFormatStructure = array(
			'formTittle'       => $formtittle,
			'hasDocSubTittle'  => true,
			'subFormTittle'    => $subFormTittle,
			'hasHeadTable'     => true,
			'hasLineTable'     => true,
			'hasNetTotalTable' => true,
			'hasNotesTable'    => false,
			'note' 			   => '',
			'hasSignTable'     => false,
			'hasGatePassTable' => false,
 			'headertable'      => $printdocheader,
			'linetable'        => $printdoclines,
			'nettolaltable'    => $nettotalline,
			'gatepasstable'    => $printgatepass,
			'signaturetable'   => $printsignature

		);	
		return $printFormatStructure;

	}else if ($doctype == 'CP') {

		$printdocheader = array(
			1 => array( 'docnumber', 'docdate'),
			2 => array( 'company', 'salesorder'),
			3 => array( 'customer', 'endcustomer'),
		);

		$printdoclines = array(
			'#'          => 'serialno',
			'Item'       => array( 'itemcode' , 'itemdescription'),
			'References' => array( 'itemlot', 'trackingno'),
			'Qty'        => array( 'totallotqty', 'iduom'),
		);

		$printdoclines = array(
			'#'                              => 'serialno',
			'Order Qty (PK)'                 => 'packqty',
			'Pcs Per PK'                     => 'pieceperpack',
			'Order Qty (Pcs)'                => 'pieceqty',
			'Goods Ready Date'               => 'shipmentdate',
			'Ex-factory Date'                => 'exfactorydate',
			'Sewing Start Date'              => 'sewingstartdate',
			'Sewing Finished Date'           => 'sewingfinisheddate',
			'Output Per Line Per Day(Piece)' => 'outputperlineperday',
			'Destinationn'                   => 'destination',
		);

		$printgatepass = array(
			'#'         => 'serialno',
			'Item Type' => 'itemtype',
			'Item Code' => 'itemcode',
			'Item Lot'  => 'itemlot',
			'Serial'    => 'serial',
			'Quantity'  => 'tnxquantity',
			'Size'      => 'size',
			'Remarks'           => ''

		);

		$printsignature = array('Receiver Signature', 'Security Incharge', 'Store Officer', 'Authorized Signature');
		$nettotalline = array("total"=>"total", "totalgarmentqty" => "totalgarmentqty", "totalcartonqty" => "totalcartonqty");




		//------------ variation based on form type
		$formtittle = "Goods Delivery Notes";
		$subFormTittle = "Default";	
		switch ($formtype) {
			case 'export':
				$subFormTittle = "For: Export";	
				break;
			case 'wms_issuetodepartment':
				$subFormTittle = "issue to department";	
				break;					
			default:
				break;
		}

		$printFormatStructure = array(
			'formTittle'       => $formtittle,
			'hasDocSubTittle'  => true,
			'subFormTittle'    => $subFormTittle,
			'hasHeadTable'     => true,
			'hasLineTable'     => true,
			'hasNetTotalTable' => true,
			'hasNotesTable'    => true,
			'note' 			   => 'N.B: Please receive the above goods in proper condition and sign the duplicate copy and return',
			'hasSignTable'     => true,
			'hasGatePassTable' => false,
 			'headertable'      => $printdocheader,
			'linetable'        => $printdoclines,
			'nettolaltable'    => $nettotalline,
			'gatepasstable'    => $printgatepass,
			'signaturetable'   => $printsignature

		);	
		return $printFormatStructure;

	}else if ($doctype == 'PO') {

		$printdocheader = array(
			1 => array( 'docnumber', 'previousponumber', 'docdate', 'salesordertype', 'endcustomer', 'company', 'requestor'),
			// 1 => array( 'docnumber', 'previousponumber', 'docdate'),
			// 2 => array( 'salesordertype', 'endcustomer'),
			// 3 => array( 'company', 'requestor'),
		);

		$printdoclines = array(
			'#'          => 'serialno',
			'Item'       => array( 'itemcode' , 'itemdescription'),
			'References' => array( 'itemlot', 'trackingno'),
			'Qty'        => array( 'totallotqty', 'iduom'),
		);

		$printdoclines = array(
			'#'                            => 'serialno',
			'Line No.'                     => 'linenumber',
			'RR No.'                       => 'rrnumber',
			'First Fabric Inhouse Date'    => 'fabricinhousedate',
			'Item Type'                    => 'itemtype',
			'Item Code'                    => 'itemcode',
			'Item Description'             => 'itemdescription',
			'Total Required Quantity'      => 'tnxquantity',
			'UOM'                          => 'iduom',
			'Fabric Price Requisition No.' => 'pricerequisitionnumber',
			'Unit Price'                   => 'unitprice',
		);


		$printsignature = array('Prepared By', 'Checked By', 'Approved By', 'Authorized Signature');
		$nettotalline = array("total"=>"total", "totalgarmentqty" => "totalgarmentqty", "totalcartonqty" => "totalcartonqty");

		$printgatepass = array(
			'#'         => 'serialno',
			'Item Type' => 'itemtype',
			'Item Code' => 'itemcode',
			'Item Lot'  => 'itemlot',
			'Serial'    => 'serial',
			'Quantity'  => 'tnxquantity',
			'Size'      => 'size',
			'Remarks'           => ''

		);



		//------------ variation based on form type
		$formtittle = "Goods Delivery Notes";
		$subFormTittle = "Default";	
		switch ($formtype) {
			case 'export':
				$subFormTittle = "For: Export";	
				break;
			case 'wms_issuetodepartment':
				$subFormTittle = "issue to department";	
				break;					
			default:
				break;
		}

		$printFormatStructure = array(
			'formTittle'       => $formtittle,
			'hasDocSubTittle'  => true,
			'subFormTittle'    => $subFormTittle,
			'hasHeadTable'     => true,
			'hasLineTable'     => true,
			'hasNetTotalTable' => true,
			'hasNotesTable'    => true,
			'note' 			   => 'N.B: Please receive the above goods in proper condition and sign the duplicate copy and return',
			'hasSignTable'     => true,
			'hasGatePassTable' => false,
 			'headertable'      => $printdocheader,
			'linetable'        => $printdoclines,
			'nettolaltable'    => $nettotalline,
			'signaturetable'   => $printsignature,
			'gatepasstable'    => $printgatepass,

		);	
		return $printFormatStructure;

	} else if($doctype == 'GRN') {

		$printdocheader = array(
			1 => array( 'docnumber', 'company', 'Receiving Date', 'suppliername', 'Challan No.', 'whlocation', 'docdate' ),

		);

		$printdoclines = array(
			'#'                  => 'serialno',
			'PR Line No.'        => '',
			'PO Line No.'        => '',
			'#'                  => 'serialno',
			'Item Code'          => 'itemcode',
			'Item Name'          => 'itemname',
			'Item Desc.'         => 'itemdescription',
			'Challan Recv. Qty.' => 'tnxquantity',
			'UoM'                => 'uom',
			'Bin Location'       => 'binlocation',
		);




		//------------ variation based on form type
		$formtittle = "GOODS RECEIPT NOTE";

		$printFormatStructure = array(
			'formTittle'       => $formtittle,
			'hasHeadTable'     => true,
			'hasLineTable'     => false,
 			'headertable'    => $printdocheader,
			'linetable'      => $printdoclines,
		);	
		return $printFormatStructure;

	}else if($doctype == 'TI') {

		$printdocheader = array(
			1 => array( 'docnumber', 'logsheetnumber', 'company', 'department', 'section'),
			2 => array( 'name', 'employeeid', 'designation', 'contactnumber', 'useremail'),

		);

		$printdoclines = array(
			'#'         => 'linenumber',
			'PO Date'   => 'purchasedate',
			'PO#'       => 'ponumber',
			'INV#'      => 'inventoryid',
			'Serial#'   => 'serialnumber',
			'PC Type'   => 'laptopordesktop',
			'RAM'       => 'ram',
			'HDD'       => 'hdd',
			'Processor' => 'processor',
			'Brand'     => 'brand',
		);

		$formtittle = "ICT Inventory";

		$printFormatStructure = array(
			'formTittle'       => $formtittle,
			'hasHeadTable'     => true,
			'hasLineTable'     => false,
 			'headertable'    => $printdocheader,
			'linetable'      => $printdoclines,
		);	
		
		return $printFormatStructure;

	}else {

		$printdocheader = array(
			1 => array( 'docnumber', 'docdate'),
			2 => array( 'vehicleno', 'lockno'),
			3 => array( 'drivername', 'drivermobileno'),
		);

		$printdoclines = array(
			'#'          => 'serialno',
			'Item'       => array( 'itemcode' , 'itemdescription'),
			'References' => array( 'itemlot', 'trackingno'),
			'Qty'        => array( 'totallotqty', 'iduom'),
		);

		$printdoclines = array(
			'#'         => 'serialno',
			'Item Type' => 'itemtype',
			'Item Code' => 'itemcode',
			'Item Lot'  => 'itemlot',
			'Serial'    => 'serial',
			'Quantity'  => 'tnxquantity',
			'Size'      => 'size',
		);

		$printgatepass = array(
			'#'         => 'serialno',
			'Item Type' => 'itemtype',
			'Item Code' => 'itemcode',
			'Item Lot'  => 'itemlot',
			'Serial'    => 'serial',
			'Quantity'  => 'tnxquantity',
			'Size'      => 'size',
			'Remarks'           => ''

		);

		$printsignature = array('Receiver Signature', 'Security Incharge', 'Store Officer', 'Authorized Signature');
		$nettotalline = array("total"=>"total", "totalgarmentqty" => "totalgarmentqty", "totalcartonqty" => "totalcartonqty");




		//------------ variation based on form type
		$formtittle = "Goods Delivery Notes";
		$subFormTittle = "Default";	
		switch ($formtype) {
			case 'export':
				$subFormTittle = "For: Export";	
				break;
			case 'wms_issuetodepartment':
				$subFormTittle = "issue to department";	
				break;					
			default:
				break;
		}

		$printFormatStructure = array(
			'formTittle'       => $formtittle,
			'hasDocSubTittle'  => true,
			'subFormTittle'    => $subFormTittle,
			'hasHeadTable'     => true,
			'hasLineTable'     => true,
			'hasNetTotalTable' => true,
			'hasNotesTable'    => true,
			'note' 			   => 'N.B: Please receive the above goods in proper condition and sign the duplicate copy and return',
			'hasSignTable'     => true,
			'hasGatePassTable' => true,
 			'headertable'      => $printdocheader,
			'linetable'        => $printdoclines,
			'nettolaltable'    => $nettotalline,
			'gatepasstable'    => $printgatepass,
			'signaturetable'   => $printsignature

		);	
		return $printFormatStructure;

	}



}


?>