<?php
$directory = __DIR__ ;
require_once __DIR__ . "/classes/config.php";
require_once $_SERVER['DOCUMENT_ROOT'] . "/includes/user.cookies.php";
require_once $_SERVER['DOCUMENT_ROOT'] . "/includes/user-privilege.php";
require_once __DIR__ . "/classes/myclassautoloader.php";
// check privilege (keep module and section empty to skip privilege check)
$module    = "";
$section   = "";
$privilege = userPrivileges($module, $section);
if (!$privilege['R']) {header("Location: ../user/no-permission.php");exit();}

if (isset($_GET['doctype'])) {
  $doctype = $_GET['doctype'];
} else {
  $doctype = '';
}

if (isset($_GET['formtype'])) {
  $formtype = $_GET['formtype'];
} else {
  $formtype = '';
}

$rootPath = $_SERVER['DOCUMENT_ROOT'];
$thisPath = dirname($_SERVER['PHP_SELF']);
$onlyPath = str_replace($rootPath, '', $thisPath);
// echo "string.." . $onlyPath;

$_URL_HOME_PAGE = $onlyPath . "/inv_documents-home.php?formtype=$formtype";
$_URL_DOCUMENT_API    = $onlyPath . '/docti_api.php';
$_URL_DOCUMENT_DEFINE = $onlyPath . "/erpdocument_define.php?doctype=TI&formtype=$formtype&crudmode=search";
$_URL_DOCUMENT_SEARCH = $onlyPath . "/docti_search.php?formtype=$formtype";
$_URL_DOCUMENT_CRUD   = $onlyPath . "/erpdocument.php?doctype=TI&formtype=$formtype";

$form = new ErpDocumentPO;
$formStructure = $form->formStructure($doctype, $formtype, '');
?>

<script type="text/javascript">
var resultcolumns = "docnumber,docdate,doccreationtime,doctype,formtype";
var searchIn = ['`docnumber`', '`doctype`' , '`formtype`'];
// var searchIn = ['`docnumber`', '`itemcode`' , '`itemlot`' , '`formtype`'];
var joinline = 'yes';

var quicklink_dates = [];
	// quicklink_dates.push({'userfield' : 'To be received today'       , 'dbfield' : 'docdate' , 'daterange' : 'today'});
	// quicklink_dates.push({'userfield' : 'To be received tomorrow'    , 'dbfield' : 'docdate' , 'daterange' : 'tomorrow'});
	// quicklink_dates.push({'userfield' : 'To be received next 7 days' , 'dbfield' : 'docdate' , 'daterange' : 'next7days'});
	quicklink_dates.push({'userfield' : 'Created today'              , 'dbfield' : 'docdate'              , 'daterange' : 'today'});
	quicklink_dates.push({'userfield' : 'Created yesterday'          , 'dbfield' : 'docdate'              , 'daterange' : 'yesterday'});
	quicklink_dates.push({'userfield' : 'Created last 7 days'        , 'dbfield' : 'docdate'              , 'daterange' : 'last7days'});

var defaultresult = quicklink_dates[0];	// on page load
</script>

<!DOCTYPE HTML>
<html>
<head>
	<?php require_once $_SERVER['DOCUMENT_ROOT'] . "/includes/head.php";?>
	<title><?php echo $form->formTitle;?></title>
</head>
<body class="right-sidebar">

<!-- Header Wrapper -->
<div id="header-wrapper">
<div class="container">
<div class="row">
<div class="12u">
<!-- Header -->
	<header id="header">
		<?php include_once $_SERVER['DOCUMENT_ROOT'] . "/includes/mainmenu.php";?>
	</header>
</div>
</div>
</div>
</div>

<!-- Main Wrapper -->
<div id="main-wrapper">
<div class="container">
<div class="row">
	<div class="12u skel-cell-important">
		<!-- Content -->
		<div id="content">
		<article class="last">
<!-- LINKS -->
		<a href="<?php echo $_URL_HOME_PAGE ?>">Home</a> &nbsp;|&nbsp;
	    <a href="<?php echo $_URL_DOCUMENT_SEARCH ?>"><b>List</b> of <?php echo $form->formTitle;?></a> &nbsp;|&nbsp;
	    <?php
            if ($formtype != "" && (userPrivileges('' , '')['C'])) {
            	echo "<a href='$_URL_DOCUMENT_CRUD'><b>Create New</b> $form->formTitle</a>";
            }
        ?>
		<br><br>
		<div class="headline1"><?php echo $form->formTitle;?></div> 
		<br><br>
<!-- PAGE CONTENTS -->
		<?php include_once __DIR__ . '/html/docall_search.html';?>
		</article>
		</div>
	</div>
</div>
</div>
</div>

<!-- Footer Wrapper -->
<div id="footer-wrapper">
	<?php include_once $_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php";?>
</div>

</body>
</html>