/**
 * Check if jQuery is loaded
 */
if (!window.jQuery) {
  var jq = document.createElement('script');
  jq.type = 'text/javascript';
  jq.src = '/js/jquery-2.1.3.min.js';
  document.getElementsByTagName('head')[0].appendChild(jq);
}
/**
 * Declare LISTDOC Namespace if not exist
 */
var LISTDOC = LISTDOC || {};

$.extend(LISTDOC, {
  mUrl: 'api/server_api.php',
  mType: 'get',
  mData: '',
  mAsync: false,
  mReqType: '',
  queryData: '',
  queryParam: '',
  _searchParams: '',
  _URL_API: 'list-doc-ab_api.php',
  isEnableMultipleEditMode: false,

  foo: 'here for no reason other than to be the last line, without a comma'
});



LISTDOC.displayQueryData = function(jsonData){

  var pagination = jsClient.makePagination(jsonData)

  var data = JSON.parse(jsonData);
  var hasData = (data.noResult) ? 'no' : 'yes';
  var listTable = LISTDOC.makeTable(jsonData, hasData);

  $("#listCntrDiv").html(pagination);
  $("#listCntrDiv").append(listTable);

  LISTDOC.initSearchAction();
  LISTDOC.getHeaderData();

  /**
   * Css
   */
  $('#listTable').css({
    'width':'100%'
  });
  $('#listTable tr#searchForm button').css({
    'padding':'2px',
    'border':'1px solid #7F7F7F',
    'border-radius':'3px',
    'vertical-align': 'middle'
  });  
  $('#listTable .hasCustomSearch').css({
    'width':'70%'
  });
  jsClient.paginationCSS();
  LISTDOC.applyCustomListCSS();
  LISTDOC.changeTempleteCSS();

  // --- Fix table header during on scroll
  $("#listTable").fixMe();

}





//Add Customization Below
LISTDOC.makeTable = function(jsonData,hasData) {

  var data   = JSON.parse(jsonData);
  var mydata = data['listData'];
  var pageNum      = parseInt(data['pageNum']-1);
  var showLimit    = parseInt(data['showLimit']);
  var trDataId = parseInt(pageNum * showLimit) + 1;
  // console.log(pageNum + '  ' +showLimit);


  //for composition column
  LISTDOC.compositeColumns = {
    // docnumber:{
    //   docnumber: {
    //     style: 'font-weight:bold; color:blue',
    //     customsearch: true,
    //     single: true,
    //     end: true
    //   }
    // },
    // linenumber:{
    //   linenumber:{
    //     style: 'font-weight:bold; color:green',
    //     single: false,
    //     end: true        
    //   }
    // },

    // documentinformation : {
    //   linestatus:{
    //     style: 'font-weight:bold; color:green',
    //     customsearch: true,
    //     islibrary: true,
    //     datasource: {
    //       0: 'Entered',
    //       1: 'Running',
    //       2: 'Closed'
    //     },        
    //     fielddesc: 'Line Status',
    //     showsearchimg: true,
    //   },
    //   company:{
    //     style: 'font-weight:bold; color:green',
    //     islibrary: true,
    //     sql: "SELECT Code AS code, Description AS description FROM mrd_library WHERE LibraryName='company'", 
    //     customsearch: true,
    //     fielddesc: 'Company',
    //   },
    //   docdate:{
    //     fielddesc: 'Doc Date',
    //     customsearch: true,
    //     fielddesc: 'Document date',
    //     type: 'date',
    //     showsearchimg: true,
    //     end: true        
    //   }
    // },
    // formtype: {
    //   formtype:{
    //     single: true,
    //     end: true        
    //   }
    // },
    // itemspecification: {
    //   itemtype:{
    //     fielddesc: 'Item Type',
    //     style: 'font-weight:bold; color:green',
    //     islibrary: true,
    //     sql: "SELECT Code AS code, Description AS description FROM mrd_library WHERE LibraryName='itemtype_textile'",        
    //     customsearch: true,
    //     single: false
    //   },
    //   docstatus:{
    //     fielddesc: 'Doc Status',
    //     customsearch: true,
    //     single: false,
    //     end: true        
    //   }
    // },    

  }

  // some trickery for nice formatting
  var hideColumns = ['idlines', 'entrypersonbadge', 'company', 'ldcslnumber', 'endcustomer', 'buyername', 'subdoclinenumber', 'ReadyForBooking', 'BookingApproval', 'docnumber', 'linestatus', 'formtype', 'docstatus', 'lineentrytime', 'doctype','workorderdocnumber', 'docdate'];

  var translationsHardCode = {};
  translationsHardCode.docnumber                    = 'Accessories BOM Doc No.';
  translationsHardCode.doclinenumber                = 'BOM Line No.';
  translationsHardCode.doctype                      = 'Doc Type';
  translationsHardCode.formtype                     = 'Form Type';
  translationsHardCode.docstatus                    = 'Document Status';
  translationsHardCode.linenumber                   = 'Line Number';
  translationsHardCode.entrypersonbadge             = 'Entry person badge';
  translationsHardCode.lineentrytime                = 'Line entry time';
  
  // translationsHardCode.iduom                        = 'UoM';
  translationsHardCode.NominatedSupplier            = 'Nominated Supplier';
  translationsHardCode.Consumption                  = 'Consumption Per Dozen';
  translationsHardCode.UOM                          = 'UOM';
  translationsHardCode.ldcslnumber                  = 'SO Item Line No.';
  translationsHardCode.ProcessLoss                  = 'Process Loss (%)';
  translationsHardCode.Size                         = 'Garment Size';
  translationsHardCode.Color                        = 'Item Color';
  translationsHardCode.itemdescription              = 'Item Description';
  translationsHardCode.ConsumptionEntryTime         = 'Consumption Entry Time';
  translationsHardCode.GarmentQty_Dzn               = 'Garment Qty (Dzn)';
  translationsHardCode.GarmentQtyEntryTime          = 'Garment Qty Entry Time';
  translationsHardCode.GarmentQtyChangeRate         = 'Garment Qty Change Rate';
  translationsHardCode.ReqQty                       = 'Garment Quantity in Pcs';
  translationsHardCode.ReadyForBooking              = 'Ready For Booking';
  translationsHardCode.RFB_Time                     = 'RFB_Time';
  translationsHardCode.BookingApproval              = 'Booking Approval';
  translationsHardCode.BATime                       = 'BA Time';
  translationsHardCode.MaterialRemarks              = 'Material Remarks';
  translationsHardCode.RowTester                    = 'Row Tester';
  translationsHardCode.ExpectedInHouseDate          = 'Expected InHouse Date';
  translationsHardCode.ExpectedInHouseChangeRate    = 'Expected InHouse Change Rate';
  translationsHardCode.FinalConsumption             = 'Final Consumption';
  translationsHardCode.FinalProcessLoss             = 'Final Process Loss';
  translationsHardCode.FinalGarmentQty_Dzn          = 'Final Garment Qty (Dzn)';
  translationsHardCode.FinalExpectedInHouseDate     = 'Final Expected InHouse Date';
  translationsHardCode.FinalReqQty                  = 'Total Required Qty';
  
  translationsHardCode.countername                  = 'Counter Name';
  translationsHardCode.idcounter                    = 'ID Counter';
  translationsHardCode.buyername                    = 'End Customer';
  translationsHardCode.company                      = 'Division';
  translationsHardCode.note                         = 'Note';
  translationsHardCode.TraceID                      = 'Trace ID';
  translationsHardCode.ItemName                     = 'Item Name';
  translationsHardCode.GarmentDesignOrColor         = 'Garment Design Or Color';
  translationsHardCode.ProcessLevel                 = 'Process Level';
  translationsHardCode.subdoclinenumber             = 'SO Delivery Line No.';
  translationsHardCode.docdate                      = 'Doc Date';
  translationsHardCode.elementuom                   = 'Elem. UoM';
  translationsHardCode.documentinformation          = 'Document Information';
  translationsHardCode.itemspecification            = 'Item Specification';
  translationsHardCode.linestatus__company__docdate = 'Document Information';

  LISTDOC.translationsHardCode = translationsHardCode;


  /**
   * builds the table header
   */
  var orgBgOn = '';
  var mydata_json = JSON.stringify(mydata);
  var firstRow = mydata[0];

  var firstRowCopy = firstRow;
  var compositeColumnsLength = Object.keys(LISTDOC.compositeColumns).length;
  var countVisibleColumn = 1; // here start from 1 cz first td for option


  var $table = $('<table border=1 id="listTable" class="listTable" />');
  var $thead = $('<thead />');
  var $tbody = $('<tbody/>');
  /**
  * first header row------------------------------------------------------------------------------------------------------------------------------------------------------------
  */
  // var $tr = LISTDOC.generateFirstHeaderTr(firstRowCopy, translationsHardCode);
  var $tr = $("<tr/>");
  // $td = $('<th/>');
  // $td.html('');
  // $td.appendTo($tr);

    $.each(firstRowCopy, function (fieldname, fieldvalue) {
    // for (var fieldname in firstRowCopy) {
      // var fieldvalue = firstRowCopy[fieldname];
      
      // search this field is in composite column
      // and assume that its not under in composite colums
      var groupName = '';
      var groupFields = {};
      var hasInCompositeColumn = false;
      if(compositeColumnsLength > 0){
        for (var groupName in LISTDOC.compositeColumns) {
          groupFields = LISTDOC.compositeColumns[groupName];
          for (var thisfieldname in groupFields) {
            if(thisfieldname == fieldname){
              hasInCompositeColumn = true;
              break;
            }
          }
          if(hasInCompositeColumn) break;
        }
      }

      
      if (hasInCompositeColumn) {   // if have then procceed composite column
      // hide first
      $.each(groupFields, function(fieldname, fieldStyle){
        var fielddesc = fieldname;
        $td = $('<th/>');
        if (!!translationsHardCode[fieldname]) fielddesc = translationsHardCode[fieldname];
        $td.html('<center>'+ fielddesc +'</center>');
        $td.css('display','none');
        $td.appendTo($tr);

        delete firstRowCopy[fieldname]; // its already procceed
      });

      $td = $('<th/>');
      $td.attr('class', groupName);
      if (!!translationsHardCode[groupName]) groupName = translationsHardCode[groupName];
      $td.html('<center>'+ groupName +'</center>');
      $td.appendTo($tr);
      countVisibleColumn++;

      } else {            //procceed normal column

      countVisibleColumn++;
      var fielddesc = fieldname;
      $td = $('<th/>');
      if (!!translationsHardCode[fieldname]) fielddesc = translationsHardCode[fieldname];
      $td.html('<center>'+ fielddesc +'</center>');
      if ( hideColumns.indexOf(fieldname) >= 0 ){ $td.css('display','none'); countVisibleColumn--};
      $td.appendTo($tr);

      }

    // }  
    });
  $tr.appendTo($thead);
  $thead.appendTo($table);
  // end -----------------------------------------------------------------------------------------------------------------


  /**
  * second header row-----------------------------------------------------------------------------------------------------------------------------------------------------------
  */
  var $tr = $("<tr/>").attr("id","searchForm");
  var $td;
  // $td = $('<td/>');
  // $td.html('<center>Option</center>');
  // $td.appendTo($tr);

  var firstRowCopy = JSON.parse(mydata_json)[0];
    $.each(firstRowCopy, function (fieldname, fieldvalue) {
    // for (var fieldname in firstRowCopy) {
      // var fieldvalue = firstRowCopy[fieldname];
      
      // search this field is in composite column
      // and assume that its not under in composite colums
      var groupName = '';
      var groupFields = {};
      var hasInCompositeColumn = false;
      if(compositeColumnsLength > 0){
        for (var groupName in LISTDOC.compositeColumns) {
          groupFields = LISTDOC.compositeColumns[groupName];
          for (var thisfieldname in groupFields) {
            if(thisfieldname == fieldname){
              hasInCompositeColumn = true;
              break;
            }
          }
          if(hasInCompositeColumn) break;
        }
      }


      if (hasInCompositeColumn) {   // if have then procceed composite column
      var compositeClass = '';
      $td = $('<td/>');
      $td.attr('class', groupName);
      $.each(groupFields, function(fieldname, fieldpropties){

        compositeClass +=  ( !!fieldpropties.end) ? fieldname : fieldname + '__';          
        var customsearch_option = ( !!fieldpropties.showsearchimg) ?'<button type="button" onclick="LISTDOC.handleCustomSearch(this);"><img src="img/search_icon.png" alt="" height="15" width="15"></button>': '';
        var customsearch_click  = ( !!fieldpropties.customsearch) ?'onclick="LISTDOC.handleCustomSearch(this);"': 'onclick="LISTDOC.handleThisSearchInputFieldClick(this);"';
        var customsearch_class  = ( !!fieldpropties.customsearch ) ? '  hasCustomSearch' : '';

        var html = '<center><input type="text" name="'+ compositeClass +'" value="" id="'+compositeClass+'" class="'+compositeClass + customsearch_class +'" '+ customsearch_click +' />'+ customsearch_option +'</center><div id="'+compositeClass+'_displaySearchParams" style="background-color:white;"></div>';
        $td.html(html);

        delete firstRowCopy[fieldname]; // its already procceed
        if(!!fieldpropties.single && fieldpropties.single == true) return; // need to make one td in list
        $td_hide = $('<td/>');
        $td_hide.html('<center><input type="hidden" class="'+ fieldname +'" value="" id="'+fieldname+'" /></center>');
        $td_hide.css('display','none');
        $td_hide.appendTo($tr);

      });
      $td.appendTo($tr);    

      } else {

      var fielddesc = fieldname;
      $td = $('<td/>');
      $td.attr('class', fieldname);
      $td.html('<center><input type="text"  name="'+ fieldname +'" class="'+ fieldname +'" value="" id="'+fieldname+'" onclick="LISTDOC.handleThisSearchInputFieldClick(this);" /></center><div id="'+fieldname+'_displaySearchParams" style="background-color:white;"></div>');
      if ( hideColumns.indexOf(fieldname) >= 0 ) $td.css('display','none');
      $td.appendTo($tr);

      }

    // }  
    });

  $tr.appendTo($thead);
  $thead.appendTo($table);
  /**
  * second header row end -----------------------------------------------------------------------------------------------------------------------------------------------------------
  */


  if(hasData == 'no'){
    $thead.appendTo($table);
    //custom for no record found
    var $tr = $("<tr/>");
    var $td = $('<td/>').attr("colspan",countVisibleColumn);
    $td.html('No Data Found')
    .css({'text-align':'center','vertical-align':'middle'});
    $td.appendTo($tr);
    $tr.appendTo($table);
    return $table;
  }


  /**
  * populates with data--------------------------------------------------------------------------------------------------------------------------------------------------
  */
  var mydata = JSON.parse(mydata_json);
  $.each(mydata, function (index, value) {

    var $tr = $("<tr/>"); // it should be in here
    $tr.attr("data-id",trDataId);
    trDataId++;

    var thisRow = value;
    var thisRowCopy = thisRow;
    var thisRowCopy_Json =  JSON.stringify(thisRow);

    // retrive variable here which is needed
    var formtype = thisRow['formtype'];
    var linestatus = thisRow['linestatus'];

    // generate button if needed
    var btnLineChooser = '<center><input type="checkbox" class="multipleLineChooser" onclick="LISTDOC.handleLineChooserCheckboxClick(this);" ></center>';
    var btnThisLineAction = '';
    if(linestatus == 'Requisition Sent'){
      btnThisLineAction = '<button type="button" class="mbutton delete" onclick="LISTDOC.handleLineEvolutionBtnAction(this)">Cancel this line</button>';
    } else if(linestatus == 'Requisition Planned'){
      btnThisLineAction = '';
    }
    $td = $('<td/>');
    // $td.html(btnLineChooser);
    // $td.appendTo($tr);


      // looping over this row
      $.each(thisRow, function (fieldname, fieldvalue) {
      // for (var fieldname in firstRowCopy) {
        // var fieldvalue = firstRowCopy[fieldname];
        
        // search this field is in composite column
        // and assume that its not under in composite colums
        var groupName = '';
        var groupFields = {};
        var hasInCompositeColumn = false;
        if(compositeColumnsLength > 0){
          for (var groupName in LISTDOC.compositeColumns) {
            groupFields = LISTDOC.compositeColumns[groupName];
            for (var thisfieldname in groupFields) {
              if(thisfieldname == fieldname){
                hasInCompositeColumn = true;
                break;
              }
            }
            if(hasInCompositeColumn) break;
          }
        }

        
        if (hasInCompositeColumn) {     // if have then procceed composite column

        $td = $('<td/>');
        $td.attr('class', groupName);
        $td.attr('fieldname', groupName);
        var compositeColumnsHTML = '';
        var divRow = '';
        $.each(groupFields, function(fieldname, fieldpropties){

          var fieldvalue = thisRow[fieldname];
          var fielddesc = (!!fieldpropties.fielddesc) ? fieldpropties.fielddesc : fieldname;
          var style = ( !!fieldpropties.style ) ? 'style="' + fieldpropties.style + '"': '';

          // *** write custom code here ---

          var obj_thisRowCopy_Json =  JSON.parse(thisRowCopy_Json);
          fieldvalue = (fieldname == "docnumber") ? "<a href='erpdocument.php?docnumber="+fieldvalue+"&doctype=T7&formtype="+formtype+"' target='_blank''>"+fieldvalue+"</a>" : fieldvalue;

          // *** custom code end ----------

          divRow += '<div class="crow" '+ '' +'>';
          if( (!!!fieldpropties.single) || (!!fieldpropties.single && fieldpropties.single == false) ){
            divRow += '<div class="ccell1 '+ fieldname +'" '+ style +'>'+ fielddesc +'</div>';
            divRow += '<div class="ccell2 '+ fieldname +'">:</div>';
          }
          divRow += '<div class="ccell3 '+ fieldname +'_ccell3" '+ style +'>'+ fieldvalue +'</div>';
          divRow += "</div>";

          delete thisRowCopy[fieldname]; // its already procceed
          if(!!fieldpropties.single && fieldpropties.single == true) return; // need to make one td in list
          $td_hide = $('<td/>');
          $td_hide.html(fieldvalue);
          $td_hide.attr("fieldname",fieldname);
          $td_hide.css('display','none');
          $td_hide.appendTo($tr);

        });

        var divTable = "<div id='ctable'>"; 
        divTable += divRow;  
        divTable += "</div>"; 

        compositeColumnsHTML = divTable;
        $td.html(compositeColumnsHTML)
        .css("cursor","pointer")
        .hover(
          function(){bgOn = $(this).closest("tr").css("background-color"); $(this).closest("tr").css("background-color", "lightblue");},
          function(){$(this).closest("tr").css("background-color", bgOn);}
        );
        $td.appendTo($tr);


        } else {

        // *** write custom code here ---
        fieldvalue = (fieldname == "docnumber") ? "<a href='erpdocument.php?docnumber="+fieldvalue+"&doctype=DR&formtype="+formtype+"&docviewflag=apparel' target='_blank''>"+fieldvalue+"</a>" : fieldvalue;
        // *** custom code end ----------

        $td = $('<td/>');
        $td.html(fieldvalue)
        .css("white-space","pre-wrap")
        .attr("fieldname",fieldname)
        .css("cursor","pointer")
        .hover(
          function(){bgOn = $(this).closest("tr").css("background-color"); $(this).closest("tr").css("background-color", "lightblue");},
          function(){$(this).closest("tr").css("background-color", bgOn);}
        );
        if ( hideColumns.indexOf(fieldname) >= 0 ) $td.css('display','none');
        $td.appendTo($tr);

        }

      // }  
      });

    // *** custom code start-----------------------------------------------------------------------------------------
    // $tr.find('td.requiredinformation').append(btnThisLineAction);
    // *** custom code end-------------------------------------------------------------------------------------------

      $tr.click( function(e) { 
          // var cell = $(e.target).get(0); // This is the TD you clicked
          var typex = $(e.target).attr('type'); 
          if(typex == 'checkbox') return;
          
          if(orgBgOn != '') $('#listTable tbody tr.clicked').css("background-color", orgBgOn);
          $('#listTable tbody tr').removeClass('clicked');
          orgBgOn = bgOn;
          $(this).closest("tr").css("background-color", "yellow");
          bgOn = $(this).closest("tr").css("background-color")
          $(this).closest("tr").addClass('clicked');

          // LISTDOC.sendBackSearchChoice($(this));
          var docnumber = $(this).find('[fieldname=docnumber]').text();

          if(LISTDOC.isEnableMultipleEditMode == false){
            LIZERP.readThisDoc_N_FillInForm(docnumber);
          }

          var doclinenumber = $(this).find('[fieldname=doclinenumber]').text();
          LIZERP.doclinenumber = doclinenumber;
        })
        .appendTo($tbody);
    });

    $thead.appendTo($table)
    $tbody.appendTo($table)

    return $table;
};




LISTDOC.closeSalesOrder = function(){
  var windowWidth = window.innerWidth;
  var windowHeight = window.innerHeight;

  var seventiPersenWidth = ( (windowWidth * 70)/100 ) - 80;
  var thirtyPersenWidth = (windowWidth * 30)/100;

  var ofst = $("#listTable tr:first").find("th:first").offset();
  var Xleft = (ofst.left + thirtyPersenWidth);
  var Ytop = ofst.top;

  console.log('calculation: total width-' + windowWidth + ' seventiPersenWidth-' + seventiPersenWidth + ' thirtyPersenWidth' + thirtyPersenWidth);  
  console.log('Xleft' + Xleft);

  $('#listCntrDiv').css({
    'display':'block',
    'floal': 'left',
    'width': thirtyPersenWidth + 'px',
    'max-width': thirtyPersenWidth + 'px',
  });

  $('#formDiv').css({
    'display':'block',
    'floal': 'left',
    'left': Xleft,
    'top': Ytop,
    'width': seventiPersenWidth + 'px',
    'min-width': seventiPersenWidth + 'px',
  });
}








LISTDOC.getHeaderData = function() {
  var params = paramsToObj(window.location.search);
  if( !!!params.ldcslnumber ) return;

  var searchParams = {
    'reqType': 'readDoc'
  };
  searchParams['ldcslnumber'] = params.ldcslnumber;

  $.get('/erp-apparel/list-doc-ab_api.php', searchParams, getHeaderData_results(searchParams), 'json')

  function getHeaderData_results(extraParams) {
    return function(data, textStatus, jqXHR) {
      mydata = data;

      var hideColumns = ['iddocument', 'destination'];
      var translationsHardCode = {};
      translationsHardCode.entitynumber      = 'BOM No.';
      translationsHardCode.docdate           = 'BOM Date';
      translationsHardCode.docnumber         = 'Sales Order No.';
      translationsHardCode.formtype          = 'Sales Order Type';
      translationsHardCode.company           = 'Division';
      translationsHardCode.endcustomer       = 'End Customer';
      translationsHardCode.buyerpo           = 'End Customer PO No.';
      translationsHardCode.style             = 'Style No.';
      translationsHardCode.styledescription  = 'Style Description';
      translationsHardCode.productcategory   = 'Product Category';
      translationsHardCode.pieceqty          = 'Order Qty Piece';
      translationsHardCode.ldcslnumber       = 'Sales Order Item Line No.';
      translationsHardCode.parentldcslnumber = 'Projection Item Line No.';


      var $table = $('<table border=1 class="no_border" />');
      $.each(mydata, function(key, val){
        // take new tr
        var $tr = $("<tr/>");

        // process th
        $th = $('<th style="border-color:grey;"/>');
        $th.html(key)
          .css("white-space", "pre")
          .attr("fieldname", key)
          .css("cursor", "pointer")
          .hover(function() {
              $(this).closest("tr").css("background-color", "lightblue");
            },
            function() {
              $(this).closest("tr").css("background-color", "transparent");
            }
          );
        if (!!translationsHardCode[key]) $th.html(translationsHardCode[key]); // substitutes the header with hard-coded descriptions          
        if (hideColumns.indexOf(key) >= 0) $th.css('display', 'none');
        $th.appendTo($tr);

        // process td
        $td = $('<td style="border-color:grey;"/>');
        $td.html(':')
          .css("white-space", "pre")
          .css("cursor", "pointer")
          .hover(function() {
              $(this).closest("tr").css("background-color", "lightblue");
            },
            function() {
              $(this).closest("tr").css("background-color", "transparent");
            }
          );
        if (hideColumns.indexOf(key) >= 0) $td.css('display', 'none');
        $td.appendTo($tr);

        // process td
        $td = $('<td style="border-color:grey;"/>');
        $td.html(val)
          .css("white-space", "pre")
          .attr("fieldname", key)
          .css("cursor", "pointer")
          .hover(function() {
              $(this).closest("tr").css("background-color", "lightblue");
            },
            function() {
              $(this).closest("tr").css("background-color", "transparent");
            }
          );
        if (hideColumns.indexOf(key) >= 0) $td.css('display', 'none');
        $td.appendTo($tr);


        $tr.click(function() {
          var docnumber = $(this).find('[fieldname=docnumber]').text();
        }).appendTo($table);

      });

      $table.css('margin-bottom', '10pt')

      var fieldset = '<fieldset style="border: 1px solid #B7B7B7; border-radius:5px; margin-bottom:10px; padding-left: 5px;"><legend style="border: 1px solid #B7B7B7; padding: 5px; border-radius:5px; font-weight: bold; padding: 5px; margin: 15px; color:black;">Header Information</legend></fieldset>';
      $('#docHeaderContainer').empty().append(fieldset);
      $('#docHeaderContainer fieldset').append($table);

    }

  }

}





LISTDOC.enableMultipleEdit = function(){

  if (!$('.btnMultipleEdit').hasClass('btn-orange')) {
    LISTDOC.isEnableMultipleEditMode = true;
    $('.btnMultipleEdit').removeClass('btn-grey');
    $('.btnMultipleEdit').addClass('btn-orange');
    $('.btnMultipleEdit').val('Save Multiple Line'); 

  } else {
    LISTDOC.isEnableMultipleEditMode = false;
    $('.btnMultipleEdit').removeClass('btn-orange');
    $('.btnMultipleEdit').addClass('btn-grey');
    $('.btnMultipleEdit').val('Edit Multiple Line'); 
  }


  // Source
  // https://stackoverflow.com/questions/6012823/how-to-make-html-table-cell-editable
  // http://ssiddique.info/jquery-and-editable-html-table.html

  // All fields will be editables
  // if needs any custom then need to add here
  LISTDOC.editableFields  = {
    dbSetKeyFieldName:'docnumber', 
    dbSetTableName:'tnx_bom_accessory', 

    doclinenumber:{
      doclinenumber:{
        editable:'no',
      }
    },
    // Consumption:{
    //   Consumption:{
    //     editable:'no',
    //   }
    // },
    // ProcessLoss:{
    //   ProcessLoss:{
    //     editable:'no',
    //   }
    // },
    // ReqQty:{
    //   ReqQty:{
    //     editable:'no',
    //   }
    // },    
    FinalReqQty:{
      FinalReqQty:{
        editable:'no',
      }
    },

    // UOM : {
    //   UOM:{
    //     islibrary: true,
    //     sql: "SELECT Code AS code, Description AS description FROM mrd_library WHERE LibraryName='UOM'", 
    //   }
    // },
  }


  function setDataInDB( setData, blurTd ){

    var data = JSON.stringify(setData);

      $.ajax({
        async :   true,
        type  :   'post',
        url   :   LISTDOC._URL_API,
        data  :   {reqType: 'setDataInDB', data:data},
        success :   function(data){
        	// alert(data);
        	data = JSON.parse(data);
        	var updateVal = data['FinalReqQty'];

        	$(blurTd).closest('tr').find('td[fieldname=FinalReqQty]').html(updateVal);
        	if(updateVal != ""){
        		// LISTDOC.getListData(50,   1,    '');
        	}
        },
        error :   function(){
            alert("error");
            return;
        }
      });

    return;

  }


  $("#listTable tbody tr td").click(function () {

    if(!LISTDOC.isEnableMultipleEditMode) return;
    var fieldname = $(this).attr('fieldname');
    if( !!LISTDOC.editableFields[fieldname] ){
      if( !!LISTDOC.editableFields[fieldname][fieldname] ){
        if( LISTDOC.editableFields[fieldname][fieldname]['editable'] == 'no' ) return;
      } 
    }
    
    var dbSetTableName = LISTDOC.editableFields['dbSetTableName'];
    var dbSetKeyFieldName = LISTDOC.editableFields['dbSetKeyFieldName'];
    var dbSetKeyFieldValue = $(this).closest('tr').find('td[fieldname='+ dbSetKeyFieldName +'] a').text();

    var setFieldName = fieldname;
    var setFieldValue = $(this).text();


      if($(this).children("input").length > 0) return false;
    var tdObj = $(this);

    // var preText = tdObj.html();
    var preText = tdObj.text();
        var inputObj = $('<input type="text" name="'+fieldname+'" value="" />');
      // $(this).append('<span style="display:none;">'+ OriginalContent +'</span>');

        tdObj.html("");
        inputObj.width(tdObj.width())
                .height(tdObj.height())
                .css({border:"0px",fontSize:"17px"})
                .css({minWidth:"120px"})
                .val(preText)
                .appendTo(tdObj)
                .trigger("focus");
                // .trigger("select");


         inputObj.keyup(function(event){
            if(13 == event.which) { // press ENTER-key
                var text = $(this).val();
                tdObj.html(text);

                var blurTd = tdObj;

                var fullContent = $(this).val(); 
                $(this).parent().html(fullContent); 
                $(this).parent().removeClass("cellEditing");

                var setFieldName = fieldname;
                var setFieldValue = $(this).val();
                var setData = {
                setFieldName: setFieldName,
                setFieldValue: setFieldValue,
                dbSetKeyFieldName: dbSetKeyFieldName,
                dbSetKeyFieldValue: dbSetKeyFieldValue,
                dbSetTableName: dbSetTableName,
                }
                setDataInDB( setData , blurTd);



            }
            else if(27 == event.which) {  // press ESC-key
                tdObj.html(preText);
            }
        });

        inputObj.click(function(){
          return false;
        });


      $(this).children().first().blur(function(){      
        var blurTd = $(this).parent().parent();

        var fullContent = $(this).val(); 
        $(this).parent().html(fullContent); 
        $(this).parent().removeClass("cellEditing");

      var setFieldName = fieldname;
      var setFieldValue = $(this).val();
      var setData = {
        setFieldName: setFieldName,
        setFieldValue: setFieldValue,
        dbSetKeyFieldName: dbSetKeyFieldName,
        dbSetKeyFieldValue: dbSetKeyFieldValue,
        dbSetTableName: dbSetTableName,
      }
        setDataInDB( setData , blurTd);

      });

  });


}



