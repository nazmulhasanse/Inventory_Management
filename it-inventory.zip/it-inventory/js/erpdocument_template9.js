/**
 * Check if jQuery is loaded
 */
if (!window.jQuery) {
  var jq = document.createElement('script');
  jq.type = 'text/javascript';
  jq.src = '/js/jquery-2.1.3.min.js';
  document.getElementsByTagName('head')[0].appendChild(jq);
}

/**
 * Declare the namespace LIZERP if not existent
 */
var LIZERP = LIZERP || {};

$.extend(LIZERP, {
  formId: '',
  formMode: '',
  dbAuxData: [], // extra data submitted by the API that are not fields of the DB

  companyHTML: '<option value="">Select</option>',
  docstatusHTML: '<option value="">Select</option>',
  iduomHTML: '<option value="">Select</option>',
  itemSearchFormHTML: '',
  inventorySearchFormHTML: '',
  inventorySearchFormJS: '',
  lineHTML_template: '',

  formFieldSettings: '',

  // line gets dirty if user changes any field after the line is added or made editable
  lineIsDirty: false,
  valAtFocus: '',

  populateCache: [],

  _URL_DOCUMENTAPI: {
    DOCTYPE1:  '',
    DOCTYPE2:  '/code-framework/form-framework1/doctype2_api.php',
    foo: ''
  },
  _URL_DOCDEFINEAPI: {
    DOCTYPE1: '',
    DOCTYPE2: '/code-framework/form-framework1/erpdocument_define.php?doctype=DOCTYPE2',
    foo: ''
  },
  _URL_LOGIN: '/user/index.php',
  _URL_LIBRARYAPI: 'mrd_library_api.php',

  _FIELDS_CREATEONLY: []
});

//******************************************* FIELD HANDLING

/**
 * Populate dropdowns
 * This adds to whatever options are already available, allowing for a blank initial option
 * To clear the options prior, use $('select').empty();
 * TO-DO: add extra options: run select2, auto-adjust width of SELECT
 */
LIZERP.populateDropdown = function(field, library, defaultval, options) {
  var populateParams = {
    'library': library,
    'field': field
  };
  if (!!defaultval && defaultval != null) {
    populateParams.defaultval = defaultval;
  }
  if (!!options && options.indexOf('showkeys') != -1) {
    populateParams.showkeys = true;
  }
  if (!!options && options.indexOf('codevalequal') != -1) {
    populateParams.codevalequal = true;
  }

  if (field == 'productionfloor') {
    var searchParams = {
      'library': library,
      'field': field
    };
    if ($('#company').val().trim().length > 0) {
      searchParams.company = $('#company').val();
    }
    $('#productionfloor').empty().append('<option value="">Select</option>');
    return $.get(LIZERP._URL_LIBRARYAPI, searchParams, populateDropdown_populate(populateParams), 'json');
  }

  // if (!!LIZERP.populateCache[library]) {
  //   populateDropdown_populate(populateParams)(LIZERP.populateCache[library]);
  //   // returns a resolved promise to signify that there's no pending ajax.
  //   return $.Deferred().resolve().promise();
  // } else {
    var searchParams = {
      'library': library,
      'field': field
    };
    return $.get(LIZERP._URL_LIBRARYAPI, searchParams, populateDropdown_populate(populateParams), 'json');
  // }

  function populateDropdown_populate(extraParams) {
    var showkeys = extraParams.showkeys;
    var codevalequal = extraParams.codevalequal;
    return function(data, textStatus, jqXHR) {
      LIZERP.populateCache[extraParams.library] = data;
      var setasdefault = false;
      $('#' + extraParams.field).empty().append('<option value="">Select</option>');
      $.each(data, function(index, value) {
        setasdefault = (!!extraParams.defaultval && (value == extraParams.defaultval || index == extraParams.defaultval));
        if (!!showkeys && showkeys === true && index != value) {
          $('#' + extraParams.field)
            .append($("<option></option>")
              .attr("value", index)
              .text(index + ' - ' + value)
              .prop('selected', setasdefault)
            );
        } else if (!!codevalequal && codevalequal === true) {
          $('#' + extraParams.field)
            .append($("<option></option>")
              .attr("value", value)
              .text(value)
              .prop('selected', setasdefault)
            );
        } else {
          $('#' + extraParams.field)
            .append($("<option></option>")
              .attr("value", index)
              .text(value)
              .prop('selected', setasdefault)
            );
        }
      });
      return;
    }
  }
}

LIZERP.searchLoupe_show = function(inputfield) {
  var imgheight = 16;
  var imgwidth = 16;
  var fieldName = $(inputfield).closest('td').attr('class');
  aleft = $(inputfield).offset().left + $(inputfield).width() - imgwidth + 2;
  atop = $(inputfield).offset().top + 3;
  $('<div/>')
    .offset({
      top: atop,
      left: aleft
    })
    .css('display', 'block')
    .css('position', 'absolute')
    .css('background-repeat', 'no-repeat')
    .css('background-image', 'url(./img/search.png)')
    .attr('fieldname', fieldName)
    .addClass('itemsearchLoupe')
    .height($(inputfield).outerHeight() - 2)
    .width($(inputfield).outerHeight() - 2)
    .appendTo($('body'))
    .hover(function(e) {}, function(e) {
      $('.itemsearchLoupe').remove();
    })
    .on('click', function() {
      LIZERP.handleSearchForm($(this).attr('fieldname'));
    });
}

LIZERP.searchLoupe_hide = function() {
  $('.itemsearchLoupe').remove();
}

/**
 * Bind datepicker with an input field
 * @param selector
 */
LIZERP.bindDatepicker = function(selector) {
  $(selector).datepicker({
    dateFormat: 'yy-mm-dd',
    changeMonth: true,
    changeYear: true,
    constrainInput: true,
    onClose: function(dateText, inst) {
      /* Validate date input; erase data if invalid */
      if (isDate(dateText, false) == false) {
        $(this).val('');
      }
    }
  });
}

/**
 * Bind datetimepicker with an input field
 * @param selector
 */
LIZERP.bindDatetimepicker = function(selector) {
  $(selector).datetimepicker({
    dateFormat: 'yy-mm-dd',
    changeMonth: true,
    changeYear: true,
    constrainInput: true,
    onClose: function(dateText, inst) {
      /* Validate date input; erase data if invalid */
      if (isDate(dateText, true) == false) {
        $(this).val('');
      }
    }
  });
}

/**
 * Handle docdate field. Current browser date is auto populated.
 */
LIZERP.handle_docdate_field = function() {
  /* Show current date in docdate field */
  var today = new Date();
  var dd = today.getDate();
  var mm = today.getMonth() + 1;
  /* January is 0! */
  var yyyy = today.getFullYear();

  dd = dd < 10 ? ('0' + dd) : dd;
  mm = mm < 10 ? ('0' + mm) : mm;

  $(LIZERP.formId + ' #docdate').val(yyyy + '-' + mm + '-' + dd);

}

/**
 * Validate form fields
 * @param container
 * @returns {boolean}
 */
LIZERP.validateFormContainerFields = function(container) {
  var error = false;
  $(container).find('input, select, textarea').each(function() {
    if (!!$(this).prop('required')) {
      if ($(this).val() == '') {
        error = true;
        LIZERP.hightlightErrorField($(this));
      }
    }
  });
  return error;
}

/**
 * Highlight error field for a certain period
 * @param field
 */
LIZERP.hightlightErrorField = function(field) {
  field.addClass('error');
  setTimeout(function() {
    field.removeClass('error');
  }, 3000);
}

/**
 * Show form error
 * @param msg
 */
LIZERP.showFormError = function(msg) {
  $(LIZERP.formId + ' #formError').html(msg).show();
  setTimeout(function() {
    $(LIZERP.formId + ' #formError').hide('slow').html('');
  }, 20000);
}

LIZERP.changeDocStatus = function(){
  var params = paramsToObj(window.location.search);
  if (!params.docnumber) {
    alert('Error: iddocument not available. Please tell ERP department.');
    return;
  }
  var searchParams = {};
  searchParams.docnumber = params.docnumber;
  searchParams.reqType = 'changeDocStatus';
  return $.post(LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM], searchParams, changeDocStatus_return(), 'json');

  function changeDocStatus_return(extraParams) {
    return function(data, textStatus, jqXHR) {
      if (data.result == 'success') {
        location.reload();
      } else {
        alert(data.errormsgs.join('\n'));
      }
    }
  }

}

//******************************************* LINE HANDLING

LIZERP.getLineBeingEdited = function(line) {

  console.log('getLineBeingEdited 1--->' + line);
  if(!!line){
    return $('#formLines table tbody tr[data-id="' + line + '"] input[type=text]').closest('tr');
  }
  // var line = $(LIZERP.formId + ' #formLines tbody tr').length > 0 ? (parseInt($(LIZERP.formId + ' #formLines tbody tr:last-child').attr('data-id'))) : 0;
  // return $('#formLines input[type=text]:visible').first().closest('tr');
  if(!LIZERP.newLineNumber){
   LIZERP.newLineNumber = 1;
  }
  console.log('getLineBeingEdited 2--- ' + LIZERP.newLineNumber);
  return $('#formLines table tbody tr[data-id="' + LIZERP.newLineNumber + '"] input[type=text]').closest('tr');

}

/**
 * Save a line
 */
LIZERP.saveLine = function(edit) {
  // edit = 1 if we're trying to save because we clicked on an edit button of another line
  var $tr2 = LIZERP.getLineBeingEdited();

  // if line is completely blank, ignore request
  var fieldsWithData = 0;
  $tr2.find('input,textarea,select').filter(':visible')
    .each(function(index, element) {
      if ($(element).attr('type') == "button") return;
      if ($(element).val().trim().length > 0) fieldsWithData++;
    });
  // if (fieldsWithData == 0) return; // @Mamun 2017-01-28


  var error = false;
  // before reading any values, make the values of the inputs actually uppercase and not only CSS transformed
  $tr2.find('input,textarea').each(function(i) {
    if ($(this).css('text-transform') == 'uppercase') $(this).val($(this).val().toUpperCase());
  });

  var fieldList = [];
  var requiredCols = [];
  $('#formLines #fieldset_lineinformation table tr th')
    .each(function(e) {
      if (!!$(this).attr('class')) fieldList.push($(this).attr('class'));
      if (!!$(this).attr('required')) requiredCols.push($(this).attr('class'));
    });
  // remove from array, this field is not user-entered
  fieldList.splice(fieldList.indexOf('idlines'), 1)
  fieldList.splice(fieldList.indexOf('linenumber'), 1)

  var $lineFields = {};
  for (key in fieldList) {
    $lineFields[fieldList[key]] = $tr2.find('.' + fieldList[key]).find('input,select,textarea');
  }

  // Check if any required fields are empty
  for (key in requiredCols) {
    $validatingField = $lineFields[requiredCols[key]];
    if ($validatingField.val() == '') {
      LIZERP.hightlightErrorField($validatingField);
      error = true;
    }
  }

  // if any blinking errors, stop
  if ($('.error').length > 0) error = true;

  if (!error) {

    var lineFormFieldSettings = LIZERP.formFieldSettings['lines'];

    for (key in fieldList) {
      if ($lineFields[fieldList[key]].prop('tagName') == 'SELECT') {
        var selectedvalue = $lineFields[fieldList[key]].find('option:selected').text();
        if (selectedvalue != 'Select') {
          $tr2.find('.' + fieldList[key]).find('span').text(selectedvalue);
        }
      } else if(fieldList[key] == 'linestatus'){
        $tr2.find('.' + fieldList[key]).find('span').text(LIZERP.formFieldSettings['linestatus'][$lineFields[fieldList[key]].val()]);
      } else {

        $tr2.find('.' + fieldList[key]).find('span').text($lineFields[fieldList[key]].val());

      } 
    }
    $tr2.find('textarea').parent().find('span').css('white-space', 'pre-wrap');

    $tr2.removeClass('editable new').addClass('valid');

    if (edit != 1) {
      LIZERP.addLine();
    }
  }
  if (edit == 1) {
    return error;
  }
}



/**
 * Edit a line
 * @param line
 */
LIZERP.editLine = function(line) {
  // try to save if currently on a dirty line
  if (LIZERP.lineIsDirty == true) $('#formLines input[type=text]:visible').closest('tr').find('.saveLine').first().click();
  // don't let user get out of a line if it has errors
  if ($('.error').length > 0) return;

  var error = false;

  if ($(LIZERP.formId + ' #formLines tr.editable.new').length > 0) {
    /* User wishes to edit a saved line and a new line exists and is editable. So remove the new line */
    $(LIZERP.formId + ' #formLines tr.new').remove();
  } else if ($(LIZERP.formId + ' #formLines tr.editable').length > 0) {
    // getting here means there's a line being edited and it's clean
    // User wishes to edit a saved line and new line doesn't exist; a saved line is now editable. So save the currently editable line first. 
    error = LIZERP.saveLine(1);
  }

  if (!error) {
    $(LIZERP.formId + ' #formLines tr[data-id="' + line + '"]').addClass('editable').removeClass('valid');
    $('#div_floatingButton').remove();
    LIZERP.initLine();
  }
}

/**
 * Remove a line
 * @param line
 */
LIZERP.removeLine = function(line) {
  if (confirm('Are you sure to delete line ' + line + '?')) {
    $(LIZERP.formId + ' #formLines tr[data-id="' + line + '"]').remove();
    // LIZERP.addLine();
  }
}

/**
 * Add a line
 */
LIZERP.addLine = function() {
  var line = $(LIZERP.formId + ' #formLines tbody tr').length > 0 ? (parseInt($(LIZERP.formId + ' #formLines tbody tr:last-child').attr('data-id'))) : 0;

  if (!!LIZERP.newLineNumber) {
    line = Math.max(line, LIZERP.newLineNumber);

  }
  line = line + 1;
  LIZERP.newLineNumber = line;
  LIZERP.currentLineNumber = line;
  console.log('Current line-- '+line)

  var lineHTML = LIZERP.lineHTML_template
    .replace('<select name="lines[1][iduom]" required="required">\n                            <option value="">Select</option>', '<select name="lines[' + line + '][iduom]" required="required">\n' + LIZERP.iduomHTML)
    .replace('class="editable"', 'class="editable new"')
    .replace('<span>1</span>', '<span>' + line + '</span>')
    .replace('value="1"', 'value="' + line + '"')
    .replace('data-id="1"', 'data-id="' + line + '"')
    .replace(/lines\[1\]/g, 'lines[' + line + ']');

  $(LIZERP.formId + ' #formLines #fieldset_lineinformation table tbody').append(lineHTML);
  LIZERP.initLine();

}

LIZERP.initLine = function() {
  $tr = LIZERP.getLineBeingEdited();
  var line = $('#formLines input[type=text]:visible').closest('tr').attr('data-id');

  // Bind auto-fills: if the value of the field has changed, send to the search function

  // Bind CTRL-Enter to save lines
  $tr.find('input,textarea,select')
    .keydown(function(e) {
      if (e.ctrlKey && e.keyCode == 13) {
        e.preventDefault();
        e.stopImmediatePropagation();
        LIZERP.saveLine();
      }
    });
    
  // Bind ENTER to move to next field
  $tr.find('input,textarea,select').keydown(bindEvent_EnterMovesFocus);

  // Move wh_description to a block under itemcode if there's no item description field
  if (!$tr.find('td.itemdescription').length) {
    var div_floatingWhDesc0 = $('<div class="div_floatingWhDesc0" style="float:left;position:absolute;">');
    var div_floatingWhDesc1 = $('<div class="div_floatingWhDesc1" style="float:left;position:absolute;top:2px;">');
    div_floatingWhDesc1.append('<pre style="font-family:monospace;"></pre>');
    div_floatingWhDesc1.appendTo(div_floatingWhDesc0);
    $tr.find('.div_floatingWhDesc0').remove();
    $tr.find('td.itemcode').append(div_floatingWhDesc0);
  }

  $tr.find('.saveLine')
    .on('click', function() {
      LIZERP.saveLine();
    });
  $tr.find('.editLine')
    .on('click', function() {
      LIZERP.editLine($(this).closest('tr').attr('data-id'));
    });
  $tr.find('.removeLine')
    .on('click', function() {
      LIZERP.removeLine($(this).closest('tr').attr('data-id'));
    });
  $tr.find('.printLine')
    .on('click', function() {
      LIZERP.printLine($(this).closest('tr').attr('data-id'));
    });


  // Enable dirty line detection
  LIZERP.lineIsDirty = false;
  $tr.find('input,textarea,select')
    .change(function() {
      LIZERP.lineIsDirty = true;
    });
}

//******************************************* FORM HANDLING

/**
 * Receives data from the API and populates the respective fields of the form
 * @param  {docobj} headerObj is the docobj from the API, minus the lines element
 * @param  {docboj.lines} linesObj is the lines element of docobj
 * @return {boolean}           true for success, false for failure
 */
LIZERP.fillForm = function(headerObj, linesObj) {
  // First, check if data is complete
  if (linesObj.length == 0) {
    return false;
  }

  // Complete the header fields
  for (var key in headerObj) {
    if (key.substr(0, 1) == "_") {
      LIZERP.dbAuxData[key.substr(1)] = headerObj[key]
      continue;
    }
    $('#' + key).filter('input,select,textarea').val(headerObj[key]);
    if(key == "docnumber"){$('span#span' + key).text(headerObj[key]);}
    else if(key == "docstatus"){$('span#span' + key).text(headerObj[key]);} 
    else {$('span#' + key).text(headerObj[key]);}

  }


  // Get a list of the TH columns marked as required
  var requiredCols = [];
  $('#formLines #fieldset_lineinformation table tr th[required=required]')
    .each(function(key, element) {
      requiredCols.push($(element).attr('class'));
    });
  // Complete the line fields
  for (var i = 0; i < linesObj.length; i++) {
    // Check if all required columns are present in the data from the DB, skip malformed lines
    for (var j = 0; j < requiredCols.length; j++) {
      if (!linesObj[i][requiredCols[j]] || linesObj[i][requiredCols[j]].trim().length == 0) {
        console.log('Skipping line ' + i + ' because ' + requiredCols[j] + ' is missing.');
        alert('A line has been lost because the data coming from the system is incomplete.');
        continue;
      }
    };

    // Build field list from the visible or hidden form
    var fieldList = [];
    $('#formLines #fieldset_lineinformation tr th').each(function(e) {
      if (!!$(this).attr('class')) fieldList.push($(this).attr('class'));
    });
    // Start copying data to the fields
    var $tr2 = LIZERP.getLineBeingEdited();


    for (var j = 0; j < fieldList.length; j++) {
      if (!!linesObj[i][fieldList[j]] && linesObj[i][fieldList[j]].length > 0) {
        // $tr2.find('td.' + fieldList[j]).find('input,textarea,select').first().val(linesObj[i][fieldList[j]]);
        $tr2.find('td.' + fieldList[j]).find('input,textarea,select').val(linesObj[i][fieldList[j]]);
      }
    }

    // Set the line number to match the DB
    var linenumber = linesObj[i]['linenumber'];
    $tr2.attr('data-id', linenumber);
    $tr2.find('td.linenumber span').text(linenumber);
    $tr2.find('input,select,textarea').each(function(e) {
      var currName = $(this).attr('name');
      if (!!currName) $(this).attr('name', currName.replace(/\[\d+\]/, "[" + linenumber + "]"));
    });
    // $tr2.find('input.saveLine:visible').first().click();
    LIZERP.saveLine();

  }
  return true;
}

/**
 * Handle form fields to show-hide/enable-disable/required/readonly etc.
 */
LIZERP.handleFormFields = function(crudmode) {
  // var searchParams = params;
  // searchParams.doctype = LIZERP._URL_DOCDEFINEAPI[LIZERP._ERP_DOCACRONYM]
  var params = paramsToObj(window.location.search);
  if (params.formtype === undefined) {
    params.formtype = 'default';
  }
  var searchParams = {
    'formtype': params.formtype,
    'crudmode': crudmode
  };
  // alert(JSON.stringify(searchParams));

  return $.get(LIZERP._URL_DOCDEFINEAPI[LIZERP._ERP_DOCACRONYM], searchParams, handleFormFields_results(), 'json');

  function handleFormFields_results(extraParams) {
    return function(data, textStatus, jqXHR) {
      /* Save to formFieldSettings for later use such as form lines */
      LIZERP.formFieldSettings = data;
      LIZERP.formFieldSettings_JSON = JSON.stringify(data);
      LIZERP.initPreviewDocFielddesc();

      /* Handle header fields */
      $.each(data['header'], function(fieldName, attributes) {

        // console.log(fieldName+ "---" + JSON.stringify(attributes));
        /* Handle required restriction */
        if (attributes['restriction'] == 'required') {
          $(LIZERP.formId + ' #' + fieldName).attr('required', 'required');
          $(LIZERP.formId + ' #' + fieldName).closest('div.formGroup').find('label').append('<span class="required">*</span>');
        } else {
          $(LIZERP.formId + ' #' + fieldName).removeAttr('required');
          $(LIZERP.formId + ' #' + fieldName).closest('div.formGroup').find('label span.required').remove();
        }

        /* Handle viewonly restriction */
        if (attributes['restriction'] == 'viewonly') {
          $(LIZERP.formId + ' #' + fieldName).attr('readonly', 'readonly');
          $(LIZERP.formId + ' #' + fieldName).attr('disabled', 'disabled');
        } else {
          $(LIZERP.formId + ' #' + fieldName).removeAttr('readonly');
          $(LIZERP.formId + ' #' + fieldName).removeAttr('disabled');
        }

        /* Handle hidden restriction */
        if (attributes['restriction'] == 'hidden') {
          $(LIZERP.formId + ' #' + fieldName).closest('div.formGroup').hide();
        }

        /* Handle defaults */
        if (!!attributes['default']) {
          if (attributes['default'].indexOf(':') == -1) {
            $(LIZERP.formId + ' #' + fieldName).val(attributes['default']);
          }
        }
        // After changing fields, must refresh

      });
      /* Handle table header */
      $.each(data['lines'], function(fieldName, attributes) {
        if (attributes['restriction'] == 'required') {
          $(LIZERP.formId + ' th.' + fieldName).attr('required', 'required');
          $(LIZERP.formId + ' th.' + fieldName).append('<span class="required">*</span>');
        }
      });
    }
  }
}

/**
 * Update the form title
 */
LIZERP.updateFormTitle = function(crudmode) {
  var params = paramsToObj(window.location.search);
  if (params.formtype != $('input#formtype').val()) {
    params.formtype = $('input#formtype').val();
    window.location = window.location.origin + window.location.pathname + '?' + $.param(params);
  }
}

/**
 * Save form via ajax after validation
 */
LIZERP.saveForm = function() {
  // tries to save the line if it's dirty
  if ((LIZERP.lineIsDirty == true) || ($(LIZERP.formId + ' #formLines tr.editable:not(.new)').length > 0)) {
    $('#formLines input[type=text]:visible').closest('tr').find('.saveLine').first().click();
  }

  // change data to actual uppercase from just css transform
  $(LIZERP.formId).find('input,textarea').each(function(i) {
    if ($(this).css('text-transform') == 'uppercase') $(this).val($(this).val().toUpperCase());
  });


  var error;
  // if no lines have been added, don't continue
  var validLines = $(LIZERP.formId + ' #formLines #fieldset_lineinformation tbody tr.valid').length;
  if (validLines == 0) {
    error = true;
    LIZERP.showFormError('Please provide at least one valid line information.');
  }

  // If all data is validated, then submit
  if (!error && LIZERP.formMode == 'edit') {
    // just to avoid re-entry, the server should also check for double submission
    LIZERP.readMode();

    /* Prepare JSON */
    var jsonData = {
      'lines': []
    };
    $.each(LIZERP.formFieldSettings['header'], function(fieldName, attributes) {
      jsonData[fieldName] = $(LIZERP.formId + ' #' + fieldName).val();
    });

    $(LIZERP.formId + ' #formLines #fieldset_lineinformation tbody tr.valid').each(function() {
      var fieldList = [];
      // Build field list from the visible form
      $('#formLines #fieldset_lineinformation tr th').each(function(e) {
        if (!!$(this).attr('class')) fieldList.push($(this).attr('class'));
      });
      // Build field list from the formFieldSettings variable
      // $.each( LIZERP.formFieldSettings['lines'], function( fieldName, attributes ) {
      //     fieldList.push( fieldName );
      // } );

      var formLine = {};
      
      for (index in fieldList) {
        formField = fieldList[index];
        formLine[formField] = $(this).find('td.' + formField).find('input,textarea,select').first().val();
      
      }
      jsonData['lines'].push(formLine);
    });
    /* Submit via ajax */
    var postData = {
      reqType: 'saveDoc',
      docobj: JSON.stringify(jsonData)
    };
    // add iddocument in case this is an Edit
    if ($(LIZERP.formId + ' #docnumber').val().length > 0) postData.docnumber = $(LIZERP.formId + ' #docnumber').val();
    console.log(postData);
    $.ajax({
      type: 'post',
      url: LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM],
      //dataType: 'json',/* if the return data is json */
      data: postData,
      success: function(data) {
          // if result is JSON, we're using the new API return format
          data = JSON.parse(data);
          if (!!data.errormsgs && data.errormsgs.length > 0) {
            console.log(data.errormsgs.join('\n'));
            alert("===>"+data.errormsgs.join('\n'));
            LIZERP.editMode();
          } else {
            var params = paramsToObj(window.location.search);
            var next_href = window.location.origin + window.location.pathname + '?doctype=' + LIZERP._ERP_DOCACRONYM + '&docnumber=' + data.docnumber;
            window.location.href = next_href;
          }
      }
    }).fail(function(e) {
      alert('Saving failed, please try again.');
      LIZERP.editMode();
    });
  }
  return;
}


/**
 * Show popup item code search form
 */
LIZERP.handleSearchForm = function(callingField, prepopulate) {
  LIZERP.searchLoupe_hide();
  if (callingField == 'itemcode') {
    var prepopJS = (!!prepopulate) ? 'var prepopulate = ' + JSON.stringify(prepopulate) + ';' : '';
    var content = LIZERP.itemSearchFormHTML + '<script> ' + prepopJS + '</script>';
  } else if (callingField == 'idlocation') {
    if (LIZERP._ERP_DOCACRONYM == 'GD' || LIZERP._ERP_DOCACRONYM == 'TO') {
      var $whlocation = $('select#sendlocation');
    } else if (LIZERP._ERP_DOCACRONYM == 'GR') {
      var $whlocation = $('select#recvlocation');
    } else {
      throw "FATAL ERROR: unrecognized doctype in handleSearchForm";
    }
    if ($whlocation.val() == '') {
      LIZERP.hightlightErrorField($whlocation);
      return;
    } else {
      var $tr2 = LIZERP.getLineBeingEdited();

      prepopulate = !!prepopulate ? prepopulate : {};
      prepopulate.whlocation = $whlocation.val();
      prepopulate.fulladdresscode = $tr2.find('.idlocation input').val();
      var prepopJS = 'var prepopulate = ' + JSON.stringify(prepopulate) + ';';
      var content = LIZERP.locationSearchFormHTML + '<script> ' + prepopJS + '</script>';
    }
  }
  $.fancybox({
    parent: LIZERP.formId,
    type: 'html',
    content: content,
    minWidth: 500,
    minHeight: 300,
    afterShow: function() {
      $('#searchForm .focusonme').first().focus();
      if (!!prepopulate) {
        for (field in prepopulate) {
          $('#searchForm').find('input,select').filter('[name=' + field + ']').val(prepopulate[field]);
        }
        $('#searchForm').find('input,select').filter('[name=whlocation]').attr('disabled', 'disabled');
        $('#searchForm button#search').first().click();
      }
    }
  });
  return;
}



//******************************************* MODE HANDLING

LIZERP.readMode = function() {
  $(LIZERP.formId).find(' #formLines tr.new').remove();
  $(LIZERP.formId).find(' #formLines tr').unbind('mouseenter mouseleave');
  $(LIZERP.formId).find('input,select,textarea').attr('disabled', 'disabled');
  $(LIZERP.formId).find(' input[type=button]').removeAttr('disabled');
  $('#fieldset_systeminformation').css('display', 'block');
  $(' .btnEditMode ').css('display', 'none');
  $(' .btnReadMode ').css('display', 'inline-block');
  $('.datepicker').unmousewheel();
  LIZERP.formMode = 'read';
}


LIZERP.editMode = function(formWhere) {

  if ($(' #formLines tr.editable').length == 0){
    LIZERP.addLine();
  }

  $(LIZERP.formId + ' #formLines tr').hover(function(e) {
    $(this).find('.div_editButton').css('display', 'block');
  }, function(e) {
    $(this).find('.div_editButton').css('display', 'none');
  });
  $(LIZERP.formId).find('input,select,textarea').removeAttr('disabled');
  LIZERP.lockCreateOnlyFields();
  $(LIZERP.formId + '#fieldset_systeminformation').css('display', 'none');
  $(LIZERP.formId + ' .btnEditMode ').css('display', 'inline-block');
  $(LIZERP.formId + ' .btnReadMode ').css('display', 'none');


  var $tr2 = LIZERP.getLineBeingEdited();
  if(formWhere == 'nodoc' || formWhere == 'eee'){

    $tr2.removeClass('editable new').addClass('valid new'); // new added by Mamun
    $(LIZERP.formId).find('.saveLine').attr('disabled', 'disabled');
    $(LIZERP.formId).find('.saveLineAndNew').attr('disabled', 'disabled');

    $(LIZERP.formId).find('.copyAndNewLine').attr('disabled', 'disabled');
    $(LIZERP.formId).find('.removeLine').attr('disabled', 'disabled');

  }


  LIZERP.formMode = 'edit';
}

LIZERP.editMode_clickFromUpperBtn = function() {

  $(LIZERP.formId + ' #formLines tr').hover(function(e) {
    $(this).find('.div_editButton').css('display', 'block');
  }, function(e) {
    $(this).find('.div_editButton').css('display', 'none');
  });
  $(LIZERP.formId).find('input,select,textarea').removeAttr('disabled');
  LIZERP.lockCreateOnlyFields();
  $(LIZERP.formId + '#fieldset_systeminformation').css('display', 'none');
  $(LIZERP.formId + ' .btnEditMode ').css('display', 'inline-block');
  $(LIZERP.formId + ' .btnReadMode ').css('display', 'none');

  $(LIZERP.formId).find('.saveLine').attr('disabled', 'disabled');
  $(LIZERP.formId).find('.saveLineAndNew').attr('disabled', 'disabled');

  $(LIZERP.formId).find('.copyAndNewLine').attr('disabled', 'disabled');
  $(LIZERP.formId).find('.removeLine').attr('disabled', 'disabled');
  // added 2017-05-03
  $(LIZERP.formId).find('#formLinesButtonsBr').empty().append('<br/><br/>');

  LIZERP.formMode = 'edit';
}

/**
 * Locks all fields that can not be changed after document is saved.
 * This is done to keep consistency on the DB.
 * E.g. status of the related document has already been changed.
 */
LIZERP.lockCreateOnlyFields = function() {
  var fieldList = LIZERP._FIELDS_CREATEONLY;
  for (field in fieldList) {
    $(LIZERP.formId).find('input,textarea,select').filter('#' + fieldList[field]).attr('disabled', 'disabled');
  }
}

//******************************************* OTHER

LIZERP.wait = function(ms) {
  var deferred = $.Deferred();
  setTimeout(function() {
    deferred.resolve()
  }, ms);
  return deferred.promise();
}




/**
 * Au: Al-Mamun
 * 2017-03-30
 * New feature
 * Handle doc preview ------------------------------------------------------------------------------------------------------------------------------ 
 */
//--------------- Common ------------------------------
LIZERP.applyCSS_docPreview = function(){
  $('#formDeliveryLine table').find('input,select').css({
    'font-family': 'Arial', 
    'font-size': '13px',
    'padding': '2px',
    'border':'1px solid #7F7F7F',
    'border-radius': '3px',
    'width': '100px',
  });
  $('#formDeliveryLine table tr:last-child td:first-child input').css({
    'text-align': 'center'
  });
  $('#formDeliveryLine table tr td:first-child input').css({
    'text-align': 'center'
  });

  //---------------------------
  $('#divHeadTableX').css({
    'display':'block',
    'overflow': 'auto'
  })
  $('#divHeadTableXX1').css({
    // 'float':'left',
    'display':'inline-block',
    'width':'33%'
  })
  $('#divHeadTableXX2').css({
    'display':'inline-block',
    'width':'33%'
  })
  $('#divHeadTableXX3').css({
    'display':'inline-block',
    'width':'33%'
  })

  //------------------------
  $('#div_companyinfo').css({
    'padding-top':'20pt',
    'font-size':'25pt',
    'font-weight':'bold',
    'text-transform':'uppercase',
    'text-align':'center',
    'margin':'0pt'
  })
  $('#div_companyinfo_name').css({
    'margin':'0pt'
  })
  $('#div_companyinfo_address').css({
    'line-height':'100%',
    'font-size':'9pt',
    'margin-top':'8pt',
    'font-weight':'normal',
    'font-family':'serif'
  })

  //--------------------------
  $('#div_documentInfo').css({
    'line-height':'100%'
  })
  $('#div_doctittle').css({
    'text-align':'center',
    'font-weight':'bold',
    'text-transform':'uppercase',
    'font-size':'20pt',
  })
  $('#div_docsubtittle').css({
    'text-align':'center',
    'font-weight':'bold',
    'text-transform':'uppercase',
    'font-size':'12pt',
  })

  $('.clearfix').css({
    'overflow': 'auto',
    'clear': 'both'
  })

  var lineTableWidth = $('#divLineTable table').width();
  if(lineTableWidth < 800){
    lineTableWidth = 800;
  }
  $('.fancybox-wrap, .fancybox-skin, .fancybox-outer, .fancybox-inner, .fancybox-image, .fancybox-wrap iframe, .fancybox-wrap object, .fancybox-nav, .fancybox-nav span, .fancybox-tmp').css({
  'width':lineTableWidth + 20+'px',
  'max-width':lineTableWidth + 20+'px',
  });
  $('.fancybox-skin').css({
    'width':lineTableWidth + 50 +'px',
    'min-width':lineTableWidth + 50 +'px',
    'max-width':lineTableWidth + 120+'px'
  })
  $('#fieldset_docpreview').css({
  	'margin':'1px 1px 1px 1px'
  });
  $.fancybox.update();

}
//-------------------- Common ------------------------

LIZERP.prepareDocHeadTable = function(docobj){
  mydata = docobj;

  var hideColumns = ['idlines'];
  var translationsHardCode = {};
  translationsHardCode.company = 'Company';

  if(!!LIZERP.hideColumns_previewDoc_headTable){
    hideColumns = LIZERP.hideColumns_previewDoc_headTable;
  }
  if(!!LIZERP.translationsHardCode_previewDoc_headTable){
    translationsHardCode = LIZERP.translationsHardCode_previewDoc_headTable;
  }

  var $table = $('<table border=1 id="tbl_1" class="no_border" />');
  var $table2 = $('<table border=1 id="tbl_2" class="no_border" />');
  var $table3 = $('<table border=1 id="tbl_3" class="no_border" />');
  var setTBL1 = true;
  var setTBL2 = false;
  var setTBL3 = false;

  $.each(mydata, function(key, val){
    // take new tr
    var $tr = $("<tr/>");

    // process th
    $th = $('<th style="border-color:grey;"/>');
    $th.html(key)
      .css("white-space", "pre-wrap")
      .attr("fieldname", key)
      .css("cursor", "pointer")
      .hover(function() {
          $(this).closest("tr").css("background-color", "lightblue");
        },
        function() {
          $(this).closest("tr").css("background-color", "transparent");
        }
      );
    if (!!translationsHardCode[key]) $th.html(translationsHardCode[key]);
    if (hideColumns.indexOf(key) >= 0) $th.css('display', 'none');
    $th.appendTo($tr);

    // process td
    $td = $('<td style="border-color:grey;"/>');
    $td.html(':')
      .css("white-space", "pre")
      .attr("fieldname", key)
      .css("cursor", "pointer")
      .hover(function() {
          $(this).closest("tr").css("background-color", "lightblue");
        },
        function() {
          $(this).closest("tr").css("background-color", "transparent");
        }
      );
    if (hideColumns.indexOf(key) >= 0) $td.css('display', 'none');
    $td.appendTo($tr);

    // process td
    $td = $('<td style="border-color:grey;"/>');
    $td.html(val)
      .css("white-space", "pre-wrap")
      .attr("fieldname", key)
      .css("cursor", "pointer")
      .hover(function() {
          $(this).closest("tr").css("background-color", "lightblue");
        },
        function() {
          $(this).closest("tr").css("background-color", "transparent");
        }
      );
    if (hideColumns.indexOf(key) >= 0) $td.css('display', 'none');
    $td.appendTo($tr);

    if(setTBL1){
      $tr.click(function() {
      }).appendTo($table);
      setTBL1 = false;
      setTBL2 = true;
      setTBL3 = false;
    } else if(setTBL2){
      $tr.click(function() {
      }).appendTo($table2);
      setTBL1 = false;
      setTBL2 = false;
      setTBL3 = true;     
    } else {
      $tr.click(function() {
      }).appendTo($table3);   
      setTBL1 = true;
      setTBL2 = false;
      setTBL3 = false;              
    }

  });

  var returnObj = {
    tbl1: $table,
    tbl2: $table2,
    tbl3: $table3
  }

  return returnObj;


}

LIZERP.prepareDocLineTable = function(lines){
      mydata = lines;
      var hideColumns = ['idlines'];
      var translationsHardCode = {};
      translationsHardCode.parentlinenumber = 'Line Number';

      if(!!LIZERP.hideColumns_previewDoc_lineTable){
        hideColumns = LIZERP.hideColumns_previewDoc_lineTable;
      }
      if(!!LIZERP.translationsHardCode_previewDoc_lineTable){
        translationsHardCode = LIZERP.translationsHardCode_previewDoc_lineTable;
      }

      var $table = $('<table border=1 id="tbl_relateddocs"/>');
      var firstRow = mydata[0];
      var $td;
      var $tr = $("<tr/>");
      $.each(firstRow, function(key, val) {
        $td = $('<th style="border-color:grey;"/>');
        $td.html(key);
        if (!!translationsHardCode[key]) $td.html(translationsHardCode[key]); 
        if (hideColumns.indexOf(key) >= 0) $td.css('display', 'none'); 
        $td.appendTo($tr);
      });
      $tr.appendTo($table);
      // populates with data
      $.each(mydata, function(index, value) {
        var $tr = $("<tr/>");
        $.each(value, function(key, val) {
          $td = $('<td style="border-color:grey;"/>');
          $td.html(val)
            .css("white-space", "pre")
            .attr("fieldname", key)
            .css("cursor", "pointer")
            .hover(function() {
                $(this).closest("tr").css("background-color", "lightblue");
              },
              function() {
                $(this).closest("tr").css("background-color", "transparent");
              }
            );
          if (hideColumns.indexOf(key) >= 0) $td.css('display', 'none');
          $td.appendTo($tr);
        });
        $tr.click(function() {
        }).appendTo($table);
      });
      return $table;
}

LIZERP.getCompanyInfo_docPreview = function(docobj){
  var companyInfo = '\
<div id="div_companyinfo">\
    <p id="div_companyinfo_name">Liz Fashion Industry Limited</p>\
    <p id="div_companyinfo_address">Head Office: House # 316, Road 4, DOHS Baridhara, Dhaka-1206, Bangladesh.<br/> Factory: Building-2, Holding-1, Block-C, Shaheed Mosharaf Hossain Road, East Chandra, Sofipur, Kaliakoir, Gazipur, Bangladesh</p>\
</div>';
  return companyInfo;
}

LIZERP.getDocumentInfo_docPreview = function(docobj){
  var docInfoTranslator = {
    SO: 'Sales Order',
    projection: 'Projection',
    direct: 'Direct Confirm',
    under_projection: 'Under Projection'
  }

  if(!!LIZERP.docInfoTranslator_docPreview){
    docInfoTranslator = LIZERP.docInfoTranslator_docPreview;
  }

  var docTittle = docInfoTranslator[docobj.doctype];
  var formTittle = docInfoTranslator[docobj.formtype];
  var documentInfo = '\
<div id="div_documentInfo">\
  <div id="div_doctittle">' + formTittle + '  ' + docTittle + '</div>\
  <div id="div_docsubtittle">'+ '' +'</div>\
</div>';
  return documentInfo;
}


LIZERP.cancelPreviewDoc = function(){

}

LIZERP.approvePreviewDoc = function(){
  
}

LIZERP.getBottomButton_docPreview = function(){
  var content = '<center>';
  content += '<button type="button" class="button" onclick="LIZERP.approvePreviewDoc()">Approve</button>';
  content += '&nbsp&nbsp&nbsp&nbsp';
  content += '<button type="button" class="button" onclick="LIZERP.cancelPreviewDoc()">Cancel</button>';
  content += '</center>';
  return content;
}

LIZERP.reviewAndApproveDoc = function(docobj){
  var docobj = JSON.parse(docobj);
  var docnumber = docobj.docnumber;
  var lines = docobj.lines;
  delete docobj.lines;
  var headTableObj = LIZERP.prepareDocHeadTable(docobj);
  var headTable1 = headTableObj.tbl1;
  var headTable2 = headTableObj.tbl2;
  var headTable3 = headTableObj.tbl3;

  var lineTable = LIZERP.prepareDocLineTable(lines);

  var companyInfo = LIZERP.getCompanyInfo_docPreview(docobj);
  var documentInfo = LIZERP.getDocumentInfo_docPreview(docobj);
  var bottomButton = LIZERP.getBottomButton_docPreview();

  var content = '';
  content += '<fieldset id="fieldset_docpreview">';
  content += companyInfo;
  content += documentInfo;
  content += '<br/>';

  content += '<div id="divHeadTableX">';
  content += '<div id="divHeadTableXX1"></div>';
  content += '<div id="divHeadTableXX2"></div>';
  content += '<div id="divHeadTableXX3"></div>';
  content += '</div>';
  content += '<div class="clearfix"></div>';
  content += '<br/>';
  content += '<div id="divLineTable"></div>';

  content += '<br/>';
  content += '<div id="divButton">';
  content += bottomButton;
  content += '</div>';

  content += '</fieldset>';

  $.fancybox({
    type: 'html',
    content: content,
    // minWidth: 500,
    minHeight: 600,
    afterLoad: function(){
    },
    afterShow: function() {
      // LIZERP.applyCSS_docPreview();
      $('#divHeadTableXX1').append(headTable1);
      $('#divHeadTableXX2').append(headTable2);
      $('#divHeadTableXX3').append(headTable3);
      $('#divLineTable').append(lineTable);
      $.fancybox.update();
      LIZERP.applyCSS_docPreview();
    },
    helpers: {
     title : {
      type : 'inside',
      position : 'top'
     },
     overlay : {
      css  : { /* 'background-color' : '#fff' */}
     }     
    }   
  });
  jQuery('.fancybox-title').css({'text-align':'center', 'margin-bottom':'10px'});


}


/**
 * Handle doc preview end ------------------------------------------------------------------------------------------------------------------------------
 */

/**
 * Customize doc preview
 */
LIZERP.docInfoTranslator_docPreview = {
    SO: 'Sales Order',
    projection: 'Projection',
    direct: 'Direct Confirm',
    under_projection: 'Under Projection'  
}
LIZERP.translationsHardCode_previewDoc_headTable = {
  parentlinenumber: 'Line Number'
};
LIZERP.hideColumns_previewDoc_headTable = ['doctype', 'formtype'];

LIZERP.translationsHardCode_previewDoc_lineTable = {
  linenumber: 'Line'
};
LIZERP.hideColumns_previewDoc_lineTable = ['idlines'];

LIZERP.cancelPreviewDoc = function(){
  $.fancybox.close();
}
LIZERP.approvePreviewDoc = function(){
}

// auto pushing fielddesc
LIZERP.initPreviewDocFielddesc = function(){
  $.each(LIZERP.formFieldSettings['header'], function(fieldName, attributes) {
    var fielddesc = attributes['fielddesc'];
    LIZERP.translationsHardCode_previewDoc_headTable[fieldName] = fielddesc;
  });
  $.each(LIZERP.formFieldSettings['lines'], function(fieldName, attributes) {
    var fielddesc = attributes['fielddesc'];
    LIZERP.translationsHardCode_previewDoc_lineTable[fieldName] = fielddesc;
  });
}









//custom Dropdown........

/**
 * Populate dropdowns
 * This adds to whatever options are already available, allowing for a blank initial option
 * To clear the options prior, use $('select').empty();
 * TO-DO: add extra options: run select2, auto-adjust width of SELECT
 */
LIZERP.customDropdown = function(field, defaultval, options, reqType, _URL) {
  if(!!!reqType) return;
  if(!!!_URL) var _URL = 'api/server_api.php';
  var populateParams = {
    'field': field
  };
  if (!!defaultval && defaultval != null) {
    populateParams.defaultval = defaultval;
  }
  if (!!options && options.indexOf('showkeys') != -1) {
    populateParams.showkeys = true;
  }

    var searchParams = {
      'field': field,
      'reqType': reqType
    };
    return $.get(URL, searchParams, populateDropdown_populate(populateParams), 'json');

  function populateDropdown_populate(extraParams) {
    var showkeys = extraParams.showkeys;
    return function(data, textStatus, jqXHR) {
      var setasdefault = false;
      $.each(data, function(index, value) {
        setasdefault = (!!extraParams.defaultval && (value == extraParams.defaultval || index == extraParams.defaultval));
        if (!!showkeys && showkeys === true && index != value) {
          $('#' + extraParams.field)
            .append($("<option></option>")
              .attr("value", index)
              .text(index + ' - ' + value)
              .prop('selected', setasdefault)
            );
        } else {
          $('#' + extraParams.field)
            .append($("<option></option>")
              .attr("value", index)
              .text(value)
              .prop('selected', setasdefault)
            );
        }
      });
      return;
    }
  }
}

// LIZERP.customDropdown('developmentprojectnumber', '', '', 'getDPRNumber', 'docso_api.php');
// LIZERP.customDropdown('developmentprojectnumber', '', '', 'getso', 'soapi');




//----------------------------------------- loupe list work --------------------------------------------------------------------------------------------------------------------------
// 2017-04-23

LIZERP.searchLoupe_show_forHeaderField = function(inputfield) {
  console.log("me---"+inputfield);
  var imgheight = 16;
  var imgwidth = 16;
  // var fieldName = $(inputfield).closest('td').attr('class');
  var fieldName = $(inputfield).attr('id');
  // aleft = $(inputfield).offset().left + 3;
  aleft = $(inputfield).offset().left + $(inputfield).width() - imgwidth + 2;
  atop = $(inputfield).offset().top + 3;
  $('<div/>')
    .offset({
      top: atop,
      left: aleft
    })
    .css('display', 'block')
    .css('position', 'absolute')
    .css('background-repeat', 'no-repeat')
    .css('background-image', 'url(./img/search.png)')
    .css('z-index', '1')
    .attr('fieldname', fieldName)
    .addClass('itemsearchLoupe')
    .height($(inputfield).outerHeight() - 2)
    .width($(inputfield).outerHeight() - 2)
    .appendTo($('body'))
    .hover(function(e) {}, function(e) {
      $('.itemsearchLoupe').remove();
    })
    .on('click', function() {
      LIZERP.handleSearchForm($(this).attr('fieldname'));
    });

}

/**
 * Populate dropdowns
 * This adds to whatever options are already available, allowing for a blank initial option
 * To clear the options prior, use $('select').empty();
 * TO-DO: add extra options: run select2, auto-adjust width of SELECT
 */
LIZERP.loupeList_makeDropdownOptions = function(field, defaultval, options, _SQL) {
  if(!!!_SQL) return;
  var _URL = 'api/server_api.php';

  var searchParams = {
    'sql': _SQL,
    'reqType': 'getCustomLibrary'
  };

  var extraParams = {};
  var showkeys = false;

  var options = '<option value="">Select</option>';
  $.ajax({
    async   :   false,
    type  :   'get',
    url   :   _URL,
    data  :   searchParams,
    success :   function(data){
      var data = JSON.parse(data);

      var setasdefault = false;
      $.each(data, function(index, value) {
        setasdefault = (!!extraParams.defaultval && (value == extraParams.defaultval || index == extraParams.defaultval));
        if (!!showkeys && showkeys === true && index != value) {
          options += '<option value="' + v + '">' + v + '</option>';
        } else {
          options += '<option value="' + index + '">' + value + '</option>';
        }
      });
      return;

    },
    error :   function(){
      alert("error");
    }
  });


  return options;

}

// var sql = "SELECT idsupplier AS code, suppliername AS description FROM mrd_suppliers WHERE 1=1";
// LIZERP.loupeList_makeDropdownOptions('suppliername', '', '', sql);

LIZERP.popupList_MakeHTML_InputField = function(fieldname, fieldproperties){

  var islibrary   = fieldproperties.islibrary;
  var libraryname = fieldproperties.libraryname;
  var fielddesc   = fieldproperties.fielddesc;

  if(islibrary){ 
    var sql   = fieldproperties.sql;
    var options = LIZERP.loupeList_makeDropdownOptions(fieldname, '', '', sql);
    return '<select id="' + fieldname +"" + '" class="select2" name="' + fieldname + '" >' +options+ '</select>';

  } else {
    return '<input id="' + fieldname + '" type="text"  placeholder="'+ fielddesc +'" value="" name="' + fieldname + '" />';
  }

}


LIZERP.loupeList_makeListTable = function(_URL_SEARCHAPI, _SEARCHPARAMS, _PREPOPJS, _HideColumns, _TranslationsHardCode ){

  $("#popupList_childDiv_2"  ).empty().append( "No item found for the above query!" );
  $.get( _URL_SEARCHAPI , _SEARCHPARAMS , search_results(_SEARCHPARAMS, _PREPOPJS, _HideColumns, _TranslationsHardCode) );

  // function search_results(data, textStatus, jqXHR) {}
  function search_results( extraParams ){

    return function(data, textStatus, jqXHR) {
        if ( textStatus == "success" && data == "") {
          return;
        };

    var jsonData = data;
    data = JSON.parse( data );
    var mydata = data.listData;
    var  paginationTable = jsClient.loupeList_makePagination(jsonData);
    if(mydata == '0'){
      $('#popupList_childDiv_2').empty();
      $('#popupList_childDiv_3').empty().append('No item found for the above query!');
      return;
    }
    var  popupListTable = makeListTable(mydata, _HideColumns, _TranslationsHardCode);
    $('#popupList_childDiv_2').empty().append(paginationTable);
    jsClient.loupeList_paginationCSS();
    $('#popupList_childDiv_3').empty().append(popupListTable);
    $.fancybox.update();
    };

  }

  function makeListTable(mydata, _HideColumns, _TranslationsHardCode){
    // some trickery for nice formatting
    var hideColumns = ['idlines'];
    if(!!hideColumns) hideColumns = _HideColumns;

    var translationsHardCode = {};
    translationsHardCode.docnumber = 'Doc Number';
    if(!!hideColumns) translationsHardCode = _TranslationsHardCode;

    var $table = $('<table border=1 id="listTable" class="listTable" />');
    var $thead = $('<thead />');
    var $tbody = $('<tbody/>');

    // builds the table header
    var firstRow = mydata[0];
    var $td;
    var $tr = $("<tr/>");

    $.each(firstRow, function (key, val) {
      $td = $('<th/>');
      $td.html(key);
      if (!!translationsHardCode[key]) $td.html(translationsHardCode[key]);
      if ( hideColumns.indexOf(key) >= 0 ) $td.css('display','none');
      $td.appendTo($tr);
    });
    $tr.appendTo($thead);

    // populates with data
    $.each(mydata, function (index, value) {
      var $tr = $("<tr/>");

      $.each(value, function (key, val) {
        
        var thisrowval = value;
        var formtype = thisrowval['formtype'];
        var materiallistid = thisrowval['materiallistid'];
   
        $td = $('<td/>');
        $td.html(val)
          .css("white-space","pre")
          .attr("fieldname",key)
          .css("cursor","pointer")
          .hover(function(){ $(this).closest("tr").css("background-color", "lightblue");},
               function(){ $(this).closest("tr").css("background-color", "");}
             );

        if (key == 'formtype' && !!formtypeTranslation[val]) $td.html(formtypeTranslation[val]);    
        if ( hideColumns.indexOf(key) >= 0 ) $td.css('display','none');
        $td.appendTo($tr);
      });
      $tr.click( function() { 
          sendBackSearchChoice($(this));
        })
        .appendTo($tbody);
    });

    $thead.appendTo($table)
    $tbody.appendTo($table)

    return $table;

  }

}


LIZERP.loupeList_getSearchData = function(showLimit, pageNum){
  var searchParams = {};
  if(!!LIZERP.loupeList_SEARCHPARAMS) searchParams = LIZERP.loupeList_SEARCHPARAMS;

    $.each(LIZERP.loupeList_searchFormFileds, function(fieldName, attributes) {
      searchParams[fieldName] = $('#loupeList_searchFormId' + ' #' + fieldName).val();
    });

    if(!!!showLimit) var showLimit = 10;
    if(!!!pageNum) var pageNum = 1;

    searchParams.showLimit = showLimit;
    searchParams.pageNum = pageNum;
  var popupListTable = LIZERP.loupeList_makeListTable(LIZERP.loupeList_URL_SEARCHAPI, searchParams, LIZERP.loupeList_PREPOPJS, LIZERP.loupeList_HideColumns, LIZERP.loupeList_TranslationsHardCode);
}

LIZERP.loupeList_MakeSearchForm = function(formFields, formId){
  var inputFields = '<form id="'+ formId +'"><div class="responsiveRow">';
  var index = 1;
  $.each(formFields, function(fieldname, fieldproperties){
    var fielddesc = fieldproperties.fielddesc;
    var input = LIZERP.popupList_MakeHTML_InputField(fieldname, fieldproperties);
    inputFields +=  '<div class="responsiveElement"><b>' + fielddesc + '</b><br>'+input+'</div>';
  });

  inputFields += '<div style="clear:both;"></div>';
  inputFields += '<div class="responsiveElement"><input type="button" id="btnSearch" class="button" value="Find" onClick="LIZERP.loupeList_getSearchData()"></div>';
  inputFields += '<div class="responsiveElement"><br><input type="button" id="btnReset" value="Reset" onClick="LIZERP.resetSearchForm(this.form.id)"></div>';

  inputFields += '</div></form>';
  return inputFields;
}


LIZERP.makeLoupeListSession = function(_URL_SEARCHAPI, _SEARCHPARAMS, _PREPOPJS, _HideColumns, _TranslationsHardCode, _SearchFormFileds, _Prepopulate, _loupeList_Title) {

  var loupeList_Title = (!!_loupeList_Title) ? _loupeList_Title : '';

  LIZERP.loupeList_URL_SEARCHAPI = _URL_SEARCHAPI;
  LIZERP.loupeList_SEARCHPARAMS = _SEARCHPARAMS;
  LIZERP.loupeList_PREPOPJS = _PREPOPJS;
  LIZERP.loupeList_HideColumns = _HideColumns;
  LIZERP.loupeList_TranslationsHardCode = _TranslationsHardCode;
  LIZERP.loupeList_searchFormFileds = _SearchFormFileds;  

  var loupeSearchForm = LIZERP.loupeList_MakeSearchForm(_SearchFormFileds, 'loupeList_searchFormId');

  var content = '<div id="popupList_motherDiv">';

  content += '<div id="popupList_childDiv_1">';
  content += '<div id="">';
  content += loupeSearchForm;
  content += '</div>'; // child div 1 end

  content+= '<div id="popupList_childDiv_2"></div>';
  content+= '</div>'; // child div 2 end

  content += '<div id="popupList_childDiv_3">';
  content += '<div id="">';
  content += '</div>'; // child div 3 end

  content+= '</div>'; // mother div end

  content+= '<script> ' + _PREPOPJS + '</script>'; // add some js

    
  $.fancybox({
    type: 'html',
    content: content,
    minWidth: 500,
    minHeight: 300,
    afterLoad: function(){
      this.title = '<b>'+ loupeList_Title +'</b>';
    },
    afterShow: function() {
      var popupListTable = LIZERP.loupeList_makeListTable(_URL_SEARCHAPI, _SEARCHPARAMS, _PREPOPJS, _HideColumns, _TranslationsHardCode);
      if (!!_Prepopulate) {
        for (field in _Prepopulate) {
          $('#loupeList_searchFormId').find('input,select').filter('[name=' + field + ']').val(prepopulate[field]);
        }
        $('#loupeList_searchFormId input#btnSearch').first().click();
      }
    },
    helpers: {
     title : {
      type : 'inside',
      position : 'top'
     },
     overlay : {
      css  : { /* 'background-color' : '#fff' */}
     }     
    }  
  });
  jQuery('.fancybox-title').css({'text-align':'center', 'margin-bottom':'10px'});

  $.fancybox.update();
  return;

 }



/**
 * Show loupe item code search form
 */
LIZERP.handleSearchForm = function(callingField, prepopulate) {
  LIZERP.searchLoupe_hide();
  if (callingField == 'XXX') {
   var popupList = LIZERP.makeLoupeListSession();
   var content = popupList;

  } else if(callingField == 'itemcode'){
  var prepopulate = {};

  // if($(LIZERP.formId+' #formLinesContainer').find('#lg_developmentprojectnumber').val().length > 0){
  //    prepopulate.docnumber = $(LIZERP.formId+' #formLinesContainer').find('#lg_developmentprojectnumber').val();
  // }

  var prepopJS = (Object.keys(prepopulate).length > 0) ? 'var prepopulate = ' + JSON.stringify(prepopulate) + ';' : '';
  prepopJS = prepopJS + "function sendBackSearchChoice( row ) {";
  prepopJS = prepopJS + "  itemcode = $(row).find('td[fieldname=itemcode]').text();";
  prepopJS = prepopJS + "  $.fancybox.close();";
  prepopJS = prepopJS + "  $('#itemcode').focus();";
  prepopJS = prepopJS + "  $('#itemcode').val(itemcode);";
  prepopJS = prepopJS + "};";

    var _URL_SEARCHAPI = '/erp-apparel/docfm_api.php';
    var searchParams = {};
    searchParams['reqType'] = "searchItemCode";

    var hideColumns = ['idlines', 'doctype'];
    var translationsHardCode = {};
    translationsHardCode.endcustomer = 'End Customer';

    var searchFormFileds = {
      ItemType:{
        'fieldname':'ItemType',
        'fielddesc':'Item Type',
        'islibrary':true,
        'sql':"SELECT Code AS code, Description AS description FROM mrd_library WHERE 1=1 AND LibraryName = 'itemtype'",
        'libraryname': 'XXX'
      },
      ItemCode:{
        'fieldname':'ItemCode',
        'fielddesc':'Item Code'
      }
    }

    var popupList = LIZERP.makeLoupeListSession(_URL_SEARCHAPI, searchParams, prepopJS, hideColumns, translationsHardCode, searchFormFileds);

  }

  return;
}
//----------------------------------------- loupe list work end ----------------------------------------------------------------------------------------------------------------------








/**
 * Handle form fields to show-hide/enable-disable/required/readonly etc.
 */
LIZERP.handleFormFields = function(crudmode) {
  var params = paramsToObj(window.location.search);
  var searchParams = params;
  if (searchParams.formtype === undefined) {
    searchParams.formtype = 'default';
  }
  delete searchParams.doctype;

  return $.get(LIZERP._URL_DOCDEFINEAPI[LIZERP._ERP_DOCACRONYM], searchParams, handleFormFields_results(), 'json');

  function handleFormFields_results(extraParams) {
    return function(data, textStatus, jqXHR) {
      /* Save to formFieldSettings for later use such as form lines */
      LIZERP.formFieldSettings = data;
      LIZERP.formFieldSettings_JSON = JSON.stringify(data);
      LIZERP.initPreviewDocFielddesc();
      // alert(JSON.stringify(data));

      /* Handle header fields */
      $.each(data['header'], function(fieldName, attributes) {

        // console.log(fieldName+ "---" + JSON.stringify(attributes));
        /* Handle required restriction */
        if (attributes['restriction'] == 'required') {
          $(LIZERP.formId + ' #' + fieldName).attr('required', 'required');
          $(LIZERP.formId + ' #' + fieldName).closest('div.formGroup').find('label').append('<span class="required">*</span>');
        } else {
          $(LIZERP.formId + ' #' + fieldName).removeAttr('required');
          $(LIZERP.formId + ' #' + fieldName).closest('div.formGroup').find('label span.required').remove();
        }

        /* Handle viewonly restriction */
        if (attributes['restriction'] == 'viewonly') {
          $(LIZERP.formId + ' #' + fieldName).attr('readonly', 'readonly');
          $(LIZERP.formId + ' #' + fieldName).attr('disabled', 'disabled');
        } else {
          // $(LIZERP.formId + ' #' + fieldName).removeAttr('readonly');
          // $(LIZERP.formId + ' #' + fieldName).removeAttr('disabled');
        }

        /* Handle hidden restriction */
        if (attributes['restriction'] == 'hidden') {
          $(LIZERP.formId + ' #' + fieldName).closest('div.formGroup').hide();
        }

        /* Handle defaults */
        if (!!attributes['default']) {
          if (attributes['default'].indexOf(':') == -1) {
            $(LIZERP.formId + ' #' + fieldName).val(attributes['default']);
          }
        }
        // After changing fields, must refresh

      });
      /* Line Group fields */
      $.each(data['lines'], function(fieldName, attributes) {
        // console.log(fieldName + "--" + attributes);

        // console.log(fieldName+ "---" + JSON.stringify(attributes));
        /* Handle required restriction */
        if (attributes['restriction'] == 'required') {
          console.log(fieldName + "-ttttt-" + attributes);
          $(LIZERP.formId + ' #rightFormLines #lg_' + fieldName).attr('required', 'required');
          $(LIZERP.formId + ' #rightFormLines #lg_' + fieldName).closest('div.formGroup').find('label').append('<span class="required">*</span>');
        } else {
          $(LIZERP.formId + ' #rightFormLines #lg_' + fieldName).removeAttr('required');
          $(LIZERP.formId + ' #rightFormLines #lg_' + fieldName).closest('div.formGroup').find('label span.required').remove();
        }

        /* Handle viewonly restriction */
        if (attributes['restriction'] == 'viewonly') {
          $(LIZERP.formId + ' #rightFormLines #' + fieldName).attr('readonly', 'readonly');
          $(LIZERP.formId + ' #rightFormLines #' + fieldName).attr('disabled', 'disabled');
        } else {
          $(LIZERP.formId + ' #rightFormLines #' + fieldName).removeAttr('readonly');
          $(LIZERP.formId + ' #rightFormLines #' + fieldName).removeAttr('disabled');
        }

        /* Handle hidden restriction */
        if (attributes['restriction'] == 'hidden') {
          $(LIZERP.formId + ' #rightFormLines #' + fieldName).closest('div.formGroup').hide();
        }

        /* Handle defaults */
        if (!!attributes['default']) {
          if (attributes['default'].indexOf(':') == -1) {
            $(LIZERP.formId + ' #rightFormLines #' + fieldName).val(attributes['default']);
          }
        }
        // After changing fields, must refresh

      });
      /* Handle table header */
      $.each(data['lines'], function(fieldName, attributes) {
        if (attributes['restriction'] == 'required') {
          $(LIZERP.formId + ' th.' + fieldName).attr('required', 'required');
          $(LIZERP.formId + ' th.' + fieldName).append('<span class="required">*</span>');
        }
      });
    }
  }
}


/**
 * Show processing overlay, code start from here -----------------------------------------------------------------------
 */
LIZERP.showProcessinOverlay = function(){
  $('body').find('#myProcessinOverlay').remove();
  var processinOverlay = '<div id="myProcessinOverlay" class="myProcessinOverlay">\
    <div class="myProcessinOverlay-content" id="myProcessinOverlay-content">\
      <div id="myProcessinOverlay-loadingDiv">\
        <center><img src="img/spinner.gif"></center>\
      </div>\
      <div class="myProcessinOverlay-body" id="myProcessinOverlay-body">\
        <div id="myProcessinOverlay-message" style="color:black; font-weight:bold; font-size:20px;"><center>Processing, please wait.</center></div>\
      </div>\
    </div>\
  </div>';
  $('body').append(processinOverlay);

  var windowWidth = window.innerWidth;
  var windowHeight = window.innerHeight;
  var windowHeight_XX =  (windowHeight/2) - 200;

  // apply css ---------
  $('.myProcessinOverlay').css({
  'position':'fixed',
  'z-index':'9999',
  'padding-top': windowHeight_XX+'px',
  'left':'0',
  'top':'0',
  'width':'100%',
  // 'overflow':'auto',
  'height':'100%',
  // 'background-color':'rgb(0,0,0)',
  // 'background-color':'rgba(0,0,0,0.4)',
  'background-color':'white',
  'opacity': '0.8',
  });
  
  return;
}

LIZERP.removeProcessingOverlay = function(){
  // var rightFormLines_innerHTML = document.getElementById("rightFormLines").innerHTML;
  // document.getElementById("rightFormLines").innerHTML = '';
  // document.getElementById("rightFormLines").innerHTML = rightFormLines_innerHTML;
  var formERP = document.getElementById('formERP');
  var style = formERP.getAttribute("style");
  if(style == 'display:none;'){
    formERP.setAttribute("style", "display: block;");
  }
  // if (formERP.style.display === 'none') {
  //   formERP.style.display = 'block';
  // }
  $('body').find('.erpFormProcessingOverlay .erpFormProcessingOverlay-body').remove();
  $('body').find('#myProcessinOverlay').remove();  
}

LIZERP.showProcessinOverlay_2 = function(){
  // $('body').find('#myProcessinOverlay_2').remove();
  // var processinOverlay = '<div id="myProcessinOverlay_2" class="myProcessinOverlay_2">\
  //   <div class="myProcessinOverlay_2-content" id="myProcessinOverlay_2-content">\
  //     <div id="myProcessinOverlay_2-loadingDiv">\
  //       <center><img src="img/spinner.gif"></center>\
  //     </div>\
  //     <div class="myProcessinOverlay_2-body" id="myProcessinOverlay_2-body">\
  //       <div id="myProcessinOverlay_2-message" style="color:black; font-weight:bold; font-size:20px;"><center>Processing, please wait.</center></div>\
  //     </div>\
  //   </div>\
  // </div>';
  // $('body').append(processinOverlay);

  // var windowWidth = window.innerWidth;
  // var windowHeight = window.innerHeight;
  // var windowHeight_XX =  (windowHeight/2) - 200;
  // // apply css ---------
  // $('.myProcessinOverlay_2').css({
  // 'position':'fixed',
  // 'z-index':'9999',
  // 'padding-top': windowHeight_XX+'px',
  // 'left':'0',
  // 'top':'0',
  // 'width':'100%',
  // 'height':'100%',
  // 'background-color':'white',
  // 'opacity': '0.8',
  // // 'background-color':'rgba(0,0,0,0.5)',
  // });
  
  return;
}

LIZERP.removeProcessingOverlay_2 = function(){
  // var rightFormLines_innerHTML = document.getElementById("rightFormLines").innerHTML;
  // document.getElementById("rightFormLines").innerHTML = '';
  // document.getElementById("rightFormLines").innerHTML = rightFormLines_innerHTML;
  var formERP = document.getElementById('formERP');
  var style = formERP.getAttribute("style");
  if(style == 'display:none;'){
    formERP.setAttribute("style", "display: block;");
  }
  // if (formERP.style.display === 'none') {
  //   formERP.style.display = 'block';
  // }
  $('body').find('.erpFormProcessingOverlay .erpFormProcessingOverlay-body').remove();
  $('body').find('#myProcessinOverlay_2').remove();
}
/**
 * Show processing overlay, code end --------------------------------------------------------------------------------
 */



/**
 * Jquery UI dialog -------------------------------------------------------------------------------------------------
 */
LIZERP.jQueryUIDialog = function(_title, _markup, _flag, _okButtonName, _passingParams, _width, _modal){
  if(!!!_title) _title   = 'Test Title';
  if(!!!_markup) _markup = 'Test Markup';
  if(!!!_flag) _flag     = 'testFlag';
  if(!!!_okButtonName) _okButtonName = 'OK';
  if(!!!_passingParams) _passingParams = {0: 'dummy'};
  if(!!!_width) _width   = '500';
  if(!!!_modal) _modal   = true;

  var buttonObj = {0: 'FFFFF', 1: 'BBBBB'};
  var bbb = 'Testsasdasd';

  //Start confirm dialog PopUp
  $('<div></div>').dialog({
     width: _width,
     modal: _modal,
     title: _title,
      open: function () {
          var markup = _markup;
          $(this).html(markup);
      },
      buttons: [{
          text: _okButtonName,
          "id": "btnOk",
          click: function () {
            var thisf = this;
            LIZERP.jQueryUIDialog_CallBackFunction(thisf, _flag, _passingParams);
          },
        }, 
        {
          text: "Cancel",
          click: function () {
            $(this).dialog("close");
          },
    }],
  }); //end confirm dialog PopUp
}

LIZERP.jQueryUIDialog_CallBackFunction = function(thisf, _flag, _passingParams){
  if(_flag == 'testFlag'){
    LIZERP.testFlag(_passingParams);
  } else if(_flag == 'BOM_NAI'){

    $(thisf).dialog("close");

  } else if(_flag == 'testFlag'){

  }
}
/**
 * Jquery UI dialog code end -------------------------------------------------------------------------------------------------
 */



/**
 * [ModalBox description]
 * Class Modal Box -------------------------------------------------------------------------------------------------
 */
LIZERP.ModalBoxFirst = function(){

  function addModal(){

    // don't do anything in below code
    $('body').find('#myModalFirst').remove();
    var modalBox = '<div id="myModalFirst" class="modal">\
      <div class="modal-content" id="modal-content">\
        <div class="modal-header">\
          <span class="close">&times;</span>\
          <p>Default</p>\
        </div>\
        <div id="modal-loadingDiv">\
          <center><img src="/images/loading_spinner.gif"></center>\
        </div>\
        <div class="modal-body" id="modal-body">\
          <div id="modal-searchContainer"></div>\
          <div id="modal-paginationContainer"></div>\
          <div id="modal-listContainer" class="modal-listContainer"></div>\
          <div id="modal-formContainer" class="modal-formContainer"></div>\
          <div id="modal-jsCodeContainer"></div>\
        </div>\
        <div class="modal-footer">\
          <p>Modal Footer</p>\
        </div>\
      </div>\
    </div>';

    $('body').append(modalBox);

    var windowWidth = window.innerWidth;
    var windowHeight = window.innerHeight;
    var windowHeight_XX =  (windowHeight/2) - 200;

    // apply css ---------
    $('#myModalFirst').css({
      'position':'fixed',
      'z-index':'9999',
      'padding-top': windowHeight_XX+'px',
      'left':'0',
      'top':'0',
      'width':'100%',
      // 'overflow':'auto',
      'height':'100%',
      'background-color':'rgb(0,0,0)',
      'background-color':'rgba(0,0,0,0.4)',
    });
    // Get the modal
    var modal = document.getElementById('myModalFirst');
    // Get the <span> element that closes the modal
    var span = document.getElementById("myModalFirst").getElementsByClassName("close")[0];
    // When the user clicks on <span> (x), close the modal
    span.onclick = function() {
      modal.style.display = "none";
      $('body').find('#myModalFirst').remove();
    }
    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
      if (event.target == modal) {
          modal.style.display = "none";
          $('body').find('#myModalFirst').remove();
      }
    }

  }

  // private method
  function updateModalBox(classElement, forWhich){
    var setWidth, setHieght, setAdjW, setAdjH;

    var windowWidth = window.innerWidth;
    var windowHeight = window.innerHeight;

    var offsetHeight = document.getElementById('modal-body').offsetHeight;
    var offsetWidth = document.getElementById('modal-body').offsetWidth;    

    var fc_offsetHeight = document.getElementById('myModalFirst').getElementsByClassName('modal-formContainer')[0].offsetHeight;
    var fc_offsetWidth = document.getElementById('myModalFirst').getElementsByClassName('modal-formContainer')[0].offsetWidth;
    var fc_innerHTML = document.getElementById('myModalFirst').getElementsByClassName('modal-formContainer')[0].innerHTML.trim();


    var lc_offsetHeight = document.getElementById('myModalFirst').getElementsByClassName('modal-listContainer')[0].offsetHeight;
    var lc_offsetWidth = document.getElementById('myModalFirst').getElementsByClassName('modal-listContainer')[0].offsetWidth;
    var lc_innerHTML = document.getElementById('myModalFirst').getElementsByClassName('modal-listContainer')[0].innerHTML.trim();


    console.log('innerHTML' + fc_innerHTML.length + '   height---' + fc_offsetHeight + '  width ---' + fc_offsetWidth );
    console.log('innerHTML' + lc_innerHTML.length + '   height---' + lc_offsetHeight + '  width ---' + lc_offsetWidth );

    if (!!forWhich && !!classElement && forWhich == 'list'){
    var offsetWidth = document.getElementById('myModalFirst').getElementsByClassName('modal-listContainer')[0].getElementsByClassName(classElement)[0].offsetWidth;
    var offsetHeight = document.getElementById('myModalFirst').getElementsByClassName('modal-listContainer')[0].getElementsByClassName(classElement)[0].offsetHeight;
    if(typeof offsetWidth === "undefined" || offsetWidth == 0) return;

    var overflow = 'none';
    if(offsetWidth > lc_offsetWidth){
      setWidth = offsetWidth;
      setAdjW = 50;
    }
    if(offsetWidth > windowWidth){
      setWidth = windowWidth;
      setAdjW = -100;
      overflow = 'scroll';
    }

    $('#myModalFirst .modal-content').css({
      'overflow':overflow,
      'width': (setWidth + setAdjW) + 'px',
      'height':(windowHeight - 100 )+ 'px'
    });
    return;
    } else if (!!forWhich && !!classElement && forWhich == 'form'){

    }

    if(fc_innerHTML.length != 0){
      var overflow = 'none';
      if(fc_offsetHeight > windowHeight) overflow = 'scroll';
      $('#myModalFirst #modal-formContainer').css({
        'overflow':overflow,
        'width': fc_offsetWidth + 'px',
        'height':(fc_offsetHeight + 20 )+ 'px'
      });
    }

    if(lc_innerHTML.length != 0){
      var overflow = 'none';
      if(lc_offsetWidth > windowWidth) overflow = 'scroll';
      overflow = 'scroll'
      $('#myModalFirst .modal-content').css({
        'overflow':overflow,
        'width': (windowWidth - 100) + 'px',
        'height':(windowHeight - 100 )+ 'px'
      });
    }

  }

  // public method
  this.addModal = function(){
    return addModal();
  }
  this.setHieght = function(height){
    $('#myModalFirst #modal-content').css('height', height+'px');
  }
  this.setWidth = function(width){
    $('#myModalFirst #modal-content').css('width', width+'px');
  }
  this.setTittle = function(tittle){
    $('#myModalFirst .modal-header').find('p').text(tittle);
  }
  this.setPosition = function(x, y){
    if(!!x && x != '') $('#myModalFirst').css('padding-left', x+'px');
    if(!!y && y != '') $('#myModalFirst').css('padding-top', y+'px');    
  }
  this.updateModalBox = function(classElement, forWhich){
    return updateModalBox(classElement, forWhich);
  }
  this.removeSpinner = function(){
    $('#myModalFirst #modal-loadingDiv').empty();
  }
  this.close = function(){
    $('body').find('#myModalFirst').remove();
  }

}





//===========================second modal box =========================================================
LIZERP.ModalBoxSecond = function(){

  function addModal(){

    // don't do anything in below code
    $('body').find('#myModalSecond').remove();
    var modalBox = '<div id="myModalSecond" class="modal">\
      <div class="modal-content" id="modal-content">\
        <div class="modal-header">\
          <span class="close">&times;</span>\
          <p>Default</p>\
        </div>\
        <div id="modal-loadingDiv">\
          <center><img src="/images/loading_spinner.gif"></center>\
        </div>\
        <div class="modal-body" id="modal-body">\
          <div id="modal-searchContainer"></div>\
          <div id="modal-paginationContainer"></div>\
          <div id="modal-listContainer" class="modal-listContainer"></div>\
          <div id="modal-formContainer" class="modal-formContainer"></div>\
          <div id="modal-jsCodeContainer"></div>\
        </div>\
        <div class="modal-footer">\
          <p>Modal Footer</p>\
        </div>\
      </div>\
    </div>';

    $('body').append(modalBox);

    var windowWidth = window.innerWidth;
    var windowHeight = window.innerHeight;
    var windowHeight_XX =  (windowHeight/2) - 200;

    // apply css ---------
    $('#myModalSecond').css({
      'position':'fixed',
      'z-index':'9999',
      'padding-top': windowHeight_XX+'px',
      'left':'0',
      'top':'0',
      'width':'100%',
      // 'overflow':'auto',
      'height':'100%',
      'background-color':'rgb(0,0,0)',
      'background-color':'rgba(0,0,0,0.4)',
    });
    // Get the modal
    var modal = document.getElementById('myModalSecond');
    // Get the <span> element that closes the modal
    var span = document.getElementById("myModalSecond").getElementsByClassName("close")[0];
    // When the user clicks on <span> (x), close the modal
    span.onclick = function() {
      modal.style.display = "none";
      $('body').find('#myModalSecond').remove();
    }
    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
      if (event.target == modal) {
          modal.style.display = "none";
          $('body').find('#myModalSecond').remove();
      }
    }

  }

  // private method
  function updateModalBox(){
    var windowWidth = window.innerWidth;
    var windowHeight = window.innerHeight;
    windowWidthXX = windowWidth - 50;
    windowHeightYY = windowHeight -100;

    var offsetHeight = document.getElementById('modal-body').offsetHeight;
    var offsetWidth = document.getElementById('modal-body').offsetWidth;    

    var fc_offsetHeight = document.getElementById('myModalSecond').getElementsByClassName('modal-formContainer')[0].offsetHeight;
    var fc_offsetWidth = document.getElementById('myModalSecond').getElementsByClassName('modal-formContainer')[0].offsetWidth;
    var fc_innerHTML = document.getElementById('myModalSecond').getElementsByClassName('modal-formContainer')[0].innerHTML.trim();

    var lc_offsetHeight = document.getElementById('myModalSecond').getElementsByClassName('modal-listContainer')[0].offsetHeight;
    var lc_offsetWidth = document.getElementById('myModalSecond').getElementsByClassName('modal-listContainer')[0].offsetWidth;
    var lc_innerHTML = document.getElementById('myModalSecond').getElementsByClassName('modal-listContainer')[0].innerHTML.trim();


    console.log('innerHTML' + fc_innerHTML.length + '   height---' + fc_offsetHeight + '  width ---' + fc_offsetWidth );

    if(fc_innerHTML.length != 0){
      var overflow = 'none';
      if(fc_offsetHeight > windowHeight) overflow = 'scroll';
      $('#myModalSecond #modal-formContainer').css({
        'overflow':overflow,
        'width': fc_offsetWidth + 'px',
        'height':(fc_offsetHeight + 20 )+ 'px'
      });
    }

    if(lc_innerHTML.length != 0){
      
    }

  }

  // public method
  this.addModal = function(height){
    return addModal();
  }
  this.setHieght = function(height){
    $('#myModalSecond #modal-content').css('height', height+'px');
  }
  this.setWidth = function(width){
    $('#myModalSecond #modal-content').css('width', width+'px');
  }
  this.setTittle = function(tittle){
    $('#myModalSecond .modal-header').find('p').text(tittle);
  }
  this.setPosition = function(x, y){
    if(!!x && x != '') $('#myModalSecond').css('padding-left', x+'px');
    if(!!y && y != '') $('#myModalSecond').css('padding-top', y+'px');    
  }
  this.updateModalBox = function(x, y){
    return updateModalBox();
  }
  this.removeSpinner = function(){
    $('#myModalSecond #modal-loadingDiv').empty();
  }
  this.close = function(){
    $('body').find('#myModalSecond').remove();
  }

}
// Class Modal Box end -------------------------------------------------------------------------------------------------