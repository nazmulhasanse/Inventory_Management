/**
 * Declare ERPLIST Namespace if not exist
 */
var ERPLIST = ERPLIST || {};

$.extend(ERPLIST, {
  mUrl: 'api/server_api.php',
  mType: 'get',
  mData: '',
  mAsync: false,
  mReqType: '',
  queryData: '',
  queryParam: '',
  _searchParams: '',
  _URL_API: 'list_to_export_api.php',

  foo: 'here for no reason other than to be the last line, without a comma'
});


ERPLIST.applyCustomListCSS = function(){
  $('#listTable tr#searchForm input').css({
    'width':'95%',
    'min-width': '80px',
    'font-family':'Arial',
    'padding':'1px',
    'border':'1px solid #7F7F7F',
    'border-radius':'3px'
  });
  // Custom CSS if required
  $('#listTable td.lineentrytime').css({
    'white-space':'nowrap'
  });   

  $('#listTable td.Location').css({
    'min-width': '250px',
  }); 
  $('#listTable td.DyeSupplier').css({
    'min-width': '150px',
  });  
  $('#listTable td.YTEM').css({
    'min-width': '150px',
  }); 
  $('#listTable td.Composition').css({
    'min-width': '120px',
  }); 
  $('#listTable td.ItemDescription').css({
    'min-width': '700px',
  }); 
  
}




ERPLIST.makeTable = function(jsonData,hasData) {

  var data      = JSON.parse(jsonData);
  var mydata    = data['listData'];
  var pageNum   = parseInt(data['pageNum']-1);
  var showLimit = parseInt(data['showLimit']);
  var trDataId  = parseInt(pageNum * showLimit) + 1;


  //for composition column
  ERPLIST.compositeColumns = {

    // Buyer:{
    //   Buyer: {
    //     fielddesc: 'Buyer',
    //     islibrary: true,
    //     sql: "SELECT Description AS code, Description AS description FROM mrd_library WHERE LibraryName='Buyer'", 
    //     customsearch: true,
    //     composite: false,
    //     single: true,
    //     end: true
    //   }
    // }
    // docnumber:{
    //   docnumber: {
    //     style: 'font-weight:bold; color:blue',
    //     customsearch: true,
    //     single: true,
    //     end: true
    //   }
    // },
    // linenumber:{
    //   linenumber:{
    //     style: 'font-weight:bold; color:green',
    //     single: false,
    //     end: true        
    //   }
    // },

    // documentinformation : {
    //   linestatus:{
    //     style: 'font-weight:bold; color:green',
    //     customsearch: true,
    //     islibrary: true,
    //     datasource: {
    //       0: 'Entered',
    //       1: 'Running',
    //       2: 'Closed'
    //     },        
    //     fielddesc: 'Line Status',
    //     showsearchimg: true,
    //   },
    //   company:{
    //     style: 'font-weight:bold; color:green',
    //     islibrary: true,
    //     sql: "SELECT Code AS code, Description AS description FROM mrd_library WHERE LibraryName='company'", 
    //     customsearch: true,
    //     fielddesc: 'Company',
    //   },
    //   docdate:{
    //     fielddesc: 'Doc Date',
    //     customsearch: true,
    //     fielddesc: 'Document date',
    //     type: 'date',
    //     showsearchimg: true,
    //     end: true        
    //   }
    // },
    // formtype: {
    //   formtype:{
    //     single: true,
    //     end: true        
    //   }
    // },
    // itemspecification: {
    //   itemtype:{
    //     fielddesc: 'Item Type',
    //     style: 'font-weight:bold; color:green',
    //     islibrary: true,
    //     sql: "SELECT Code AS code, Description AS description FROM mrd_library WHERE LibraryName='itemtype_textile'",        
    //     customsearch: true,
    //     single: false
    //   },
    //   docstatus:{
    //     fielddesc: 'Doc Status',
    //     customsearch: true,
    //     single: false,
    //     end: true        
    //   }
    // },    

  }

  // some trickery for nice formatting
  var hideColumns = ['idlines', 'doctype','workorderdocnumber', 'Location', 'InternalLotNo'];

  var translationsHardCode = {};
  translationsHardCode.materiallistid = 'MLID';
  translationsHardCode.YarnType = 'Yarn Type';
  translationsHardCode.YarnEffect = 'Yarn Effect';
  translationsHardCode.ManufacturingProcess = 'Manufacturing Process';
  translationsHardCode.iduom = 'UoM';
  translationsHardCode.FFColor = 'Color Name';
  translationsHardCode.FFColorRef = 'Color Code';
  translationsHardCode.FDia = 'Fabric Width';
  translationsHardCode.DyeSupplier = 'Supplier';
  translationsHardCode.FunctionalProperties = 'Functional Properties';
  translationsHardCode.FabricDesignType = 'Fabric Design Type';
  translationsHardCode.ColorCode = 'Color Code';
  translationsHardCode.FabOpenTube = 'Fabric Open/Tube';
  translationsHardCode.CollarMeasurement = 'Collar Measurement';
  translationsHardCode.Count = 'Yarn Count';
  translationsHardCode.Batch = 'Supplier Lot No.';
  translationsHardCode.FFSKU = 'Full Item Code';
  translationsHardCode.InternalLotNo = 'Internal Lot No.';
  translationsHardCode.FabricTrackingNo = 'Fabric Tracking No.';
  translationsHardCode.RefNo = 'Master Ref No.';
  translationsHardCode.buyerpo = 'Buyer PO No.';
  translationsHardCode.ProjectNo = 'SO/Project No.';
  translationsHardCode.StockQty = 'On Hand Quantity';
  translationsHardCode.AllocatedQty = 'Allocated Quantity';
  translationsHardCode.OrderQty = 'Order Quantity';
  // translationsHardCode.StockQty = 'Stock Quantity';
  translationsHardCode.ReceiveQty = 'Received Quantity';
  translationsHardCode.IssueQty = 'Issued Quantity';
  translationsHardCode.PO = 'PO No/Style';
  translationsHardCode.POLineNumber = 'Internal PO Line No.';
  translationsHardCode.elementuom = 'Elem. UoM';
  translationsHardCode.docstatus = 'Document Status';
  translationsHardCode.documentinformation = 'Document Information';
  translationsHardCode.itemspecification = 'Item Specification';
  translationsHardCode.docnumber = 'Document';
  translationsHardCode.linestatus__company__docdate  = 'Document Information';

  ERPLIST.translationsHardCode = translationsHardCode;


  /**
   * builds the table header
   */
  var mydata_json = JSON.stringify(mydata);
  var firstRow = mydata[0];

  var firstRowCopy = firstRow;
  var compositeColumnsLength = Object.keys(ERPLIST.compositeColumns).length;
  var countVisibleColumn = 1; // here start from 1 cz first td for option


  var $table = $('<table border=1 id="listTable" class="listTable" />');
  var $thead = $('<thead />');
  var $tbody = $('<tbody/>');
  /**
  * first header row------------------------------------------------------------------------------------------------------------------------------------------------------------
  */
  // var $tr = ERPLIST.generateFirstHeaderTr(firstRowCopy, translationsHardCode);
  var $tr = $("<tr/>");
  // $td = $('<th/>');
  // $td.html('');
  // $td.appendTo($tr);

    $.each(firstRowCopy, function (fieldname, fieldvalue) {
    // for (var fieldname in firstRowCopy) {
      // var fieldvalue = firstRowCopy[fieldname];
      
      // search this field is in composite column
      // and assume that its not under in composite colums
      var groupName = '';
      var groupFields = {};
      var hasInCompositeColumn = false;
      if(compositeColumnsLength > 0){
        for (var groupName in ERPLIST.compositeColumns) {
          groupFields = ERPLIST.compositeColumns[groupName];
          for (var thisfieldname in groupFields) {
            if(thisfieldname == fieldname){
              hasInCompositeColumn = true;
              break;
            }
          }
          if(hasInCompositeColumn) break;
        }
      }

      // if have then procceed composite column
      if (hasInCompositeColumn) {
      // hide first
      $.each(groupFields, function(fieldname, fieldpropties){
        if(!!fieldpropties.single && fieldpropties.single == true) return;
        var fielddesc = fieldname;
        $td = $('<th/>');
        if (!!translationsHardCode[fieldname]) fielddesc = translationsHardCode[fieldname];
        $td.html('<center>'+ fielddesc +'</center>');
        $td.css('display','none');
        $td.appendTo($tr);

        delete firstRowCopy[fieldname]; // its already procceed
      });

      $td = $('<th/>');
      $td.attr('class', groupName);
      if (!!translationsHardCode[groupName]) groupName = translationsHardCode[groupName];
      $td.html('<center>'+ groupName +'</center>');
      $td.appendTo($tr);
      countVisibleColumn++;

      } else {

      countVisibleColumn++;
      var fielddesc = fieldname;
      $td = $('<th/>');
      if (!!translationsHardCode[fieldname]) fielddesc = translationsHardCode[fieldname];
      $td.html('<center>'+ fielddesc +'</center>');
      if ( hideColumns.indexOf(fieldname) >= 0 ){ $td.css('display','none'); countVisibleColumn--};
      $td.appendTo($tr);

      }

    // }  
    });
  $tr.appendTo($thead);
  $thead.appendTo($table);
  // end -----------------------------------------------------------------------------------------------------------------


  /**
  * second header row-----------------------------------------------------------------------------------------------------------------------------------------------------------
  */
  var $tr = $("<tr/>").attr("id","searchForm");
  var $td;
  // $td = $('<td/>');
  // $td.html('<center>Option</center>');
  // $td.appendTo($tr);

  var firstRowCopy = JSON.parse(mydata_json)[0];
    $.each(firstRowCopy, function (fieldname, fieldvalue) {
    // for (var fieldname in firstRowCopy) {
      // var fieldvalue = firstRowCopy[fieldname];
      
      // search this field is in composite column
      // and assume that its not under in composite colums
      var groupName = '';
      var groupFields = {};
      var hasInCompositeColumn = false;
      if(compositeColumnsLength > 0){
        for (var groupName in ERPLIST.compositeColumns) {
          groupFields = ERPLIST.compositeColumns[groupName];
          for (var thisfieldname in groupFields) {
            if(thisfieldname == fieldname){
              hasInCompositeColumn = true;
              break;
            }
          }
          if(hasInCompositeColumn) break;
        }
      }

      // if have then procceed composite column
      if (hasInCompositeColumn) {   
      var compositeClass = '';
      $td = $('<td/>');
      $td.attr('class', groupName);
      $.each(groupFields, function(fieldname, fieldpropties){

        compositeClass +=  ( !!fieldpropties.end) ? fieldname : fieldname + '__';          
        var customsearch_option = ( !!fieldpropties.showsearchimg) ?'<button type="button" onclick="ERPLIST.handleCustomSearch(this);"><img src="img/search_icon.png" alt="" height="15" width="15"></button>': '';
        var customsearch_click  = ( !!fieldpropties.customsearch) ?'onclick="ERPLIST.handleCustomSearch(this);"': 'onclick="ERPLIST.handleThisSearchInputFieldClick(this);"';
        var customsearch_class  = ( !!fieldpropties.customsearch ) ? '  hasCustomSearch' : '';

        var html = '<center><input type="text" name="'+ compositeClass +'" value="" id="'+compositeClass+'" class="'+compositeClass + customsearch_class +'" '+ customsearch_click +' />'+ customsearch_option +'</center><div id="'+compositeClass+'_displaySearchParams" style="background-color:white;"></div>';
        $td.html(html);

        delete firstRowCopy[fieldname]; // its already procceed
        if(!!fieldpropties.single && fieldpropties.single == true) return; // need to make one td in list
        $td_hide = $('<td/>');
        $td_hide.html('<center><input type="hidden" class="'+ fieldname +'" value="" id="'+fieldname+'" /></center>');
        $td_hide.css('display','none');
        $td_hide.appendTo($tr);

      });
      $td.appendTo($tr);    

      } else {

      var fielddesc = fieldname;
      $td = $('<td/>');
      $td.attr('class', fieldname);
      $td.html('<center><input type="text"  name="'+ fieldname +'" class="'+ fieldname +'" value="" id="'+fieldname+'" onclick="ERPLIST.handleThisSearchInputFieldClick(this);" /></center><div id="'+fieldname+'_displaySearchParams" style="background-color:white;"></div>');
      if ( hideColumns.indexOf(fieldname) >= 0 ) $td.css('display','none');
      $td.appendTo($tr);

      }

    // }  
    });
  $tr.find('td.System').html('');
  $tr.find('td.ReceiveQty').html('');
  $tr.find('td.IssueQty').html('');
  $tr.find('td.StockQty').html('');
  $tr.find('td.OrderQty').html('');
  
  $tr.appendTo($thead);
  $thead.appendTo($table);
  /**
  * second header row end -----------------------------------------------------------------------------------------------------------------------------------------------------------
  */


  if(hasData == 'no'){
    $thead.appendTo($table);
    //custom for no record found
    var $tr = $("<tr/>");
    var $td = $('<td/>').attr("colspan",countVisibleColumn);
    $td.html('No Data Found')
    .css({'text-align':'center','vertical-align':'middle'});
    $td.appendTo($tr);
    $tr.appendTo($table);
    return $table;
  }


  /**
  * populates with data--------------------------------------------------------------------------------------------------------------------------------------------------
  */
  var mydata = JSON.parse(mydata_json);
  $.each(mydata, function (index, value) {

    var $tr = $("<tr/>"); // it should be in here
    $tr.attr("data-id",trDataId);
    trDataId++;

    var thisRow = value;
    var thisRowCopy = thisRow;
    var thisRowCopy_Json =  JSON.stringify(thisRow);

    // retrive variable here which is needed
    var formtype = thisRow['formtype'];
    var linestatus = thisRow['linestatus'];

    // generate button if needed
    var btnLineChooser = '<center><input type="checkbox" class="multipleLineChooser" onclick="ERPLIST.handleLineChooserCheckboxClick(this);" ></center>';
    var btnThisLineAction = '';
    if(linestatus == 'Requisition Sent'){
      btnThisLineAction = '<button type="button" class="mbutton delete" onclick="ERPLIST.handleLineEvolutionBtnAction(this)">Cancel this line</button>';
    } else if(linestatus == 'Requisition Planned'){
      btnThisLineAction = '';
    }
    $td = $('<td/>');
    // $td.html(btnLineChooser);
    // $td.appendTo($tr);


      // looping over this row
      $.each(thisRow, function (fieldname, fieldvalue) {
      // for (var fieldname in firstRowCopy) {
        // var fieldvalue = firstRowCopy[fieldname];
        
        // search this field is in composite column
        // and assume that its not under in composite colums
        var groupName = '';
        var groupFields = {};
        var hasInCompositeColumn = false;
        if(compositeColumnsLength > 0){
          for (var groupName in ERPLIST.compositeColumns) {
            groupFields = ERPLIST.compositeColumns[groupName];
            for (var thisfieldname in groupFields) {
              if(thisfieldname == fieldname){
                hasInCompositeColumn = true;
                break;
              }
            }
            if(hasInCompositeColumn) break;
          }
        }

        // if have then procceed composite column
        if (hasInCompositeColumn) {

        $td = $('<td/>');
        $td.attr('class', groupName);
        $td.attr('fieldname', groupName);
        var compositeColumnsHTML = '';
        var divRow = '';
        $.each(groupFields, function(fieldname, fieldpropties){

          var fieldvalue = thisRow[fieldname];
          var fielddesc = (!!fieldpropties.fielddesc) ? fieldpropties.fielddesc : fieldname;
          var style = ( !!fieldpropties.style ) ? 'style="' + fieldpropties.style + '"': '';

          // *** write custom code here ---

          var obj_thisRowCopy_Json =  JSON.parse(thisRowCopy_Json);
          fieldvalue = (fieldname == "docnumber") ? "<a href='erpdocument.php?docnumber="+fieldvalue+"&doctype=T7&formtype="+formtype+"' target='_blank'>"+fieldvalue+"</a>" : fieldvalue;

          // *** custom code end ----------

          divRow += '<div class="crow" '+ '' +'>';
          if( (!!!fieldpropties.single) || (!!fieldpropties.single && fieldpropties.single == false) ){
            divRow += '<div class="ccell1 '+ fieldname +'" '+ style +'>'+ fielddesc +'</div>';
            divRow += '<div class="ccell2 '+ fieldname +'">:</div>';
          }
          divRow += '<div class="ccell3 '+ fieldname +'_ccell3" '+ style +'>'+ fieldvalue +'</div>';
          divRow += "</div>";

          delete thisRowCopy[fieldname]; // its already procceed
          if(!!fieldpropties.single && fieldpropties.single == true) return; // need to make one td in list
          $td_hide = $('<td/>');
          $td_hide.html(fieldvalue);
          $td_hide.attr("fieldname",fieldname);
          $td_hide.css('display','none');
          $td_hide.appendTo($tr);

        });

        var divTable = "<div id='ctable'>"; 
        divTable += divRow;  
        divTable += "</div>"; 

        compositeColumnsHTML = divTable;
        $td.html(compositeColumnsHTML)
        .css("cursor","pointer")
        .hover(
          function(){bgOn = $(this).closest("tr").css("background-color"); $(this).closest("tr").css("background-color", "lightblue");},
          function(){$(this).closest("tr").css("background-color", bgOn);}
        );
        $td.appendTo($tr);


        } else {

        // *** write custom code here ---
        fieldvalue = (fieldname == "docnumber") ? "<a href='erpdocument.php?docnumber="+fieldvalue+"&doctype=DR&formtype="+formtype+"&docviewflag=apparel' target='_blank'>"+fieldvalue+"</a>" : fieldvalue;
        // *** custom code end ----------

        $td = $('<td/>');
        $td.html(fieldvalue)
        .css("white-space","pre-wrap")
        .attr("fieldname",fieldname)
        .css("cursor","pointer")
        .hover(
          function(){bgOn = $(this).closest("tr").css("background-color"); $(this).closest("tr").css("background-color", "lightblue");},
          function(){$(this).closest("tr").css("background-color", bgOn);}
        );
        if ( hideColumns.indexOf(fieldname) >= 0 ) $td.css('display','none');
        $td.appendTo($tr);

        }

      // }  
      });

    // *** custom code start-----------------------------------------------------------------------------------------
    // $tr.find('td.requiredinformation').append(btnThisLineAction);
    // *** custom code end-------------------------------------------------------------------------------------------

      $tr.click( function() { 
          ERPLIST.sendBackSearchChoice($(this));
        })
        .appendTo($tbody);
    });

    $thead.appendTo($table)
    $tbody.appendTo($table)

    return $table;
};



/**
* Custom function code------------------------------------------------------------------------------------------------------
*/
ERPLIST.customFunction = function(argument) {
}



ERPLIST.initLibFieldsForSearch = function(){
  ERPLIST.libraryColumns = {
      linestatus:{
        style: 'font-weight:bold; color:green',
        customsearch: true,
        islibrary: true,
        datasource: {
            0: 'Entered',
            1: 'Running',
            2: 'Closed'
         },        
        fielddesc: 'Line Status',
        showsearchimg: true,
      },
    company: {
      fielddesc: 'Company',
      sql: "SELECT Code AS code, Description AS description FROM mrd_library WHERE LibraryName='company'",
    },
  };  
  return ERPLIST.libraryColumns;
}



ERPLIST.exportToExecl = function(){
  var searchParams = {};
  $('table#listTable thead tr#searchForm').each(function() {
    $(this).find("td input:text,select").each(function() {
      var textVal   = this.value.trim();
      var inputName = $(this).attr("name");
      var tagName   = $(this).prop("tagName");

      // if inputName is undefined then assume its combobox 
      if(inputName == undefined) return;
      // try to retrive name by closest select tag
      if(!!ERPLIST.libraryColumns[inputName]){
          if(textVal == '______'){ // define for empty
            textVal = "";
          }
      }
      if(textVal != ""){
        searchParams[inputName] = textVal;
      }            
    });
  });
// return encodeURIComponent(key) + '=' + encodeURIComponent(params[key]);
  var qrystr = $.param( searchParams );
  var expURL = '/erp-apparel/list_to_export_api.php?reqType=exportListData&' + qrystr;
  window.open(expURL);
}