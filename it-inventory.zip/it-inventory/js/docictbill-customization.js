/**
 * Declare the namespace LIZERP if not existent
 */
var LIZERP = LIZERP || {};

$.extend(LIZERP, {
  _ERP_DOCACRONYM: '',
  _FIELDSETS_HEADER: ['fieldset_documentinformation', 'fieldset_logisticsinformation'],
  _FIELDS_AUTOFILLUP: ['ldcslnumber'],
  _FIELDSETS_RIGHTFORM: ['fieldset_linegroup1','fieldset_linegroup2','fieldset_linegroup3','fieldset_linegroup4','fieldset_linegroup5'],

  foo: 'here for no reason other than to be the last line, without a comma'
});


LIZERP.changeDocStatus = function(docnumber, docstatus){
  var searchParams = {};
  searchParams.docnumber = docnumber;
  searchParams.docstatus = docstatus;
  searchParams.reqType = 'changeDocStatus';
  return $.post(LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM], searchParams, changeDocStatus_return(), 'json');

  function changeDocStatus_return(extraParams) {
    return function(data, textStatus, jqXHR) {
      if (data.result == 'success') {
        location.reload();
      } else {
        alert(data.errormsgs.join('\n'));
      }
    }
  }

}









/**
 * [handleLookup description]
 * @param  {[type]} thisPtr [description]
 * @return {[type]}         [description]
 * ============================================================================== All Loupe List Work =================================================================================
 */
LIZERP.handleLookup = function(thisPtr){
  var fieldname = $(thisPtr).closest('div').find('input, select').prop('name');
  if(fieldname == 'project'){
    LIZERP.loupeListProjectCode(thisPtr);
    // LIZERP.handleSearchForm('designid');
  } else if(fieldname == 'itemcode'){
      LIZERP.loupeListItemCode(thisPtr);

  }else if(fieldname == 'pricerequisitionnumber'){
    LIZERP.loupeListPriceInquiry();
  }  else {
  }
  
}



LIZERP.loupeListItemCode = function(thisPtr) {
  var prepopulate = {};

  // prepopulate.ItemName = 'Ram';
  // prepopulate.ItemName = $(LIZERP.formId + '#rightFormLines #lg_itemname').find('select,input').val();
  prepopulate.ItemName        = $(thisPtr).closest('fieldset').find('select#lg_itemname').val();
  prepopulate.ItemNature      = $(thisPtr).closest('fieldset').find('select#lg_itemnature').val();
  prepopulate.Brand           = $(thisPtr).closest('fieldset').find('select#lg_brand').val();
  prepopulate.ColorCode       = $(thisPtr).closest('fieldset').find('select#lg_color').val();
  prepopulate.Size            = $(thisPtr).closest('fieldset').find('input#lg_sizeormeasurement').val();
  prepopulate.ItemDescription = $(thisPtr).closest('fieldset').find('textarea#lg_itemdescription').val();



  var prepopJS = (Object.keys(prepopulate).length > 0) ? 'var prepopulate = ' + JSON.stringify(prepopulate) + ';' : '';
  prepopJS = prepopJS + "var ERPLIST = ERPLIST || {};";
  prepopJS = prepopJS + "$(document).ajaxStop(function() {";
  prepopJS = prepopJS + "ERPLIST.sendBackSearchChoice = function( thisRow ) {";
  prepopJS = prepopJS + "var ItemName = $(thisRow).find('td[fieldname=ItemName]').text();";
  prepopJS = prepopJS + "var ItemNature = $(thisRow).find('td[fieldname=ItemNature]').text();";
  prepopJS = prepopJS + "var Brand = $(thisRow).find('td[fieldname=Brand]').text();";
  prepopJS = prepopJS + "var ColorCode = $(thisRow).find('td[fieldname=ColorCode]').text();";
  prepopJS = prepopJS + "var Size = $(thisRow).find('td[fieldname=Size]').text();";
  prepopJS = prepopJS + "var ItemDescription = $(thisRow).find('td[fieldname=ItemDescription]').text();";
  prepopJS = prepopJS + "var ItemCode = $(thisRow).find('td[fieldname=ItemCode]').text();";
  // prepopJS = prepopJS + "alert(ItemCode);";

  prepopJS = prepopJS + "  $.fancybox.close();";

  prepopJS = prepopJS + "  $('#rightFormLines select').removeClass('select2');";
  prepopJS = prepopJS + "  $(LIZERP.formId + '#rightFormLines #lg_itemcode').val(ItemCode);";
  prepopJS = prepopJS + "  $(LIZERP.formId + '#rightFormLines #lg_itemname').val(ItemName);";
  prepopJS = prepopJS + "  $(LIZERP.formId + '#rightFormLines #lg_itemnature').val(ItemNature);";
  prepopJS = prepopJS + "  $(LIZERP.formId + '#rightFormLines #lg_brand').val(Brand);";
  prepopJS = prepopJS + "  $(LIZERP.formId + '#rightFormLines #lg_color').val(ColorCode);";
  prepopJS = prepopJS + "  $(LIZERP.formId + '#rightFormLines #lg_sizeormeasurement').val(Size);";
  prepopJS = prepopJS + "  $(LIZERP.formId + '#rightFormLines #lg_itemdescription').val(ItemDescription);";
  prepopJS = prepopJS + "  $(LIZERP.formId + '#rightFormLines #lg_itemcode').focus();";
  prepopJS = prepopJS + "  $('#rightFormLines').find('#lg_brand').select2();";
  prepopJS = prepopJS + "  $('#rightFormLines').find('#lg_color').select2();";
  prepopJS = prepopJS + "  $('#rightFormLines').find('#lg_itemname').select2();";
  prepopJS = prepopJS + "  $('#rightFormLines').find('#lg_itemnature').select2();";

  // prepopJS = prepopJS + "  $(LIZERP.formId + '#unitprice').val(acceptedprice);";
  prepopJS = prepopJS + "};";
  prepopJS = prepopJS + "});";

  var content = '<div id="popupListContent">\
    <div id="loadingDiv">\
      <center><img src="/images/loading_spinner.gif"></center>\
    </div>\
  </div>';
  content+= '<script> ' + prepopJS + '</script>'; // add some js

  $.fancybox({
    type: 'html',
    content: content,
    minWidth: 500,
    minHeight: 300,
    afterLoad: function(){
      this.title = "<b>Item Code List</b>";
    },    
    afterShow: function() {
      loadSessionContent();
      $.fancybox.update();
    },
    helpers: {
     title : {
      type : 'inside',
      position : 'top'
     },
     overlay : {
      css  : { /* 'background-color' : '#fff' */}
     }     
    }  
  });
  jQuery('.fancybox-title').css({'text-align':'center', 'margin-bottom':'10px'});

  function loadSessionContent(){
    $.ajax({
      async: false,
      type: 'get',
      url: '/erp-nonpo/list-pr-itemcode-session.php',
      success: function(htmlContent) {
        $('#popupListContent').empty().append(htmlContent);
        var searchParams = (Object.keys(prepopulate).length > 0) ? prepopulate : {};
        //                  show,   page,   api_url
        ERPLIST.getListData(50,   1,    ERPLIST._URL_API, searchParams);
        updateFancyBox();
      }
    }).fail(function(e) {
      alert('Loading failed, please try again.');
    });
  }

  function updateFancyBox(){
    $(document).ajaxStop(function() {
      // place code to be executed on completion of 
      // last outstanding ajax call here
      // this is needed// because ajax call is asyncronus
      $.fancybox.update(); 
    });
  }

}







LIZERP.initHead = function(){


  // LIZERP.searchHeaderInfo();

}




LIZERP.readMode = function() {
  $(LIZERP.formId).find(' #formLines tr.new').remove();
  $(LIZERP.formId).find(' #formLines tr').unbind('mouseenter mouseleave');
  $(LIZERP.formId).find('input,select,textarea').attr('disabled', 'disabled');
  $(LIZERP.formId).find(' input[type=button]').removeAttr('disabled');

  $('#rightFormLines').css('display', 'none');
  $('.editLine').css('display', 'none');
  $('.copyAndNewLine').css('display', 'none');

  $('#fieldset_systeminformation').css('display', 'block');
  $(' .btnEditMode ').css('display', 'none');
  $(' .btnReadMode ').css('display', 'inline-block');
  $(' .datepicker').unmousewheel();
  $(LIZERP.formId).find(' #formLines tr .fileAttachmentContainer').css('display', 'block');
  $(LIZERP.formId).find(' #fieldset_documentfile .fileAttachmentContainer').css('display', 'block');
  


  var docStatus = $(LIZERP.formId).find('#docstatus').val();

  if(docStatus == "0"){ 
    $(LIZERP.formId + ' .btnAmend ').css('display', 'none');
  }
  


  LIZERP.formMode = 'read';
  LIZERP.viewMode();
}



LIZERP.viewMode = function(){
  var params = paramsToObj(window.location.search);
  if(params.flag == 'view'){
    $('input[type=button]').addClass('btndisabled');
    $('button[type=button]').addClass('btndisabled');
    $(' .btndisabled ').css('display', 'none');
    $('.fileInputContainer').css('display','none');

    $('.btnPrintSheet').css('display','block');
  }

}





/**
 * Save form via ajax after validation
 */
 LIZERP.saveForm = function(flag) {
  // tries to save the line if it's dirty
  if ((LIZERP.lineIsDirty == true) || ($(LIZERP.formId + ' #formLines tr.editable:not(.new)').length > 0)) {
    $('#formLines input[type=text]:visible').closest('tr').find('.saveLine').first().click();
  }

  // change data to actual uppercase from just css transform
  $(LIZERP.formId).find('input,textarea').each(function(i) {
    if ($(this).css('text-transform') == 'uppercase') $(this).val($(this).val().toUpperCase());
  });

  // run validation on all header fields
  var error = false;
  for (i in LIZERP._FIELDSETS_HEADER) {
    error = error || LIZERP.validateFormContainerFields(LIZERP.formId + ' #' + LIZERP._FIELDSETS_HEADER[i]);
  }

  var error;
  // if no lines have been added, don't continue
  var validLines = $(LIZERP.formId + ' #formLines #fieldset_lineinformation tbody tr.valid').length;
  if (validLines == 0) {
    error = true;
    LIZERP.showFormError('Please provide at least one valid line information.');
  }

  // If all data is validated, then submit
  if (!error && LIZERP.formMode == 'edit') {
    // just to avoid re-entry, the server should also check for double submission
    LIZERP.readMode();

    /* Prepare JSON */
    var jsonData = {
      'lines': []
    };
    $.each(LIZERP.formFieldSettings['header'], function(fieldName, attributes) {

      if(attributes['html_InputTag'] == 'checkbox'){
        if(!!attributes['groupname']){
          $('.'+attributes['groupname'] ).each(function() {
            if($(this).prop('checked')){
             var checkboxid = $(this).prop('id');
             var text    = $('label[for='+ checkboxid +']').text();
             jsonData[fieldName] = text;
              // var or_this = $('#pre-payment').next('label').text();
              // var selectedVal = $(this).closest('label').text();
              // <input type="checkbox" name="PrePayment" value="Pre-Payment">Pre-Payment<br />
              // $(input).attr('value');
            } 
          });

        } else {
          jsonData[fieldName] = $(LIZERP.formId + ' #' + fieldName).prop("checked") ? 1 : 0;
        }
      } else {
        jsonData[fieldName] = $(LIZERP.formId + ' #' + fieldName).val();
      }
    });

    $(LIZERP.formId + ' #formLines #fieldset_lineinformation tbody tr.valid').each(function() {
      var fieldList = [];
      // Build field list from the visible form
      $('#formLines #fieldset_lineinformation tr th').each(function(e) {
        if (!!$(this).attr('class')) fieldList.push($(this).attr('class'));
      });
      // Build field list from the formFieldSettings variable
      // $.each( LIZERP.formFieldSettings['lines'], function( fieldName, attributes ) {
      //     fieldList.push( fieldName );
      // } );

    LIZERP.formFieldSettings_OBJ = JSON.parse(LIZERP.formFieldSettings_JSON)
    var allowFormLineFields = Object.keys(LIZERP.formFieldSettings_OBJ['lines']);
    var formLine = {};
    for (index in fieldList) {
      formField = fieldList[index];
      if(allowFormLineFields.indexOf(formField) == -1){
        continue;
      }

      var isGroupCheckBox = (formField.indexOf('groupcheckbox') > -1) ? true : false;

      formLine[formField] = $(this).find('td.' + formField).find('input,textarea,select').first().val();
      
    }
    jsonData['lines'].push(formLine);
  });




/* Submit via ajax */
var postData = {
  reqType: 'saveDoc',
  docobj: JSON.stringify(jsonData)
};


    // add iddocument in case this is an Edit
    if ($(LIZERP.formId + ' #docnumber').val().length > 0) postData.docnumber = $(LIZERP.formId + ' #docnumber').val();
    console.log(postData);
    




    $.ajax({
      type: 'post',
      url: LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM],
      //dataType: 'json',/* if the return data is json */
      data: postData,
      success: function(data) {
          // if result is JSON, we're using the new API return format
          console.log(data);
          data = JSON.parse(data);
          if (!!data.errormsgs && data.errormsgs.length > 0) {
            console.log(data.errormsgs.join('\n'));
            alert("===>"+data.errormsgs.join('\n'));
            LIZERP.editMode();
          } else {
            var params = paramsToObj(window.location.search);
            // if(data.createdocheader == 'yes' && params.docflag != 'createcapacityplan'){
              if(!!flag && flag == 'autoLineFill_Save_Edit'){
                var next_href = window.location.origin + window.location.pathname + '?doctype=' + LIZERP._ERP_DOCACRONYM  + '&docnumber=' + data.docnumber + '&autoLineFill_Save_Edit=yes';
                window.location.href = next_href;
              } else {
                var params = paramsToObj(window.location.search);
                var next_href = window.location.origin + window.location.pathname + '?doctype=' + LIZERP._ERP_DOCACRONYM + '&docnumber=' + data.docnumber;
                window.location.href = next_href;
              }
            }
          }
        }).fail(function(e) {
          alert('Saving failed, please try again.');
          LIZERP.editMode();
        });
      }
      return;
    }




/**
 * Save a line
 */
 LIZERP._saveLine = function(line) {
  // edit = 1 if we're trying to save because we clicked on an edit button of another line
  if(!!line){
    var $tr2 = LIZERP.getLineBeingEdited(line);
  } else {
    // line not defined
    // so its a new line, add new line
    if ($(LIZERP.formId + ' #formLines tr.valid.new').length == 0) {
      LIZERP.addLine();
      var $tr2 = LIZERP.getLineBeingEdited();
      $tr2.removeClass('editable new').addClass('valid new'); // new added by Mamun
    }
    var $tr2 = LIZERP.getLineBeingEdited();
  }

  // run validation on all right form fields
  var error = false;
  for (i in LIZERP._FIELDSETS_RIGHTFORM) {
    error = error || LIZERP.validateFormContainerFields('#rightFormLines #' + LIZERP._FIELDSETS_RIGHTFORM[i]);
  }
  if(error){
    alert('Required Field must have value.');
    return 0;
  } 
  
  /**
   * Passing Value right div to left div
   * Take header data
   */
   var lineData = {};

   $.each(LIZERP.formFieldSettings['header'], function(fieldName, attributes) {
    if(attributes['html_InputTag'] == 'checkbox'){
      if(!!attributes['groupname']){
        $('.'+attributes['groupname'] ).each(function() {
          if($(this).prop('checked')){
           var checkboxid = $(this).prop('id');
           var text    = $('label[for='+ checkboxid +']').text();
           lineData[fieldName] = text;
         } 
       });
      } else {
        lineData[fieldName] = $(LIZERP.formId + ' #' + fieldName).prop("checked") ? 1 : 0;
      }
    } else {
      lineData[fieldName] = $(LIZERP.formId + ' #' + fieldName).val();
    }
  });


   $("#rightFormLines").find('.select2').removeClass('select2');
  /**
   *Take Line Data
   */
   var formFieldSettings = LIZERP.formFieldSettings['lines'];
   $.each(formFieldSettings, function(fieldName, attributes) {

    if(attributes['html_InputTag'] == 'checkbox'){

      if(!!attributes['groupname']){
        $('.'+attributes['groupname'] ).each(function() {
          if($(this).prop('checked')){
           var checkboxid = $(this).prop('id');
           var text    = $('label[for='+ checkboxid +']').text();
         } 
       });
      } else {
        var val = $(LIZERP.formId + ' #lg_' + fieldName).prop("checked") ? 'Yes' : 'No';
      }

    } else {
      var value = $(LIZERP.formId + ' #lg_' + fieldName).val();
      if(!value) value = "";
      lineData[fieldName] = value;
    }


  });

  /**
   * show process overlay*/
  // LIZERP.showProcessinOverlay(); 
  /*
   *
   **/

  // alert(JSON.stringify(lineData));
  // post line data in api
  var postdata = {};
  postdata.line = JSON.stringify(lineData);

  // console.log(postdata.line);
  // return;
  postdata.reqType = '_saveLine';
  $.post(LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM], postdata, postLineData_results);

  function postLineData_results(data, textStatus, jqXHR) {

    // console.log(data);
    // return;

    data = JSON.parse(data);
    var lines = data.lines;
    delete data.lines;

    var headerObj = data;
    var linesObj = lines;
    
    // console.log(linesObj);
    if(data.isApprove == 'No'){
      alert("You cann't insert special value except these , - / # + into these field Item Color, Shade No., Elastic Code, Item Description.");
      return;
    }

    /**
     * for first time doc create
     */
     if(headerObj['doccreate'] == 'yes'){
      for (var key in headerObj) {
        if (key.substr(0, 1) == "_") {
          LIZERP.dbAuxData[key.substr(1)] = headerObj[key]
          continue;
        }
        $('#' + key).filter('input,select,textarea').val(headerObj[key]);
        if(key == "docnumber"){$('span#span' + key).text(headerObj[key]);}
        else if(key == 'docstatus'){
          $(LIZERP.formId +' #' + key).val(headerObj[key]);
          $(LIZERP.formId).find('span#span' + key).text(LIZERP.formFieldSettings['docstatus'][headerObj[key]]); 
        }
        else {$('span#' + key).text(headerObj[key]);}
      }
      // add docnumber in URL
      var currURL = window.location.pathname + window.location.search + '&docnumber=' + headerObj['docnumber'];
      window.history.pushState('', 'Title', currURL);
    }


    var fieldList = [];
    var requiredCols = [];
    $('#formLines #fieldset_lineinformation table tr th')
    .each(function(e) {
      if (!!$(this).attr('class')) fieldList.push($(this).attr('class'));
    });
    // remove from array, this field is not user-entered
    // fieldList.splice(fieldList.indexOf('idlines'), 1)

    /**
     * Putting value in line input field
     */
     for (var j = 0; j < fieldList.length; j++) {
      // if (!!linesObj[0][fieldList[j]] && linesObj[0][fieldList[j]].length > 0) {

      // if (!!linesObj[0][fieldList[j]] ) {
        $tr2.find('td.' + fieldList[j]).find('input,textarea,select').val(linesObj[0][fieldList[j]]);
      // }
    }

    /**
     * Take line input field object
     */
     var $lineFields = {};
     for (key in fieldList) {
      $lineFields[fieldList[key]] = $tr2.find('.' + fieldList[key]).find('input,select,textarea');
    }

    /**
     * Show this line field value to span
     */
     var error = false;
     if (!error) {

      for (key in fieldList) {  


        // if(fieldList[key] == 'linestatus'){
        //   $tr2.find('td.' + fieldList[key]).find('span').text(LIZERP.formFieldSettings['linestatus'][$lineFields[fieldList[key]].val()]);
        // } else {
        //   $tr2.find('.' + fieldList[key]).find('span').text($lineFields[fieldList[key]].val());
        // }   

        if ($lineFields[fieldList[key]].prop('tagName') == 'SELECT') {
          var selectedvalue = $lineFields[fieldList[key]].find('option:selected').text();

          if (selectedvalue != 'Select') {
            $tr2.find('.' + fieldList[key]).find('span').text(selectedvalue);
          } else {
            $tr2.find('.' + fieldList[key]).find('span').text('');
          }
        } else if(fieldList[key] == 'linestatus'){
          $tr2.find('.' + fieldList[key]).find('span').text(LIZERP.formFieldSettings['linestatus'][$lineFields[fieldList[key]].val()]);
        } else {

          $tr2.find('.' + fieldList[key]).find('span').text($lineFields[fieldList[key]].val());

        } 

      }
      $tr2.find('textarea').parent().find('span').css('white-space', 'pre-wrap');
      $tr2.removeClass('editable new').addClass('valid');

      LIZERP.handleFormLinesTrClick();
      LIZERP.cancelLine();

    }

    if (line == 1) {

  /**
   * remove processing overlay */
  // LIZERP.removeProcessingOverlay(); 
  /*
   *
   **/

      return error;
    }

  /**
   * remove processing overlay */
  // LIZERP.removeProcessingOverlay(); 
  /*
   *
   **/

  }

}


/**
 * Save a line and new
 */
 LIZERP._saveLineAndNew = function(line) {
  // edit = 1 if we're trying to save because we clicked on an edit button of another line
  if(!!line){
    var $tr2 = LIZERP.getLineBeingEdited(line);
  } else {
    // line not defined
    // so its a new line, add new line
    if ($(LIZERP.formId + ' #formLines tr.valid.new').length == 0) {
      LIZERP.addLine();
      var $tr2 = LIZERP.getLineBeingEdited();
      $tr2.removeClass('editable new').addClass('valid new'); // new added by Mamun
    }
    var $tr2 = LIZERP.getLineBeingEdited();
  }
  

  /**
   * Passing Value right div to left div
   * Take header data
   */
   var lineData = {};

   $.each(LIZERP.formFieldSettings['header'], function(fieldName, attributes) {
    if(attributes['html_InputTag'] == 'checkbox'){
      if(!!attributes['groupname']){
        $('.'+attributes['groupname'] ).each(function() {
          if($(this).prop('checked')){
           var checkboxid = $(this).prop('id');
           var text    = $('label[for='+ checkboxid +']').text();
           lineData[fieldName] = text;
         } 
       });
      } else {
        lineData[fieldName] = $(LIZERP.formId + ' #' + fieldName).prop("checked") ? 1 : 0;
      }
    } else {
      lineData[fieldName] = $(LIZERP.formId + ' #' + fieldName).val();
    }
  });


  /**
   *Take Line Data
   */
   var formFieldSettings = LIZERP.formFieldSettings['lines'];
   $.each(formFieldSettings, function(fieldName, attributes) {

    if(attributes['html_InputTag'] == 'checkbox'){

      if(!!attributes['groupname']){
        $('.'+attributes['groupname'] ).each(function() {
          if($(this).prop('checked')){
           var checkboxid = $(this).prop('id');
           var text    = $('label[for='+ checkboxid +']').text();
         } 
       });
      } else {
        var val = $(LIZERP.formId + ' #lg_' + fieldName).prop("checked") ? 'Yes' : 'No';
      }

    } else {
      var value = $(LIZERP.formId + ' #lg_' + fieldName).val();
      if(!value) value = "";
      lineData[fieldName] = value;
    }

  });

  // alert(JSON.stringify(lineData));
  // post line data in api

  var postdata = {};
  postdata.line = JSON.stringify(lineData);
  postdata.reqType = '_saveLine';
  $.post(LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM], postdata, postLineData_results);

  function postLineData_results(data, textStatus, jqXHR) {

    data = JSON.parse(data);
    var lines = data.lines;
    delete data.lines;

    var headerObj = data;
    var linesObj = lines;

    /**
     * for first time doc create
     */
     if(headerObj['doccreate'] == 'yes'){
      for (var key in headerObj) {
        if (key.substr(0, 1) == "_") {
          LIZERP.dbAuxData[key.substr(1)] = headerObj[key]
          continue;
        }
        $('#' + key).filter('input,select,textarea').val(headerObj[key]);
        if(key == "docnumber"){$('span#span' + key).text(headerObj[key]);}
        else if(key == 'docstatus'){
          $(LIZERP.formId +' #' + key).val(headerObj[key]);
          $(LIZERP.formId).find('span#span' + key).text(LIZERP.formFieldSettings['docstatus'][headerObj[key]]); 
        }
        else {$('span#' + key).text(headerObj[key]);}
      }
      // add docnumber in URL
      var currURL = window.location.pathname + window.location.search + '&docnumber=' + headerObj['docnumber'];
      window.history.pushState('', 'Title', currURL);
    }


    var fieldList = [];
    var requiredCols = [];
    $('#formLines #fieldset_lineinformation table tr th')
    .each(function(e) {
      if (!!$(this).attr('class')) fieldList.push($(this).attr('class'));
    });
    // remove from array, this field is not user-entered
    // fieldList.splice(fieldList.indexOf('idlines'), 1)
    // fieldList.splice(fieldList.indexOf('linenumber'), 1)

    /**
     * Putting value in line input field
     */
     for (var j = 0; j < fieldList.length; j++) {
      if (!!linesObj[0][fieldList[j]] && linesObj[0][fieldList[j]].length > 0) {
        $tr2.find('td.' + fieldList[j]).find('input,textarea,select').val(linesObj[0][fieldList[j]]);
      }
    }

    /**
     * Take line input field object
     */
     var $lineFields = {};
     for (key in fieldList) {
      $lineFields[fieldList[key]] = $tr2.find('.' + fieldList[key]).find('input,select,textarea');
    }

    /**
     * Show this line field value to span
     */
     var error = false;
     if (!error) {

      for (key in fieldList) {  
        if(fieldList[key] == 'linestatus'){
          $tr2.find('td.' + fieldList[key]).find('span').text(LIZERP.formFieldSettings['linestatus'][$lineFields[fieldList[key]].val()]);
        } else {
          $tr2.find('.' + fieldList[key]).find('span').text($lineFields[fieldList[key]].val());
        }   
      }
      $tr2.find('textarea').parent().find('span').css('white-space', 'pre-wrap');
      $tr2.removeClass('editable new').addClass('valid');

      LIZERP.handleFormLinesTrClick();
      // LIZERP.cancelLine();

    }

    if (line == 1) {
      return error;
    }


  }


}


LIZERP.editMode = function(formWhere) {


  if ($(' #formLines tr.editable').length == 0){
    LIZERP.addLine();
    // $tr2.removeClass('editable new').addClass('valid new');
  }

  $(LIZERP.formId + ' #formLines tr').hover(function(e) {
    $(this).find('.div_editButton').css('display', 'block');
  }, function(e) {
    $(this).find('.div_editButton').css('display', 'none');
  });
  $(LIZERP.formId).find('input,select,textarea').removeAttr('disabled');
  LIZERP.lockCreateOnlyFields();
  $('#fieldset_systeminformation').css('display', 'none');
  $(' .btnEditMode ').css('display', 'inline-block');
  $(' .btnReadMode ').css('display', 'none');


  var $tr2 = LIZERP.getLineBeingEdited();
  if(formWhere == 'nodoc' || formWhere == 'eee'){

    $tr2.removeClass('editable new').addClass('valid new'); // new added by Mamun
    $(LIZERP.formId).find('.saveLine').attr('disabled', 'disabled');
    $(LIZERP.formId).find('.saveLineAndNew').attr('disabled', 'disabled');

    $(LIZERP.formId).find('.copyAndNewLine').attr('disabled', 'disabled');
    $(LIZERP.formId).find('.removeLine').attr('disabled', 'disabled');
    $(LIZERP.formId).find('.btnCancelDocLine').attr('disabled', 'disabled');

  } 

  LIZERP.controlLineButtons();
    // added 2017-05-03
  $(LIZERP.formId).find('#formLinesButtonsBr').empty();

  LIZERP.formMode = 'edit';


  console.log('\n\n ***edit mode called');

  LIZERP.lockAutoFillupFields();
}



LIZERP.controlLineButtons = function(){
  // $(LIZERP.formId + ' .newLine').css('display', 'none');
  // $(LIZERP.formId + ' .saveLineAndNew').css('display', 'none');
  // $(LIZERP.formId + ' .copyAndNewLine').css('display', 'none');
  // $(LIZERP.formId + ' .removeLine').css('display', 'none');
}



LIZERP.editMode_clickFromUpperBtn = function() {

  $(LIZERP.formId + ' #formLines tr').hover(function(e) {
    $(this).find('.div_editButton').css('display', 'block');
  }, function(e) {
    $(this).find('.div_editButton').css('display', 'none');
  });
  $(LIZERP.formId).find('input,select,textarea').removeAttr('disabled');
  LIZERP.lockCreateOnlyFields();
  $(LIZERP.formId + '#fieldset_systeminformation').css('display', 'none');
  $(LIZERP.formId + ' .btnEditMode ').css('display', 'inline-block');
  $(LIZERP.formId + ' .btnReadMode ').css('display', 'none');

  $(LIZERP.formId).find('.saveLine').attr('disabled', 'disabled');
  $(LIZERP.formId).find('.saveLineAndNew').attr('disabled', 'disabled');

  $(LIZERP.formId).find('.copyAndNewLine').attr('disabled', 'disabled');
  $(LIZERP.formId).find('.removeLine').attr('disabled', 'disabled');
  $(LIZERP.formId).find('.btnCancelDocLine').attr('disabled', 'disabled');
  
  LIZERP.controlLineButtons();
  // added 2017-05-03
  $(LIZERP.formId).find('#formLinesButtonsBr').empty().append('<br/>');

  LIZERP.formMode = 'edit';
  LIZERP.lockHeaderFieldsUsingLineStatus();
}



LIZERP.lockHeaderFieldsUsingLineStatus = function(){
  $('#fieldset_lineinformation table tbody tr').each(function(){
    var linestatus = $(this).closest('tr').find('td.linestatus span').text();

    $('#fieldset_documentinformation').find('#suppliername').attr('disabled','disabled');
    $('#fieldset_documentinformation').find('#supplieraddress').attr('disabled','disabled');
  });
}



/**
 * Locks all fields that are auto fillup
 */
LIZERP.lockAutoFillupFields = function() {
  var fieldList = LIZERP._FIELDS_AUTOFILLUP;
  for (field in fieldList) {
    console.log('--------------->' + fieldList[field]);
    $(LIZERP.formId).find('input,textarea,select').filter('#' + fieldList[field]).attr('disabled', 'disabled');
  }

}



/**
 * Remove a line
 * @param line
 */
LIZERP.removeLine = function(line) {
  var idlines           = $(LIZERP.formId).find('input#lg_idlines').val();
  if (confirm('Are you sure to delete line ' + line + '?')) {
    $(LIZERP.formId + ' #formLines tr[data-id="' + line + '"]').remove();
    LIZERP.removePOLine(idlines);
    LIZERP.cancelLine();
  }
}

LIZERP.removePOLine = function(idlines) {

      var postData = {
        reqType: 'removePOLine',
        idlines: idlines
       };
      $.ajax({
        type: 'post',
        url: 'docprels_api.php',
        data: postData,
        success: function(data) {
            data = JSON.parse(data);
            if (!!data.errormsgs && data.errormsgs.length > 0) {
              console.log(data.errormsgs.join('\n'));
              alert("===>"+data.errormsgs.join('\n'));
            } else {
              // parent.location.reload(true);
            }
        }
      }).fail(function(e) {
        alert('Assign failed, please try again.');
      });
}

LIZERP.renameFieldSet = function(){
	$('#rightFormLines #fieldset_linegroup1').find('legend').text('Line Info');
    $('#rightFormLines #fieldset_linegroup2').find('legend').text('Company Info');
    $('#rightFormLines #fieldset_linegroup3').find('legend').text('Invoice Info');
    $('#rightFormLines #fieldset_linegroup4').find('legend').text('Amount Info');
}

LIZERP.initRightFormLines = function() {
    $(LIZERP.formId + ' #rightFormLines').find('#lg_company').attr('disabled','disabled');
    $(LIZERP.formId + ' #rightFormLines').find('#lg_description').attr('disabled','disabled');

    $(LIZERP.formId).find('input#lg_vatpercent')
    .focus(function() {
        valAtFocus = $(this).val();
    })
    .blur(function() {
        LIZERP.amountCalculation();
    });    

    $(LIZERP.formId).find('input#lg_discountpercent')
    .focus(function() {
        valAtFocus = $(this).val();
    })
    .blur(function() {
        LIZERP.amountCalculation();
    });

    $(LIZERP.formId).find('input#lg_quantity')
    .focus(function() {
        valAtFocus = $(this).val();
    })
    .blur(function() {
        LIZERP.amountCalculation();
    });    
}

LIZERP.amountCalculation = function() {

    var vatpercent = $(LIZERP.formId + ' #rightFormLines #lg_vatpercent').val();
    var discountpercent = $(LIZERP.formId + ' #rightFormLines #lg_discountpercent').val();
    var quantity = $(LIZERP.formId + ' #rightFormLines #lg_quantity').val();
    var unitprice = $(LIZERP.formId + ' #rightFormLines #lg_unitprice').val();
    var servicecharge = $(LIZERP.formId + ' #rightFormLines #lg_servicecharge').val();
    var tdspercent = $(LIZERP.formId + ' #rightFormLines #lg_tdspercent').val();

    if(vatpercent == '' || vatpercent == null || !$.isNumeric(vatpercent)){ vatpercent = '5'}
    if(discountpercent == '' || discountpercent == null || !$.isNumeric(discountpercent)){ discountpercent = '0'}
    if(tdspercent == '' || tdspercent == null || !$.isNumeric(tdspercent)){ tdspercent = '10'}
    if(unitprice == '' || unitprice == null || !$.isNumeric(unitprice)){ unitprice = '0'}
    if(servicecharge == '' || servicecharge == null || !$.isNumeric(servicecharge)){ servicecharge = '0'}
    if(quantity == '' || quantity == null || !$.isNumeric(quantity)) return;

    var price = quantity * unitprice;
    var netprice = price + parseInt(servicecharge);
    
    var payamountpercent = 100 - discountpercent;
    if(discountpercent == '0.00' || discountpercent == '0'){
        var amountexcludingvat = netprice;  
    } else{
        var amountexcludingvat = netprice * (payamountpercent / 100); 
    }
    var vatamount = amountexcludingvat * (vatpercent/100);
    var tdsamount = amountexcludingvat * (tdspercent/100);
    vatamount = Math.round(vatamount);
    tdsamount = Math.round(tdsamount);
    amountexcludingvat = Math.round(amountexcludingvat);
    var netamount = amountexcludingvat - tdsamount;
    var finalamount = amountexcludingvat + vatamount;
    var amount = (100 * finalamount) / payamountpercent;
    amount = Math.round(amount);
    var discountamount = amount * (discountpercent/100);    
    discountamount = Math.round(discountamount);

    $(LIZERP.formId + ' #rightFormLines #lg_amount').val(amount);
    $(LIZERP.formId + ' #rightFormLines #lg_amountexcludingvat').val(amountexcludingvat);
    $(LIZERP.formId + ' #rightFormLines #lg_vatamount').val(vatamount);
    $(LIZERP.formId + ' #rightFormLines #lg_tdsamount').val(tdsamount);
    $(LIZERP.formId + ' #rightFormLines #lg_discountamount').val(discountamount);
    $(LIZERP.formId + ' #rightFormLines #lg_netamount').val(netamount);
    $(LIZERP.formId + ' #rightFormLines #lg_finalamount').val(finalamount);

}


LIZERP.newLine = function(){
  $('#rightFormLines').css('display', 'block');
  LIZERP.adjustLineFormInterface();
  LIZERP.cleanLineEntryForm();
  LIZERP.initRightFormLines();

  $(LIZERP.formId).find('.saveLine').removeAttr('disabled');
  $(LIZERP.formId).find('.saveLineAndNew').removeAttr('disabled');

  $(LIZERP.formId).find('.copyAndNewLine').attr('disabled', 'disabled');
  $(LIZERP.formId).find('.removeLine').attr('disabled', 'disabled');
  $(LIZERP.formId).find('.btnCancelDocLine').attr('disabled', 'disabled');

  delete LIZERP.newLineNumber;
  delete LIZERP.clickLineStatus;
  // it will take from table tr length
  // so delete it which is one step above now
  $(LIZERP.formId + ' #rightFormLines').find('input,select,textarea').removeAttr('disabled');

}




/**
* Auto URL fillup document line
*/
//  $.when.apply($, populatePromises).then(function() {
//   var params = jsClient.paramsToObj(window.location.search); 
//   var idlines = params.idlines;
//   if(!!idlines){
//     LIZERP.isgetPOLineInfo = true; 
//     LIZERP.getPOLineInfo();
//     LIZERP.getSOInfo();
//   } else {
//     LIZERP.isgetPOLineInfo = false;
//   }    
// });



 

LIZERP.prDeleteLine = function(idlines){
    var line = LIZERP.currentLineNumber;
    if(LIZERP.clickLineStatus == 'Released' || LIZERP.clickLineStatus == 'Closed'){
      alert('This PR line cannot be deleted as PO already created.');
      return;
    }

    if (confirm('Are you sure to delete line ' + line + '?')) {
        var searchParams = {};
        searchParams.idlines = idlines;
        searchParams.reqType = 'deletePRLine';
        return $.post(LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM], searchParams, deletePRLine_return(), 'json');

        function deletePRLine_return(extraParams) {
            return function(data, textStatus, jqXHR) {
              console.log(data);
              if (data.result == 'success') {
                $(LIZERP.formId + ' #formLines tr[data-id="' + line + '"]').remove();
                LIZERP.cancelLine();
                // location.reload();
              } else if (data.isApprove == 'No') {
                alert('This PR line cannot be deleted as PO already created.')
              } else {
                alert(data.errormsgs.join('\n'));
              }
            }
        }
    }
}

LIZERP.handleFormLinesTrClick = function(){
  $(LIZERP.formId + ' #formLines table tbody tr').click(function(e) {
      e.stopPropagation();
      var $this = $(this);
      $(LIZERP.formId + ' #formLines table tbody tr').removeClass('clicked');
      $this.addClass('clicked');
      var trNum = $this.closest('tr').data('id');

      var linestatus = $this.closest('tr').find('td.linestatus span').text();

      LIZERP.cleanLineEntryForm();

      if(LIZERP.formMode == 'read') return;
      if(LIZERP.formMode == 'edit'){
        if(! $(LIZERP.formId + ' #rightFormLines').is(":visible") ){
            $('#rightFormLines').css('display', 'block');
            LIZERP.adjustLineFormInterface();

              $(LIZERP.formId).find('.saveLine').removeAttr('disabled');
              $(LIZERP.formId).find('.saveLineAndNew').removeAttr('disabled');

            if ($(LIZERP.formId + ' #formLines tr.valid.new').length > 0) {
              /* User wishes to edit a saved line and a new line exists and is editable. So remove the new line */
              $(LIZERP.formId + ' #formLines tr.new').remove();
            }

        }
      }
      LIZERP.clickLineNum = trNum;
      LIZERP.currentLineNumber = trNum;
      LIZERP.newLineMode = false;
      LIZERP.editLineMode = true;
      LIZERP.currentLineidlines = $this.closest('tr').find('td.idlines input').val();

      LIZERP.clickLineStatus = linestatus;

      $(LIZERP.formId).find('.copyAndNewLine').removeAttr('disabled');
      $(LIZERP.formId).find('.removeLine').removeAttr('disabled');
      $(LIZERP.formId).find('.btnCancelDocLine').removeAttr('disabled');

      console.log('Current line--->' +  LIZERP.clickLineNum);
      // $('#rightFormLines select').removeClass('select2');
      LIZERP.setThisLineDataInRightFormLines(trNum);
      $(LIZERP.formId + ' #rightFormLines #dragbar').css({'background-color': '#D6EAF8'});
      // alert("TR ID " + trNum);
      // var tdid = $this.find('td[data-id]').data('id');
      // alert("TD ID " + tdid);  
  });
}

LIZERP.setThisLineDataInRightFormLines = function(line){
  var $tr2 = LIZERP.getLineBeingEdited(line);
  var fieldsWithData = 0;
  var lineData = {};
  $('#rightFormLines select').removeClass('select2');
  $tr2.find('input,textarea,select')
    .each(function(index, element) {
      if ($(element).attr('type') == "button") return;
      if ( !!$(element).val() && $(element).val().trim().length > 0){
       fieldsWithData++;
       // var keyName = $(element).attr('name');
       // var myString = "abcdefg";
       // var newString = myString.substr(2); 
       // newString is now "cdefg"
       // var keyName = keyName.substr(9);
       // var myString = "abcdefg";
       // var newString = myString.substr(0, myString.length-4); 
       // newString is now "abc"
       var keyName = $(element).closest('td').attr('class');
       lineData[keyName] = $(element).val();
      }
    });

  if(fieldsWithData == 0) return;  

  $.each(lineData, function(key, value){
    $(LIZERP.formId + ' #rightFormLines #lg_'+key).val(value);
  });


  $("#rightFormLines").find("#lg_itemtype").select2();
  LIZERP.initRightFormLines();
}


LIZERP.copyAndNewLine = function(){

  $(LIZERP.formId).find('.copyAndNewLine').attr('disabled', 'disabled');

  LIZERP.newLineMode = true;
  LIZERP.editLineMode = false;
  delete LIZERP.currentLineNumber;
  delete LIZERP.newLineNumber; // 2017-01-31 added

  $(LIZERP.formId + ' #rightFormLines #lg_idlines').val('');
  $(LIZERP.formId + ' #rightFormLines #lg_itemcode').val('');
  $(LIZERP.formId + ' #formLines table tbody tr').removeClass('clicked');
  $(LIZERP.formId + ' #rightFormLines #dragbar').css({'background-color': 'black'});        
  $(LIZERP.formId + ' #rightFormLines').find('input,select,textarea').removeAttr('disabled');

}


$.extend(LIZERP, {
  /**
   * Start up function
   * @description Any JS code to be run on start up
   * @returns {undefined}
   */



   init: function() {
    /* executable JS */
    return;
  },
  enableRead: function() {
    LIZERP.readMode();
    return;
  },
  enableEdit: function() {
    LIZERP.editMode();
    return;
  },
  enableReceive: function() {
    LIZERP.receiveMode();
    return;
  },

  /**
   * Process Purchase Request Form
   * @param selector formId
   * @returns {undefined}
   */
   processForm: function(purchaseFormId, _ERP_DOCACRONYM, _URL_DOCUMENTAPI, _URL_DOCDEFINEAPI) {
    LIZERP.formId = purchaseFormId + ' ';
    LIZERP.formMode = 'edit';
    LIZERP._ERP_DOCACRONYM = _ERP_DOCACRONYM;
    LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM] = _URL_DOCUMENTAPI;
    LIZERP._URL_DOCDEFINEAPI[LIZERP._ERP_DOCACRONYM] = _URL_DOCDEFINEAPI;
    if(!LIZERP.newLineNumber) LIZERP.newLineNumber = 1;

    var populatePromises = [];
    populatePromises.push(LIZERP.populateDropdown('suppliername', 'ict_billing_supplier','', 'codevalequal'));
        populatePromises.push(LIZERP.populateDropdown('division', 'ict_billing_division','', 'codevalequal'));
    populatePromises.push(LIZERP.populateDropdown('lg_division', 'ict_billing_division', '', 'codevalequal'));


    $.when.apply($, populatePromises).then(function() {
      // Caches the HTML of a new line
      LIZERP.lineHTML_template = $('#fieldset_lineinformation table tr[data-id=1]')[0].outerHTML;
      LIZERP.adjustLineFormInterface();
    });

    LIZERP.handle_docdate_field();
    /* Show/Hide/Enable/Disable fields on document load */
    populatePromises.push(LIZERP.handleFormFields('create'));
    $.when.apply($, populatePromises).then(function() {}); 

    // Change line legend name
    $('#fieldset_documentinformation legend').text('Header');
    $('#formLines #legend').text('Purchase Line');





    LIZERP.initHead();
    LIZERP.initLine(); // Enables functionality of the Line entry
    LIZERP.editMode();      


    $(window).keydown(function(e) {
      if (e.ctrlKey || e.metaKey) {
        switch (String.fromCharCode(e.which).toLowerCase()) {
          case 's':
          e.preventDefault();
          $(LIZERP.formId + ' .btnSaveForm').click();
          break;
        }
      }
    });



    $(LIZERP.formId + ' .btnSaveForm').on('click', function(e) {
      e.preventDefault();
      LIZERP.saveForm();
    });     

    $(LIZERP.formId + ' .btnCancelForm').on('click', function(e) {
      e.preventDefault();
      var params = paramsToObj(window.location.search);
      if (!!params.docnumber) location.reload();
    });
    $(' .btnEnterEditMode').on('click', function(e) {
      e.preventDefault();
      LIZERP.editMode_clickFromUpperBtn();
      LIZERP.editLineMode = true;
      LIZERP.newLineMode = false;
    });

$(LIZERP.formId + ' .btnSendToTextile').on('click', function(e) {
  e.preventDefault();
  LIZERP.sendToTextile();
});


    // $(LIZERP.formId + ' .btnConfirmation').on('click', function(e) {
    //   e.preventDefault();
    //   LIZERP.reviewAndApproveDoc(LIZERP.docobj);
    // });
    
    $(LIZERP.formId + ' .btnPrintSheet').on('click', function(e) {
      e.preventDefault();
      var params = paramsToObj(window.location.search);
      window.open('printdoc-po.php?doctype=' + params.doctype + '&formtype='+params.formtype+'&docnumber=' + params.docnumber);
    });

    // $(LIZERP.formId + ' .btnChangeDocStatus').on('click', function(e) {
    //   e.preventDefault();
    //   var params = paramsToObj(window.location.search);
    //   var r = confirm('Click OK to close this document.');
    //   if(!r) return;
    //   LIZERP.changeDocStatus(params.docnumber, '1');
    // });

$(LIZERP.formId + ' .btnSendRequest').on('click', function(e) {
  e.preventDefault();
  var params = paramsToObj(window.location.search);
  if (!params.docnumber) {
    alert('Error: iddocument not available. Please contact system.support@lizfashion.com.');
    return;
  }
  if (confirm('Click OK to send to request')) LIZERP.changeDocStatus(params.docnumber, '1');
});



$(LIZERP.formId + ' .btnAmend').on('click', function(e) {
  e.preventDefault();
  var params = paramsToObj(window.location.search);
  if (!params.docnumber) {
    alert('Error: iddocument not available. Please contact system.support@lizfashion.com.');
    return;
  }
  if (confirm('Click OK to Amend the PO')) LIZERP.poAmendment(params.docnumber, '0');
});


$(LIZERP.formId + ' .btnAutoRevised').on('click', function(e) {
  e.preventDefault();
  var params = paramsToObj(window.location.search);
  if (!params.docnumber) {
    alert('Error: iddocument not available. Please contact system.support@lizfashion.com.');
    return;
  }
  if (confirm('Click OK to PO Revised auto update')) LIZERP.updateRevisedPO(params.docnumber);
});

$(LIZERP.formId + ' .btnFileAttachment').on('click', function(e) {
  e.preventDefault();
  LIZERP.fileAttachmentMode();
});


$(LIZERP.formId + ' .btnCopyAndNew').on('click', function(e) {
  e.preventDefault();
  var params = paramsToObj(window.location.search);
  window.open(window.location.origin + window.location.pathname + '?docnumber=' + params.docnumber + '&doctype=' + params.doctype + '&formtype='+params.formtype+"&docflag=copyandnew" );
});

$(LIZERP.formId + ' .btnInformApparelPlanner').on('click', function(e) {
  e.preventDefault();
  // LIZERP.approvePreviewDoc();
  LIZERP.reviewAndApproveDoc(LIZERP.docobj);
  // var params = paramsToObj(window.location.search);
  // if (confirm('Are you sure to Inform Apparel Planner?')) LIZERP.changeDocStatus(params.docnumber, '2');
});


$(LIZERP.formId + ' .newLine').on('click', function(e) {
  e.preventDefault();
  $(LIZERP.formId).find('.newLine').attr('disabled', 'disabled');
  LIZERP.newLineMode = true;
  LIZERP.editLineMode = false;
  LIZERP.newLine();
});

$(LIZERP.formId + ' .saveLine').on('click', function(e) {
  e.preventDefault();
  if(!!LIZERP.currentLineNumber && LIZERP.editLineMode && !LIZERP.newLineMode){

    flag = LIZERP._saveLine(LIZERP.currentLineNumber);
  } else {

    flag = LIZERP._saveLine();
  }
  if(flag == '0') return;
  LIZERP.cleanLineEntryForm();
  LIZERP.handleFormLinesTrClick();
  $(LIZERP.formId).find('.newLine').removeAttr('disabled');

});

$(LIZERP.formId + ' .saveLineAndNew').on('click', function(e) {
  e.preventDefault();
  if(!!LIZERP.currentLineNumber && LIZERP.editLineMode && !LIZERP.newLineMode){

    LIZERP.newLineMode = true;
    LIZERP.editLineMode = false;

    LIZERP._saveLineAndNew(LIZERP.currentLineNumber);
  } else {

    LIZERP._saveLineAndNew();
  }
  LIZERP.cleanLineEntryForm();
  LIZERP.handleFormLinesTrClick();
});

$(LIZERP.formId + ' .copyAndNewLine').on('click', function(e) {
  e.preventDefault();
  LIZERP.copyAndNewLine();

});

$(LIZERP.formId + ' .cancelLine').on('click', function(e) {
  e.preventDefault();
  LIZERP.cancelLine();

      // save form in  db
      // LIZERP.saveForm();
    });

$(LIZERP.formId + ' .removeLine').on('click', function(e) {
  e.preventDefault();
  if(!!!LIZERP.currentLineNumber) return;
  LIZERP.prDeleteLine(LIZERP.currentLineidlines);
  // LIZERP.removeLine(LIZERP.currentLineNumber);
});


$(LIZERP.formId + ' .btnCancelDocLine').on('click', function(e) {
  e.preventDefault();
  if(!!!LIZERP.currentLineidlines) return;
  if (confirm('Click OK to Cancel the PR Line')) LIZERP.prCancelLine(LIZERP.currentLineidlines);
});


$(LIZERP.formId + ' .btnParentPO').on('click', function(e) {
  e.preventDefault();
  LIZERP.showParentPO();
});

// LIZERP.initHead();
//     LIZERP.initLine(); // Enables functionality of the Line entry
//     LIZERP.editMode();

    // If the page was called with a document ID, try to read the record
    var params = paramsToObj(window.location.search);
    if (!!params.docnumber) {
      var searchParams = {
        'reqType': 'readDoc',
        'docnumber': params.docnumber
      };
      $.when.apply($, populatePromises).then(function() {
        $.get(LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM], searchParams, populateFromDb);
      });

    } else {
        LIZERP.editMode('nodoc');
        $.when.apply($, populatePromises).then(function() {
          /**
          * remove processing overlay */
          LIZERP.removeProcessingOverlay_2(); /*
          *
          **/
        });
    }

    function populateFromDb(data, textStatus, jqXHR) {
      // alert(data);
      LIZERP.docobj = data;
      data = JSON.parse(data);
      var lines = data.lines;
      delete data.lines;
      if (Object.keys(data).length > 0) {
        $.when.apply($, populatePromises).then(function() {
          LIZERP.editMode('populateFromDb');
          LIZERP.fillForm(data, lines);
          LIZERP.updateFormTitle('read');
          LIZERP.readMode();
          LIZERP.handleFormLinesTrClick();
          LIZERP.checkCopyAndNewDocFlag();  
          LIZERP.autoLineFill_Save_Edit();  
          $(LIZERP.formId + ' .btnFileAttachment').css('display', 'none');  
          // LIZERP.autoRevisedPO();     
          window.scrollTo(0, 0);

          /**
          * remove processing overlay */
          LIZERP.removeProcessingOverlay_2(); /*
          *
          **/

        });
      } else {
        LIZERP.editMode();
        alert('Document not found.');
      }
    }

    /**
     * Auto URL fillup document header
     * Auto URL fillup document line
     *
     * this for all library data populate 
     */
    $.when.apply($, populatePromises).then(function() {
      // when all things are populate, then call
      // LIZERP.autoFillup_byURLParams();
      // LIZERP.checkItemCodeAndAutoFill();
      LIZERP.renameFieldSet();

    });

    /**
     * LIZERP.autoFillup_afterPopulateFromDb();
     */




     return;
   }
 });