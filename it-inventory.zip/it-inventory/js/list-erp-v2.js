  // ***** All Function *****

  // jsClient.paginationCSS();
  // ERPLIST.applyCustomListCSS();
  // ERPLIST.changeTempleteCSS();
  // ERPLIST.initList();


/**
 * Check if jQuery is loaded
 */
if (!window.jQuery) {
  var jq = document.createElement('script');
  jq.type = 'text/javascript';
  jq.src = '/js/jquery-2.1.3.min.js';
  document.getElementsByTagName('head')[0].appendChild(jq);
}
/**
 * Declare ERPLIST Namespace if not exist
 */
var ERPLIST = ERPLIST || {};

$.extend(ERPLIST, {
  mUrl: 'api/server_api.php',
  mType: 'get',
  mData: '',
  mAsync: false,
  mReqType: '',
  queryData: '',
  queryParam: '',
  _searchParams: '',
  _sessionCall: false,  
  populateLibCache:[],
  libraryColumns: {},
  _URL_API: 'list-yourname-v2_api.php',

  foo: 'here for no reason other than to be the last line, without a comma'
});


/**
 * How to use 
 * just call this function
 */
ERPLIST.initSearchAction = function(){
    $('#searchForm input').keypress(function (event) {
        if (event.which == 13) {
            ERPLIST.getSearchData();        
        }
    });
}

ERPLIST.checkAndRetriveSearchData = function(){
    var searchParams = {};
    $('table#listTable thead tr').each(function() {
        $(this).find("td input:text,select").each(function() {
            textVal = this.value;
            inputName = $(this).attr("name");
            if(textVal != "" && !!inputName ){
              searchParams[inputName] = textVal;
            }
        });
    });
    return searchParams;
}

ERPLIST.getSearchData = function(){
    var searchParams = {};
    $('#listDiv table#listTable thead tr').each(function() {
        $(this).find("td input:text,select").each(function() {
            textVal = this.value;
            inputName = $(this).attr("name");
            if(textVal != ""){
              searchParams[inputName] = textVal;
            }            
        });
    });

    ERPLIST._searchParams = JSON.stringify(searchParams);
    //                  show,   page,   api_url search_param
    ERPLIST.getListData(50,   1,    '',   searchParams);
}


/**
 * [getListData description]
 * @param  {[type]} numRecords   [description]
 * @param  {[type]} pageNum      [description]
 * @param  {[type]} apiURL       [description]
 * @param  {[type]} searchParams [description]
 * @return {[type]}              [description]
 *
 * fetching records =========================================================================================================
 */
ERPLIST.getListData = function(numRecords, pageNum, apiURL, searchParams) {

  var numRecords = (!!numRecords && numRecords != '') ? numRecords : '10';
  var pageNum    = (!!pageNum && pageNum != '') ? pageNum : '10';
  var apiURL     = (!!apiURL && apiURL != '') ? apiURL : ERPLIST._URL_API;

  if(!!!searchParams){
    // check search field value is exist 
    // user may click in pagination page after search
    searchParams = ERPLIST.checkAndRetriveSearchData();
  }
  var searchParams = (!!searchParams && Object.keys(searchParams).length > 0)? searchParams : {};

  var inputPlusUrlSearchParams = {};
  $.each(searchParams, function(key, val){
    inputPlusUrlSearchParams[key] = val; // push input search param
  });

  searchParams['showLimit'] = numRecords;
  searchParams['pageNum'] = pageNum;
  searchParams['reqType'] = 'getListData';

  var urlSearchParams = (!ERPLIST._sessionCall) ? jsClient.paramsToObj(window.location.search) : {}
  if( Object.keys(urlSearchParams).length > 0 ){
      // var inputSearchParams = (!!ERPLIST._searchParams && ERPLIST._searchParams.length > 0) ? JSON.parse(ERPLIST._searchParams) : {};
    // var inputPlusUrlSearchParams = (Object.keys(inputSearchParams).length > 0) ? inputSearchParams : {};
    $.each(urlSearchParams, function(key, val){
      searchParams[key] = val; // push url search data in search param object
      inputPlusUrlSearchParams[key] = val; // push url search data in search param object
    });
  }
  if( Object.keys(inputPlusUrlSearchParams).length > 0 ){
    ERPLIST._searchParams = JSON.stringify(inputPlusUrlSearchParams);
  }

    $.ajax({
      type: "GET",
      url: apiURL,
      data: searchParams,
      cache: false,
      beforeSend: function() {
          $('#loadingDiv').html('<center><img src="/images/loading_spinner.gif"></center>');
      },
      success: function(jsonData) {
        $('#loadingDiv').html('');
          var parseData = JSON.parse(jsonData);
          ERPLIST.displayQueryData(jsonData);

          // if(!!ERPLIST._searchParams){
          //   ERPLIST.setPriviousSearchParams(ERPLIST._searchParams);
          // }
      }
    });

}




ERPLIST.displayQueryData = function(jsonData){

  var pagination = jsClient.makePagination(jsonData)

  var data = JSON.parse(jsonData);
  var hasData = (data.noResult) ? 'no' : 'yes';
  var listTable = ERPLIST.makeTable(jsonData, hasData);

  $("#listDiv").html(pagination);
  $("#listDiv").append(listTable);

  ERPLIST.initSearchAction();

  /**
   * Css
   */
  $('#listTable').css({
    'width':'100%'
  });
  $('#listTable tr#searchForm button').css({
    'padding':'2px',
    'border':'1px solid #7F7F7F',
    'border-radius':'3px',
    'vertical-align': 'middle'
  });  
  $('#listTable .hasCustomSearch').css({
    'width':'70%'
  });
  jsClient.paginationCSS();
  ERPLIST.applyCustomListCSS();
  ERPLIST.changeTempleteCSS();

  ERPLIST.initList();

}

ERPLIST.applyCustomListCSS = function(){
  $('#listTable tr#searchForm input').css({
    'width':'95%',
    'min-width': '100px',
    'font-family':'Arial',
    'padding':'2px',
    'border':'1px solid #7F7F7F',
    'border-radius':'3px'
  });
  // Custom CSS if required
  $('#listTable td.lineentrytime').css({
    'white-space':'nowrap'
  }); 
}


ERPLIST.generateFirstHeaderTr = function(){
	return $tr;
}


ERPLIST.makeTable = function(jsonData,hasData) {

	var data   = JSON.parse(jsonData);
	var mydata = data['listData'];
	var pageNum      = parseInt(data['pageNum']-1);
	var showLimit    = parseInt(data['showLimit']);
	var trDataId = parseInt(pageNum * showLimit) + 1;
	// console.log(pageNum + '  ' +showLimit);


	//for composition column
	ERPLIST.compositeColumns = {
		docnumber:{
		  docnumber: {
		    style: 'font-weight:bold; color:blue',
		    customsearch: true,
		    single: true,
		    end: true
		  }
		},
		linenumber:{
		  linenumber:{
		    style: 'font-weight:bold; color:green',
		    single: false,
		    end: true        
		  }
		},

		documentinformation : {
		  linestatus:{
		    style: 'font-weight:bold; color:green',
		    customsearch: true,
		    islibrary: true,
		    datasource: {
		      0: 'Entered',
		      1: 'Running',
		      2: 'Closed'
		    },        
		    fielddesc: 'Line Status',
		    showsearchimg: true,
		  },
		  company:{
		    style: 'font-weight:bold; color:green',
		    islibrary: true,
		    sql: "SELECT Code AS code, Description AS description FROM mrd_library WHERE LibraryName='company'", 
		    customsearch: true,
		    fielddesc: 'Company',
		  },
		  docdate:{
		    fielddesc: 'Doc Date',
		    customsearch: true,
		    fielddesc: 'Document date',
		    type: 'date',
		    showsearchimg: true,
		    end: true        
		  }
		},
		formtype: {
		  formtype:{
		    single: true,
		    end: true        
		  }
		},
		itemspecification: {
		  itemtype:{
		    fielddesc: 'Item Type',
		    style: 'font-weight:bold; color:green',
		    islibrary: true,
		    sql: "SELECT Code AS code, Description AS description FROM mrd_library WHERE LibraryName='itemtype_textile'",        
		    customsearch: true,
		    single: false
		  },
		  docstatus:{
		    fielddesc: 'Doc Status',
		    customsearch: true,
		    single: false,
		    end: true        
		  }
		},    

	}

	// some trickery for nice formatting
	var hideColumns = ['idlines', 'doctype','workorderdocnumber'];

	var translationsHardCode = {};
	translationsHardCode.iduom = 'UoM';
	translationsHardCode.elementuom = 'Elem. UoM';
	translationsHardCode.docstatus = 'Document Status';
	translationsHardCode.documentinformation = 'Document Information';
	translationsHardCode.itemspecification = 'Item Specification';
	translationsHardCode.docnumber = 'Document';
	translationsHardCode.linestatus__company__docdate  = 'Document Information';

	ERPLIST.translationsHardCode = translationsHardCode;


	/**
	 * builds the table header
	 */
	var mydata_json = JSON.stringify(mydata);
	var firstRow = mydata[0];

	var firstRowCopy = firstRow;
	var compositeColumnsLength = Object.keys(ERPLIST.compositeColumns).length;
	var countVisibleColumn = 1; // here start from 1 cz first td for option


	var $table = $('<table border=1 id="listTable" class="listTable" />');
	var $thead = $('<thead />');
	var $tbody = $('<tbody/>');
	/**
	* first header row------------------------------------------------------------------------------------------------------------------------------------------------------------
	*/
	// var $tr = ERPLIST.generateFirstHeaderTr(firstRowCopy, translationsHardCode);
	var $tr = $("<tr/>");
	$td = $('<th/>');
	$td.html('');
	$td.appendTo($tr);

  	$.each(firstRowCopy, function (fieldname, fieldvalue) {
  	// for (var fieldname in firstRowCopy) {
  		// var fieldvalue = firstRowCopy[fieldname];
  		
  		// search this field is in composite column
  		// and assume that its not under in composite colums
  		var groupName = '';
  		var groupFields = {};
  		var hasInCompositeColumn = false;
  		if(compositeColumnsLength > 0){
  			for (var groupName in ERPLIST.compositeColumns) {
  				groupFields = ERPLIST.compositeColumns[groupName];
  				for (var thisfieldname in groupFields) {
  					if(thisfieldname == fieldname){
  						hasInCompositeColumn = true;
  						break;
  					}
  				}
  				if(hasInCompositeColumn) break;
  			}
  		}

  		
  		if (hasInCompositeColumn) { 	// if have then procceed composite column
			// hide first
			$.each(groupFields, function(fieldname, fieldStyle){
				var fielddesc = fieldname;
				$td = $('<th/>');
				if (!!translationsHardCode[fieldname]) fielddesc = translationsHardCode[fieldname];
				$td.html('<center>'+ fielddesc +'</center>');
				$td.css('display','none');
				$td.appendTo($tr);

				delete firstRowCopy[fieldname]; // its already procceed
			});

			$td = $('<th/>');
			$td.attr('class', groupName);
			if (!!translationsHardCode[groupName]) groupName = translationsHardCode[groupName];
			$td.html('<center>'+ groupName +'</center>');
			$td.appendTo($tr);
			countVisibleColumn++;

  		} else {						//procceed normal column

			countVisibleColumn++;
			var fielddesc = fieldname;
			$td = $('<th/>');
			if (!!translationsHardCode[fieldname]) fielddesc = translationsHardCode[fieldname];
			$td.html('<center>'+ fielddesc +'</center>');
			if ( hideColumns.indexOf(fieldname) >= 0 ){ $td.css('display','none'); countVisibleColumn--};
			$td.appendTo($tr);

  		}

  	// }	
  	});
	$tr.appendTo($thead);
	$thead.appendTo($table);
	// end -----------------------------------------------------------------------------------------------------------------


	/**
	* second header row-----------------------------------------------------------------------------------------------------------------------------------------------------------
	*/
	var $tr = $("<tr/>").attr("id","searchForm");
	var $td;
	$td = $('<td/>');
	$td.html('<center>Option</center>');
	$td.appendTo($tr);

	var firstRowCopy = JSON.parse(mydata_json)[0];
  	$.each(firstRowCopy, function (fieldname, fieldvalue) {
  	// for (var fieldname in firstRowCopy) {
  		// var fieldvalue = firstRowCopy[fieldname];
  		
  		// search this field is in composite column
  		// and assume that its not under in composite colums
  		var groupName = '';
  		var groupFields = {};
  		var hasInCompositeColumn = false;
  		if(compositeColumnsLength > 0){
  			for (var groupName in ERPLIST.compositeColumns) {
  				groupFields = ERPLIST.compositeColumns[groupName];
  				for (var thisfieldname in groupFields) {
  					if(thisfieldname == fieldname){
  						hasInCompositeColumn = true;
  						break;
  					}
  				}
  				if(hasInCompositeColumn) break;
  			}
  		}


  		if (hasInCompositeColumn) {		// if have then procceed composite column
			var compositeClass = '';
			$td = $('<td/>');
			$td.attr('class', groupName);
			$.each(groupFields, function(fieldname, fieldpropties){

				compositeClass +=  ( !!fieldpropties.end) ? fieldname : fieldname + '__';          
				var customsearch_option = ( !!fieldpropties.showsearchimg) ?'<button type="button" onclick="ERPLIST.handleCustomSearch(this);"><img src="img/search_icon.png" alt="" height="15" width="15"></button>': '';
				var customsearch_click  = ( !!fieldpropties.customsearch) ?'onclick="ERPLIST.handleCustomSearch(this);"': 'onclick="ERPLIST.handleThisSearchInputFieldClick(this);"';
				var customsearch_class  = ( !!fieldpropties.customsearch ) ? '  hasCustomSearch' : '';

				var html = '<center><input type="text" name="'+ compositeClass +'" value="" id="'+compositeClass+'" class="'+compositeClass + customsearch_class +'" '+ customsearch_click +' />'+ customsearch_option +'</center><div id="'+compositeClass+'_displaySearchParams" style="background-color:white;"></div>';
				$td.html(html);

				delete firstRowCopy[fieldname]; // its already procceed
				if(!!fieldpropties.single && fieldpropties.single == true) return; // need to make one td in list
				$td_hide = $('<td/>');
				$td_hide.html('<center><input type="hidden" class="'+ fieldname +'" value="" id="'+fieldname+'" /></center>');
				$td_hide.css('display','none');
				$td_hide.appendTo($tr);

			});
			$td.appendTo($tr);		

  		} else {

			var fielddesc = fieldname;
			$td = $('<td/>');
			$td.attr('class', fieldname);
			$td.html('<center><input type="text"  name="'+ fieldname +'" class="'+ fieldname +'" value="" id="'+fieldname+'" onclick="ERPLIST.handleThisSearchInputFieldClick(this);" /></center><div id="'+fieldname+'_displaySearchParams" style="background-color:white;"></div>');
			if ( hideColumns.indexOf(fieldname) >= 0 ) $td.css('display','none');
			$td.appendTo($tr);

  		}

  	// }	
  	});

	$tr.appendTo($thead);
	$thead.appendTo($table);
	/**
	* second header row end -----------------------------------------------------------------------------------------------------------------------------------------------------------
	*/


	if(hasData == 'no'){
		$thead.appendTo($table);
		//custom for no record found
		var $tr = $("<tr/>");
		var $td = $('<td/>').attr("colspan",countVisibleColumn);
		$td.html('No Data Found')
		.css({'text-align':'center','vertical-align':'middle'});
		$td.appendTo($tr);
		$tr.appendTo($table);
		return $table;
	}


	/**
	* populates with data--------------------------------------------------------------------------------------------------------------------------------------------------
	*/
	var mydata = JSON.parse(mydata_json);
	$.each(mydata, function (index, value) {

		var $tr = $("<tr/>"); // it should be in here
		$tr.attr("data-id",trDataId);
		trDataId++;

		var thisRow = value;
		var thisRowCopy = thisRow;
		var thisRowCopy_Json =  JSON.stringify(thisRow);

		// retrive variable here which is needed
		var formtype = thisRow['formtype'];
		var linestatus = thisRow['linestatus'];

		// generate button if needed
		var btnLineChooser = '<center><input type="checkbox" class="multipleLineChooser" onclick="ERPLIST.handleLineChooserCheckboxClick(this);" ></center>';
		var btnThisLineAction = '';
		if(linestatus == 'Requisition Sent'){
			btnThisLineAction = '<button type="button" class="mbutton delete" onclick="ERPLIST.handleLineEvolutionBtnAction(this)">Cancel this line</button>';
		} else if(linestatus == 'Requisition Planned'){
			btnThisLineAction = '';
		}
		$td = $('<td/>');
		$td.html(btnLineChooser);
		$td.appendTo($tr);


	    // looping over this row
	  	$.each(thisRow, function (fieldname, fieldvalue) {
	  	// for (var fieldname in firstRowCopy) {
	  		// var fieldvalue = firstRowCopy[fieldname];
	  		
	  		// search this field is in composite column
	  		// and assume that its not under in composite colums
	  		var groupName = '';
	  		var groupFields = {};
	  		var hasInCompositeColumn = false;
	  		if(compositeColumnsLength > 0){
	  			for (var groupName in ERPLIST.compositeColumns) {
	  				groupFields = ERPLIST.compositeColumns[groupName];
	  				for (var thisfieldname in groupFields) {
	  					if(thisfieldname == fieldname){
	  						hasInCompositeColumn = true;
	  						break;
	  					}
	  				}
	  				if(hasInCompositeColumn) break;
	  			}
	  		}

	  		
	  		if (hasInCompositeColumn) {			// if have then procceed composite column

				$td = $('<td/>');
				$td.attr('class', groupName);
				$td.attr('fieldname', groupName);
				var compositeColumnsHTML = '';
				var divRow = '';
				$.each(groupFields, function(fieldname, fieldpropties){

					var fieldvalue = thisRow[fieldname];
					var fielddesc = (!!fieldpropties.fielddesc) ? fieldpropties.fielddesc : fieldname;
					var style = ( !!fieldpropties.style ) ? 'style="' + fieldpropties.style + '"': '';

					// *** write custom code here ---

					var obj_thisRowCopy_Json =  JSON.parse(thisRowCopy_Json);
					fieldvalue = (fieldname == "docnumber") ? "<a href='erpdocument.php?docnumber="+fieldvalue+"&doctype=T7&formtype="+formtype+"' target='_blank''>"+fieldvalue+"</a>" : fieldvalue;

					// *** custom code end ----------

					divRow += '<div class="crow" '+ '' +'>';
					if( (!!!fieldpropties.single) || (!!fieldpropties.single && fieldpropties.single == false) ){
						divRow += '<div class="ccell1 '+ fieldname +'" '+ style +'>'+ fielddesc +'</div>';
						divRow += '<div class="ccell2 '+ fieldname +'">:</div>';
					}
					divRow += '<div class="ccell3 '+ fieldname +'_ccell3" '+ style +'>'+ fieldvalue +'</div>';
					divRow += "</div>";

					delete thisRowCopy[fieldname]; // its already procceed
					if(!!fieldpropties.single && fieldpropties.single == true) return; // need to make one td in list
					$td_hide = $('<td/>');
					$td_hide.html(fieldvalue);
					$td_hide.attr("fieldname",fieldname);
					$td_hide.css('display','none');
					$td_hide.appendTo($tr);

				});

				var divTable = "<div id='ctable'>"; 
				divTable += divRow;  
				divTable += "</div>"; 

				compositeColumnsHTML = divTable;
				$td.html(compositeColumnsHTML)
				.css("cursor","pointer")
				.hover(
					function(){bgOn = $(this).closest("tr").css("background-color"); $(this).closest("tr").css("background-color", "lightblue");},
					function(){$(this).closest("tr").css("background-color", bgOn);}
				);
				$td.appendTo($tr);


	  		} else {

				// *** write custom code here ---
				fieldvalue = (fieldname == "docnumber") ? "<a href='erpdocument.php?docnumber="+fieldvalue+"&doctype=DR&formtype="+formtype+"&docviewflag=apparel' target='_blank''>"+fieldvalue+"</a>" : fieldvalue;
				// *** custom code end ----------

				$td = $('<td/>');
				$td.html(fieldvalue)
				.css("white-space","pre-wrap")
				.attr("fieldname",fieldname)
				.css("cursor","pointer")
				.hover(
					function(){bgOn = $(this).closest("tr").css("background-color"); $(this).closest("tr").css("background-color", "lightblue");},
					function(){$(this).closest("tr").css("background-color", bgOn);}
				);
				if ( hideColumns.indexOf(fieldname) >= 0 ) $td.css('display','none');
				$td.appendTo($tr);

	  		}

	  	// }	
	  	});

		// *** custom code start-----------------------------------------------------------------------------------------
		// $tr.find('td.requiredinformation').append(btnThisLineAction);
		// *** custom code end-------------------------------------------------------------------------------------------

    	$tr.click( function() { 
        	ERPLIST.sendBackSearchChoice($(this));
      	})
      	.appendTo($tbody);
  	});

  	$thead.appendTo($table)
  	$tbody.appendTo($table)

  	return $table;
};






ERPLIST.setPriviousSearchParams = function(searchParams){
  searchParams = JSON.parse(searchParams);
  $.each(searchParams, function(key, val){
    var fieldID = "#"+key;
    var fieldValue = val;
    $("#searchForm "+fieldID).val(fieldValue);
    $("#searchForm "+fieldID).focus();

    var fieldname = key;
    var fieldNames = fieldname.split('__');
    var fieldValues = fieldValue.split(',__');

    var span = '<span style="display:block; color:blue; font-weight:bold;">Searched by</span>';

    if(fieldValues.length > 1){
      for(var i = 0; i < fieldValues.length; i++){
        var fn = fieldNames[i];
        var fv = fieldValues[i];
        if(fv == '') continue;

        var fd = fn;
        for(key in ERPLIST.compositeColumns){
          var val = ERPLIST.compositeColumns[key];
          for(k in val){
            var v = val[k];
            if(k == fn){
              fd = (!!v.fielddesc) ? v.fielddesc : k;
              fv = (!!v.islibrary && !!v.datasource) ? v.datasource[fv] : fv;
              break;
            }
          }
        }
        span += '<span style="display:block; white-space:nowrap;">'+ fd + ' : ' + fv +'</span>';
      }
      $(fieldID +"_displaySearchParams").html(span);

    } else {
      // first assume its single and composite
      if(!!ERPLIST.compositeColumns[fieldname]){
        var fielddesc = (!!ERPLIST.compositeColumns[fieldname][fieldname]['fielddesc']) ? ERPLIST.compositeColumns[fieldname][fieldname]['fielddesc'] : fieldname;
        span += '<span style="display:block; white-space:nowrap;">'+ fielddesc + ' : ' + fieldValue +'</span>';
        $(fieldID +"_displaySearchParams").html(span);
      } else {
        // span += '<span style="display:block; white-space:nowrap;">'+ fieldname + ' : ' + fieldValue +'</span>';
        // $(fieldID +"_displaySearchParams").html(span);

        var fielddesc = fieldname;
        if (!!ERPLIST.translationsHardCode[fieldname]) fielddesc = ERPLIST.translationsHardCode[fieldname];
        span += '<span style="display:block; white-space:nowrap;">'+ fielddesc + ' : ' + fieldValue +'</span>';
        $(fieldID +"_displaySearchParams").html(span);


      }
    }

  });
}





ERPLIST.handleThisSearchInputFieldClick = function(thisf){
  if($('#erplistExpandDivID').length) $('body').find('#erplistExpandDivID').remove();

  var searchFiedlName = $(thisf).prop('class');
  var fieldvalue = $(thisf).val();
  if(searchFiedlName == 'docdate' || searchFiedlName == 'lineentrytime'){
    var from_date = "";
    var to_date = "";
    if(fieldvalue.length > 0){
      var fieldvalues = fieldvalue.split('_to_');
      from_date = fieldvalues[0];
      to_date = fieldvalues[1];
    }
    var dateSearchDiv = '\
    <div id="erplistExpandDivID" style="position:relative; display:none;">\
      <div class="dateFieldExpand erplistExpandDiv" style="position:absolute; background:white; min-width:300px; padding:10px; padding-bottom:25px;">\
      	<div style="float:right;">\
      		<button type="button" onclick="ERPLIST.closeExpandDiv(this);"><img src="img/cancel.png" alt="" height="10" width="10"></button>\
      	</div>\
        <div style="clear:both;"></div>\
      	<table>\
      		<tr>\
        		<td><span>From </span></td>\
        		<td  style="min-width:125px;"><input type="text" value="'+ from_date +'" class="datepicker" id="dateFieldFrom" /></td>\
        		<td><span> To </span></td>\
        		<td  style="min-width:125px;"><input type="text" value="'+ to_date +'" class="datepicker" id="dateFieldTo" /></td>\
        	</tr>\
        	<tr></tr>\
        	<tr></tr>\
        	<tr></tr>\
        	<tr>\
        		<td colspan="4" style="text-align:right;">\
        		<button type="button" onclick="ERPLIST.submitDateSearchField(this);">Search</button>\
        		&nbsp;&nbsp;&nbsp;\
        		<button type="button" onclick="ERPLIST.resetDateSearchField(this);">Reset</button>\
        		</td>\
      		</tr>\
      	</table>\
      </div>\
    </div>';
    $(thisf).closest('td').append(dateSearchDiv);
    $('#erplistExpandDivID').fadeIn('slow');
    jsClient.initDateTimePicker();
    ERPLIST.initDisApprear();
  } else {
    ERPLIST.initDisApprear();
  }


}

ERPLIST.submitDateSearchField = function(thisf){
  var dateFrom = $('#dateFieldFrom').val(); 
  var dateTo = $('#dateFieldTo').val(); 
  if(dateFrom == "") return;
  if(dateTo == "") return;

  var fieldname = $(thisf).closest('td').prop('class');
  var fieldvalue = dateFrom + '_to_' + dateTo;

  // $(thisf).closest('td').find('#'+fieldname).val(fieldvalue);
  $(thisf).parent().parent().parent().parent().parent().parent().parent().find('center input').val(fieldvalue);

  $('body').find('#erplistExpandDivID').remove();
  ERPLIST.getSearchData();
}

ERPLIST.resetDateSearchField = function(thisf){
  var fieldname = $(thisf).closest('td').prop('class');
  // $(thisf).closest('td').find('#'+fieldname).val('');
  $(thisf).parent().parent().parent().parent().parent().parent().parent().find('center input').val('');
  $('body').find('#erplistExpandDivID').remove();
  ERPLIST.getSearchData();
}


ERPLIST.handleCustomSearch = function(thisf){
  if($('#erplistExpandDivID').length) $('body').find('#erplistExpandDivID').remove();
	
  var customSearchFiedlName = $(thisf).closest('td').prop('class');
  if(!!ERPLIST.compositeColumns[customSearchFiedlName]){
    if(!!ERPLIST.compositeColumns[customSearchFiedlName][customSearchFiedlName]){ //its already single
      if(!!!ERPLIST.compositeColumns[customSearchFiedlName][customSearchFiedlName]['customsearch'])  return;
      // if(!!ERPLIST.compositeColumns[customSearchFiedlName][customSearchFiedlName]['customsearch']  && ERPLIST.compositeColumns[customSearchFiedlName][customSearchFiedlName]['hidefromcsearch'])  return;
    }
  } 

  var fieldvalue = $(thisf).closest('td').find('input').val();
  var fieldvalues = fieldvalue.split(',__');  

  var dateSearchDiv = '\
    <div id="erplistExpandDivID" style="position:relative; display:none;">\
    <div class="customSearchExpand erplistExpandDiv" style="position:absolute; background:white; min-width:300px; padding:10px; padding-bottom:25px;">\
    <div style="float:right;">\
    <button type="button" onclick="ERPLIST.closeExpandDiv(this);"><img src="img/cancel.png" alt="" height="10" width="10"></button>\
    </div>\
    <div style="clear:both;"></div>\
    <form id="customSearchForm">\
    <table>';

    count = 0;
    $.each(ERPLIST.compositeColumns[customSearchFiedlName],function(fieldname,fieldprop){
      dateSearchDiv += ERPLIST.makeHTML_InputField(fieldname,fieldprop,fieldvalue,count);
      count++;
    });

    dateSearchDiv +='<tr><td colspan="3" style="text-align:right;">\
    	<button type="button" onclick="ERPLIST.submitCustomSearchField(this,\''+customSearchFiedlName+'\');">Search</button>\
      	&nbsp;&nbsp;&nbsp;\
      	<button type="button" onclick="ERPLIST.resetCustomSearchField(this);">Reset</button>\
      </td></tr>\
      </table>\
      </form>\
      </div>\
      </div>';
  $(thisf).closest('td').append(dateSearchDiv);
  $('#erplistExpandDivID').fadeIn('slow');
  jsClient.initDateTimePicker();
  ERPLIST.initDisApprear();

}

ERPLIST.closeExpandDiv = function(thisf){
	if($('#erplistExpandDivID').length) $('body').find('#erplistExpandDivID').remove();
}

ERPLIST.initDisApprear = function(){
  var targetID = document.getElementById('erplistExpandDivID');
  window.onclick = function(event) {
    var fieldnames = {};
    $.each(ERPLIST.compositeColumns,function(groupName,groupColumns){
    	var groupColumn = Object.keys(groupColumns);
    	if(groupColumn.length > 1){
    		groupColumnx = groupColumn.join('__');
    		fieldnames[groupColumnx] = groupColumnx; // for composite
    	} else {
      		fieldnames[groupName] = groupName; // for single
    	}
    });
    fieldnames['inquirysendingdate'] = 'inquirysendingdate';
    fieldnames['requireddeliverydate'] = 'requireddeliverydate';
    fieldnames['lineentrytime'] = 'lineentrytime';
    console.log(event.target.id);
    if ( !(event.target.id in fieldnames) && event.target.id != 'dateFieldFrom' && event.target.id != 'dateFieldTo' && event.target.id != '') { 
      $('body').find('#erplistExpandDivID').remove();
    }
  }

}

ERPLIST.resetCustomSearchField = function(thisf){
  var fieldname = $(thisf).parent().parent().parent().parent().parent().parent().parent(). parent().prop('class');
  $(thisf).parent().parent().parent().parent().parent().parent().parent(). parent().find('center input').val('');
  $('body').find('#erplistExpandDivID').remove();
  ERPLIST.getSearchData();
}



ERPLIST.submitCustomSearchField = function(thisf,compositeFieldName){

  var thisForm = $('#customSearchForm');
  var searchParams = jsClient.formToSerializeObject(thisForm);

  var countFieldWithValue = 0;
  $.each(searchParams, function(fieldname, fieldvalue){
    countFieldWithValue++;
  });
  if(countFieldWithValue == 0) return;

  var customSearchValue = "";
  var compositeFields = ERPLIST.compositeColumns[compositeFieldName];
  for (var fieldname in compositeFields) {
    var fieldprop = compositeFields[fieldname];
    // if(!!fieldprop.hidefromcsearch && fieldprop.hidefromcsearch == true) continue;
    if(!!fieldprop.type && fieldprop.type == 'date'){
      var formdate = (searchParams[fieldname+'_from']);
      var todate = (searchParams[fieldname+'_to']);
      fieldvalue = formdate + '_to_' + todate;
      customSearchValue += (formdate != '' && todate != '') ? fieldvalue + ',__' : ',__';
    } else {
      customSearchValue += (!!searchParams[fieldname]) ? searchParams[fieldname] + ',__' : ',__'; // separate by , and two underscore
    }
  }

  var customSearchValue = customSearchValue.slice(0,-3);
  var fieldname = $(thisf).parent().parent().parent().parent().parent().parent().parent(). parent().prop('class');
  var fieldvalue = customSearchValue;
  $(thisf).parent().parent().parent().parent().parent().parent().parent(). parent().find('center input').val(fieldvalue);
  $('body').find('#erplistExpandDivID').remove();
  ERPLIST.getSearchData();
}

ERPLIST.makeHTML_InputField = function(fieldname,fieldprop,fieldvalue,count){
  var dateSearchDiv = '';
  
  var fieldvalues   = (!!fieldvalue && fieldvalue != '') ? fieldvalue.split(',__') : '';
  var fielddesc     = ( !!fieldprop.fielddesc ) ? fieldprop.fielddesc : fieldname; 
  var trStyle       = ( !!fieldprop.hidefromcsearch && fieldprop.hidefromcsearch == true) ? 'style="display:none;"' : '';
  var fieldval      = (Array.isArray(fieldvalues) && fieldvalues.length > 0 ) ? fieldvalues[count] : '';

  if(!!fieldprop.type && fieldprop.type == 'date'){
    var from_to_dates = (fieldval != '') ? fieldval.split('_to_') : '';
    var from_date     = '';
    var to_date       = '';
    if(from_to_dates.length > 1){
      from_date = from_to_dates[0];
      to_date   = from_to_dates[1];
    }
    dateSearchDiv += '<tr><td><span>'+fielddesc+'</span></td><td>:</td><td style="min-width:365px;"><input type="text" name="'+fieldname+'_from" value="'+from_date+'" class="datepicker" id="" /> to <input type="text" name="'+fieldname+'_to" value="'+to_date+'" class="datepicker" id="" /></td></tr>';
  
  } else if(!!fieldprop.islibrary){
    var options = ERPLIST.makeDropdownOptions(fieldname,fieldval,fieldprop);
    dateSearchDiv += '<tr><td><span>'+fielddesc+': </span><td>:</td><td><select name="'+fieldname+'" class="select2" id="">'+ options +'</select></td></tr>';
  
  } else{
    dateSearchDiv += '<tr '+trStyle+'><td><span>'+fielddesc+'</span></td><td>:</td><td><input type="text" name="'+fieldname+'" value="'+fieldval+'" class="" id="" /></td></tr>';
  }

  return dateSearchDiv;

}

ERPLIST.makeDropdownOptions = function(field, defaultval, fieldprop) {
  if(!!!fieldprop.sql && !!!fieldprop.datasource) return;

  var options = '<option value="">Select</option>';
  if(!!fieldprop.datasource){
    var setasdefault = 'selected';
    $.each(fieldprop.datasource, function(index, value) {
      setasdefault = (!!defaultval && (value == defaultval || index == defaultval)) ? 'selected' : '';
      options += '<option value="' + index + '" '+ setasdefault +'>' + value + '</option>';
    });
    return options;
  }

  var _URL = 'api/server_api.php';

  var searchParams = {
    'sql': fieldprop.sql,
    'reqType': 'getCustomLibrary'
  };

  var extraParams = {};
  var showkeys = false;

  $.ajax({
    async :   false,
    type  :   'get',
    url   :   _URL,
    data  :   searchParams,
    success :   function(data){
      var data = JSON.parse(data);
      var setasdefault = 'selected';
      $.each(data, function(index, value) {
        setasdefault = (!!defaultval && (value == defaultval || index == defaultval)) ? 'selected' : '';
        if (!!showkeys && showkeys === true && index != value) {
          options += '<option value="' + v + '">' + v + '</option>';
        } else {
          options += '<option value="' + index + '" '+ setasdefault +'>' + value + '</option>';
        }
      });
      return options;
    },
    error :   function(){
      alert("error");
       return;
    }
  });

  return options;

}

// CSS added by Mamun
// CSS added by Mamun
ERPLIST.changeTempleteCSS = function(){
  var windowWidth = window.innerWidth
  || document.documentElement.clientWidth
  || document.body.clientWidth;

  var windowHeight = window.innerHeight
  || document.documentElement.clientHeight
  || document.body.clientHeight;

  var screenWidth = screen.width;
  var screenHeight = screen.height 
  // alert('screen width*height = ' + screenWidth + '*' + screenHeight);

  var www = $('#listTable').width(); // which element is max width
  var minwidth = www;
  www = www + 30;
  // var minheight = 1024;

  var bodye = $('body');
  var bodywidth = bodye.width ();
  if (bodywidth < minwidth){   
    bodye.css({'background-size': www+'px 100%'});
    // Previous
    $('#header-wrapper .container .row').css({'min-width':www+'px'});
    // $('#main-wrapper .container .row #content').css({'min-width':www+'px'});

    // Now
    // $('body').css({'min-width':www+'px', 'width':www+'px'});
    $('body').css({'min-width':www+'px'});
    $('.container').css({
      'margin-left': '10pt',
      'margin-right': '10pt',
    });

  } else {   
  }
}



ERPLIST.clearSearchData = function(){
    delete ERPLIST._searchParams;
    $('table#listTable thead tr').each(function() {
        $(this).find("td input:text,select").each(function() {
            $(this).val('');
        });
    });
  ERPLIST.getListData('50', '1');
}
/**
* List template code end ================================================================================================================================================================
*/



/**
* Custom code------------------------------------------------------------------------------------------------------
*/
ERPLIST.handleLineChooserCheckboxClick = function(thisf){
  var thisrow = $(thisf).closest('tr').attr('data-id');
  console.log(thisrow);
  var docnumber = $(thisf).closest('tr').find('td[fieldname=docnumber] .ccell3 a').text();
  // var bomlinestatus = $(thisf).closest('tr').find('td[fieldname=bomlinestatus]').text();

  var chooserType = $(thisf).prop('class');
  if(chooserType == 'multipleLineChooser'){
    // define array
    if(!!!ERPLIST.selectedLineInfo){
      ERPLIST.selectedLineInfo  = {};
      ERPLIST.selectedLineInfo.uniquekey = [];
      ERPLIST.selectedLineInfo.docnumber = [];
    } 
    if($(thisf).prop('checked')){
      $(thisf).prop('checked', true);
      // push data in array
      ERPLIST.selectedLineInfo.uniquekey.push(thisrow);
      ERPLIST.selectedLineInfo.docnumber.push(docnumber);

    } else {
      $(thisf).prop('checked', false);
      var index = ERPLIST.selectedLineInfo.uniquekey.indexOf(thisrow);
      // pop data in array
      ERPLIST.selectedLineInfo.uniquekey.splice(index, 1);
      ERPLIST.selectedLineInfo.docnumber.splice(index, 1);
      console.log(JSON.stringify(ERPLIST.selectedLineInfo.docnumber) + '---' + index);
    }


  } else if (chooserType == 'singleLineChooser'){

    if($(thisf).prop('checked')){
      $('.singleLineChooser').prop('checked', false);
      $(thisf).prop('checked', true);
      // define variable
      if(!!!ERPLIST.docnumber) ERPLIST.docnumber = docnumber;
      if(!!!ERPLIST.bomlinestatus) ERPLIST.bomlinestatus = 'xxxx';

    } else {
      $(thisf).prop('checked', false);
      delete ERPLIST.docnumber;
      delete ERPLIST.bomlinestatus;
    }
  }


}


ERPLIST.actionButton = function(){

  if ( $('#listSuccessDiv').css('display') == 'none' ){

    var cloneDiv = $('#listSuccessDiv').clone();
    cloneDiv.css({'display':'block'})
    		.insertBefore('#listSuccessDiv')
    		.find('#listSuccessMsg').text('sdfsferwerewrewr');
    
  } else if($('#listSuccessDiv').css('display') == 'block'){
    // element is block
    var cloneDiv = $('#listSuccessDiv').clone();
    cloneDiv.css({'display':'block'})
    		.insertBefore('#listSuccessDiv')
    		.find('#listSuccessMsg').text('this is success');

    var cloneDiv = $('#listWarningDiv').clone();
    cloneDiv.css({'display':'block'})
    		.insertBefore('#listWarningDiv')
    		.find('#listWarningMsg').text('this is warning');

    var cloneDiv = $('#listErrorDiv').clone();
    cloneDiv.css({'display':'block'})
    		.insertBefore('#listErrorDiv')
    		.find('#listErrorMsg').text('this is error');

  }

}


ERPLIST.closeISWEMsg = function(thisf){
  var parentId = $(thisf).parent().attr('id');
  $(thisf).closest('div').css({'display':'none'});
  $(thisf).closest('div').find('#listSuccessMsg').text('');
}



ERPLIST.sendBackSearchChoice = function(thisRow){
  var docnumber = $(thisRow).find('td[fieldname=docnumber]').text();
  console.log(docnumber);
}

ERPLIST.redrawList = function(){
	var pagenum = $('#pagination').find('span.current').text();
      var lineperpage = $('#divRowLimit').find('select[name=show]').val();
      if(!!!pagenum) pagenum=1;
      if(!!!lineperpage) lineperpage=50;
  ERPLIST.getListData( lineperpage, pagenum );

  delete ERPLIST.selectedLineInfo;
}



ERPLIST.exportToExecl = function(){
  $('body').find('#listTable').attr('class', 'table2excel');
  $('#listTable').find('br').remove();

  $(".table2excel").table2excel({
    exclude: ".noExl",
    name: "Excel Document Name",
    filename: "Export File",
    fileext: ".xls",
    exclude_img: true,
    exclude_links: true,
    exclude_inputs: true
  });  
}



















ERPLIST.initList = function(){
  if(!!ERPLIST._searchParams){
    ERPLIST.setPriviousSearchParams(ERPLIST._searchParams);
  }
  ERPLIST.handleLibFieldsSearchOption();
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * [setPriviousSearchParams description]
 * @param {[type]} searchParams [description]
 */
ERPLIST.setPriviousSearchParams = function(searchParams){
  searchParams = JSON.parse(searchParams);
  $.each(searchParams, function(key, val){
    var fieldID = "#"+key;
    var fieldValue = val;
    $("#searchForm "+fieldID).val(fieldValue);
    $("#searchForm "+fieldID).focus();

    var fieldname = key;
    var fieldNames = fieldname.split('__');
    var fieldValues = fieldValue.split(',__');

    var span = '<span style="display:block; color:blue; font-weight:bold;">Searched by</span>';

    if(fieldValues.length > 1){
      for(var i = 0; i < fieldValues.length; i++){
        var fn = fieldNames[i];
        var fv = fieldValues[i];
        if(fv == '') continue;

        var fd = fn;
        for(key in ERPLIST.compositeColumns){
          var val = ERPLIST.compositeColumns[key];
          for(k in val){
            var v = val[k];
            if(k == fn){
              fd = (!!v.fielddesc) ? v.fielddesc : k;
              fv = (!!v.islibrary && !!v.datasource) ? v.datasource[fv] : fv;
              break;
            }
          }
        }
        span += '<span style="display:block; white-space:nowrap;">'+ fd + ' : ' + fv +'</span>';
      }
      $(fieldID +"_displaySearchParams").html(span);

    } else {
      // first assume its single and composite
      if(!!ERPLIST.libraryColumns[fieldname]){  

        var fielddesc = (!!ERPLIST.libraryColumns[fieldname]['fielddesc']) ? ERPLIST.libraryColumns[fieldname]['fielddesc'] : fieldname;
        if(!!ERPLIST.libraryColumns[fieldname]['datasource']){
          var fieldValue = ERPLIST.libraryColumns[fieldname]['datasource'][fieldValue];

        } else if(!!ERPLIST.populateLibCache[fieldname]) {
          var fieldValue = ERPLIST.populateLibCache[fieldname][fieldValue];
        }         
        span += '<span style="display:block; white-space:nowrap;">'+ fielddesc + ' : ' + fieldValue +'</span>';
        $(fieldID +"_displaySearchParams").html(span);

      } else if(!!ERPLIST.compositeColumns[fieldname]){


        var fielddesc = (!!ERPLIST.compositeColumns[fieldname][fieldname]['fielddesc']) ? ERPLIST.compositeColumns[fieldname][fieldname]['fielddesc'] : fieldname;
        var fieldValue = (!!ERPLIST.compositeColumns[fieldname][fieldname]['datasource']) ? ERPLIST.compositeColumns[fieldname][fieldname]['datasource'][fieldValue] : fieldValue;        
        span += '<span style="display:block; white-space:nowrap;">'+ fielddesc + ' : ' + fieldValue +'</span>';
        $(fieldID +"_displaySearchParams").html(span);


      } else {

        var fielddesc = fieldname;
        if (!!ERPLIST.translationsHardCode[fieldname]) fielddesc = ERPLIST.translationsHardCode[fieldname];
        span += '<span style="display:block; white-space:nowrap;">'+ fielddesc + ' : ' + fieldValue +'</span>';
        $(fieldID +"_displaySearchParams").html(span);

      }
    }

  });
}




/**
 * [getSearchData description]
 * @return {[type]} [description]
 */
ERPLIST.getSearchData = function(){
  var searchParams = {};
  $('table#listTable thead tr#searchForm').each(function() {
      $(this).find("td input:text,select").each(function() {
          textVal = this.value.trim();
          inputName = $(this).attr("name");
          tagName = $(this).prop("tagName");

          // if inputName is undefined then assume its combobox 
          if(inputName == undefined) return;
          // try to retrive name by closest select tag
          if(!!ERPLIST.libraryColumns[inputName]){
            // if(tagName == "SELECT") return;
            // $('table#listTable thead tr#searchForm td.'+ inputName +' select option').each(function() {
              // console.log(this.text + '---to----' + textVal);
              // if(this.text == textVal){
              //  textVal = this.value;
              // }
           // });
              if(textVal == '______'){ // define for empty
                textVal = "";
              }
          }

          if(textVal != ""){
            searchParams[inputName] = textVal;
          }            
      });
  });

  ERPLIST._searchParams = JSON.stringify(searchParams);
  //                  show,   page,   api_url search_param
  ERPLIST.getListData(50,   1,    '',   searchParams);
}



ERPLIST.initLibFieldsForSearch = function(){
	ERPLIST.libraryColumns = {};
	return ERPLIST.libraryColumns;
}

/**
 * [handleLibFieldsSearchOption description]
 * @return {[type]} [description]
 */
ERPLIST.handleLibFieldsSearchOption = function(){

  ERPLIST.libraryColumns = {
      linestatus:{
        style: 'font-weight:bold; color:green',
        customsearch: true,
        islibrary: true,
        datasource: {
            0: 'Entered',
            1: 'Running',
            2: 'Closed'
         },        
        fielddesc: 'Line Status',
        showsearchimg: true,
      },
    company: {
      fielddesc: 'Company',
      sql: "SELECT Code AS code, Description AS description FROM mrd_library WHERE LibraryName='company'",
    },
  };

  ERPLIST.libraryColumns = ERPLIST.initLibFieldsForSearch();
  if( Object.keys( ERPLIST.libraryColumns).length == 0 ) return;


  // Processing
  for (var fieldname in ERPLIST.libraryColumns) {
      var fieldprop = ERPLIST.libraryColumns[fieldname];
      if(!!!fieldprop.sql && !!!fieldprop.datasource) continue;


      if(!!fieldprop.datasource){
        ERPLIST.populateLibCache[fieldname] = fieldprop.datasource; // cache lib data

        var options = '<option value="______">______</option>';
        var setasdefault = 'selected';
        $.each(fieldprop.datasource, function(index, value) {
            options += '<option value="' + index + '" >' + value + '</option>';
        });
        var returnInputTag = '<select name="'+fieldname+'" class="" id="'+ fieldname +'">'+ options +'</select>';

          // appending
          var copyVal =  $('#listTable tr#searchForm').find('td.'+fieldname).find('input').val();

          $('#listTable tr#searchForm').find('td.'+fieldname).find('center').empty().append(returnInputTag);
          $('#listTable tr#searchForm').find('td.'+fieldname).find('select').val(copyVal);
          applyCommonThings(fieldname);

      } else {

        var _URL = 'api/server_api.php';
        var searchParams = {
          'sql': fieldprop.sql,
          'reqType': 'getCustomLibrary'
        };

        var extraParams = {};
        var showkeys = false;

        $.ajax({
          async :   false,
          type  :   'get',
          url   :   _URL,
          data  :   searchParams,
          success :   function(data){
            var data = JSON.parse(data);
            ERPLIST.populateLibCache[fieldname] = data; // cache lib data

            var options = '<option value="______">______</option>';
            $.each(data, function(index, value) {
              options += '<option value="' + index + '">' + value + '</option>';
            });
            var returnInputTag = '<select name="'+fieldname+'" class="" id="'+ fieldname +'">'+ options +'</select>';

            // appending
            var copyVal =  $('#listTable tr#searchForm').find('td.'+fieldname).find('input').val();
            $('#listTable tr#searchForm').find('td.'+fieldname).find('center').empty().append(returnInputTag);
            $('#listTable tr#searchForm').find('td.'+fieldname).find('select').val(copyVal);
            applyCommonThings(fieldname);
          },
          error :   function(){
              alert("error");
              return;
          }
        });

        
      }


  }


  function applyCommonThings(fieldname){
        // initComboboxAction();
      $( "#listTable tr#searchForm #"+fieldname ).combobox();
      $( "#toggle" ).on( "click", function() {
      $( "#listTable tr#searchForm #"+fieldname ).toggle();
    });


        $('#listTable tr#searchForm').find('td.'+fieldname).find('input').keypress(function (event) {
          if (event.which == 13) {
            ERPLIST.getSearchData();        
          }
        });


        // width fix
        var elmntW = $('#listTable tr#searchForm').find('td.'+fieldname).width();
        $('#listTable tr#searchForm').find('td.'+fieldname).css('width',  (elmntW+ 30)+'px') ;
        $('#listTable tr#searchForm').find('td.'+fieldname).css('min-width',  (elmntW+ 30)+'px');
        $('#listTable tr#searchForm').find('td.'+fieldname+ ' input').css('min-width',  (elmntW)+'px');
        $('#listTable tr#searchForm').find('td.'+fieldname).find('center').css({'display':'initial'});

        
        // CSS override for combobox
        $('.ui-state-default, .ui-widget-content .ui-state-default, .ui-widget-header .ui-state-default').css({
          'border':'1px solid #7F7F7F',
          'border-radius':':3px',
          'font-family':'Arial',
          'padding':'2px',
          'background': 'none',
          'height': '25px',
          'background-color': 'white'
        });

  }

  function initComboboxAction(){
    // $( "#company" ).combobox();
    // $( "#toggle" ).on( "click", function() {
    //   $( "#company" ).toggle();
    // });
  }

}


//////////////////////// Combobox Plugin  Start - 2017-11-05 /////////////////////////////////////////////////////////////////////////
 $( function() {
    $.widget( "custom.combobox", {
      _create: function() {
        this.wrapper = $( "<span>" )
          .addClass( "custom-combobox" )
          .insertAfter( this.element );

        // this.elementName = this.element.attr('name'); // mamun
        // this.elementId = this.element.attr('id'); // mamun
        // // alert(this.element.attr('id'));
 
        this.element.hide();
        this._createAutocomplete();
        this._createShowAllButton();
      },
 
      _createAutocomplete: function() {
        var selected = this.element.children( ":selected" ),
          value = selected.val() ? selected.text() : "";
 
        this.input = $( "<input>" )
          .appendTo( this.wrapper )
          .val( value )
          .attr( "title", "" )
          .attr( "name", this.elementName ) // mamun
          .attr( "id", this.elementId ) // mamun
          .addClass( "custom-combobox-input ui-widget ui-widget-content ui-state-default ui-corner-left" )
          .css( "width", "50px" ) // mamun
          .autocomplete({
            delay: 0,
            minLength: 0,
            source: $.proxy( this, "_source" )
          })
          .tooltip({
            classes: {
              "ui-tooltip": "ui-state-highlight"
            }
          });
 
        this._on( this.input, {
          autocompleteselect: function( event, ui ) {
            ui.item.option.selected = true;
            console.log(ui.item.option.text); // mamun
            this._trigger( "select", event, {
              item: ui.item.option
            });
            this.input.val(ui.item.option.text); // mamun
            ERPLIST.getSearchData(); // mamun
          },
      
          autocompletechange: "_removeIfInvalid"
        });
      },
 
      _createShowAllButton: function() {
        var input = this.input,
          wasOpen = false;
 
        $( "<a>" )
          .attr( "tabIndex", -1 )
          .attr( "title", "Show All Items" )
          .tooltip()
          .appendTo( this.wrapper )
          .button({
            icons: {
              primary: "ui-icon-triangle-1-s"
            },
            text: false
          })
          .removeClass( "ui-corner-all" )
          .addClass( "custom-combobox-toggle ui-corner-right" )
          .on( "mousedown", function() {
            wasOpen = input.autocomplete( "widget" ).is( ":visible" );
          })
          .on( "click", function() {
            input.trigger( "focus" );
 
            // Close if already visible
            if ( wasOpen ) {
              return;
            }
 
            // Pass empty string as value to search for, displaying all results
            input.autocomplete( "search", "" );
          });
      },
 
      _source: function( request, response ) {
        var matcher = new RegExp( $.ui.autocomplete.escapeRegex(request.term), "i" );
        response( this.element.children( "option" ).map(function() {
          var text = $( this ).text();
          if ( this.value && ( !request.term || matcher.test(text) ) )
            return {
              label: text,
              value: text,
              option: this
            };
        }) );
      },
 
      _removeIfInvalid: function( event, ui ) {

        // Selected an item, nothing to do
        if ( ui.item ) {
          return;
        }
 
        // Search for a match (case-insensitive)
        var value = this.input.val(),
          valueLowerCase = value.toLowerCase(),
          valid = false;
        this.element.children( "option" ).each(function() {
          if ( $( this ).text().toLowerCase() === valueLowerCase ) {
            this.selected = valid = true;
            return false;
          }
        });
 
        // Found a match, nothing to do
        if ( valid ) {
          return;
        }
 
        // Remove invalid value
        this.input
          .val( "" )
          .attr( "title", value + " didn't match any item" )
          .tooltip( "open" );
        this.element.val( "" );
        this._delay(function() {
          this.input.tooltip( "close" ).attr( "title", "" );
        }, 2500 );
        this.input.autocomplete( "instance" ).term = "";
      },
 
      _destroy: function() {
        this.wrapper.remove();
        this.element.show();
      }
    });
 
    // $( "#company" ).combobox();
    // $( "#toggle" ).on( "click", function() {
    //   $( "#company" ).toggle();
    // });
  } );
//////////////////////// Combobox Plugin  End ////////////////////////////////////////////////////////////////////////////////////////
















































jsClient.makePagination = function(jsonData){

  var data = JSON.parse(jsonData);
  pageNum      = data['pageNum'];
  lastPageNum  = data['lastPageNum'];
  queryRowsNum = data['queryRowsNum'];
  showLimit    = data['showLimit'];

  var rowLimit =  jsClient.makeRowLimit(showLimit);
  var pagTable =  jsClient.getPagination(showLimit, queryRowsNum, pageNum);

  var paginationDiv = '<div style="display:inline-block" id="paginationContainer">';

  paginationDiv += '<div style="float:left;" id="divClearSearch">';
  paginationDiv += '<a href="javascript:void(0);" onclick="ERPLIST.clearSearchData()">Clear Search</a>';
  paginationDiv += '</div>';

  paginationDiv += '<div style="float:left;" id="divRowCounter">';
  paginationDiv += '<span>';
  paginationDiv += queryRowsNum;
  paginationDiv += ' records found ';
  paginationDiv += '</span>';
  paginationDiv += '</div>';

  paginationDiv += '<div style="float:left;" id="divPage">';
  paginationDiv += pagTable;
  paginationDiv += '</div>';

  paginationDiv += '<div style="float:left;" id="divRowLimit">';
  paginationDiv += rowLimit;
  paginationDiv += '</div>';

  paginationDiv += '</div>';

  return paginationDiv;
}


jsClient.makeRowLimit = function(show){

    var rowLimit = "";
    rowLimit += '<label> <span id="spanRowLimit">Rows Limit:</span>' 
    rowLimit += '<select name="show" onChange="jsClient.changeDisplayRowCount(this.value);">';
    rowLimit += (show == 5) ? '<option value="5" selected="selected" >5</option>' : '<option value="5">5</option>';
    rowLimit += (show == 10) ? '<option value="10" selected="selected" >10</option>' : '<option value="10">10</option>';
    rowLimit += (show == 20) ? '<option value="20" selected="selected" >20</option>' : '<option value="20">20</option>';
    rowLimit += (show == 30) ? '<option value="30" selected="selected" >30</option>' : '<option value="30">30</option>';
    rowLimit += (show == 40) ? '<option value="40" selected="selected" >40</option>' : '<option value="40">40</option>';
    rowLimit += (show == 50) ? '<option value="50" selected="selected" >50</option>' : '<option value="50">50</option>';
    rowLimit += (show == 100) ? '<option value="100" selected="selected" >100</option>' : '<option value="100">100</option>';
    rowLimit += (show == 150) ? '<option value="150" selected="selected" >150</option>' : '<option value="150">150</option>';
    rowLimit += '</select>';
    rowLimit += '</label>';

    return rowLimit;

}

jsClient.changeDisplayRowCount = function(numRecords) {
	var pagenum = $('#pagination').find('span.current').text();
      var lineperpage = $('#divRowLimit').find('select[name=show]').val();
      if(!!!pagenum) pagenum=1;
      if(!!!lineperpage) lineperpage=50;
  ERPLIST.getListData( lineperpage, pagenum );

  delete ERPLIST.selectedLineInfo;
}

jsClient.getPagination = function(showLimit, rows, page){ 

    var limit = showLimit;
    var adjacents = 3;
    show = showLimit;

    pagination='';
    if (page == 0) page = 1;                    //if no page var is given, default to 1.
    prev = page - 1;                            //previous page is page - 1
    next = page + 1;                            //next page is page + 1
    prev_='';
    first='';
    // lastpage = Math.round(rows/limit);  
    lastpage = Math.ceil(rows/limit);  
    next_='';
    last='';

    if(lastpage > 1)
    {   
        
        //previous button
        if (page > 1) 
            // prev_+= "<a class='page-numbers' href=\"?page=prev\">previous</a>";
            prev_  += '<a href="javascript:void(0);" class="page-numbers page-'+ prev +'"  onclick="ERPLIST.getListData(  \''+ show +'\'      ' +","+ '    \'' + prev+ '\');" > previous </a>';

        else {
            //pagination.= "<span class=\"disabled\">previous</span>";  
            }
        


        //pages 
        if (lastpage < 5 + (adjacents * 2)) //not enough pages to bother breaking it up
        {   
        first='';
            for (counter = 1; counter <= lastpage; counter++)
            {
                if (counter == page)
                    pagination+= "<span class='current'>" + counter + "</span>";
                else
                    // pagination+= "<a class='page-numbers' href='?page=" +counter+ "' " + "> " + counter + "</a>"; 
                    pagination  += '<a href="javascript:void(0);" class="page-numbers page-'+ counter +'"  onclick="ERPLIST.getListData(  \''+ show +'\'      ' +","+ '    \'' + counter+ '\');" > ' + counter + ' </a>';
            }
            last='';
        }
        else if(lastpage > 3 + (adjacents * 2))  //enough pages to hide some
        {
            //close to beginning; only hide later pages
            first='';
            if(page < 1 + (adjacents * 2))      
            {
                for (counter = 1; counter < 4 + (adjacents * 2); counter++)
                {
                    if (counter == page)
                        pagination+= "<span class='current'>" + counter + "</span>";
                    else
                        // pagination+= "<a class='page-numbers' href='?page="+counter + "' "+ "> " +counter+ "</a>"; 
                    pagination  += '<a href="javascript:void(0);" class="page-numbers page-'+ counter +'"  onclick="ERPLIST.getListData(  \''+ show +'\'      ' +","+ '    \'' + counter+ '\');" > ' + counter + ' </a>';

                }
            // last+= "<a class='page-numbers' href='?page="+lastpage + "' " + ">Last</a>";          
            last+= '<a href="javascript:void(0);" class="page-numbers page-'+ counter +'"  onclick="ERPLIST.getListData(  \''+ show +'\'      ' +","+ '    \'' + lastpage+ '\');" > ' + 'Last' + ' </a>';          
            }
            
            //in middle; hide some front and some back
            else if(lastpage - (adjacents * 2) > page && page > (adjacents * 2))
            {
               // first+= "<a class='page-numbers' href='?page=1'>First</a>";    
               first+='<a href="javascript:void(0);" class="page-numbers page-'+ counter +'"  onclick="ERPLIST.getListData(  \''+ show +'\'      ' +","+ '    \'' + '1'+ '\');" > ' + 'First' + ' </a>';          
   
            for (counter = page - adjacents; counter <= page + adjacents; counter++)
                {
                    if (counter == page)
                        pagination+= "<span class=current>" + counter + "</span>";
                    else
                        // pagination+= "<a class='page-numbers' href='?page=" + counter + "' " + ">counter</a>"; 
                    pagination  += '<a href="javascript:void(0);" class="page-numbers page-'+ counter +'"  onclick="ERPLIST.getListData(  \''+ show +'\'      ' +","+ '    \'' + counter+ '\');" > ' + counter + ' </a>';

                }
                // last+= "<a class='page-numbers' href='?page='"+lastpage +"' " + ">Last</a>";          
                last+= '<a href="javascript:void(0);" class="page-numbers page-'+ counter +'"  onclick="ERPLIST.getListData(  \''+ show +'\'      ' +","+ '    \'' + lastpage+ '\');" > ' + 'Last' + ' </a>';                  
            }
            //close to end; only hide early pages
            else
            {
                // first+= "<a class='page-numbers' href='?page=1'>First</a>";   
                first+='<a href="javascript:void(0);" class="page-numbers page-'+ counter +'"  onclick="ERPLIST.getListData(  \''+ show +'\'      ' +","+ '    \'' + '1'+ '\');" > ' + 'First' + ' </a>';             
                for (counter = lastpage - (2 + (adjacents * 2)); counter <= lastpage; counter++)
                {
                    if (counter == page)
                        pagination+= "<span class='current'>"+counter+"</span>";
                    else
                        // pagination+= "<a class='page-numbers' href='?page="+counter+"' " + ">counter</a>";   
                    pagination  += '<a href="javascript:void(0);" class="page-numbers page-'+ counter +'"  onclick="ERPLIST.getListData(  \''+ show +'\'      ' +","+ '    \'' + counter+ '\');" > ' + counter + ' </a>';

                }
                last='';
            }
            
            }





        if (page < counter - 1) 
            // next_+= "<a class='page-numbers' href='?page='"+next+">next</a>";
            next_  += '<a href="javascript:void(0);" class="page-numbers page-'+ next +'"  onclick="ERPLIST.getListData(  \''+ show +'\'      ' +","+ '    \'' + next+ '\');" > next </a>';


        else{
            //pagination.= "<span class=\"disabled\">next</span>";
            }
        pagination = "<div id='pagination' class='pagination'>" + first + prev_ + pagination + next_ + last;
        //next button
        
        pagination += "</div>\n";        



    }

    // pagination = "<div class='pagination'>" + first + prev_ + pagination + next_ + last;
    
    return pagination;  
}


jsClient.paginationCSS = function(){

  $('#paginationContainer #divRowCounter').css({
    'padding':'4px 10px',
    'color':'black',
    'font-weight':'bold',
    // 'border': '2px solid blue',
    // 'vertical-align': 'text-bottom',
    'margin-top': '3pt',
    'height': '20pt'
  });

  $('#paginationContainer #divClearSearch').css({
    'padding':'4px 10px',
    'color':'black',
    'font-weight':'bold',
    'margin-top': '3pt',
    'height': '20pt'
  });


  $('#paginationContainer #divPage').css({
    'padding':'4px 10px',
  });

  $('#paginationContainer #divRowLimit').css({
    'padding':'4px 10px',
    'color':'black',
    'font-weight':'bold',
    // 'border': '2px solid blue',
    // 'vertical-align': 'text-bottom',
    'height': '20pt'
  });

  $('#paginationContainer #divRowLimit #spanRowLimit').css({
    'padding-right':'4pt'
  });

  //------------------------
  $('.pagination').css({
    // 'width':'600px',
    'margin':'0px auto'
  });
  $('.pagination .current').css({
    'padding':'4px 10px',
    'color':'black',
    'margin':'1px 0px 9px 6px',
    'display':'block',
    'text-decoration':'none',
    'float':'left',
    'text-transform':'capitalize',
    'background':'whitesmoke'
  });
  $('.pagination .page-numbers').css({
    'padding':'4px 10px',
    'color':'white !important',
    'margin':'1px 0px 9px 6px',
    'display':'block',
    'text-decoration':'none',
    'float':'left',
    'text-transform':'capitalize',
    'background':'#00b4cc'
  });


}











//======================================================= ===================================================================
// Source
//https://codepen.io/jgx/pen/wiIGc
//
;(function($) {
   $.fn.fixMe = function() {
      return this.each(function() {
         var $this = $(this),
            $t_fixed;
         function init() {
            // $this.wrap('<div class="container" />');
            $t_fixed = $this.clone();
            $t_fixedXX = $this.clone();
            // $t_fixed2 = $this.clone();
            $t_fixed.find("tbody").remove();
            $t_fixed.removeAttr('id');
            $t_fixed.find("tr#searchForm").remove().end().addClass("fixed").insertBefore($this);
            // $t_fixed.find("tbody").remove().end().addClass("fixed").insertBefore($this);
            resizeFixed();
         }
         function resizeFixed() {
      // org table first tr first obj
      // org table width
          // var $trObj = $("#listTable tr:first");
          // var tw = $("#listTable tr:first").width();
          var $trObj = $("#listTable tr:nth-child(2)");
          var tw = $("#listTable tr:nth-child(2)").width();
          $('table.fixed').css('width', tw+'px');

            $t_fixed.find("th").each(function(index) {
        var cn = index + 1;
        // var xx =  $trObj.find('th:nth-child('+ cn +')').outerWidth();
        var xx =  $trObj.find('td:nth-child('+ cn +')').outerWidth();
        // var ww = $this.find("th").eq(index).outerWidth()+"px";
        // console.log('ddddddddddddd' + ww);
        // console.log('xxxxxxxxxxxxx' + xx);
        // $(this).css("min-width",ww);
        // $(this).css("width",ww);
        // $(this).css("max-width",ww);
        $(this).css("min-width",xx + "px");
        $(this).css("width",xx + "px");
        $(this).css("max-width",xx + "px");
            });
         }
         function scrollFixed() {
            var offset = $(this).scrollTop(),
            tableOffsetTop = $this.offset().top,
            tableOffsetBottom = tableOffsetTop + $this.height() - $this.find("thead").height();
            if(offset < tableOffsetTop || offset > tableOffsetBottom)
               $t_fixed.hide();
            else if(offset >= tableOffsetTop && offset <= tableOffsetBottom && $t_fixed.is(":hidden"))
               $t_fixed.show();
         }
         $(window).resize(resizeFixed);
         $(window).scroll(scrollFixed);
         init();
      });
   };
})(jQuery);



$(window).on('scroll', function(e) {
    var left = $(this).scrollLeft();
  // org table first tr first th ofset
  // for fixing width for different width display
  var ofst = $("#listTable tr:first").find("th:first").offset();
  var Xleft = ofst.left;
  left = left - Xleft;
  $('.fixed').css('left', -left);
});
//======================================================= ===================================================================