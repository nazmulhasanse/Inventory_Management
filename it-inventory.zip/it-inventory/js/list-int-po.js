/**
 * Declare ERPLIST Namespace if not exist
 */
var ERPLIST = ERPLIST || {};

$.extend(ERPLIST, {
  mUrl: 'api/server_api.php',
  mType: 'get',
  mData: '',
  mAsync: false,
  mReqType: '',
  queryData: '',
  queryParam: '',
  _searchParams: '',
  _URL_API: 'list-int-po_api.php',

  foo: 'here for no reason other than to be the last line, without a comma'
});




// ERPLIST.displayQueryData = function(jsonData){

//   var pagination = jsClient.makePagination(jsonData);

//   var data = JSON.parse(jsonData);
//   var listData = data['listData'];
//   var hasData = (data.noResult) ? 'no' : 'yes';
//   // var listTable = ERPLIST.makeTable(listData, hasData);

//   $("#listDiv").html(pagination);
//   $("#listDiv").append(listTable);

//   // ERPLIST.initSearchAction();

//   /**
//    * Css
//    */
//   $('#listTable').css({
//     'width':'100%'
//   });
//   $('#listTable tr#searchForm input').css({
//     'width':'95%',
//     'min-width': '60px',
//     'font-family':'Arial',
//     'padding':'2px',
//     'border':'1px solid #7F7F7F',
//     'border-radius':'3px'
//   });
//   $('#listTable tr#searchForm button').css({
//     'padding':'2px',
//     'border':'1px solid #7F7F7F',
//     'border-radius':'3px',
//     'vertical-align': 'middle'
//   });  
//   $('#listTable .hasCustomSearch').css({
//     'width':'70%'
//   });
//   jsClient.paginationCSS();
//   ERPLIST.changeTempleteCSS();

//   // Custom CSS if required
//   // $('#listTable td.lineentrytime').css({
//   //   'white-space':'nowrap'
//   // });
//   // $('#listTable td.itemcode .ccell3 ').css({
//   //   'white-space':'nowrap'
//   // });
//   $('#listTable td.docnumber').css({
//     'min-width':'50px'
//   });

//   $('.classRed ').css({
//     'border-radius':'50%',
//     'background-color':'red',
//     'border':'none',
//     // 'padding-top':'10px'
//   });

//   $('.classGreen ').css({
//     'border-radius':'50%',
//     'background-color':'green',
//     'border':'none',
//     // 'padding-top':'10px'
//   });

// }

ERPLIST.changeTempleteCSS();
$('#listTable td.docnumber').css({
    'width':'50px'
});



ERPLIST.exportToExecl = function(){
  var searchParams = {};
  $('table#listTable thead tr#searchForm').each(function() {
    $(this).find("td input:text,select").each(function() {
      var textVal   = this.value.trim();
      var inputName = $(this).attr("name");
      var tagName   = $(this).prop("tagName");

      // if inputName is undefined then assume its combobox 
      if(inputName == undefined) return;
      // try to retrive name by closest select tag
      if(!!ERPLIST.libraryColumns[inputName]){
          if(textVal == '______'){ // define for empty
            textVal = "";
          }
      }
      if(textVal != ""){
        searchParams[inputName] = textVal;
      }            
    });
  });
// return encodeURIComponent(key) + '=' + encodeURIComponent(params[key]);
  var qrystr = $.param( searchParams );
  var expURL = '/erp-nonpo/list-int-po_api.php?reqType=exportListData&' + qrystr;
  window.open(expURL);
}

ERPLIST.makeTable = function(mydata,hasData) {
  var $table = $('<table border=1 id="listTable" class="listTable" />');
  var $thead = $('<thead />');
  var $tbody = $('<tbody/>');

  //for composition column
  ERPLIST.compositeColumns = {
    
    
   // linestatus:{
   //    linestatus: {
   //      fielddesc: 'Status',
   //      islibrary: true,
   //      datasource: {
   //        0: 'Entered',
   //        1: 'Complete',
   //        2: 'Released'
   //      },  
   //      customsearch: true,
   //      composite: false,
   //      end: true
   //    }
   //  },

   //  docnumber : {
   //    docnumber : {
   //      fielddesc: 'Requisition No.',
   //      composite: false,
   //      customsearch: false,
   //      single: true,
   //      end: true
   //    },        
   //  },


   //  doclinenumber : {
   //    doclinenumber : {
   //      fielddesc: 'Requisition Line No.',
   //      composite: false,
   //      customsearch: false,
   //      single: true,
   //      end: true
   //    },        
   //  },

    // docdate : {
    //   docdate : {
    //     fielddesc: 'PR Date',
    //     composite: false,
    //     customsearch: true,
    //     single: true,
    //     type: 'date',
    //     end: true
    //   },        
    // },

    // company : {
    //   company : {
    //     fielddesc: 'Division',
    //     composite: false,
    //     customsearch: false,
    //     single: true,
    //     end: true
    //   },        
    // },

    // ponumber : {
    //   ponumber : {
    //     fielddesc: 'PO No.',
    //     composite: false,
    //     customsearch: false,
    //     single: true,
    //     end: true
    //   },        
    // },

    // podocdate : {
    //   podocdate : {
    //     fielddesc: 'PO Date',
    //     composite: false,
    //     customsearch: true,
    //     single: true,
    //     type: 'date',
    //     end: true
    //   },        
    // },  

    // itemcode : {
    //   itemcode : {
    //     fielddesc: 'Item Code',
    //     composite: false,
    //     customsearch: false,
    //     single: true,
    //     end: true
    //   },        
    // },

    // itemname : {
    //   itemname : {
    //     fielddesc: 'Item Name',
    //     composite: false,
    //     customsearch: false,
    //     single: true,
    //     end: true
    //   },        
    // },

    // itemdescription : {
    //   itemdescription : {
    //     fielddesc: 'Item Description',
    //     composite: false,
    //     customsearch: false,
    //     single: true,
    //     end: true
    //   },        
    // },

    // purchasemode : {
    //   purchasemode : {
    //     fielddesc: 'Procurer',
    //     composite: false,
    //     customsearch: false,
    //     single: true,
    //     end: true
    //   },        
    // },

    // suppliername : {
    //   suppliername : {
    //     fielddesc: 'Supplier Name',
    //     composite: false,
    //     customsearch: false,
    //     single: true,
    //     end: true
    //   },        
    // },

    // supplieraddress : {
    //   supplieraddress : {
    //     fielddesc: 'Supplier Address',
    //     composite: false,
    //     customsearch: false,
    //     single: true,
    //     end: true
    //   },        
    // },

    // unitprice : {
    //   unitprice : {
    //     fielddesc: 'Unit Price',
    //     composite: false,
    //     customsearch: false,
    //     single: true,
    //     end: true
    //   },        
    // },

    // deliverydate : {
    //   deliverydate : {
    //     fielddesc: 'Delivery Date',
    //     composite: false,
    //     customsearch: true,
    //     single: true,
    //     type: 'date',
    //     end: true
    //   },        
    // },
  }

  var params = jsClient.paramsToObj(window.location.search);
  
  var hideColumns = [ 'docstatus','idlines', 'usertype', 'customer', 'doctype','workorderdocnumber','bomdocnumber','cpdocnumber','isrrfreezed','recalculationbit', 'actualdeductionqty', 'requirednetqty', 'parentrrnumber', 'ldcslnumber'];
    // some trickery for nice formatting
  
  var translationsHardCode = {};
  translationsHardCode.docnumber       = 'Doc No.';
  translationsHardCode.employeeid      = 'Employee ID';
  translationsHardCode.name            = 'Name';
  translationsHardCode.purchasedate    = 'Purchase Date';
  translationsHardCode.designation     = 'Designation';
  // translationsHardCode.company         = 'Company';
  translationsHardCode.contactnumber   = 'Contact No.';
  translationsHardCode.department      = 'Department';
  translationsHardCode.section         = 'Section';
  translationsHardCode.inventoryid     = 'Inventory ID';
  translationsHardCode.serialnumber    = 'Serial No.';
  translationsHardCode.logsheetnumber  = 'Log Sheet No.';
  translationsHardCode.processor       = 'Processor';
  translationsHardCode.hdd             = 'HDD';
  translationsHardCode.ram             = 'RAM';
  translationsHardCode.model           = 'PC Model';
  translationsHardCode.useremail       = 'Mail ID';
  translationsHardCode.domainid        = 'Domain ID';
  translationsHardCode.active          = 'User Active?';
  translationsHardCode.laptopordesktop = 'PC Type';
  // translationsHardCode.returntype      = 'Return Type';
  translationsHardCode.username        = 'User Name';

  // translationsHardCode.doclinenumber   = 'Identification No.';
  // translationsHardCode.itemdescription = 'Item Description';
  // translationsHardCode.iduom           = 'UoM';


  ERPLIST.translationsHardCode = translationsHardCode;


  // builds the table header
  var mydata_json = JSON.stringify(mydata);
  var firstRow = mydata[0];

  var firstRowCopy = firstRow;
  var compositeColumnsLength = Object.keys(ERPLIST.compositeColumns).length;
  var countVisibleColumn = 1; // here start from 1 cz first td for option
  /**
   * first header row------------------------------------------------------------------------------------------------------------------------------------------------------------
   */
  var $tr = $("<tr/>");
  // $td = $('<th/>');
  // thisLineActionBtn = '<center>Check All</center>';
  // $td.html(thisLineActionBtn);
  // $td.appendTo($tr);

  // process composite column first if has
  if(compositeColumnsLength > 0){
    $.each(ERPLIST.compositeColumns, function(groupName, groupColumns){
      // hide first
      $.each(groupColumns, function(fieldname, fieldStyle){
        var fielddesc = fieldname;
        $td = $('<th/>');
        if (!!translationsHardCode[fieldname]) fielddesc = translationsHardCode[fieldname];
        $td.html('<center>'+ fielddesc +'</center>');
        $td.css('display','none');
        $td.appendTo($tr);

        delete firstRowCopy[fieldname]; // its already procceed
      });

      $td = $('<th/>');
      $td.attr('class', groupName);
      if ( hideColumns.indexOf(groupName) >= 0 ){ 
        $td.css('display','none'); countVisibleColumn--;
      }else{
        countVisibleColumn++;
      }
      if (!!translationsHardCode[groupName]) groupName = translationsHardCode[groupName];
      $td.html('<center>'+ groupName +'</center>');
      $td.appendTo($tr);
      // countVisibleColumn++;
    });
  }

  // precess rest of columns----------------------------------------------------------------------------------------------
  $.each(firstRowCopy, function (fieldname, fieldvalue) {
    countVisibleColumn++;
    var fielddesc = fieldname;
    $td = $('<th/>');
    if (!!translationsHardCode[fieldname]) fielddesc = translationsHardCode[fieldname];
    $td.html('<center>'+ fielddesc +'</center>');
    if ( hideColumns.indexOf(fieldname) >= 0 ){ $td.css('display','none'); countVisibleColumn--};
    $td.appendTo($tr);
  });
  $tr.appendTo($thead);
  $thead.appendTo($table);
  // end -----------------------------------------------------------------------------------------------------------------


  /**
   * second header row-----------------------------------------------------------------------------------------------------------------------------------------------------------
   */
  var $tr = $("<tr/>").attr("id","searchForm");
  var $td;
  // $td = $('<td/>');
  // thisLineActionBtn = '<center><input type="checkbox" class="chkallrrline" name="" onclick="ERPLIST.alllineChooser(this);"></center>';
  // $td.html(thisLineActionBtn);
  // $td.appendTo($tr);

  if(compositeColumnsLength > 0){
    $.each(ERPLIST.compositeColumns, function(groupName, groupColumns){

      var compositeClass = '';
      $td = $('<td/>');
      $td.attr('class', groupName);
      $.each(groupColumns, function(fieldname, fieldpropties){

        compositeClass +=  ( !!fieldpropties.end) ? fieldname : fieldname + '__';          
        var customsearch_option = ( !!fieldpropties.showsearchimg) ?'<button type="button" onclick="ERPLIST.handleCustomSearch(this);"><img src="img/search_icon.png" alt="" height="15" width="15"></button>': '';
        var customsearch_click  = ( !!fieldpropties.customsearch) ?'onclick="ERPLIST.handleCustomSearch(this);"': 'onclick="ERPLIST.handleThisSearchInputFieldClick(this);"';
        var customsearch_class  = ( !!fieldpropties.customsearch ) ? '  hasCustomSearch' : '';

        var html = '<center><input type="text" name="'+ compositeClass +'" value="" id="'+compositeClass+'" class="'+compositeClass + customsearch_class +'" onclick="ERPLIST.handleCustomSearch(this);" />'+ customsearch_option +'</center><div id="'+compositeClass+'_displaySearchParams" style="background-color:white;"></div>';
        $td.html(html);

        // delete firstRowCopy[fieldname]; // its already procceed
        if(fieldpropties.composite == false) return;
        $td_hide = $('<td/>');
        $td_hide.html('<center><input type="hidden" class="'+ fieldname +'" value="" id="'+fieldname+'" /></center>');
        $td_hide.css('display','none');
        $td_hide.appendTo($tr);

      });
      if ( hideColumns.indexOf(groupName) >= 0 ) $td.css('display','none');
      $td.appendTo($tr);

    });
  }
  // end -----------------------------------------------------------------------------------------------------------------

  // precess rest of columns----------------------------------------------------------------------------------------------
  $.each(firstRowCopy, function (fieldname, fieldvalue) {    
    var fielddesc = fieldname;
    $td = $('<td/>');
    $td.attr('class', fieldname);
    $td.html('<center><input type="text"  name="'+ fieldname +'" class="'+ fieldname +'" value="" id="'+fieldname+'" onclick="ERPLIST.handleThisSearchInputFieldClick(this);" /></center><div id="'+fieldname+'_displaySearchParams" style="background-color:white;"></div>');
    if ( hideColumns.indexOf(fieldname) >= 0 ) $td.css('display','none');
    $td.appendTo($tr);
  });
  $tr.appendTo($thead);
  $thead.appendTo($table);
  // end -----------------------------------------------------------------------------------------------------------------
  /**
   * second header row end -----------------------------------------------------------------------------------------------------------------------------------------------------------
   */

  if(hasData == 'no'){
    $thead.appendTo($table);
    //custom for no record found
    var $tr = $("<tr/>");
    // var numberOfColumn = $("#listTable > thead > tr:first > th:visible").length;
    var $td = $('<td/>').attr("colspan",countVisibleColumn);
    $td.html('No Data Found')
      .css({'text-align':'center','vertical-align':'middle'});
    $td.appendTo($tr);
    $tr.appendTo($table);
    return $table;
  }

  /**
   * populates with data--------------------------------------------------------------------------------------------------------------------------------------------------
   */
  var mydata = JSON.parse(mydata_json);
  $.each(mydata, function (index, value) {
    var $tr = $("<tr/>"); // it should be in here

    var thisRow = value;
    var thisRowCopy = thisRow;
    var thisRowCopy_Json =  JSON.stringify(thisRow);

    var formtype = thisRow['formtype'];
    var linestatus = thisRow['linestatus'];
    var isrrfreezed = thisRow['isrrfreezed'];
    var recalculationbit = thisRow['recalculationbit'];
    // generate button if needed
    var thisLineActionBtn = '';
    if(isrrfreezed != '0'){
      thisLineActionBtn = '<center><input type="checkbox" class="chkrrline" name="" onclick="ERPLIST.lineChooser(this);"></center>';
    } else{
      thisLineActionBtn = '<center><input type="checkbox" class="chkrrline " name="" onclick="ERPLIST.lineChooser(this);"></center>';
    }

    // $td = $('<td/>');
    // $td.html(thisLineActionBtn);
    // $td.appendTo($tr);

    // process composite column first if has----------------------------------------------------------------------------------
    if(compositeColumnsLength > 0){
      $.each(ERPLIST.compositeColumns, function(groupName, groupColumns){
        $td = $('<td/>');
        $td.attr('class', groupName);
        $td.attr('fieldname', groupName);
        var compositeColumnsHTML = '';
        var divRow = '';
        $.each(groupColumns, function(fieldname, fieldprop){

          var fieldvalue = thisRow[fieldname];
          var fielddesc = (!!fieldprop.fielddesc) ? fieldprop.fielddesc : fieldname;
          var style = ( !!fieldprop.style ) ? 'style="' + fieldprop.style + '"': '';

          // *** write custom code here

          var obj_thisRowCopy_Json =  JSON.parse(thisRowCopy_Json);
          // fieldvalue = (fieldname == "powonumber") ? "<a href='erpdocument.php?docnumber="+fieldvalue+"&doctype=PO&formtype="+formtype+"' target='_blank''>"+fieldvalue+"</a>" : fieldvalue;
          
          fieldvalue = (fieldname == "docnumber") ? "<a href='erpdocument.php?docnumber="+fieldvalue+"&doctype=IPO&formtype=IPO' target='_blank'>"+fieldvalue+"</a>" : fieldvalue;
          // fieldvalue = (fieldname == "ponumber") ? "<a href='erpdocument.php?docnumber="+fieldvalue+"&doctype=PO&formtype=PO' target='_blank''>"+fieldvalue+"</a>" : fieldvalue;
          if(fieldname == "podocdate" && fieldvalue == null) fieldvalue="";
          if(fieldname == "fabricinhousedate"){
           fieldvalue = ERPLIST.generateHTMLinHouse(thisRowCopy,fieldname, fieldvalue);
          }
          // *** custom code end

          divRow += '<div class="crow" '+ '' +'>';
          if( !!fieldprop.composite ){
            divRow += '<div class="ccell1 '+ fieldname +'" '+ style +'>'+ fielddesc +'</div>';
            divRow += '<div class="ccell2 '+ fieldname +'">:</div>';
          }
          divRow += '<div class="ccell3 '+ fieldname +'_ccell3" '+ style +'>'+ fieldvalue +'</div>';
          divRow += "</div>";

          delete thisRowCopy[fieldname]; // its already procceed
          if(fieldprop.composite == false) return;
          $td_hide = $('<td/>');
          $td_hide.html(fieldvalue);
          $td_hide.attr("fieldname",fieldname);
          $td_hide.css('display','none');
          $td_hide.appendTo($tr);

        });

        var divTable = "<div id='ctable'>"; 
        divTable += divRow;  
        divTable += "</div>"; 

        compositeColumnsHTML = divTable;
        $td.html(compositeColumnsHTML)
          .css("cursor","pointer")
          .hover(
               function(){bgOn = $(this).closest("tr").css("background-color"); $(this).closest("tr").css("background-color", "lightblue");},
               function(){$(this).closest("tr").css("background-color", bgOn);}
             );
        if ( hideColumns.indexOf(groupName) >= 0 ) $td.css('display','none');
        $td.appendTo($tr);

      });
    }
    // end -----------------------------------------------------------------------------------------------------------------

    // precess rest of columns----------------------------------------------------------------------------------------------
    $.each(thisRowCopy, function (fieldname, fieldvalue) {

      // *** write custom code here
      fieldvalue = (fieldname == "docnumber") ? "<a href='erpdocument.php?docnumber="+fieldvalue+"&doctype=IPO&formtype=IPO' target='_blank''>"+fieldvalue+"</a>" : fieldvalue;
      // fieldvalue = (fieldname == "ponumber") ? "<a href='erpdocument.php?docnumber="+fieldvalue+"&doctype=PO&formtype=PO' target='_blank''>"+fieldvalue+"</a>" : fieldvalue;
      if(fieldname == "fabricinhousedate"){
        fieldvalue = ERPLIST.generateHTMLinHouse(thisRowCopy,fieldname, fieldvalue);
      }

      // *** custom code end

      $td = $('<td/>');
        $td.html(fieldvalue)
          .css("white-space","pre-wrap")
          .attr("fieldname",fieldname)
          .attr("class",fieldname)
          .css("cursor","pointer")
          .hover(
               function(){bgOn = $(this).closest("tr").css("background-color"); $(this).closest("tr").css("background-color", "lightblue");},
               function(){$(this).closest("tr").css("background-color", bgOn);}
             );
        if ( hideColumns.indexOf(fieldname) >= 0 ) $td.css('display','none');
        $td.appendTo($tr);
    });


    // *** custom code start-----------------------------------------------------------------------------------------
    // $tr.find('td.requiredinformation').append(thisLineActionBtn);
    // *** custom code end-------------------------------------------------------------------------------------------

    if(linestatus == 'Complete'){
      $tr.css("background-color", "#FFFFCC");
    }else if(linestatus == 'Released'){
      $tr.css("background-color", "#AEF5D4");
    }

    $tr.click( function() { 
        // sendBackSearchChoice($(this));
      })
      .appendTo($tbody);
  });

  $thead.appendTo($table)
  $tbody.appendTo($table)

  return $table;
};





/**
* Custom table generate code------------------------------------------------------------------------------------------------------
*/










/**
* Custom function code------------------------------------------------------------------------------------------------------
*/
ERPLIST.showPlannedDateForm = function (thisbtn){
  $(thisbtn).parents('td').find('#formDiv').css({'display':'block'});
  $(thisbtn).parents('td').find('#btnDiv1').css({'display':'none'});
  $(thisbtn).parents('td').find('#btnDiv2').css({'display':'none'});
  jsClient.initDateTimePicker();
}

ERPLIST.setFabricInhouseDate = function(thisbtn, idlines){
  var fabricinhousedate = $(thisbtn).parents('td').find('#formDiv #fabricinhousedate').val();
  var rrnumber = $(thisbtn).closest('tr').find('td[fieldname=rrnumber]').text();
  
  //click checkbox for uncheck when set fabric inhouse date
  if($(thisbtn).closest('tr').find('td input.chkrrline').prop('checked')){
    $(thisbtn).closest('tr').find('td input.chkrrline').trigger('click');
  }
  
  var postData = JSON.stringify({idlines:idlines, fabricinhousedate:fabricinhousedate});
  var mType    = 'post';
  var mUrl     = ERPLIST._URL_API;
  var mReqType = "setFabricInhouseDate";
  var returnData = jsClient.communicationToServer(mReqType, postData, mUrl, mType, false);

  returnData = JSON.parse(returnData);
  if(returnData.result == 'success'){
    $(thisbtn).parents('td').find('#formDiv').css({'display':'none'});
    $(thisbtn).parents('td').find('#btnDiv1').css({'display':'none'});
    $(thisbtn).parents('td').find('#btnDiv2').css({'display':'block'});

    $(thisbtn).parents('td').find('#showInhouseDate').css({'display':'block'});
    $(thisbtn).parents('td').find('#showInhouseDate').find('span').text(fabricinhousedate);

    jsClient.msgDisplayer('success:: Successfully updated inhouse date '+rrnumber); // green
  }

}

ERPLIST.generateHTMLinHouse = function(thisRowCopy,fieldname, fieldvalue){
  var fabricinhousedate = fieldvalue;

  if(fieldvalue == "" || fieldvalue == null || fieldvalue == "0000-00-00"){
    var content = '<div id="formDiv" style="display:none;">'
    content += '<input type="text" class="datepicker" name="fabricinhousedate" value="" id="fabricinhousedate">';
    content += '<input type="button" value="Done" onclick="ERPLIST.setFabricInhouseDate(this ' +","+ '  \'' + thisRowCopy['idlines'] + '\')"/>';
    content += '</div>';

    var content2 = '<div id="btnDiv1">';
    content2 += '<input type="button" value="Enter In-house Date" onclick="ERPLIST.showPlannedDateForm(this)"/>';
    content2 += '</div>';

    var content3 = '<div id="btnDiv2" style="float:left;display:none;">';
    content3 += '<a href="javascript:void(0)" onclick="ERPLIST.showPlannedDateForm(this)"><img src="img/edit.png"></a>';
    content3 += '</div>';

    var content4 = '<div id="showInhouseDate" style="float:left;display:none;">';
    content4 += '<span>' +fabricinhousedate+ '</span>';
    content4 += '</div>';

    fieldvalue = content4;
    fieldvalue += content;
    fieldvalue += content2;
    fieldvalue += content3;
  }else{
    var content = '<div id="formDiv" style="display:none;">'
    content += '<input type="text" class="datepicker" name="fabricinhousedate" value="'+fabricinhousedate+'" id="fabricinhousedate">';
    content += '<input type="button" value="Done" onclick="ERPLIST.setFabricInhouseDate(this ' +","+ '  \'' + thisRowCopy['idlines'] + '\')"/>';
    content += '</div>';

    var content2 = '<div id="btnDiv2" style="float:left;">';
    content2 += '<a href="javascript:void(0)" onclick="ERPLIST.showPlannedDateForm(this)"><img src="img/edit.png"></a>';
    content2 += '</div>';

    var content3 = '<div id="showInhouseDate" style="float:left;">';
    content3 += '<span>' +fabricinhousedate+ '</span>';
    content3 += '</div>';

    fieldvalue = content3;
    fieldvalue += content;
    fieldvalue += content2;          
  }  

  return fieldvalue;
}

ERPLIST.alllineChooser = function(thisflag){
  if($(thisflag).prop('checked')){
    $('.chkrrline').each(function(){
      $(this).prop('checked', true);
      ERPLIST.lineChooser(this);
    });
  }else{
    $('.chkrrline').each(function(){
      $(this).prop('checked', false);
      ERPLIST.lineChooser(this);
    });
  }

}


ERPLIST.lineChooser = function(thisf){
  var thisrow = $(thisf).parent().parent().parent().index();
  
  var idlines = $(thisf).closest('tr').find('td[fieldname=idlines]').text();
  var linestatus = $(thisf).closest('tr').find('td[fieldname=linestatus]').text();
  var supplier = $(thisf).closest('tr').find('td[fieldname=suppliername]').text();
  var purchasemode = $(thisf).closest('tr').find('td[fieldname=purchasemode]').text();
  var currency = $(thisf).closest('tr').find('td[fieldname=currency]').text();
  var company = $(thisf).closest('tr').find('td[fieldname=company]').text();

  console.log(linestatus);
    // define array
    if(!!!ERPLIST.selectedLineInfo){
      ERPLIST.selectedLineInfo  = {};
      ERPLIST.selectedLineInfo.uniquekey = [];
      ERPLIST.selectedLineInfo.idlines = [];
      ERPLIST.selectedLineInfo.linestatus = [];
      ERPLIST.selectedLineInfo.supplier = [];
      ERPLIST.selectedLineInfo.purchasemode = [];
      ERPLIST.selectedLineInfo.currency = [];
      ERPLIST.selectedLineInfo.company = [];
    } 


    if($(thisf).prop('checked')){
      $(thisf).prop('checked', true);

      // push data in array
      ERPLIST.selectedLineInfo.uniquekey.push(thisrow);
      ERPLIST.selectedLineInfo.idlines.push(idlines);
      ERPLIST.selectedLineInfo.supplier.push(supplier);
      ERPLIST.selectedLineInfo.linestatus.push(linestatus);
      ERPLIST.selectedLineInfo.purchasemode.push(purchasemode);
      ERPLIST.selectedLineInfo.currency.push(currency);
      ERPLIST.selectedLineInfo.company.push(company);

     // Check end customer, division and SO type... which need to be same

      var arrayLengthSupplier = ERPLIST.selectedLineInfo.supplier.length;
      var chkSupplier  = ERPLIST.selectedLineInfo.supplier[0];      

      var arrayLengthLinestatus = ERPLIST.selectedLineInfo.linestatus.length;
      var chkLinestatus  = ERPLIST.selectedLineInfo.linestatus[0];     

      var arrayLengthPurchasemode = ERPLIST.selectedLineInfo.purchasemode.length;
      var chkPurchasemode  = ERPLIST.selectedLineInfo.purchasemode[0];

      var arrayLengthCurrency = ERPLIST.selectedLineInfo.currency.length;
      var chkCurrency  = ERPLIST.selectedLineInfo.currency[0];

      var arrayLengthCompany = ERPLIST.selectedLineInfo.company.length;
      var chkCompany  = ERPLIST.selectedLineInfo.company[0];

      if(arrayLengthSupplier > 0 || arrayLengthLinestatus > 0 || arrayLengthPurchasemode > 0 || arrayLengthCurrency > 0 || arrayLengthCompany > 0){
        if(supplier != chkSupplier){
          alert("Supplier need to be same.");
          $(thisf).prop('checked', false);
          ERPLIST.popUncheckedValue(thisrow);

          return;
        }
        if(company != chkCompany){
          alert("Division need to be same.");
          $(thisf).prop('checked', false);
          ERPLIST.popUncheckedValue(thisrow);

          return;
        }
        if(linestatus != chkLinestatus && linestatus == 'Complete'){
          alert("Status Should be Complete");
          $(thisf).prop('checked', false);
          ERPLIST.popUncheckedValue(thisrow);

          return;
        }
        if(purchasemode != chkPurchasemode){
          alert("Purchase mode need to be same.");
          $(thisf).prop('checked', false);
          ERPLIST.popUncheckedValue(thisrow);

          return;
        }
        if(currency != chkCurrency){
          alert("Currency need to be same.");
          $(thisf).prop('checked', false);
          ERPLIST.popUncheckedValue(thisrow);

          return;
        }

      }

    } else {
      $(thisf).prop('checked', false);


      var index = ERPLIST.selectedLineInfo.uniquekey.indexOf(thisrow);

      // pop data in array
      ERPLIST.popUncheckedValue(thisrow);
    }

}

ERPLIST.popUncheckedValue = function(thisrow){
    var index = ERPLIST.selectedLineInfo.uniquekey.indexOf(thisrow);
    ERPLIST.selectedLineInfo.uniquekey.splice(index, 1);
    ERPLIST.selectedLineInfo.idlines.splice(index, 1);
    ERPLIST.selectedLineInfo.supplier.splice(index, 1);
    ERPLIST.selectedLineInfo.linestatus.splice(index, 1);
    ERPLIST.selectedLineInfo.purchasemode.splice(index, 1);
    ERPLIST.selectedLineInfo.currency.splice(index, 1);
    ERPLIST.selectedLineInfo.company.splice(index, 1);
    console.log(JSON.stringify(ERPLIST.selectedLineInfo.idlines) + '---' + index);

}



ERPLIST.cancel = function(){
   if(!!!ERPLIST.selectedLineInfo || ERPLIST.selectedLineInfo.idlines.length == 0){
    alert('You need to select atleast one RR line');
    return;
  }

  var idlines = ERPLIST.selectedLineInfo.idlines;

  var r = confirm(ERPLIST.selectedLineInfo.rrnumbers + ' will be gone to Allocated RR list');
  if(!r) return;


  var mType    = 'post';
  var mUrl     = ERPLIST._URL_API;
  var mReqType = "sendtoAllocatedRR";
  var postData = JSON.stringify({
    idlines  : ERPLIST.selectedLineInfo.idlines 
  });
  var returnData = jsClient.communicationToServer(mReqType, postData, mUrl, mType, false);

  returnData = JSON.parse(returnData);
  console.log(returnData.result);

  if(returnData.result == 'success'){
    ERPLIST.getListData(10,   1);
    var msgString  = 'success:: Successfully '+ ERPLIST.selectedLineInfo.rrnumber +' lines cancel for PO creation.';
    jsClient.msgDisplayer(msgString); // green
    delete(ERPLIST.selectedLineInfo);
  }  


}


ERPLIST.createPO = function(){
  if(!!!ERPLIST.selectedLineInfo || ERPLIST.selectedLineInfo.idlines.length == 0){
    alert('You need to select atleast one Requisition line');
    return;
  }

  length = ERPLIST.selectedLineInfo.idlines.length;
  requisitionStatus = ERPLIST.selectedLineInfo.linestatus;
  for(i=0 ; i < length ; i++){
    //check rr status is po created 
    if(requisitionStatus[i] == 'Released' || requisitionStatus[i] == 'Entered'){
      alert('Can not create PO with the status Entered or Released.');
      return;
    }
  }

  //Start confirm dialog PopUp
  $('<div id="jQueryUIDialogDiv"></div>').dialog({
     width: 500,
      modal: true,
      title: "Confirmation for Creating PO",
      open: function () {
          var markup = '<table><tr><th></th><th>Yes</th><th>Not Required</th></tr>';
          markup += '<tr><td>Capex Approved</td><td><input type="checkbox" class="approvalChk radioCapex" id="" name="" onclick=""></td><td><input type="checkbox" class="approvalChk radioCapex" id="" name="" onclick=""></td></tr>';
          markup += '<tr><td>Requisition Approved</td><td><input type="checkbox" class="approvalChk radioRequisition" id="" name="" onclick=""></td><td><input type="checkbox" class="approvalChk radioRequisition" id="" name="" onclick=""></td></tr>';
          markup += '<tr><td>Quotation Approved</td><td><input type="checkbox" class="approvalChk radioQuotation" id="" name="" onclick=""></td><td><input type="checkbox" class="approvalChk radioQuotation" id="" name="" onclick=""></td></tr>';
          markup += '<tr><td>CS Approved</td><td><input type="checkbox" class="approvalChk radioCS" id="" name="" onclick=""></td><td><input type="checkbox" class="approvalChk radioCS" id="" name="" onclick=""></td></tr></table>';
          
          // var markup = '<table><tr><td><input type="checkbox" class="approvalChk" id="" name="" onclick=""></td><td>Capex Approved</td></tr>';
          // markup += '<tr><td><input type="checkbox" class="approvalChk" id="" name="" onclick=""></td><td>Requisition Approved</td></tr>';
          // markup += '<tr><td><input type="checkbox" class="approvalChk" id="" name="" onclick=""></td><td>Quotation Approved</td></tr>';
          // markup += '<tr><td><input type="checkbox" class="approvalChk" id="" name="" onclick=""></td><td>CS Approved</td></tr></table>';
          $(this).html(markup);
          ERPLIST.checkboxAsRadio();
      },
      buttons: {
          "Yes": function () {
              var allChk = 1;
              var count = 0;
              $('.approvalChk').each(function(){
                if($(this).is(":checked")){
                  count++;
                }else{
                  allChk = 0;
                }
              });

              console.log(count);

              if(count != 4){
                alert("All Condition must be checked else can not create PO.");
              }else{
                var next_href = '/erp-nonpo/erpdocument.php?doctype=TI&formtype=TI&idlines=' + ERPLIST.selectedLineInfo.idlines;
                window.location = next_href;
              }
              
          },
          No: function () {
              $(this).dialog("close");
          }
      }
  }); //end confirm dialog PopUp

  
}


ERPLIST.checkboxAsRadio = function(){

  $(".radioCapex").change(function() {
    var checked = $(this).is(':checked');
    $(".radioCapex").prop('checked',false);
    if(checked) {
        $(this).prop('checked',true);
    }
  });

  $(".radioRequisition").change(function() {
    var checked = $(this).is(':checked');
    $(".radioRequisition").prop('checked',false);
    if(checked) {
        $(this).prop('checked',true);
    }
  });

  $(".radioQuotation").change(function() {
    var checked = $(this).is(':checked');
    $(".radioQuotation").prop('checked',false);
    if(checked) {
        $(this).prop('checked',true);
    }
  });

  $(".radioCS").change(function() {
    var checked = $(this).is(':checked');
    $(".radioCS").prop('checked',false);
    if(checked) {
        $(this).prop('checked',true);
    }
  });

}

ERPLIST.getAutoCompleteInfo = function(){
  var searchParams = {
    'reqType': 'getProcurer'
  };

  var mType = 'get';
  var mUrl     = "list-rr-released_api.php";
  var mReqType = "";

  var returnData = jsClient.communicationToServer(mReqType, searchParams, mUrl, mType, false);

  console.log(returnData);
   if (returnData.length > 0) {

    data = JSON.parse(returnData);
   

    var purchasemodeTags = JSON.parse(data['purchasemode']);


    $( ".modal_procurer" ).autocomplete({
      source: purchasemodeTags
    });

   }

}


ERPLIST.setProcurer = function(){
  if(!!!ERPLIST.selectedLineInfo || ERPLIST.selectedLineInfo.idlines.length == 0){
    alert('You need to select atleast one Requisition line');
    return;
  }

  length = ERPLIST.selectedLineInfo.idlines.length;
  requisitionStatus = ERPLIST.selectedLineInfo.linestatus;
  for(i=0 ; i < length ; i++){
    //check rr status is po created 
    if(requisitionStatus[i] == 'Released'){
      alert('PO has already been created.');
      return;
    }
  }

  //Start confirm dialog PopUp
  $('<div id="jQueryUIDialogDiv"></div>').dialog({
     width: 500,
      modal: true,
      title: "Set Procurer",
      open: function () {
          var markup = '<table class="no_border"><tr><td>Procurer :</td><td><input type="text" id="modal_procurer" name="" class="modal_procurer" onclick="ERPLIST.getAutoCompleteInfo();"></td></tr></table>';
          $(this).html(markup);

          // ERPLIST.getAutoCompleteInfo();
      },
      buttons: {
          "Yes": function () {
              ERPLIST.assignProcurerName(this);
              $(this).dialog("close");
              
          },
          No: function () {
              $(this).dialog("close");
          }
      }
  }); //end confirm dialog PopUp



  
}



ERPLIST.acknowledgeCancellation = function() {

  if(!!!ERPLIST.selectedRRLines){
    alert("You have to select One or More RR Line");
    return;
  }

  if(ERPLIST.selectedRRLines.idlines.length =='0'){
    alert("You have to select One or More RR Line");
    return;
  }

  var selectedRRLines = ERPLIST.selectedRRLines;
  var isrrfreezed = selectedRRLines.isrrfreezed;

  if(isrrfreezed =='0'){
    alert("There have no request for Acknowledge Cancellation.");
    return;
  }

  //Start confirm dialog PopUp
  $('<div id="jQueryUIDialogDiv"></div>').dialog({
     width: 500,
      modal: true,
      title: "RR Modification/Cancellation",
      open: function () {
          var markup = "Are you sure, you want to Acknowledge the Cancellation?";
          $(this).html(markup);
      },
      buttons: {
          "Yes": function () {
              ERPLIST.approveacknowledgeCancellation();
          },
          No: function () {
              $(this).dialog("close");
          }
      }
  }); //end confirm dialog PopUp
}

ERPLIST.assignProcurerName = function(thismodal) {
  var selectedRRLines = ERPLIST.selectedLineInfo;
  var idlines = selectedRRLines.idlines;
  var procurer = $(thismodal).find('table input#modal_procurer').val();


  var postData = {
    reqType: 'setProcurer',
    idlines: JSON.stringify(idlines),
    procurer: procurer
  };

  console.log(postData);


  $.ajax({
    type: 'post',
    url: 'list-rr-released_api.php',
    data: postData,
    success: function(data) {
        // data = JSON.parse(data);
        // if (!!data.errormsgs && data.errormsgs.length > 0) {
          
        // } else {
        //   ERPLIST.getListData(100,    1);
        // }
        delete(ERPLIST.selectedLineInfo);
        ERPLIST.getListData(100,    1);
    }
  }).fail(function(e) {
    alert('Assign failed, please try again.');
  });

}


ERPLIST.approveacknowledgeCancellation = function() {
  var selectedRRLines = ERPLIST.selectedRRLines;
  var idliness = selectedRRLines.idlines;
  var rrnumber = selectedRRLines.rrnumber;
  var isrrfreezed = selectedRRLines.isrrfreezed[0];
  var reqType = '';
  if(isrrfreezed == '1'){
    var _url = 'docso_api.php';
    var reqType = 'modifyCancelAcknowledged_salesOrder';
  } else if(isrrfreezed == '2'){
    var _url = 'doccp_api.php';
    var reqType = 'modifyCancelAcknowledged_CapacityPlan';
  } else if(isrrfreezed == '3'){
    var _url = 'docbom_api.php';
    var reqType = 'modifyCancelAcknowledged_BOM';
  } else if(isrrfreezed == '4'){
    var _url = 'docfm_api.php';
    var reqType = 'modifyCancelAcknowledged_MaterialLine';
  } else if(isrrfreezed == '5'){
    var _url = 'docfm_api.php';
    var reqType = 'modifyCancelAcknowledged_MaterialListDoc';
  }

  var postData = {
    reqType: reqType,
    docnumber: JSON.stringify(idliness),
    fromWchich: 'RR'
   };
  $.ajax({
    type: 'post',
    url: _url,
    data: postData,
    success: function(data) {
        data = JSON.parse(data);
        if (!!data.errormsgs && data.errormsgs.length > 0) {
          console.log(data.errormsgs.join('\n'));
          alert("===>"+data.errormsgs.join('\n'));
        } else {
           ERPLIST.getListData(10,    1);
           delete ERPLIST.selectedRRLines;
          jQuery('#jQueryUIDialogDiv').dialog('close');
          $('body').find('#jQueryUIDialogDiv').remove();

          var cloneDiv = $('#listSuccessDiv').clone();
          cloneDiv.css({'display':'block'})
          .insertBefore('#listSuccessDiv')
          .find('#listSuccessMsg').text(rrnumber +' Acknowledge Cancellation is success');
        }
    }
  }).fail(function(e) {
    alert('Assign failed, please try again.');
  });
}



ERPLIST.actionButton = function(){
  var cloneDiv = $('#listSuccessDiv').clone();
  cloneDiv.css({'display':'block'})
      .insertBefore('#listSuccessDiv')
      .find('#listSuccessMsg').text('this is success');

  var cloneDiv = $('#listWarningDiv').clone();
  cloneDiv.css({'display':'block'})
      .insertBefore('#listWarningDiv')
      .find('#listWarningMsg').text('this is warning');

  var cloneDiv = $('#listErrorDiv').clone();
  cloneDiv.css({'display':'block'})
      .insertBefore('#listErrorDiv')
      .find('#listErrorMsg').text('this is error');
}

ERPLIST.initLibFieldsForSearch = function(){
  ERPLIST.libraryColumns = {
    // docstatus:{
    //     style: 'font-weight:bold; color:green',
    //     customsearch: true,
    //     islibrary: true,
    //     datasource: {
    //         '0': 'Entered',
    //         '1': 'Approved by Section Head',
    //         '2': 'Approved by Dept. Head',
    //         '3': 'Approved by COO',
    //         '4': 'Approved by CEO',
    //         '5': 'Completed',
    //         '9': 'Cancelled',
    //      },        
    //     fielddesc: 'Doc Status',
    //     showsearchimg: true,
    // },

    // department: {
    //   fielddesc: 'Department',
    //   sql: "SELECT Description AS code, Description AS description FROM mrd_library WHERE LibraryName = 'ITINV_Department' ",
    // },
    // section: {
    //   fielddesc: 'Section',
    //   sql: "SELECT Description AS code, Description AS description FROM mrd_library WHERE LibraryName = 'ITINV_Section' ",
    // },
    // company: {
    //   fielddesc: 'Company',
    //   sql: "SELECT Description AS description, Code AS code FROM mrd_library WHERE LibraryName = 'company' ",
    // },
    // returntype: {
    //   fielddesc: 'returntype',
    //   sql: "SELECT Description AS description, Code AS code FROM mrd_library WHERE LibraryName = 'returntype' ",
    // },
    // department: {
    //   fielddesc: 'Department',
    //   sql: "SELECT Code AS code, Description AS description FROM mrd_library WHERE LibraryName = 'ITINV_Department' ",
    // },
    // section: {
    //   fielddesc: 'Section',
    //   sql: "SELECT Code AS code, Description AS description FROM mrd_library WHERE LibraryName = 'ITINV_Section' ",
    // },
    // section: {
    //   fielddesc: 'Section',
    //   sql: "SELECT Code AS code, Description AS description FROM mrd_library WHERE LibraryName = 'ITINV_Section' ",
    // },
    
   
  };  
  return ERPLIST.libraryColumns;
}