/**
 * Declare the namespace LIZERP if not existent
 */
var LIZERP = LIZERP || {};

$.extend(LIZERP, {
  _ERP_DOCACRONYM: '',
  _FIELDSETS_HEADER: ['fieldset_documentinformation', 'fieldset_logisticsinformation'],
  _FIELDS_AUTOFILLUP: ['ldcslnumber'],
  _FIELDSETS_RIGHTFORM: ['fieldset_linegroup1','fieldset_linegroup2','fieldset_linegroup3','fieldset_linegroup4','fieldset_linegroup5'],

  foo: 'here for no reason other than to be the last line, without a comma'
});


LIZERP.changeDocStatus = function(docnumber, docstatus){
  var searchParams = {};
  searchParams.docnumber = docnumber;
  searchParams.docstatus = docstatus;
  searchParams.reqType = 'changeDocStatus';
  return $.post(LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM], searchParams, changeDocStatus_return(), 'json');

  function changeDocStatus_return(extraParams) {
    return function(data, textStatus, jqXHR) {
      if (data.result == 'success') {
        location.reload();
      } else {
        alert(data.errormsgs.join('\n'));
      }
    }
  }

}

LIZERP.updateRevisedPO = function(docnumber){

  LIZERP.autoFillup_newRR();


  var searchParams = {};
  searchParams.docnumber = docnumber;
  searchParams.reqType = 'updateRevisedPO';
  return $.post(LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM], searchParams, updateRevisedPO_return(), 'json');

  function updateRevisedPO_return(extraParams) {
    return function(data, textStatus, jqXHR) {
      console.log(data.result);
      if (data.result == 'success') {
        location.reload();
      } else {
        alert(data.errormsgs.join('\n'));
      }
    }
  }

}

LIZERP.poAmendment = function(docnumber, docstatus){
  var searchParams = {};
  searchParams.docnumber = docnumber;
  searchParams.docstatus = docstatus;
  searchParams.reqType = 'poAmendment';
  return $.post(LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM], searchParams, poAmendment_return(), 'json');

  function poAmendment_return(extraParams) {
    return function(data, textStatus, jqXHR) {
      if (data.result == 'success') {
        location.reload();
      } else {
        alert(data.errormsgs.join('\n'));
      }
    }
  }

}

LIZERP.getPOLineInfo = function(){
  var params     = paramsToObj(window.location.search);
  var idlines  = params.idlines; 

  var searchParams = {
    'reqType': 'getPOLineInfo',
    'idlines': idlines
  };

  var mType = 'get';
  var mUrl     = "docpr_api.php";
  var mReqType = "";

  var returnData = jsClient.communicationToServer(mReqType, searchParams, mUrl, mType, false);

  console.log(returnData);

  if (returnData.length > 0) {

    data = JSON.parse(returnData);
    $tr2 = LIZERP.getLineBeingEdited();

    $.each(data, function(index, line){
      // $tr2.find('input.saveLine:visible').first().click();
      $tr2.find('td.itemcode input').val(line.itemcode);
      $tr2.find('td.itemtype input').val(line.itemtype);
      $tr2.find('td.itemdescription textarea').val(line.itemdescription);
      $tr2.find('td.pricerequisitionnumber input').val(line.pricerequisitionnumber);
      $tr2.find('td.unitprice input').val(line.unitprice);
      $tr2.find('td.iduom select').val(line.iduom);
      $tr2.find('td.fabricinhousedate input').val(line.fabricinhousedate);
      $tr2.find('td.rrnumber input').val(line.rrnumber);
      $tr2.find('td.parentrrnumber input').val(line.parentrrnumber);
      $tr2.find('td.tnxqty input').val(line.requirednetqty);
      $tr2.find('td.originalqty input').val(line.requirednetqty);
      $tr2.find('td.previousqty input').val(line.requirednetqty);
      $tr2.find('td.iduom input').val(line.iduom);
      $tr2.find('td.dlvbrktext textarea').val(line.dlvbrktext);
      $tr2.find('td.salesorder input').val(line.salesorder);
      LIZERP.saveLine();
      $tr2 = LIZERP.getLineBeingEdited();


    });

    $('#fieldset_documentinformation').find('.formGroup select[name=endcustomer]').val(data[0]['endcustomer']);
    $('#fieldset_documentinformation').find('.formGroup select[name=endcustomer]').attr('disabled','disabled');
    $('#fieldset_documentinformation').find('.formGroup select[name=customer]').val(data[0]['customer']);
    $('#fieldset_documentinformation').find('.formGroup select[name=customer]').attr('disabled','disabled');
    $('#fieldset_documentinformation').find('.formGroup select[name=company]').val(data[0]['company']);
    $('#fieldset_documentinformation').find('.formGroup select[name=company]').attr('disabled','disabled');
    $('#fieldset_documentinformation').find('.formGroup input[name=previousponumber]').val(data[0]['powonumber']);
    $('#fieldset_documentinformation').find('.formGroup input[name=previousponumber]').attr('disabled','disabled');

    LIZERP.getSOInfo(data[0]['salesorder']);
    LIZERP.handleFormLinesTrClick();

    // click first tr
    // $(LIZERP.formId + ' #formLines table tbody tr:first').click();
    $(LIZERP.formId + ' #formLines tr.new').remove();

    // System will click now in Save button in upper button
    // and document will create, then user will modify line
    
    if(!!params.idlines && params.idlines != ''){
      LIZERP.saveForm('autoLineFill_Save_Edit');
    }


  }

  console.log('\n\n ***delivery line auto fillup');

}




/**
 * [handleLookup description]
 * @param  {[type]} thisPtr [description]
 * @return {[type]}         [description]
 * ============================================================================== All Loupe List Work =================================================================================
 */
LIZERP.handleLookup = function(thisPtr){
  var fieldname = $(thisPtr).closest('div').find('input, select').prop('name');
  if(fieldname == 'project'){
    LIZERP.loupeListProjectCode(thisPtr);
    // LIZERP.handleSearchForm('designid');
  } else if(fieldname == 'itemcode'){
      LIZERP.loupeListItemCode(thisPtr);

  }else if(fieldname == 'pricerequisitionnumber'){
    LIZERP.loupeListPriceInquiry();
  }  else {
  }
  
}



LIZERP.loupeListProjectCode = function() {
  var prepopulate = {};

  var prepopJS = (Object.keys(prepopulate).length > 0) ? 'var prepopulate = ' + JSON.stringify(prepopulate) + ';' : '';
  prepopJS = prepopJS + "var ERPLIST = ERPLIST || {};";
  prepopJS = prepopJS + "$(document).ajaxStop(function() {";
  prepopJS = prepopJS + "ERPLIST.sendBackSearchChoice = function( thisRow ) {";
  prepopJS = prepopJS + "var projectcode = $(thisRow).find('td[fieldname=projectcode]').text();";
  prepopJS = prepopJS + "var costcenter = $(thisRow).find('td[fieldname=costcenter]').text();";
  prepopJS = prepopJS + "var costdepartment = $(thisRow).find('td[fieldname=costdepartment]').text();";
  prepopJS = prepopJS + "  $.fancybox.close();";
  prepopJS = prepopJS + "  $(LIZERP.formId + '#rightFormLines #lg_project').val(projectcode);";
  prepopJS = prepopJS + "  $(LIZERP.formId + '#rightFormLines #lg_costcenter').val(costcenter);";
  prepopJS = prepopJS + "  $(LIZERP.formId + '#rightFormLines #lg_costdept').val(costdepartment);";
  prepopJS = prepopJS + "  $(LIZERP.formId + '#rightFormLines #lg_project').focus();";
  prepopJS = prepopJS + "};";
  prepopJS = prepopJS + "});";

  var content = '<div id="popupListContent">\
    <div id="loadingDiv">\
      <center><img src="/images/loading_spinner.gif"></center>\
    </div>\
  </div>';
  content+= '<script> ' + prepopJS + '</script>'; // add some js

  $.fancybox({
    type: 'html',
    content: content,
    minWidth: 500,
    minHeight: 300,
    afterLoad: function(){
      this.title = "<b>Project List</b>";
    },    
    afterShow: function() {
      loadSessionContent();
      $.fancybox.update();
    },
    helpers: {
     title : {
      type : 'inside',
      position : 'top'
     },
     overlay : {
      css  : { /* 'background-color' : '#fff' */}
     }     
    }  
  });
  jQuery('.fancybox-title').css({'text-align':'center', 'margin-bottom':'10px'});

  function loadSessionContent(){
    $.ajax({
      async: false,
      type: 'get',
      url: '/erp-nonpo/list-pr-project-session.php',
      success: function(htmlContent) {
        $('#popupListContent').empty().append(htmlContent);
        var searchParams = (Object.keys(prepopulate).length > 0) ? prepopulate : {};
        //                  show,   page,   api_url
        ERPLIST.getListData(50,   1,    ERPLIST._URL_API, searchParams);
        updateFancyBox();
      }
    }).fail(function(e) {
      alert('Loading failed, please try again.');
    });
  }

  function updateFancyBox(){
    $(document).ajaxStop(function() {
      // place code to be executed on completion of 
      // last outstanding ajax call here
      // this is needed// because ajax call is asyncronus
      $.fancybox.update(); 
    });
  }

}


LIZERP.loupeListItemCode = function(thisPtr) {
  var prepopulate = {};

  // prepopulate.ItemName = 'Ram';
  // prepopulate.ItemName = $(LIZERP.formId + '#rightFormLines #lg_itemname').find('select,input').val();
  prepopulate.ItemName        = $(thisPtr).closest('fieldset').find('select#lg_itemname').val();
  prepopulate.ItemNature      = $(thisPtr).closest('fieldset').find('select#lg_itemnature').val();
  prepopulate.Brand           = $(thisPtr).closest('fieldset').find('select#lg_brand').val();
  prepopulate.ColorCode       = $(thisPtr).closest('fieldset').find('select#lg_color').val();
  prepopulate.Size            = $(thisPtr).closest('fieldset').find('input#lg_sizeormeasurement').val();
  prepopulate.ItemDescription = $(thisPtr).closest('fieldset').find('textarea#lg_itemdescription').val();



  var prepopJS = (Object.keys(prepopulate).length > 0) ? 'var prepopulate = ' + JSON.stringify(prepopulate) + ';' : '';
  prepopJS = prepopJS + "var ERPLIST = ERPLIST || {};";
  prepopJS = prepopJS + "$(document).ajaxStop(function() {";
  prepopJS = prepopJS + "ERPLIST.sendBackSearchChoice = function( thisRow ) {";
  prepopJS = prepopJS + "var ItemName = $(thisRow).find('td[fieldname=ItemName]').text();";
  prepopJS = prepopJS + "var ItemNature = $(thisRow).find('td[fieldname=ItemNature]').text();";
  prepopJS = prepopJS + "var Brand = $(thisRow).find('td[fieldname=Brand]').text();";
  prepopJS = prepopJS + "var ColorCode = $(thisRow).find('td[fieldname=ColorCode]').text();";
  prepopJS = prepopJS + "var Size = $(thisRow).find('td[fieldname=Size]').text();";
  prepopJS = prepopJS + "var ItemDescription = $(thisRow).find('td[fieldname=ItemDescription]').text();";
  prepopJS = prepopJS + "var ItemCode = $(thisRow).find('td[fieldname=ItemCode]').text();";
  // prepopJS = prepopJS + "alert(ItemCode);";

  prepopJS = prepopJS + "  $.fancybox.close();";

  prepopJS = prepopJS + "  $('#rightFormLines select').removeClass('select2');";
  prepopJS = prepopJS + "  $(LIZERP.formId + '#rightFormLines #lg_itemcode').val(ItemCode);";
  prepopJS = prepopJS + "  $(LIZERP.formId + '#rightFormLines #lg_itemname').val(ItemName);";
  prepopJS = prepopJS + "  $(LIZERP.formId + '#rightFormLines #lg_itemnature').val(ItemNature);";
  prepopJS = prepopJS + "  $(LIZERP.formId + '#rightFormLines #lg_brand').val(Brand);";
  prepopJS = prepopJS + "  $(LIZERP.formId + '#rightFormLines #lg_color').val(ColorCode);";
  prepopJS = prepopJS + "  $(LIZERP.formId + '#rightFormLines #lg_sizeormeasurement').val(Size);";
  prepopJS = prepopJS + "  $(LIZERP.formId + '#rightFormLines #lg_itemdescription').val(ItemDescription);";
  prepopJS = prepopJS + "  $(LIZERP.formId + '#rightFormLines #lg_itemcode').focus();";
  prepopJS = prepopJS + "  $('#rightFormLines').find('#lg_brand').select2();";
  prepopJS = prepopJS + "  $('#rightFormLines').find('#lg_color').select2();";
  prepopJS = prepopJS + "  $('#rightFormLines').find('#lg_itemname').select2();";
  prepopJS = prepopJS + "  $('#rightFormLines').find('#lg_itemnature').select2();";

  // prepopJS = prepopJS + "  $(LIZERP.formId + '#unitprice').val(acceptedprice);";
  prepopJS = prepopJS + "};";
  prepopJS = prepopJS + "});";

  var content = '<div id="popupListContent">\
    <div id="loadingDiv">\
      <center><img src="/images/loading_spinner.gif"></center>\
    </div>\
  </div>';
  content+= '<script> ' + prepopJS + '</script>'; // add some js

  $.fancybox({
    type: 'html',
    content: content,
    minWidth: 500,
    minHeight: 300,
    afterLoad: function(){
      this.title = "<b>Item Code List</b>";
    },    
    afterShow: function() {
      loadSessionContent();
      $.fancybox.update();
    },
    helpers: {
     title : {
      type : 'inside',
      position : 'top'
     },
     overlay : {
      css  : { /* 'background-color' : '#fff' */}
     }     
    }  
  });
  jQuery('.fancybox-title').css({'text-align':'center', 'margin-bottom':'10px'});

  function loadSessionContent(){
    $.ajax({
      async: false,
      type: 'get',
      url: '/erp-nonpo/list-pr-itemcode-session.php',
      success: function(htmlContent) {
        $('#popupListContent').empty().append(htmlContent);
        var searchParams = (Object.keys(prepopulate).length > 0) ? prepopulate : {};
        //                  show,   page,   api_url
        ERPLIST.getListData(50,   1,    ERPLIST._URL_API, searchParams);
        updateFancyBox();
      }
    }).fail(function(e) {
      alert('Loading failed, please try again.');
    });
  }

  function updateFancyBox(){
    $(document).ajaxStop(function() {
      // place code to be executed on completion of 
      // last outstanding ajax call here
      // this is needed// because ajax call is asyncronus
      $.fancybox.update(); 
    });
  }

}






LIZERP.getAutoCompleteInfo = function(){
  var searchParams = {
    'reqType': 'getCostCenterAndDept'
  };

  var mType = 'get';
  var mUrl     = "docpr_api.php";
  var mReqType = "";

  var returnData = jsClient.communicationToServer(mReqType, searchParams, mUrl, mType, false);

  console.log(returnData);
   if (returnData.length > 0) {

    data = JSON.parse(returnData);
   

    var costcenterTags   = JSON.parse(data['costcenter']);
    var projectTags      = JSON.parse(data['projectcode']);
    var purchasemodeTags = JSON.parse(data['purchasemode']);
    // var uomTags          = JSON.parse(data['iduom']);
    var itemdescription  = JSON.parse(data['itemdescription']);
    var size             = JSON.parse(data['size']);


    $( "#lg_costcenter" ).autocomplete({
      source: costcenterTags
    });
    $( "#lg_purchasemode" ).autocomplete({
      source: purchasemodeTags
    });
    // $('#lg_iduom' ).autocomplete({
    //   source: uomTags
    // });
    $('#lg_project' ).autocomplete({
      source: projectTags
    });
    $('#lg_sizeormeasurement' ).autocomplete({
      source: size
    });
    $('#lg_itemdescription' ).autocomplete({
      source: itemdescription
    });


   }

}






LIZERP.checkItemCodeAndAutoFill = function(){

  var itemcode = '';


  $("#lg_itemcode").blur(function(){
      itemcode   = $("#lg_itemcode").val();
      if(itemcode == "") return;
      
      var searchParams = {
        'reqType': 'checkItemCodeAndAutoFill',
        'itemcode': itemcode
      };

      var mType    = 'get';
      var mUrl     = "docpr_api.php";
      var mReqType = "";

      var returnData = jsClient.communicationToServer(mReqType, searchParams, mUrl, mType, false);

      console.log(returnData);
      if (returnData.length > 0) {
        data = JSON.parse(returnData); 
        var ItemName        = JSON.parse(data['ItemName']);
        var ItemNature      = JSON.parse(data['ItemNature']);
        var Brand           = JSON.parse(data['Brand']);
        var ColorCode       = JSON.parse(data['ColorCode']);
        var Size            = JSON.parse(data['Size']);
        var ItemDescription = JSON.parse(data['ItemDescription']);

        $("#lg_itemname").val(ItemName);
        $("#lg_itemnature").val(ItemNature);
        $("#lg_brand").val(Brand);
        $("#lg_color").val(ColorCode);
        $("#lg_sizeormeasurement").val(Size);
        $("#lg_itemdescription").val(ItemDescription);

        // $("#lg_itemname").attr('disabled','disabled');
        // $("#lg_itemnature").attr('disabled','disabled');
        // $("#lg_brand").attr('disabled','disabled');
        // $("#lg_color").attr('disabled','disabled');
        // $("#lg_sizeormeasurement").attr('disabled','disabled');
        // $("#lg_itemdescription").attr('disabled','disabled');
      }
  });

  



}











LIZERP.autoManageItemNature = function(){

  // $(selector).change(function)
  var itemName   = '';
  var itemNature = '';

  $("#lg_itemname").change(function(){
      itemName   = $("select#lg_itemname").val();
      itemNature = $("select#lg_itemnature").val();
      color      = $("select#lg_color").val();
      brand      = $("select#lg_brand").val();

      LIZERP.populateDropdown('color', 'NonPOColor', color, 'codevalequal');
      LIZERP.populateDropdown('lg_color', 'NonPOColor', color, 'codevalequal');

      LIZERP.populateDropdown('brand', 'NonPOBrand', brand, 'codevalequal');
      LIZERP.populateDropdown('lg_brand', 'NonPOBrand', brand, 'codevalequal');

      LIZERP.populateDropdown('itemname', 'NonPOitemname', itemName, 'codevalequal');
      LIZERP.populateDropdown('lg_itemname', 'NonPOitemname', itemName, 'codevalequal');

      console.log(itemName);


      if(itemName != "") LIZERP.checkItemNature(itemName, itemNature);
      // console.log('aa');
  });


  $("#lg_brand").change(function(){

      itemName   = $("select#lg_itemname").val();
      itemNature = $("select#lg_itemnature").val();
      color = $("select#lg_color").val();
      brand = $("select#lg_brand").val();

      LIZERP.populateDropdown('color', 'NonPOColor', color, 'codevalequal');
      LIZERP.populateDropdown('lg_color', 'NonPOColor', color, 'codevalequal');

      LIZERP.populateDropdown('brand', 'NonPOBrand', brand, 'codevalequal');
      LIZERP.populateDropdown('lg_brand', 'NonPOBrand', brand, 'codevalequal');

      LIZERP.populateDropdown('itemname', 'NonPOitemname', itemName, 'codevalequal');
      LIZERP.populateDropdown('lg_itemname', 'NonPOitemname', itemName, 'codevalequal');

      
  });

  $("#lg_color").change(function(){

      itemName   = $("select#lg_itemname").val();
      itemNature = $("select#lg_itemnature").val();
      color = $("select#lg_color").val();
      brand = $("select#lg_brand").val();

      LIZERP.populateDropdown('color', 'NonPOColor', color, 'codevalequal');
      LIZERP.populateDropdown('lg_color', 'NonPOColor', color, 'codevalequal');

      LIZERP.populateDropdown('brand', 'NonPOBrand', brand, 'codevalequal');
      LIZERP.populateDropdown('lg_brand', 'NonPOBrand', brand, 'codevalequal');

      LIZERP.populateDropdown('itemname', 'NonPOitemname', itemName, 'codevalequal');
      LIZERP.populateDropdown('lg_itemname', 'NonPOitemname', itemName, 'codevalequal');

      
  });


}



LIZERP.checkItemNature = function(itemName, itemNature){

  var searchParams = {
    'reqType': 'checkItemNature',
    'itemName': itemName,
    'itemNature': itemNature
  };

  var mType    = 'get';
  var mUrl     = "docpr_api.php";
  var mReqType = "";

  var returnData = jsClient.communicationToServer(mReqType, searchParams, mUrl, mType, false);

  console.log(returnData);
  if (returnData.length > 0) {
    data = JSON.parse(returnData); 
    var itemNature = data;
    console.log(itemNature);
  // $("#rightFormLines").find('.select2').removeClass('select2');
  // $(ZERP.FrmMgr.genFrm.formId).find('.select2').select2();

    $("#rightFormLines").find("#lg_itemnature").removeClass('select2');
    $("#rightFormLines").find("select#lg_itemnature").val(itemNature);
    $("#rightFormLines").find("#lg_itemnature").select2();
    if(itemNature != "") {
      $("select#lg_itemnature").attr('disabled','disabled');
    }else{
      $("select#lg_itemnature").attr('disabled',false);
    }
    // alert(itemNature);

  }
  
}













LIZERP.autoCalculateAmount = function(){
  
    var orderQty = 0;
    var unitPrice = 0;
    var extraCost = 0;
    var discountamount = 0;
 
    $("#lg_orderqty").blur(function(){
      orderQty = $("#lg_orderqty").val();
      unitPrice = $("#lg_unitprice").val();
      extraCost = $("#lg_extracost").val();
      discountamount = $("#lg_discountamount").val();

      orderQty = (orderQty == '')? 0 : orderQty;
      unitPrice = (unitPrice == '')? 0 : unitPrice;
      extraCost = (extraCost == '')? 0 : extraCost;
      discountamount = (discountamount == '')? 0 : discountamount;

      withoutDiscount = (parseFloat(orderQty)*parseFloat(unitPrice)) +  parseFloat(extraCost);
      withDiscount = (parseFloat(orderQty)*parseFloat(unitPrice)) +  parseFloat(extraCost) - parseFloat(discountamount);

      $("#lg_amountwithoutdiscount").val(withoutDiscount);
      $("#lg_amount").val(withDiscount);
    });

    $("#lg_unitprice").blur(function(){
      orderQty = $("#lg_orderqty").val();
      unitPrice = $("#lg_unitprice").val();
      extraCost = $("#lg_extracost").val();
      discountamount = $("#lg_discountamount").val();

      orderQty = (orderQty == '')? 0 : orderQty;
      unitPrice = (unitPrice == '')? 0 : unitPrice;
      extraCost = (extraCost == '')? 0 : extraCost;
      discountamount = (discountamount == '')? 0 : discountamount;

      withoutDiscount = (parseFloat(orderQty)*parseFloat(unitPrice)) +  parseFloat(extraCost);
      withDiscount = (parseFloat(orderQty)*parseFloat(unitPrice)) +  parseFloat(extraCost) - parseFloat(discountamount);

      $("#lg_amountwithoutdiscount").val(withoutDiscount);
      $("#lg_amount").val(withDiscount);
    });

    $("#lg_extracost").blur(function(){
      orderQty = $("#lg_orderqty").val();
      unitPrice = $("#lg_unitprice").val();
      extraCost = $("#lg_extracost").val();
      discountamount = $("#lg_discountamount").val();

      orderQty = (orderQty == '')? 0 : orderQty;
      unitPrice = (unitPrice == '')? 0 : unitPrice;
      extraCost = (extraCost == '')? 0 : extraCost;
      discountamount = (discountamount == '')? 0 : discountamount;

      withoutDiscount = (parseFloat(orderQty)*parseFloat(unitPrice)) +  parseFloat(extraCost);
      withDiscount = (parseFloat(orderQty)*parseFloat(unitPrice)) +  parseFloat(extraCost) - parseFloat(discountamount);

      $("#lg_amountwithoutdiscount").val(withoutDiscount);
      $("#lg_amount").val(withDiscount);
    });

    $("#lg_discountamount").blur(function(){
      orderQty = $("#lg_orderqty").val();
      unitPrice = $("#lg_unitprice").val();
      extraCost = $("#lg_extracost").val();
      discountamount = $("#lg_discountamount").val();

      orderQty = (orderQty == '')? 0 : orderQty;
      unitPrice = (unitPrice == '')? 0 : unitPrice;
      extraCost = (extraCost == '')? 0 : extraCost;
      discountamount = (discountamount == '')? 0 : discountamount;

      withoutDiscountAndExtracost = (parseFloat(orderQty)*parseFloat(unitPrice));
      withoutDiscountAnd = (parseFloat(orderQty)*parseFloat(unitPrice)) +  parseFloat(extraCost);
      discountpercentage = ( (parseFloat(discountamount)*100) / parseFloat(withoutDiscountAndExtracost) ).toFixed(2);
      withDiscount = (parseFloat(orderQty)*parseFloat(unitPrice)) +  parseFloat(extraCost) - parseFloat(discountamount);

      $("#lg_amountwithoutdiscount").val(withoutDiscount);
      $("#lg_discountpercentage").val(discountpercentage);
      $("#lg_amount").val(withDiscount);

    });

    $("#lg_discountpercentage").blur(function(){
      orderQty = $("#lg_orderqty").val();
      unitPrice = $("#lg_unitprice").val();
      extraCost = $("#lg_extracost").val();
      discountpercentage = $("#lg_discountpercentage").val();

      orderQty = (orderQty == '')? 0 : orderQty;
      unitPrice = (unitPrice == '')? 0 : unitPrice;
      extraCost = (extraCost == '')? 0 : extraCost;
      discountamount = (discountamount == '')? 0 : discountamount;

      withoutDiscount = (parseFloat(orderQty)*parseFloat(unitPrice)) +  parseFloat(extraCost);
      discountamount = ((((parseFloat(orderQty)*parseFloat(unitPrice)))*parseFloat(discountpercentage))/100).toFixed(2);
      withDiscount = (parseFloat(orderQty)*parseFloat(unitPrice)) +  parseFloat(extraCost) - parseFloat(discountamount);

      $("#lg_amountwithoutdiscount").val(withoutDiscount);
      $("#lg_discountamount").val(discountamount);
      $("#lg_amount").val(withDiscount);

    });





}


LIZERP.onDemandAutoCompleteInfo = function(){

  $('#lg_itemname').keyup(function(){
    var lengthItem = $('#lg_itemname').val().length;
    var itemName = $('#lg_itemname').val();

    if(lengthItem > 1){
      var searchParams = {
        'reqType': 'getItemName',
        'itemname': itemName
      };

      var mType = 'get';
      var mUrl     = "docpr_api.php";
      var mReqType = "";

      var returnData = jsClient.communicationToServer(mReqType, searchParams, mUrl, mType, false);

      console.log(returnData);
      if (returnData.length > 0) {

        data = JSON.parse(returnData);

        $( "#lg_itemname" ).autocomplete({
          source: data
        });
      }
    }
  });


  $('#lg_suppliername').keyup(function(){
    var lengthSupplierName = $('#lg_suppliername').val().length;
    var supplierName = $('#lg_suppliername').val();

    if(lengthSupplierName > 1){
      var searchParams = {
        'reqType': 'getSupplierName',
        'suppliername': supplierName
      };

      var mType = 'get';
      var mUrl     = "docpr_api.php";
      var mReqType = "";

      var returnData = jsClient.communicationToServer(mReqType, searchParams, mUrl, mType, false);

      console.log(returnData);
      if (returnData.length > 0) {

        data = JSON.parse(returnData);

        $( "#lg_suppliername" ).autocomplete({
          source: data
        });
      }
    }
  });


  $('#lg_project').blur(function(){
    var lengthProject = $('#lg_project').val().length;
    var project = $('#lg_project').val();

    if(lengthProject > 0){
      var searchParams = {
        'reqType': 'getCostDept',
        'project': project
      };

      var mType = 'get';
      var mUrl     = "docpr_api.php";
      var mReqType = "";

      var returnData = jsClient.communicationToServer(mReqType, searchParams, mUrl, mType, false);

      console.log(returnData);
      if (returnData.length > 0) {

        data = JSON.parse(returnData);

        $( "#lg_costcenter" ).val(data['costcenter']);
        $( "#lg_costdept" ).val(data['costdepartment']);

        $('#lg_costcenter').attr('disabled','disabled');
        $('#lg_costdept').attr('disabled','disabled');
      }else{
        $( "#lg_costcenter" ).val('');
        $( "#lg_costdept" ).val('');
      }
    }
  });


	$('#lg_suppliername').blur(function(){
		var lengthSupplierName = $('#lg_suppliername').val().length;
		var supplierName = $('#lg_suppliername').val();

		if(lengthSupplierName > 0){
			var searchParams = {
				'reqType': 'getSupplierAddress',
				'suppliername': supplierName
			};

			var mType = 'get';
			var mUrl     = "docpr_api.php";
			var mReqType = "";

			var returnData = jsClient.communicationToServer(mReqType, searchParams, mUrl, mType, false);

			console.log(returnData);
			if (returnData.length > 0) {

				// data = JSON.parse(returnData);
        data = JSON.parse(returnData)[0];


        $( "#lg_supplieraddress" ).val(data.SupplierAddress);
        $( "#lg_supplierorigin" ).val(data.SupplierOrigin);
			}
		}
	});
	 
}


LIZERP.checkTrackingAndAutoFill = function(){

  var params         = paramsToObj(window.location.search);
  var trackingnumber = params.trackingnumber;

  // if(trackingnumber != '') alert(trackingnumber);

  if(trackingnumber != '') {
      
      var searchParams = {
        'reqType': 'checkTrackingAndAutoFill',
        'trackingnumber': trackingnumber
      };

      var mType    = 'get';
      var mUrl     = "docpr_api.php";
      var mReqType = "";

      var returnData = jsClient.communicationToServer(mReqType, searchParams, mUrl, mType, false);

      console.log(returnData);

      
  }
}


  



LIZERP.getAdditionalRRPOLineInfo = function(){
  var params     = paramsToObj(window.location.search);
  var docnumber  = params.docnumber; 

  var searchParams = {
    'reqType': 'getAdditionalRRPOLineInfo',
    'docnumber': docnumber
  };

  var mType = 'get';
  var mUrl     = "docpr_api.php";
  var mReqType = "";

  var returnData = jsClient.communicationToServer(mReqType, searchParams, mUrl, mType, false);

  console.log(returnData);

  LIZERP.editMode();

  if (returnData.length > 0) {

    data = JSON.parse(returnData);
    $tr2 = LIZERP.getLineBeingEdited();

    $.each(data, function(index, line){
      // $tr2.find('input.saveLine:visible').first().click();
      $tr2.find('td.itemcode input').val(line.itemcode);
      $tr2.find('td.itemtype input').val(line.itemtype);
      $tr2.find('td.itemdescription textarea').val(line.itemdescription);
      $tr2.find('td.pricerequisitionnumber input').val(line.pricerequisitionnumber);
      $tr2.find('td.unitprice input').val(line.unitprice);
      $tr2.find('td.iduom select').val(line.iduom);
      $tr2.find('td.fabricinhousedate input').val(line.fabricinhousedate);
      $tr2.find('td.rrnumber input').val(line.rrnumber);
      $tr2.find('td.parentrrnumber input').val(line.parentrrnumber);
      $tr2.find('td.tnxqty input').val(line.requirednetqty);
      $tr2.find('td.originalqty input').val(line.requirednetqty);
      $tr2.find('td.previousqty input').val(line.requirednetqty);
      $tr2.find('td.iduom input').val(line.iduom);
      $tr2.find('td.dlvbrktext textarea').val(line.dlvbrktext);
      $tr2.find('td.salesorder input').val(line.salesorder);
      LIZERP.saveLine();
      $tr2 = LIZERP.getLineBeingEdited();


    });

    
    LIZERP.handleFormLinesTrClick();

    // click first tr
    // $(LIZERP.formId + ' #formLines table tbody tr:first').click();
    $(LIZERP.formId + ' #formLines tr.new').remove();


    LIZERP.saveForm();

  }
  console.log('\n\n ***delivery line auto fillup');

}


LIZERP.getSOInfo = function(salesorder){
  // var salesorder = $('#fieldset_documentinformation').find('.formGroup input[name=salesorder]').val(); 

  var searchParams = {
    'reqType': 'getSOInfo',
    'salesorder': salesorder
  };

  var mType = 'get';
  var mUrl     = "docpr_api.php";
  var mReqType = "";

  var returnData = jsClient.communicationToServer(mReqType, searchParams, mUrl, mType, false);

  console.log(returnData);

  if (returnData.length > 0) {

    data = JSON.parse(returnData);

    // $('#fieldset_documentinformation').find('.formGroup input[name=salesordertype]').val(data[0]['formtype']);
    // $('#fieldset_documentinformation').find('.formGroup input[name=salesordertype]').attr('disabled','disabled');
    // $('#fieldset_documentinformation').find('.formGroup input[name=salesorder]').val(salesorder);
    // $('#fieldset_documentinformation').find('.formGroup input[name=salesorder]').attr('disabled','disabled');

  }

}



/**
 * Customize doc review and approve by....Nazmul
 */

 LIZERP.docInfoTranslator_docPreview = {
  CP: 'Capacity Plan',
  projection: 'Projection',
  direct: 'Direct Confirm',
  under_projection: 'Projection Confirm'  
}

LIZERP.hideColumns_previewDoc_headTable = ['doctype', 'formtype', 'docnumber', 'docdate', 'docstatus', 'entrypersonbadge', 'doccreationtime'];
LIZERP.hideColumns_previewDoc_lineTable = ['idlines', 'linestatus'];
LIZERP.cancelPreviewDoc = function(){
  $.fancybox.close();
}
LIZERP.approvePreviewDoc = function(){
  var params = paramsToObj(window.location.search);

    //Start confirm dialog PopUp
    $('<div></div>').dialog({
       width: 500,
        modal: true,
        title: "Confirmation",
        open: function () {
            var markup = 'Warning: After Confirming this Capacity Plan, in future if you wish to Cancel/Modify, you will face problem.';
            $(this).html(markup);
        },
        buttons: {
            "Ok, Confirm Material Planner": function () {
               LIZERP.changeDocStatus(params.docnumber, '1');
            },

            cancel: function () {
                $(this).dialog("close");
            }
        }
    }); //end confirm dialog PopUp
 // if(confirm('Note that after approving this Capacity Plan info, if in future you wish to cancel/Modify you will face problem.')) LIZERP.changeDocStatus(params.docnumber, '1');
}



//------------27/04/17-----------------

LIZERP.initHead = function(){


  // LIZERP.searchHeaderInfo();

}

LIZERP.searchHeaderInfo = function() {

  var params     = paramsToObj(window.location.search);
  var ldcslnumber  = params.ldcslnumber; 

  var searchParams = {
    'reqType': 'searchHeaderInfo',
    'ldcslnumber': ldcslnumber
  };

  $.get(LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM], searchParams, searchHeaderInfo_results(searchParams));

  function searchHeaderInfo_results(extraParams) {
    return function(data, textStatus, jqXHR) {
      if (data.length > 0) {
        data = JSON.parse(data)[0];

        $(LIZERP.formId).find('#company').val(data.company);
        if(data.company != "") $(LIZERP.formId).find('#company').attr('disabled','disabled');

        $(LIZERP.formId).find('#salesordertype').val(data.formtype);
        if(data.formtype != "") $(LIZERP.formId).find('#salesordertype').attr('disabled','disabled');

        $(LIZERP.formId).find('#salesorder').val(data.docnumber);
        if(data.docnumber != "") $(LIZERP.formId).find('#salesorder').attr('disabled','disabled');

        $(LIZERP.formId).find('#customer').val(data.customer);
        if(data.customer != "") $(LIZERP.formId).find('#customer').attr('disabled','disabled');

        $(LIZERP.formId).find('#endcustomer').val(data.endcustomer);
        if(data.endcustomer != "") $(LIZERP.formId).find('#endcustomer').attr('disabled','disabled');

        $(LIZERP.formId).find('#season').val(data.season);
        if(data.season != "") $(LIZERP.formId).find('#season').attr('disabled','disabled');

        $(LIZERP.formId).find('#totalpackqty').val(data.totalpackqty);
        if(data.totalpackqty != "") $(LIZERP.formId).find('#totalpackqty').attr('disabled','disabled');

        $(LIZERP.formId).find('#totalpieceqty').val(data.totalpieceqty);
        if(data.totalpieceqty != "") $(LIZERP.formId).find('#totalpieceqty').attr('disabled','disabled');

        $(LIZERP.formId).find('#style').val(data.style);salesordertype
        if(data.style != "") $(LIZERP.formId).find('#style').attr('disabled','disabled');

        $(LIZERP.formId).find('#styledescription').val(data.styledescription);
        if(data.styledescription != "" && data.styledescription != null) $(LIZERP.formId).find('#styledescription').attr('disabled','disabled');

        $(LIZERP.formId).find('#productcategory').val(data.productcategory);
        if(data.productcategory != "" && data.productcategory != null) $(LIZERP.formId).find('#productcategory').attr('disabled','disabled');

        $(LIZERP.formId).find('#ldcslnumber').val(data.ldcslnumber);
        if(data.ldcslnumber != "") $(LIZERP.formId).find('#ldcslnumber').attr('disabled','disabled'); 

        $(LIZERP.formId).find('#buyerpo').val(data.buyerpo);
        if(data.buyerpo != "" && data.buyerpo != null) $(LIZERP.formId).find('#buyerpo').attr('disabled','disabled');

        $(LIZERP.formId).find('#processbeforesewing').val(data.processbeforesewing);
        if(data.processbeforesewing != "" && data.processbeforesewing != null) $(LIZERP.formId).find('#processbeforesewing').attr('disabled','disabled'); 

        $(LIZERP.formId).find('#processaftersewing').val(data.processaftersewing);
        if(data.processaftersewing != "" && data.processaftersewing != null) $(LIZERP.formId).find('#processaftersewing').attr('disabled','disabled');

        // $('#fieldset_documentinformation').find('#customer').val(data.docnumber);
        // $('#fieldset_documentinformation').find('#customer').attr('disabled','disabled');

      } else {
      }
    }
  }
}




LIZERP.readMode = function() {
  $(LIZERP.formId).find(' #formLines tr.new').remove();
  $(LIZERP.formId).find(' #formLines tr').unbind('mouseenter mouseleave');
  $(LIZERP.formId).find('input,select,textarea').attr('disabled', 'disabled');
  $(LIZERP.formId).find(' input[type=button]').removeAttr('disabled');

  $('#rightFormLines').css('display', 'none');
  $('.editLine').css('display', 'none');
  $('.copyAndNewLine').css('display', 'none');

  $('#fieldset_systeminformation').css('display', 'block');
  $(' .btnEditMode ').css('display', 'none');
  $(' .btnReadMode ').css('display', 'inline-block');
  $(' .datepicker').unmousewheel();
  $(LIZERP.formId).find(' #formLines tr .fileAttachmentContainer').css('display', 'block');
  $(LIZERP.formId).find(' #fieldset_documentfile .fileAttachmentContainer').css('display', 'block');
  


  var docStatus = $(LIZERP.formId).find('#docstatus').val();

  if(docStatus == "0"){ 
    $(LIZERP.formId + ' .btnAmend ').css('display', 'none');
  }
  
  $(LIZERP.formId + ' .btnSendToTextile ').css('display', 'none');
  if(docStatus == "1"){ 
    $(LIZERP.formId + ' .btnSendToTextile ').css('display', 'inline-block');
    $(LIZERP.formId + ' .btnEnterEditMode ').css('display', 'none');
    $(LIZERP.formId + ' .btnSentTextile ').css('display', 'none');
  }

  if(docStatus == "2"){ 
    $(LIZERP.formId + ' .btnConfirmation ').css('display', 'none');
    $(LIZERP.formId + ' .btnEnterEditMode ').css('display', 'none');
    $(LIZERP.formId + ' .btnSendToTextile ').css('display', 'none');
    $(LIZERP.formId + ' .btnSentTextile ').css('display', 'none');
  }
  
  if(docStatus == "9"){
    $(LIZERP.formId + ' .btnConfirmation ').css('display', 'none');
    $(LIZERP.formId + ' .btnEnterEditMode ').css('display', 'none');
    $(LIZERP.formId + ' .btnInformApparelPlanner ').css('display', 'none');
    $(LIZERP.formId + ' .btnChangeDocStatus ').css('display', 'none');
  }  


  //get partent po number by button
  previousponumber = $(LIZERP.formId + ' #fieldset_documentinformation').find('input#previousponumber').val();
  console.log(previousponumber);
  if(previousponumber == null || previousponumber == ''){
    $(LIZERP.formId + ' #upperButtonBar').find('.btnParentPO').css('display','none');
  }


  LIZERP.formMode = 'read';
  LIZERP.viewMode();
}



LIZERP.viewMode = function(){
  var params = paramsToObj(window.location.search);
  if(params.flag == 'view'){
    $('input[type=button]').addClass('btndisabled');
    $('button[type=button]').addClass('btndisabled');
    $(' .btndisabled ').css('display', 'none');
    $('.fileInputContainer').css('display','none');

    $('.btnPrintSheet').css('display','block');
  }

  if(params.viewflag == 'P'){
    $('input[type=button]').addClass('btndisabled');
    $('button[type=button]').addClass('btndisabled');
    $(' .btndisabled ').css('display', 'none');
    $('.fileInputContainer').css('display','none');

    $('.btnPrintSheet').css('display','block');
  }
}

// LIZERP.editMode_clickFromUpperBtn = function() {

//   $(LIZERP.formId + ' #formLines tr').hover(function(e) {
//     $(this).find('.div_editButton').css('display', 'block');
//   }, function(e) {
//     $(this).find('.div_editButton').css('display', 'none');
//   });
//   $(LIZERP.formId).find('input,select,textarea').removeAttr('disabled');
//   LIZERP.lockCreateOnlyFields();
//   $('#fieldset_systeminformation').css('display', 'none');
//   $(' .btnEditMode ').css('display', 'inline-block');
//   $(' .btnReadMode ').css('display', 'none');

//   $(LIZERP.formId).find('.saveLine').attr('disabled', 'disabled');
//   $(LIZERP.formId).find('.saveLineAndNew').attr('disabled', 'disabled');

//   $(LIZERP.formId).find('.copyAndNewLine').attr('disabled', 'disabled');
//   $(LIZERP.formId).find('.removeLine').attr('disabled', 'disabled');
//   $(LIZERP.formId).find('.btnCancelDocLine').attr('disabled', 'disabled');

//   // $(LIZERP.formId + ' .newLine').css('display', 'none');
//   // $(LIZERP.formId + ' .saveLineAndNew').css('display', 'none');
//   // $(LIZERP.formId + ' .copyAndNewLine').css('display', 'none');
//   // $(LIZERP.formId + ' .removeLine').css('display', 'none');


//   LIZERP.formMode = 'edit';
//   LIZERP.disableHeader();

//   LIZERP.lockAutoFillupFields();

//   LIZERP.lockHeaderFieldsUsingLineStatus();
// }



//Disables header in Edit Mode.....by Nazmul
LIZERP.disableHeader = function(){

  $(LIZERP.formId).find('#docdate').attr('disabled','disabled');

  $(LIZERP.formId).find('#salesordertype').attr('disabled','disabled');

  $(LIZERP.formId).find('#company').attr('disabled','disabled');

  $(LIZERP.formId).find('#salesorder').attr('disabled','disabled');

  $(LIZERP.formId).find('#customer').attr('disabled','disabled');

  $(LIZERP.formId).find('#endcustomer').attr('disabled','disabled');

  $(LIZERP.formId).find('#season').attr('disabled','disabled');

  $(LIZERP.formId).find('#totalpackqty').attr('disabled','disabled');

  $(LIZERP.formId).find('#totalpieceqty').attr('disabled','disabled');

  $(LIZERP.formId).find('#style').attr('disabled','disabled');

  $(LIZERP.formId).find('#styledescription').attr('disabled','disabled');

  $(LIZERP.formId).find('#productcategory').attr('disabled','disabled');

  $(LIZERP.formId).find('#ldcslnumber').attr('disabled','disabled');

  $(LIZERP.formId).find('#buyerpo').attr('disabled','disabled');

}




LIZERP.checkCreateCapacityPlanDocFlag = function(){

  var params = paramsToObj(window.location.search); 
  if(!!params.docflag && params.docflag == "createcapacityplan"){
    LIZERP.editMode_clickFromUpperBtn();
    $(LIZERP.formId + ' #docnumber').val('');
    $(LIZERP.formId + ' #spandocnumber').text('');
    $(LIZERP.formId + ' #docstatus').val('');
    $(LIZERP.formId + ' #spandocstatus').text('');
    $(LIZERP.formId + ' #doctype').val(params.doctype);
    // $(LIZERP.formId + ' .newLine').css('display', 'none');
    // $(LIZERP.formId + ' .saveLineAndNew').css('display', 'none');

    $(LIZERP.formId + ' #salesorder').val(params.docnumber);
    $(LIZERP.formId + ' #sotype').val(params.formtype);

    $(LIZERP.formId + ' #fieldset_lineinformation .valid .idlines').find('input').val('');

    LIZERP.saveForm();

  }

  if(params.createcapacityplan == 'yes'){
    LIZERP.editMode_clickFromUpperBtn();
  }

}




LIZERP.loupeListRRnumber = function(xxx) {
  var prepopulate = {};

  var prepopJS = (Object.keys(prepopulate).length > 0) ? 'var prepopulate = ' + JSON.stringify(prepopulate) + ';' : '';
  prepopJS = prepopJS + "var ERPLIST = ERPLIST || {};";
  prepopJS = prepopJS + "$(document).ajaxStop(function() {";
  prepopJS = prepopJS + "ERPLIST.sendBackSearchChoice = function( thisRow ) {";
  prepopJS = prepopJS + "  rrnumber = $(thisRow).find('td[fieldname=rrnumber]').text();";
  prepopJS = prepopJS + "  $.fancybox.close();";
  prepopJS = prepopJS + "  $(LIZERP.formId + '#lg_rrnumber').val(rrnumber);";
  prepopJS = prepopJS + "  $(LIZERP.formId + '#lg_rrnumber').focus();";
  prepopJS = prepopJS + "};";
  prepopJS = prepopJS + "});";

  var content = '<div id="popupListContent">\
    <div id="loadingDiv">\
      <center><img src="/images/loading_spinner.gif"></center>\
    </div>\
  </div>';
  content+= '<script> ' + prepopJS + '</script>'; // add some js

  $.fancybox({
    type: 'html',
    content: content,
    minWidth: 500,
    minHeight: 300,
    afterLoad: function(){
      this.title = "<b>PO Creation RR List</b>";
    },    
    afterShow: function() {
      loadSessionContent();
      $.fancybox.update();
    },
    helpers: {
     title : {
      type : 'inside',
      position : 'top'
     },
     overlay : {
      css  : { /* 'background-color' : '#fff' */}
     }     
    }  
  });
  jQuery('.fancybox-title').css({'text-align':'center', 'margin-bottom':'10px'});

  function loadSessionContent(){
    $.ajax({
      async: false,
      type: 'get',
      url: 'list-pocreation-rr-lines-session.php',
      success: function(htmlContent) {
        $('#popupListContent').empty().append(htmlContent);
        $.fancybox.update();
      }
    }).fail(function(e) {
      alert('Assign failed, please try again.');
    });
  }

}

/**
 * Show loupe item code search form
 */
LIZERP.handleSearchForm = function(callingField, prepopulate) {
  LIZERP.searchLoupe_hide();
  console.log(callingField);
  if(callingField == 'lg_rrnumber'){
    LIZERP.loupeListRRnumber(true);
  }
  return;
}
//----------------------------------------- loupe list work end ----------------------------------------------------------------------------------------------------------------------


/**
 * Save form via ajax after validation
 */
 LIZERP.saveForm = function(flag) {
  // tries to save the line if it's dirty
  if ((LIZERP.lineIsDirty == true) || ($(LIZERP.formId + ' #formLines tr.editable:not(.new)').length > 0)) {
    $('#formLines input[type=text]:visible').closest('tr').find('.saveLine').first().click();
  }

  // change data to actual uppercase from just css transform
  $(LIZERP.formId).find('input,textarea').each(function(i) {
    if ($(this).css('text-transform') == 'uppercase') $(this).val($(this).val().toUpperCase());
  });

  // run validation on all header fields
  var error = false;
  for (i in LIZERP._FIELDSETS_HEADER) {
    error = error || LIZERP.validateFormContainerFields(LIZERP.formId + ' #' + LIZERP._FIELDSETS_HEADER[i]);
  }

  var error;
  // if no lines have been added, don't continue
  var validLines = $(LIZERP.formId + ' #formLines #fieldset_lineinformation tbody tr.valid').length;
  if (validLines == 0) {
    error = true;
    LIZERP.showFormError('Please provide at least one valid line information.');
  }

  // If all data is validated, then submit
  if (!error && LIZERP.formMode == 'edit') {
    // just to avoid re-entry, the server should also check for double submission
    LIZERP.readMode();

    /* Prepare JSON */
    var jsonData = {
      'lines': []
    };
    $.each(LIZERP.formFieldSettings['header'], function(fieldName, attributes) {

      if(attributes['html_InputTag'] == 'checkbox'){
        if(!!attributes['groupname']){
          $('.'+attributes['groupname'] ).each(function() {
            if($(this).prop('checked')){
             var checkboxid = $(this).prop('id');
             var text    = $('label[for='+ checkboxid +']').text();
             jsonData[fieldName] = text;
              // var or_this = $('#pre-payment').next('label').text();
              // var selectedVal = $(this).closest('label').text();
              // <input type="checkbox" name="PrePayment" value="Pre-Payment">Pre-Payment<br />
              // $(input).attr('value');
            } 
          });

        } else {
          jsonData[fieldName] = $(LIZERP.formId + ' #' + fieldName).prop("checked") ? 1 : 0;
        }
      } else {
        jsonData[fieldName] = $(LIZERP.formId + ' #' + fieldName).val();
      }
    });

    $(LIZERP.formId + ' #formLines #fieldset_lineinformation tbody tr.valid').each(function() {
      var fieldList = [];
      // Build field list from the visible form
      $('#formLines #fieldset_lineinformation tr th').each(function(e) {
        if (!!$(this).attr('class')) fieldList.push($(this).attr('class'));
      });
      // Build field list from the formFieldSettings variable
      // $.each( LIZERP.formFieldSettings['lines'], function( fieldName, attributes ) {
      //     fieldList.push( fieldName );
      // } );

    LIZERP.formFieldSettings_OBJ = JSON.parse(LIZERP.formFieldSettings_JSON)
    var allowFormLineFields = Object.keys(LIZERP.formFieldSettings_OBJ['lines']);
    var formLine = {};
    for (index in fieldList) {
      formField = fieldList[index];
      if(allowFormLineFields.indexOf(formField) == -1){
        continue;
      }

      var isGroupCheckBox = (formField.indexOf('groupcheckbox') > -1) ? true : false;

      formLine[formField] = $(this).find('td.' + formField).find('input,textarea,select').first().val();
      
    }
    jsonData['lines'].push(formLine);
  });




/* Submit via ajax */
var postData = {
  reqType: 'saveDoc',
  docobj: JSON.stringify(jsonData)
};


    // add iddocument in case this is an Edit
    if ($(LIZERP.formId + ' #docnumber').val().length > 0) postData.docnumber = $(LIZERP.formId + ' #docnumber').val();
    console.log(postData);
    




    $.ajax({
      type: 'post',
      url: LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM],
      //dataType: 'json',/* if the return data is json */
      data: postData,
      success: function(data) {
          // if result is JSON, we're using the new API return format
          console.log(data);
          data = JSON.parse(data);
          if (!!data.errormsgs && data.errormsgs.length > 0) {
            console.log(data.errormsgs.join('\n'));
            alert("===>"+data.errormsgs.join('\n'));
            LIZERP.editMode();
          } else {
            var params = paramsToObj(window.location.search);
            // if(data.createdocheader == 'yes' && params.docflag != 'createcapacityplan'){
              if(!!flag && flag == 'autoLineFill_Save_Edit'){
                var next_href = window.location.origin + window.location.pathname + '?doctype=' + LIZERP._ERP_DOCACRONYM + '&formtype=' + params.formtype + '&docnumber=' + data.docnumber + '&autoLineFill_Save_Edit=yes';
                window.location.href = next_href;
              } else {
                var params = paramsToObj(window.location.search);
                var next_href = window.location.origin + window.location.pathname + '?doctype=' + LIZERP._ERP_DOCACRONYM + '&formtype=' + params.formtype + '&docnumber=' + data.docnumber;
                window.location.href = next_href;
              }
            }
          }
        }).fail(function(e) {
          alert('Saving failed, please try again.');
          LIZERP.editMode();
        });
      }
      return;
    }




/**
 * Save a line
 */
 LIZERP._saveLine = function(line) {
  // edit = 1 if we're trying to save because we clicked on an edit button of another line
  if(!!line){
    var $tr2 = LIZERP.getLineBeingEdited(line);
  } else {
    // line not defined
    // so its a new line, add new line
    if ($(LIZERP.formId + ' #formLines tr.valid.new').length == 0) {
      LIZERP.addLine();
      var $tr2 = LIZERP.getLineBeingEdited();
      $tr2.removeClass('editable new').addClass('valid new'); // new added by Mamun
    }
    var $tr2 = LIZERP.getLineBeingEdited();
  }

  // run validation on all right form fields
  var error = false;
  for (i in LIZERP._FIELDSETS_RIGHTFORM) {
    error = error || LIZERP.validateFormContainerFields('#rightFormLines #' + LIZERP._FIELDSETS_RIGHTFORM[i]);
  }
  if(error){
    alert('Required Field must have value.');
    return 0;
  } 
  
  /**
   * Passing Value right div to left div
   * Take header data
   */
   var lineData = {};

   $.each(LIZERP.formFieldSettings['header'], function(fieldName, attributes) {
    if(attributes['html_InputTag'] == 'checkbox'){
      if(!!attributes['groupname']){
        $('.'+attributes['groupname'] ).each(function() {
          if($(this).prop('checked')){
           var checkboxid = $(this).prop('id');
           var text    = $('label[for='+ checkboxid +']').text();
           lineData[fieldName] = text;
         } 
       });
      } else {
        lineData[fieldName] = $(LIZERP.formId + ' #' + fieldName).prop("checked") ? 1 : 0;
      }
    } else {
      lineData[fieldName] = $(LIZERP.formId + ' #' + fieldName).val();
    }
  });


   $("#rightFormLines").find('.select2').removeClass('select2');
  /**
   *Take Line Data
   */
   var formFieldSettings = LIZERP.formFieldSettings['lines'];
   $.each(formFieldSettings, function(fieldName, attributes) {

    if(attributes['html_InputTag'] == 'checkbox'){

      if(!!attributes['groupname']){
        $('.'+attributes['groupname'] ).each(function() {
          if($(this).prop('checked')){
           var checkboxid = $(this).prop('id');
           var text    = $('label[for='+ checkboxid +']').text();
         } 
       });
      } else {
        var val = $(LIZERP.formId + ' #lg_' + fieldName).prop("checked") ? 'Yes' : 'No';
      }

    } else {
      var value = $(LIZERP.formId + ' #lg_' + fieldName).val();
      if(!value) value = "";
      lineData[fieldName] = value;
    }


  });

  /**
   * show process overlay*/
  // LIZERP.showProcessinOverlay(); 
  /*
   *
   **/

  // alert(JSON.stringify(lineData));
  // post line data in api
  var postdata = {};
  postdata.line = JSON.stringify(lineData);

  // console.log(postdata.line);
  // return;
  postdata.reqType = '_saveLine';
  $.post(LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM], postdata, postLineData_results);

  function postLineData_results(data, textStatus, jqXHR) {

    // console.log(data);
    // return;

    data = JSON.parse(data);
    var lines = data.lines;
    delete data.lines;

    var headerObj = data;
    var linesObj = lines;

    // console.log(linesObj);

    /**
     * for first time doc create
     */
     if(headerObj['doccreate'] == 'yes'){
      for (var key in headerObj) {
        if (key.substr(0, 1) == "_") {
          LIZERP.dbAuxData[key.substr(1)] = headerObj[key]
          continue;
        }
        $('#' + key).filter('input,select,textarea').val(headerObj[key]);
        if(key == "docnumber"){$('span#span' + key).text(headerObj[key]);}
        else if(key == 'docstatus'){
          $(LIZERP.formId +' #' + key).val(headerObj[key]);
          $(LIZERP.formId).find('span#span' + key).text(LIZERP.formFieldSettings['docstatus'][headerObj[key]]); 
        }
        else {$('span#' + key).text(headerObj[key]);}
      }
      // add docnumber in URL
      var currURL = window.location.pathname + window.location.search + '&docnumber=' + headerObj['docnumber'];
      window.history.pushState('', 'Title', currURL);
    }


    var fieldList = [];
    var requiredCols = [];
    $('#formLines #fieldset_lineinformation table tr th')
    .each(function(e) {
      if (!!$(this).attr('class')) fieldList.push($(this).attr('class'));
    });
    // remove from array, this field is not user-entered
    // fieldList.splice(fieldList.indexOf('idlines'), 1)

    /**
     * Putting value in line input field
     */
     for (var j = 0; j < fieldList.length; j++) {
      // if (!!linesObj[0][fieldList[j]] && linesObj[0][fieldList[j]].length > 0) {

      // if (!!linesObj[0][fieldList[j]] ) {
        $tr2.find('td.' + fieldList[j]).find('input,textarea,select').val(linesObj[0][fieldList[j]]);
      // }
    }

    /**
     * Take line input field object
     */
     var $lineFields = {};
     for (key in fieldList) {
      $lineFields[fieldList[key]] = $tr2.find('.' + fieldList[key]).find('input,select,textarea');
    }

    /**
     * Show this line field value to span
     */
     var error = false;
     if (!error) {

      for (key in fieldList) {  


        // if(fieldList[key] == 'linestatus'){
        //   $tr2.find('td.' + fieldList[key]).find('span').text(LIZERP.formFieldSettings['linestatus'][$lineFields[fieldList[key]].val()]);
        // } else {
        //   $tr2.find('.' + fieldList[key]).find('span').text($lineFields[fieldList[key]].val());
        // }   

        if ($lineFields[fieldList[key]].prop('tagName') == 'SELECT') {
          var selectedvalue = $lineFields[fieldList[key]].find('option:selected').text();

          if (selectedvalue != 'Select') {
            $tr2.find('.' + fieldList[key]).find('span').text(selectedvalue);
          } else {
            $tr2.find('.' + fieldList[key]).find('span').text('');
          }
        } else if(fieldList[key] == 'linestatus'){
          $tr2.find('.' + fieldList[key]).find('span').text(LIZERP.formFieldSettings['linestatus'][$lineFields[fieldList[key]].val()]);
        } else {

          $tr2.find('.' + fieldList[key]).find('span').text($lineFields[fieldList[key]].val());

        } 

      }
      $tr2.find('textarea').parent().find('span').css('white-space', 'pre-wrap');
      $tr2.removeClass('editable new').addClass('valid');

      LIZERP.handleFormLinesTrClick();
      LIZERP.cancelLine();

    }

    if (line == 1) {

  /**
   * remove processing overlay */
  // LIZERP.removeProcessingOverlay(); 
  /*
   *
   **/

      return error;
    }

  /**
   * remove processing overlay */
  // LIZERP.removeProcessingOverlay(); 
  /*
   *
   **/

  }

}


/**
 * Save a line and new
 */
 LIZERP._saveLineAndNew = function(line) {
  // edit = 1 if we're trying to save because we clicked on an edit button of another line
  if(!!line){
    var $tr2 = LIZERP.getLineBeingEdited(line);
  } else {
    // line not defined
    // so its a new line, add new line
    if ($(LIZERP.formId + ' #formLines tr.valid.new').length == 0) {
      LIZERP.addLine();
      var $tr2 = LIZERP.getLineBeingEdited();
      $tr2.removeClass('editable new').addClass('valid new'); // new added by Mamun
    }
    var $tr2 = LIZERP.getLineBeingEdited();
  }
  

  /**
   * Passing Value right div to left div
   * Take header data
   */
   var lineData = {};

   $.each(LIZERP.formFieldSettings['header'], function(fieldName, attributes) {
    if(attributes['html_InputTag'] == 'checkbox'){
      if(!!attributes['groupname']){
        $('.'+attributes['groupname'] ).each(function() {
          if($(this).prop('checked')){
           var checkboxid = $(this).prop('id');
           var text    = $('label[for='+ checkboxid +']').text();
           lineData[fieldName] = text;
         } 
       });
      } else {
        lineData[fieldName] = $(LIZERP.formId + ' #' + fieldName).prop("checked") ? 1 : 0;
      }
    } else {
      lineData[fieldName] = $(LIZERP.formId + ' #' + fieldName).val();
    }
  });


  /**
   *Take Line Data
   */
   var formFieldSettings = LIZERP.formFieldSettings['lines'];
   $.each(formFieldSettings, function(fieldName, attributes) {

    if(attributes['html_InputTag'] == 'checkbox'){

      if(!!attributes['groupname']){
        $('.'+attributes['groupname'] ).each(function() {
          if($(this).prop('checked')){
           var checkboxid = $(this).prop('id');
           var text    = $('label[for='+ checkboxid +']').text();
         } 
       });
      } else {
        var val = $(LIZERP.formId + ' #lg_' + fieldName).prop("checked") ? 'Yes' : 'No';
      }

    } else {
      var value = $(LIZERP.formId + ' #lg_' + fieldName).val();
      if(!value) value = "";
      lineData[fieldName] = value;
    }

  });

  // alert(JSON.stringify(lineData));
  // post line data in api

  var postdata = {};
  postdata.line = JSON.stringify(lineData);
  postdata.reqType = '_saveLine';
  $.post(LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM], postdata, postLineData_results);

  function postLineData_results(data, textStatus, jqXHR) {

    data = JSON.parse(data);
    var lines = data.lines;
    delete data.lines;

    var headerObj = data;
    var linesObj = lines;

    /**
     * for first time doc create
     */
     if(headerObj['doccreate'] == 'yes'){
      for (var key in headerObj) {
        if (key.substr(0, 1) == "_") {
          LIZERP.dbAuxData[key.substr(1)] = headerObj[key]
          continue;
        }
        $('#' + key).filter('input,select,textarea').val(headerObj[key]);
        if(key == "docnumber"){$('span#span' + key).text(headerObj[key]);}
        else if(key == 'docstatus'){
          $(LIZERP.formId +' #' + key).val(headerObj[key]);
          $(LIZERP.formId).find('span#span' + key).text(LIZERP.formFieldSettings['docstatus'][headerObj[key]]); 
        }
        else {$('span#' + key).text(headerObj[key]);}
      }
      // add docnumber in URL
      var currURL = window.location.pathname + window.location.search + '&docnumber=' + headerObj['docnumber'];
      window.history.pushState('', 'Title', currURL);
    }


    var fieldList = [];
    var requiredCols = [];
    $('#formLines #fieldset_lineinformation table tr th')
    .each(function(e) {
      if (!!$(this).attr('class')) fieldList.push($(this).attr('class'));
    });
    // remove from array, this field is not user-entered
    // fieldList.splice(fieldList.indexOf('idlines'), 1)
    // fieldList.splice(fieldList.indexOf('linenumber'), 1)

    /**
     * Putting value in line input field
     */
     for (var j = 0; j < fieldList.length; j++) {
      if (!!linesObj[0][fieldList[j]] && linesObj[0][fieldList[j]].length > 0) {
        $tr2.find('td.' + fieldList[j]).find('input,textarea,select').val(linesObj[0][fieldList[j]]);
      }
    }

    /**
     * Take line input field object
     */
     var $lineFields = {};
     for (key in fieldList) {
      $lineFields[fieldList[key]] = $tr2.find('.' + fieldList[key]).find('input,select,textarea');
    }

    /**
     * Show this line field value to span
     */
     var error = false;
     if (!error) {

      for (key in fieldList) {  
        if(fieldList[key] == 'linestatus'){
          $tr2.find('td.' + fieldList[key]).find('span').text(LIZERP.formFieldSettings['linestatus'][$lineFields[fieldList[key]].val()]);
        } else {
          $tr2.find('.' + fieldList[key]).find('span').text($lineFields[fieldList[key]].val());
        }   
      }
      $tr2.find('textarea').parent().find('span').css('white-space', 'pre-wrap');
      $tr2.removeClass('editable new').addClass('valid');

      LIZERP.handleFormLinesTrClick();
      // LIZERP.cancelLine();

    }

    if (line == 1) {
      return error;
    }


  }


}


LIZERP.editMode = function(formWhere) {


  if ($(' #formLines tr.editable').length == 0){
    LIZERP.addLine();
    // $tr2.removeClass('editable new').addClass('valid new');
  }

  $(LIZERP.formId + ' #formLines tr').hover(function(e) {
    $(this).find('.div_editButton').css('display', 'block');
  }, function(e) {
    $(this).find('.div_editButton').css('display', 'none');
  });
  $(LIZERP.formId).find('input,select,textarea').removeAttr('disabled');
  LIZERP.lockCreateOnlyFields();
  $('#fieldset_systeminformation').css('display', 'none');
  $(' .btnEditMode ').css('display', 'inline-block');
  $(' .btnReadMode ').css('display', 'none');


  var $tr2 = LIZERP.getLineBeingEdited();
  if(formWhere == 'nodoc' || formWhere == 'eee'){

    $tr2.removeClass('editable new').addClass('valid new'); // new added by Mamun
    $(LIZERP.formId).find('.saveLine').attr('disabled', 'disabled');
    $(LIZERP.formId).find('.saveLineAndNew').attr('disabled', 'disabled');

    $(LIZERP.formId).find('.copyAndNewLine').attr('disabled', 'disabled');
    $(LIZERP.formId).find('.removeLine').attr('disabled', 'disabled');
    $(LIZERP.formId).find('.btnCancelDocLine').attr('disabled', 'disabled');

  } 

  LIZERP.controlLineButtons();
    // added 2017-05-03
  $(LIZERP.formId).find('#formLinesButtonsBr').empty();

  LIZERP.formMode = 'edit';


  console.log('\n\n ***edit mode called');

  LIZERP.lockAutoFillupFields();
}



LIZERP.controlLineButtons = function(){
  // $(LIZERP.formId + ' .newLine').css('display', 'none');
  // $(LIZERP.formId + ' .saveLineAndNew').css('display', 'none');
  // $(LIZERP.formId + ' .copyAndNewLine').css('display', 'none');
  // $(LIZERP.formId + ' .removeLine').css('display', 'none');
}



LIZERP.editMode_clickFromUpperBtn = function() {

  $(LIZERP.formId + ' #formLines tr').hover(function(e) {
    $(this).find('.div_editButton').css('display', 'block');
  }, function(e) {
    $(this).find('.div_editButton').css('display', 'none');
  });
  $(LIZERP.formId).find('input,select,textarea').removeAttr('disabled');
  LIZERP.lockCreateOnlyFields();
  $(LIZERP.formId + '#fieldset_systeminformation').css('display', 'none');
  $(LIZERP.formId + ' .btnEditMode ').css('display', 'inline-block');
  $(LIZERP.formId + ' .btnReadMode ').css('display', 'none');

  $(LIZERP.formId).find('.saveLine').attr('disabled', 'disabled');
  $(LIZERP.formId).find('.saveLineAndNew').attr('disabled', 'disabled');

  $(LIZERP.formId).find('.copyAndNewLine').attr('disabled', 'disabled');
  $(LIZERP.formId).find('.removeLine').attr('disabled', 'disabled');
  $(LIZERP.formId).find('.btnCancelDocLine').attr('disabled', 'disabled');
  
  LIZERP.controlLineButtons();
  // added 2017-05-03
  $(LIZERP.formId).find('#formLinesButtonsBr').empty().append('<br/>');

  LIZERP.formMode = 'edit';
  LIZERP.lockHeaderFieldsUsingLineStatus();
}



LIZERP.lockHeaderFieldsUsingLineStatus = function(){
  $('#fieldset_lineinformation table tbody tr').each(function(){
    var linestatus = $(this).closest('tr').find('td.linestatus span').text();

    if(linestatus == 'Released'){
      $('#company').prop('disabled',true);
    }
  });
}

/**
 * Document RR line send to textile
 */
$('.btnSentTextile').click(function(){

  var r = confirm( 'Are you want to send it to textile ?' );
  if(!r) return;
  var params = paramsToObj(window.location.search);
  docnumber = params.docnumber;

  $('#fieldset_lineinformation table tbody tr').each(function(){
    rrnumber = $(this).find('td.rrnumber input').val();
    console.log(rrnumber);

    if(!!!LIZERP.selectedLineInfo){
      LIZERP.selectedLineInfo  = {};
      LIZERP.selectedLineInfo.rrnumber = [];
    }

    LIZERP.selectedLineInfo.rrnumber.push(rrnumber); 
  });

  var mType    = 'post';
  var mUrl     = LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM];
  var mReqType = "senttoTextile";
  var postData = JSON.stringify({
    rrnumber  : LIZERP.selectedLineInfo.rrnumber,
    docnumber : docnumber 
  });
  var returnData = jsClient.communicationToServer(mReqType, postData, mUrl, mType, false);

  returnData = JSON.parse(returnData);
  console.log(returnData.result);

  if(returnData.result == 'success'){
    // var msgString  = 'success:: Successfully sent it to textile.';
    // jsClient.msgDisplayer(msgString); // green
    // delete(LIZERP.selectedLineInfo);
    location.reload();
  } 

});


/**
 * Locks all fields that are auto fillup
 */
LIZERP.lockAutoFillupFields = function() {
  var fieldList = LIZERP._FIELDS_AUTOFILLUP;
  for (field in fieldList) {
    console.log('--------------->' + fieldList[field]);
    $(LIZERP.formId).find('input,textarea,select').filter('#' + fieldList[field]).attr('disabled', 'disabled');
  }
}



/**
 * Remove a line
 * @param line
 */
LIZERP.removeLine = function(line) {
  var idlines           = $(LIZERP.formId).find('input#lg_idlines').val();
  if (confirm('Are you sure to delete line ' + line + '?')) {
    $(LIZERP.formId + ' #formLines tr[data-id="' + line + '"]').remove();
    LIZERP.removePOLine(idlines);
    LIZERP.cancelLine();
  }
}

LIZERP.removePOLine = function(idlines) {

      var postData = {
        reqType: 'removePOLine',
        idlines: idlines
       };
      $.ajax({
        type: 'post',
        url: 'docpr_api.php',
        data: postData,
        success: function(data) {
            data = JSON.parse(data);
            if (!!data.errormsgs && data.errormsgs.length > 0) {
              console.log(data.errormsgs.join('\n'));
              alert("===>"+data.errormsgs.join('\n'));
            } else {
              // parent.location.reload(true);
            }
        }
      }).fail(function(e) {
        alert('Assign failed, please try again.');
      });
}

LIZERP.renameFieldSet = function(){
	$('#rightFormLines #fieldset_linegroup1').find('legend').text('PR Info');
    $('#rightFormLines #fieldset_linegroup2').find('legend').text('Project Info');
    $('#rightFormLines #fieldset_linegroup3').find('legend').text('Item Info');
    $('#rightFormLines #fieldset_linegroup4').find('legend').text('Order Info');
    $('#rightFormLines #fieldset_linegroup5').find('legend').text('Supplier Info');
}

LIZERP.initRightFormLines = function() {

    $('#rightFormLines select').removeClass('select2');

    $(LIZERP.formId+' #formLinesContainer #rightFormLines').find('#lg_rrnumber')
    .hover(function(e) {
      LIZERP.searchLoupe_show_forHeaderField(this);
    }, function(e) {
      atop = $(this).offset().top;
      aleft = $(this).offset().left;
      abottom = atop + parseFloat($(this).css('height').replace('px', ''));
      aright = aleft + parseFloat($(this).css('width').replace('px', ''));
      if (atop > e.pageY || abottom < e.pageY || aleft > e.pageX || aright < e.pageX) LIZERP.searchLoupe_hide();
    });


    $(LIZERP.formId+' #formLinesContainer #rightFormLines').find('#lg_rrnumber')
    .focus(function() {
      LIZERP.valAtFocus = $(this).val();
    })
    .blur(function() {
      LIZERP.valAtFocus = $(this).val();
      LIZERP.getRRLineInfo(LIZERP.valAtFocus);
    });


    

}


LIZERP.newLine = function(){

  $('#rightFormLines').css('display', 'block');
  LIZERP.adjustLineFormInterface();
  LIZERP.cleanLineEntryForm();
  LIZERP.initRightFormLines();
  
  $('#rightFormLines #lg_brand,#lg_color select').removeClass('select2');	
  $('#rightFormLines #lg_brand').val('N/A');
  $('#rightFormLines #lg_color').val('N/A');
  $('#rightFormLines #lg_sizeormeasurement').val('N/A');
  $('#rightFormLines #lg_itemdescription').val('N/A');
  $('#rightFormLines').find('#lg_brand').select2();
  $('#rightFormLines').find('#lg_color').select2();

  $(LIZERP.formId).find('.saveLine').removeAttr('disabled');
  $(LIZERP.formId).find('.saveLineAndNew').removeAttr('disabled');

  $(LIZERP.formId).find('.copyAndNewLine').attr('disabled', 'disabled');
  $(LIZERP.formId).find('.removeLine').attr('disabled', 'disabled');
  $(LIZERP.formId).find('.btnCancelDocLine').attr('disabled', 'disabled');

  delete LIZERP.newLineNumber;
  // it will take from table tr length
  // so delete it which is one step above now

}


LIZERP.showParentPO = function(){
  var params = paramsToObj(window.location.search);
  previousponumber = $(LIZERP.formId + ' #fieldset_documentinformation').find('input#previousponumber').val();
  
  window.open(window.location.origin + window.location.pathname + '?docnumber=' + previousponumber + '&doctype=' + params.doctype + '&formtype='+params.formtype );
}




/**
* Auto URL fillup document line
*/
//  $.when.apply($, populatePromises).then(function() {
//   var params = jsClient.paramsToObj(window.location.search); 
//   var idlines = params.idlines;
//   if(!!idlines){
//     LIZERP.isgetPOLineInfo = true; 
//     LIZERP.getPOLineInfo();
//     LIZERP.getSOInfo();
//   } else {
//     LIZERP.isgetPOLineInfo = false;
//   }    
// });



LIZERP.getRRLineInfo = function(rrnumber){

  var searchParams = {
    'reqType': 'getRRLineInfo',
    'rrnumber': rrnumber
  };

  var mType = 'get';
  var mUrl     = "docpr_api.php";
  var mReqType = "";
  var returnData = jsClient.communicationToServer(mReqType, searchParams, mUrl, mType, false);

  if (returnData.length > 0) {
    data = JSON.parse(returnData);
    $(LIZERP.formId + '#lg_itemcode').val(data[0]['itemcode']);
    $(LIZERP.formId + '#lg_itemcode').attr('disabled','disabled');

    $(LIZERP.formId + '#lg_itemtype').val(data[0]['itemtype']);
    $(LIZERP.formId + '#lg_itemtype').attr('disabled','disabled');

    $(LIZERP.formId + '#lg_itemdescription').val(data[0]['itemdescription']);
    $(LIZERP.formId + '#lg_itemdescription').attr('disabled','disabled');

    $(LIZERP.formId + '#lg_pricerequisitionnumber').val(data[0]['pricerequisitionnumber']);
    $(LIZERP.formId + '#lg_pricerequisitionnumber').attr('disabled','disabled');

    $(LIZERP.formId + '#lg_tnxqty').val(data[0]['requirednetqty']);
    $(LIZERP.formId + '#lg_tnxqty').attr('disabled','disabled');

    $(LIZERP.formId + '#lg_iduom').val(data[0]['iduom']);
    $(LIZERP.formId + '#lg_iduom').attr('disabled','disabled');

    $(LIZERP.formId + '#lg_salesorder').val(data[0]['salesorder']);
    $(LIZERP.formId + '#lg_salesorder').attr('disabled','disabled');
    
    $(LIZERP.formId + '#lg_dlvbrktext').val(data[0]['dlvbrktext']);
    $(LIZERP.formId + '#lg_dlvbrktext').attr('disabled','disabled');
   
  }




}




LIZERP.autoRevisedPO = function(){

  var params = paramsToObj(window.location.search);
  docnumber = params.docnumber;

  var searchParams = {
    'reqType': 'autoRevisedButtonVisibility',
    'docnumber': docnumber
  };

  var mType = 'get';
  var mUrl     = "docpr_api.php";
  var mReqType = "";
  var returnData = jsClient.communicationToServer(mReqType, searchParams, mUrl, mType, false);

  if(returnData == '1'){
    $(LIZERP.formId + ' .btnAutoRevised').css('display', 'inline-block');
  }else{
    $(LIZERP.formId + ' .btnAutoRevised').css('display', 'none');
  }

}




/**
 * [autoFillup_byURLParams description]
 * @return {[type]} [description]
 */
LIZERP.autoFillup_byURLParams = function(){
  // need to make dependency for auto line fillup
  // this for header data auto fillup
  var params = jsClient.paramsToObj(window.location.search);
  if(!!!params.idlines) return;

  var populateFunctions = $.when(
    LIZERP.getSOInfo()    
  );
  populateFunctions.then(function() {                 
    if(!!params.idlines){
      LIZERP.isgetPOLineInfo = true; 
      LIZERP.getPOLineInfo();
    } else {
      LIZERP.isgetPOLineInfo = false;
    }         
  });
  return;
}

/**
 * [autoFillup_newRR description]
 * @return {[type]} [description]
 */
LIZERP.autoFillup_newRR = function(){
  // need to make dependency for auto line fillup
  // this for header data auto fillup
  var params = jsClient.paramsToObj(window.location.search);
  var populateFunctionsAddRR = $.when(
  );

  populateFunctionsAddRR.then(function() {                 
    
    LIZERP.getAdditionalRRPOLineInfo();         
  });
  return;
}

LIZERP.prCancelLine = function(idlines){
  console.log(idlines);
  var searchParams = {};
  searchParams.idlines = idlines;
  searchParams.reqType = 'cancelPRLine';
  return $.post(LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM], searchParams, cancelPRLine_return(), 'json');

  function cancelPRLine_return(extraParams) {
    return function(data, textStatus, jqXHR) {
      console.log(data);
      if (data.result == 'success') {
        location.reload();
      } else {
        alert(data.errormsgs.join('\n'));
      }
    }
  }
}



LIZERP.sendToTextile = function(){

  var params = paramsToObj(window.location.search);
  if (!params.docnumber) {
    alert('Error: iddocument not available. Please tell ERP department.');
    return;
  }

  var r = confirm('Are you sure want to send this PO to NOW?');
  if(!r)return;

  var searchParams = {};
  searchParams.docnumber = params.docnumber;
  // return $.post('/connector_erp_to_db2-so-import/erp_to_db2-so-import.php', searchParams, sendToWMS_return(), 'json');
  return $.post('/connector_erp_to_db2-so-import/erp_to_db2-so-import.php', searchParams, sendToWMS_return());

  function sendToWMS_return(extraParams) {

    return function(data, textStatus, jqXHR) {
      console.log(data);
      data = JSON.parse(data);
      if (data.result == 'success') {
        location.reload();
      } else {
        alert(data.errormsgs.join('\n'));
      }
    }
  }

}


LIZERP.prDeleteLine = function(idlines){
  console.log(idlines);
  var searchParams = {};
  searchParams.idlines = idlines;
  searchParams.reqType = 'deletePRLine';
  return $.post(LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM], searchParams, deletePRLine_return(), 'json');

  function deletePRLine_return(extraParams) {
    return function(data, textStatus, jqXHR) {
      console.log(data);
      // if (data.result == 'success') {
      //   location.reload();
      // } else {
      //   alert(data.errormsgs.join('\n'));
      // }
    }
  }
}


$.extend(LIZERP, {
  /**
   * Start up function
   * @description Any JS code to be run on start up
   * @returns {undefined}
   */



   init: function() {
    /* executable JS */
    return;
  },
  enableRead: function() {
    LIZERP.readMode();
    return;
  },
  enableEdit: function() {
    LIZERP.editMode();
    return;
  },
  enableReceive: function() {
    LIZERP.receiveMode();
    return;
  },

  /**
   * Process Purchase Request Form
   * @param selector formId
   * @returns {undefined}
   */
   processForm: function(purchaseFormId, _ERP_DOCACRONYM, _URL_DOCUMENTAPI, _URL_DOCDEFINEAPI) {
    LIZERP.formId = purchaseFormId + ' ';
    LIZERP.formMode = 'edit';
    LIZERP._ERP_DOCACRONYM = _ERP_DOCACRONYM;
    LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM] = _URL_DOCUMENTAPI;
    LIZERP._URL_DOCDEFINEAPI[LIZERP._ERP_DOCACRONYM] = _URL_DOCDEFINEAPI;
    if(!LIZERP.newLineNumber) LIZERP.newLineNumber = 1;

    var populatePromises = [];
    populatePromises.push(LIZERP.populateDropdown('company', 'company', 'LFI'));
    populatePromises.push(LIZERP.populateDropdown('customer', 'Buyer'));
    populatePromises.push(LIZERP.populateDropdown('endcustomer', 'Buyer'));
    // populatePromises.push(LIZERP.populateDropdown('itemtype', 'itemtype'));
    
    populatePromises.push(LIZERP.populateDropdown('currency', 'Currency', '', 'codevalequal'));
    populatePromises.push(LIZERP.populateDropdown('lg_currency', 'Currency', '', 'codevalequal'));

    populatePromises.push(LIZERP.populateDropdown('itemnature', 'NonPOItemNature', '', 'codevalequal'));
    populatePromises.push(LIZERP.populateDropdown('lg_itemnature', 'NonPOItemNature', '', 'codevalequal'));

    populatePromises.push(LIZERP.populateDropdown('brand', 'NonPOBrand', 'N/A', 'codevalequal'));
    populatePromises.push(LIZERP.populateDropdown('lg_brand', 'NonPOBrand', 'N/A', 'codevalequal'));

    populatePromises.push(LIZERP.populateDropdown('purpose', 'ChemicalPurposeOfUse', '', ''));
    populatePromises.push(LIZERP.populateDropdown('lg_purpose', 'ChemicalPurposeOfUse', '', ''));

    populatePromises.push(LIZERP.populateDropdown('chemicalcharecter', 'ChemicalCharacteristics', '', ''));
    populatePromises.push(LIZERP.populateDropdown('lg_chemicalcharecter', 'ChemicalCharacteristics', '', ''));
    
    populatePromises.push(LIZERP.populateDropdown('itemtype', 'itemtype_PO_NONPO', '', ''));
    populatePromises.push(LIZERP.populateDropdown('lg_itemtype', 'itemtype_PO_NONPO', '', ''));

    populatePromises.push(LIZERP.populateDropdown('color', 'NonPOColor', '', 'codevalequal'));
    populatePromises.push(LIZERP.populateDropdown('lg_color', 'NonPOColor', '', 'codevalequal'));

    populatePromises.push(LIZERP.populateDropdown('itemname', 'NonPOitemname', '', 'codevalequal'));
    populatePromises.push(LIZERP.populateDropdown('lg_itemname', 'NonPOitemname', '', 'codevalequal'));
    
    populatePromises.push(LIZERP.populateDropdown('iduom', 'UOM', '', 'codevalequal'));
    populatePromises.push(LIZERP.populateDropdown('lg_iduom', 'UOM', '', 'codevalequal'));    

    $.when.apply($, populatePromises).then(function() {
      // Caches the HTML of a new line
      LIZERP.lineHTML_template = $('#fieldset_lineinformation table tr[data-id=1]')[0].outerHTML;
      LIZERP.adjustLineFormInterface();
    });

    LIZERP.handle_docdate_field();
    /* Show/Hide/Enable/Disable fields on document load */
    populatePromises.push(LIZERP.handleFormFields('create'));
    $.when.apply($, populatePromises).then(function() {}); 

    // Change line legend name
    $('#fieldset_documentinformation legend').text('Header');
    $('#formLines #legend').text('Purchase Line');





    LIZERP.initHead();
    LIZERP.initLine(); // Enables functionality of the Line entry
    LIZERP.editMode();      


    $(window).keydown(function(e) {
      if (e.ctrlKey || e.metaKey) {
        switch (String.fromCharCode(e.which).toLowerCase()) {
          case 's':
          e.preventDefault();
          $(LIZERP.formId + ' .btnSaveForm').click();
          break;
        }
      }
    });



    $(LIZERP.formId + ' .btnSaveForm').on('click', function(e) {
      e.preventDefault();
      LIZERP.saveForm();
    });     

    $(LIZERP.formId + ' .btnCancelForm').on('click', function(e) {
      e.preventDefault();
      var params = paramsToObj(window.location.search);
      if (!!params.docnumber) location.reload();
    });
    $(' .btnEnterEditMode').on('click', function(e) {
      e.preventDefault();
      LIZERP.editMode_clickFromUpperBtn();
      LIZERP.editLineMode = true;
      LIZERP.newLineMode = false;
    });

$(LIZERP.formId + ' .btnSendToTextile').on('click', function(e) {
  e.preventDefault();
  LIZERP.sendToTextile();
});


    // $(LIZERP.formId + ' .btnConfirmation').on('click', function(e) {
    //   e.preventDefault();
    //   LIZERP.reviewAndApproveDoc(LIZERP.docobj);
    // });
    
    $(LIZERP.formId + ' .btnPrintSheet').on('click', function(e) {
      e.preventDefault();
      var params = paramsToObj(window.location.search);
      window.open('printdoc-po.php?doctype=' + params.doctype + '&formtype='+params.formtype+'&docnumber=' + params.docnumber);
    });

    // $(LIZERP.formId + ' .btnChangeDocStatus').on('click', function(e) {
    //   e.preventDefault();
    //   var params = paramsToObj(window.location.search);
    //   var r = confirm('Click OK to close this document.');
    //   if(!r) return;
    //   LIZERP.changeDocStatus(params.docnumber, '1');
    // });

$(LIZERP.formId + ' .btnSendRequest').on('click', function(e) {
  e.preventDefault();
  var params = paramsToObj(window.location.search);
  if (!params.docnumber) {
    alert('Error: iddocument not available. Please contact system.support@lizfashion.com.');
    return;
  }
  if (confirm('Click OK to send to request')) LIZERP.changeDocStatus(params.docnumber, '1');
});



$(LIZERP.formId + ' .btnAmend').on('click', function(e) {
  e.preventDefault();
  var params = paramsToObj(window.location.search);
  if (!params.docnumber) {
    alert('Error: iddocument not available. Please contact system.support@lizfashion.com.');
    return;
  }
  if (confirm('Click OK to Amend the PO')) LIZERP.poAmendment(params.docnumber, '0');
});


$(LIZERP.formId + ' .btnAutoRevised').on('click', function(e) {
  e.preventDefault();
  var params = paramsToObj(window.location.search);
  if (!params.docnumber) {
    alert('Error: iddocument not available. Please contact system.support@lizfashion.com.');
    return;
  }
  if (confirm('Click OK to PO Revised auto update')) LIZERP.updateRevisedPO(params.docnumber);
});

$(LIZERP.formId + ' .btnFileAttachment').on('click', function(e) {
  e.preventDefault();
  LIZERP.fileAttachmentMode();
});


$(LIZERP.formId + ' .btnCopyAndNew').on('click', function(e) {
  e.preventDefault();
  var params = paramsToObj(window.location.search);
  window.open(window.location.origin + window.location.pathname + '?docnumber=' + params.docnumber + '&doctype=' + params.doctype + '&formtype='+params.formtype+"&docflag=copyandnew" );
});

$(LIZERP.formId + ' .btnInformApparelPlanner').on('click', function(e) {
  e.preventDefault();
  // LIZERP.approvePreviewDoc();
  LIZERP.reviewAndApproveDoc(LIZERP.docobj);
  // var params = paramsToObj(window.location.search);
  // if (confirm('Are you sure to Inform Apparel Planner?')) LIZERP.changeDocStatus(params.docnumber, '2');
});


$(LIZERP.formId + ' .newLine').on('click', function(e) {
  e.preventDefault();
  $(LIZERP.formId).find('.newLine').attr('disabled', 'disabled');
  LIZERP.newLineMode = true;
  LIZERP.editLineMode = false;
  LIZERP.newLine();
});

$(LIZERP.formId + ' .saveLine').on('click', function(e) {
  e.preventDefault();
  if(!!LIZERP.currentLineNumber && LIZERP.editLineMode && !LIZERP.newLineMode){

    flag = LIZERP._saveLine(LIZERP.currentLineNumber);
  } else {

    flag = LIZERP._saveLine();
  }
  if(flag == '0') return;
  LIZERP.cleanLineEntryForm();
  LIZERP.handleFormLinesTrClick();
  $(LIZERP.formId).find('.newLine').removeAttr('disabled');

});

$(LIZERP.formId + ' .saveLineAndNew').on('click', function(e) {
  e.preventDefault();
  if(!!LIZERP.currentLineNumber && LIZERP.editLineMode && !LIZERP.newLineMode){

    LIZERP.newLineMode = true;
    LIZERP.editLineMode = false;

    LIZERP._saveLineAndNew(LIZERP.currentLineNumber);
  } else {

    LIZERP._saveLineAndNew();
  }
  LIZERP.cleanLineEntryForm();
  LIZERP.handleFormLinesTrClick();
});

// $(LIZERP.formId + ' .copyAndNewLine').on('click', function(e) {
//   e.preventDefault();
//   LIZERP.copyAndNewLine();

// });

$(LIZERP.formId + ' .cancelLine').on('click', function(e) {
  e.preventDefault();
  LIZERP.cancelLine();

      // save form in  db
      // LIZERP.saveForm();
    });

$(LIZERP.formId + ' .removeLine').on('click', function(e) {
  e.preventDefault();
  if(!!!LIZERP.currentLineNumber) return;
  if (confirm('Click OK to Delete the PR Line')) LIZERP.prDeleteLine(LIZERP.currentLineidlines);
  LIZERP.removeLine(LIZERP.currentLineNumber);
});


$(LIZERP.formId + ' .btnCancelDocLine').on('click', function(e) {
  e.preventDefault();
  if(!!!LIZERP.currentLineidlines) return;
  if (confirm('Click OK to Cancel the PR Line')) LIZERP.prCancelLine(LIZERP.currentLineidlines);
});


$(LIZERP.formId + ' .btnParentPO').on('click', function(e) {
  e.preventDefault();
  LIZERP.showParentPO();
});

// LIZERP.initHead();
//     LIZERP.initLine(); // Enables functionality of the Line entry
//     LIZERP.editMode();

    // If the page was called with a document ID, try to read the record
    var params = paramsToObj(window.location.search);
    if (!!params.docnumber) {
      var searchParams = {
        'reqType': 'readDoc',
        'docnumber': params.docnumber
      };
      $.when.apply($, populatePromises).then(function() {
        $.get(LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM], searchParams, populateFromDb);
      });

    } else {
        LIZERP.editMode('nodoc');
        $.when.apply($, populatePromises).then(function() {
          /**
          * remove processing overlay */
          LIZERP.removeProcessingOverlay_2(); /*
          *
          **/
        });
    }

    function populateFromDb(data, textStatus, jqXHR) {
      // alert(data);
      LIZERP.docobj = data;
      data = JSON.parse(data);
      var lines = data.lines;
      delete data.lines;
      if (Object.keys(data).length > 0) {
        $.when.apply($, populatePromises).then(function() {
          LIZERP.editMode('populateFromDb');
          LIZERP.fillForm(data, lines);
          LIZERP.updateFormTitle('read');
          LIZERP.readMode();
          LIZERP.handleFormLinesTrClick();
          LIZERP.checkCopyAndNewDocFlag();  
          LIZERP.autoLineFill_Save_Edit();    
          LIZERP.autoRevisedPO();     
          window.scrollTo(0, 0);

          /**
          * remove processing overlay */
          LIZERP.removeProcessingOverlay_2(); /*
          *
          **/

        });
      } else {
        LIZERP.editMode();
        alert('Document not found.');
      }
    }

    /**
     * Auto URL fillup document header
     * Auto URL fillup document line
     *
     * this for all library data populate 
     */
    $.when.apply($, populatePromises).then(function() {
      // when all things are populate, then call
      LIZERP.autoFillup_byURLParams();
      LIZERP.getAutoCompleteInfo();
      LIZERP.onDemandAutoCompleteInfo();
      LIZERP.autoCalculateAmount();
      LIZERP.autoManageItemNature();
      LIZERP.checkItemCodeAndAutoFill();
      // LIZERP.checkTrackingAndAutoFill();
      LIZERP.renameFieldSet();
    });

    /**
     * LIZERP.autoFillup_afterPopulateFromDb();
     */




     return;
   }
 });