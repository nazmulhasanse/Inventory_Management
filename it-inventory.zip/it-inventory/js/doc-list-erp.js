/**
 * Check if jQuery is loaded
 */
if (!window.jQuery) {
  var jq = document.createElement('script');
  jq.type = 'text/javascript';
  jq.src = '/js/jquery-2.1.3.min.js';
  document.getElementsByTagName('head')[0].appendChild(jq);
}

/**
 * Declare the namespace LIZERP if not existent
 */
var LIZERP = LIZERP || {};

$.extend(LIZERP, {
  formId: '',
  formMode: '',
  dbAuxData: [], // extra data submitted by the API that are not fields of the DB

  companyHTML: '<option value="">Select</option>',
  docstatusHTML: '<option value="">Select</option>',
  iduomHTML: '<option value="">Select</option>',
  itemSearchFormHTML: '',
  inventorySearchFormHTML: '',
  inventorySearchFormJS: '',
  lineHTML_template: '',

  formFieldSettings: '',

  // line gets dirty if user changes any field after the line is added or made editable
  lineIsDirty: false,
  valAtFocus: '',

  populateCache: [],

  _URL_DOCUMENTAPI: {
    DOCTYPE1:  '',
    DOCTYPE2:  '/code-framework/form-framework1/doctype2_api.php',
    foo: ''
  },
  _URL_DOCDEFINEAPI: {
    DOCTYPE1: '',
    DOCTYPE2: '/code-framework/form-framework1/erpdocument_define.php?doctype=DOCTYPE2',
    foo: ''
  },
  _URL_LOGIN: '/user/index.php',
  _URL_PDMLIBRARYAPI: '/pdm/mrd_library_api.php',
  _URL_LIBRARYAPI: '/pdm/mrd_library_api.php',
  _URL_MODULEDIR: '', // will be load

  _FIELDS_CREATEONLY: []
});

//******************************************* FIELD HANDLING


/**
 * Populate dropdowns
 * This adds to whatever options are already available, allowing for a blank initial option
 * To clear the options prior, use $('select').empty();
 * TO-DO: add extra options: run select2, auto-adjust width of SELECT
 */
LIZERP.populatePdmDropdown = function(field, library, defaultval, options) {
  var populateParams = {
    'library': library,
    'field': field
  };
  if (!!defaultval && defaultval != null) {
    populateParams.defaultval = defaultval;
  }
  if (!!options && options.indexOf('showkeys') != -1) {
    populateParams.showkeys = true;
  }
  if (!!options && options.indexOf('codevalequal') != -1) {
    populateParams.codevalequal = true;
  }

  if (field == 'productionfloor') {
    var searchParams = {
      'library': library,
      'field': field
    };
    if ($('#company').val().trim().length > 0) {
      searchParams.company = $('#company').val();
    }
    $('#productionfloor').empty().append('<option value="">Select</option>');
    return $.get(LIZERP._URL_PDMLIBRARYAPI, searchParams, populatePdmDropdown_populate(populateParams), 'json');
  }

  if (!!LIZERP.populateCache[library]) {
    populatePdmDropdown_populate(populateParams)(LIZERP.populateCache[library]);
    // returns a resolved promise to signify that there's no pending ajax.
    return $.Deferred().resolve().promise();
  } else {
    var searchParams = {
      'library': library,
      'field': field
    };
    return $.get(LIZERP._URL_PDMLIBRARYAPI, searchParams, populatePdmDropdown_populate(populateParams), 'json');
  }

  function populatePdmDropdown_populate(extraParams) {
    var showkeys = extraParams.showkeys;
    var codevalequal = extraParams.codevalequal;
    return function(data, textStatus, jqXHR) {
      LIZERP.populateCache[extraParams.library] = data;
      var setasdefault = false;

      $(LIZERP.formId + '#' + extraParams.field).empty().append('<option value="">Select</option>');
      $.each(data, function(index, value) {
        setasdefault = (!!extraParams.defaultval && (value == extraParams.defaultval || index == extraParams.defaultval));
        if (!!showkeys && showkeys === true && index != value) {
          $(LIZERP.formId + '#' + extraParams.field)
            .append($("<option></option>")
              .attr("value", index)
              .text(index + ' - ' + value)
              .prop('selected', setasdefault)
            );
        } else if (!!codevalequal && codevalequal === true) {
          $(LIZERP.formId + '#' + extraParams.field)
            .append($("<option></option>")
              .attr("value", value)
              .text(value)
              .prop('selected', setasdefault)
            );
        } else {
          $(LIZERP.formId + '#' + extraParams.field)
            .append($("<option></option>")
              .attr("value", index)
              .text(value)
              .prop('selected', setasdefault)
            );
        }
      });
      return;
    }
  }
}


/**
 * Populate dropdowns
 * This adds to whatever options are already available, allowing for a blank initial option
 * To clear the options prior, use $('select').empty();
 * TO-DO: add extra options: run select2, auto-adjust width of SELECT
 */
LIZERP.populateDropdown = function(field, library, defaultval, options) {
  var populateParams = {
    'library': library,
    'field': field
  };
  if (!!defaultval && defaultval != null) {
    populateParams.defaultval = defaultval;
  }
  if (!!options && options.indexOf('showkeys') != -1) {
    populateParams.showkeys = true;
  }
  if (!!options && options.indexOf('codevalequal') != -1) {
    populateParams.codevalequal = true;
  }

  if (!!LIZERP.populateCache[library]) {
    populateDropdown_populate(populateParams)(LIZERP.populateCache[library]);
    // returns a resolved promise to signify that there's no pending ajax.
    return $.Deferred().resolve().promise();
  } else {
    var searchParams = {
      'library': library,
      'field': field
    };
    return $.get(LIZERP._URL_MODULEDIR + '/api/sys_library_api.php', searchParams, populateDropdown_populate(populateParams), 'json');
  }

  function populateDropdown_populate(extraParams) {
    var showkeys = extraParams.showkeys;
    var codevalequal = extraParams.codevalequal;
    return function(data, textStatus, jqXHR) {
      LIZERP.populateCache[extraParams.library] = data;
      var setasdefault = false;

      $(LIZERP.formId + '#' + extraParams.field).empty().append('<option value="">Select</option>');
      $.each(data, function(index, value) {
        setasdefault = (!!extraParams.defaultval && (value == extraParams.defaultval || index == extraParams.defaultval));
        if (!!showkeys && showkeys === true && index != value) {
          $(LIZERP.formId + '#' + extraParams.field)
            .append($("<option></option>")
              .attr("value", index)
              .text(index + ' - ' + value)
              .prop('selected', setasdefault)
            );
        } else if (!!codevalequal && codevalequal === true) {
          $(LIZERP.formId + '#' + extraParams.field)
            .append($("<option></option>")
              .attr("value", value)
              .text(value)
              .prop('selected', setasdefault)
            );
        } else {
          $(LIZERP.formId + '#' + extraParams.field)
            .append($("<option></option>")
              .attr("value", index)
              .text(value)
              .prop('selected', setasdefault)
            );
        }
      });
      return;
    }
  }
}


/**
 * Populate populateDataList
 * This adds to whatever options are already available, allowing for a blank initial option
 * To clear the options prior, use $('select').empty();
 * TO-DO: add extra options: run select2, auto-adjust width of SELECT
 */
LIZERP.populateDataList = function(field, library, defaultval, options) {
  var populateParams = {
    'library': library,
    'field': field
  };
  if (!!defaultval && defaultval != null) {
    populateParams.defaultval = defaultval;
  }
  if (!!options && options.indexOf('showkeys') != -1) {
    populateParams.showkeys = true;
  }

  if (!!LIZERP.populateCache[library]) {
    populateDataList_populate(populateParams)(LIZERP.populateCache[library]);
    // returns a resolved promise to signify that there's no pending ajax.
    return $.Deferred().resolve().promise();
  } else {
    var searchParams = {
      'library': library,
      'field': field
    };
    return $.get(LIZERP._URL_LIBRARYAPI, searchParams, populateDataList_populate(populateParams), 'json');
  }

  function populateDataList_populate(extraParams) {
    var showkeys = extraParams.showkeys;
    return function(data, textStatus, jqXHR) {
      LIZERP.populateCache[extraParams.library] = data;
      var setasdefault = false;

      var options = '';
      $.each(data, function(index, value) {
        setasdefault = (!!extraParams.defaultval && (value == extraParams.defaultval || index == extraParams.defaultval));
        options += '<option value="'+ value +'"/>';
      });

      var dataList = '<datalist id="list_'+ extraParams.field +'">'+ options +'</datalist>';
      $('#' + extraParams.field).attr('list','list_' + extraParams.field); 
      $('#' + extraParams.field).append(dataList);
      return;
    }
  }
}



LIZERP.searchLoupe_show = function(inputfield) {
  var imgheight = 16;
  var imgwidth = 16;
  var fieldName = $(inputfield).closest('td').attr('class');
  aleft = $(inputfield).offset().left + $(inputfield).width() - imgwidth + 2;
  atop = $(inputfield).offset().top + 3;
  $('<div/>')
    .offset({
      top: atop,
      left: aleft
    })
    .css('display', 'block')
    .css('position', 'absolute')
    .css('background-repeat', 'no-repeat')
    .css('background-image', 'url(./img/search.png)')
    .attr('fieldname', fieldName)
    .addClass('itemsearchLoupe')
    .height($(inputfield).outerHeight() - 2)
    .width($(inputfield).outerHeight() - 2)
    .appendTo($('body'))
    .hover(function(e) {}, function(e) {
      $('.itemsearchLoupe').remove();
    })
    .on('click', function() {
      LIZERP.handleSearchForm($(this).attr('fieldname'));
    });
}

LIZERP.searchLoupe_hide = function() {
  $('.itemsearchLoupe').remove();
}

/**
 * Bind datepicker with an input field
 * @param selector
 */
LIZERP.bindDatepicker = function(selector) {
  $(selector).datepicker({
    dateFormat: 'yy-mm-dd',
    changeMonth: true,
    changeYear: true,
    constrainInput: true,
    onClose: function(dateText, inst) {
      /* Validate date input; erase data if invalid */
      if (isDate(dateText, false) == false) {
        $(this).val('');
      }
    }
  });
}

/**
 * Bind datetimepicker with an input field
 * @param selector
 */
LIZERP.bindDatetimepicker = function(selector) {
  $(selector).datetimepicker({
    dateFormat: 'yy-mm-dd',
    changeMonth: true,
    changeYear: true,
    constrainInput: true,
    onClose: function(dateText, inst) {
      /* Validate date input; erase data if invalid */
      if (isDate(dateText, true) == false) {
        $(this).val('');
      }
    }
  });
}

/**
 * Handle docdate field. Current browser date is auto populated.
 */
LIZERP.handle_docdate_field = function() {
  /* Show current date in docdate field */
  var today = new Date();
  var dd = today.getDate();
  var mm = today.getMonth() + 1;
  /* January is 0! */
  var yyyy = today.getFullYear();

  dd = dd < 10 ? ('0' + dd) : dd;
  mm = mm < 10 ? ('0' + mm) : mm;

  $(LIZERP.formId + ' #docdate').val(yyyy + '-' + mm + '-' + dd);

}

/**
 * Validate form fields
 * @param container
 * @returns {boolean}
 */
LIZERP.validateFormContainerFields = function(container) {
  var error = false;
  $(container).find('input, select, textarea').each(function() {
    if (!!$(this).prop('required')) {
      if ($(this).val() == '') {
        error = true;
        LIZERP.hightlightErrorField($(this));
      }
    }
  });
  return error;
}

/**
 * Highlight error field for a certain period
 * @param field
 */
LIZERP.hightlightErrorField = function(field) {
  field.addClass('error');
  setTimeout(function() {
    field.removeClass('error');
  }, 3000);
}

/**
 * Show form error
 * @param msg
 */
LIZERP.showFormError = function(msg) {
  $(LIZERP.formId + ' #formError').html(msg).show();
  setTimeout(function() {
    $(LIZERP.formId + ' #formError').hide('slow').html('');
  }, 3000);
}



//******************************************* FORM HANDLING
/**
 * Receives data from the API and populates the respective fields of the form
 * @param  {docobj} headerObj is the docobj from the API, minus the lines element
 * @param  {docboj.lines} linesObj is the lines element of docobj
 * @return {boolean}           true for success, false for failure
 */
LIZERP.fillForm = function(headerObj) {
  // First, check if data is complete
  // if (headerObj.length == 0) {
  //   return false;
  // }

  // Complete the header fields
  for (var key in headerObj) {
    if (key.substr(0, 1) == "_") {
      LIZERP.dbAuxData[key.substr(1)] = headerObj[key]
      continue;
    }
    $(LIZERP.formId + '#' + key).filter('input,select,textarea').val(headerObj[key]);
  }

  return true;
}


/**
 * Update the form title
 */
LIZERP.updateFormTitle = function(crudmode) {
  var params = paramsToObj(window.location.search);
  if (params.formtype != $('input#formtype').val()) {
    params.formtype = $('input#formtype').val();
    window.location = window.location.origin + window.location.pathname + '?' + $.param(params);
  }
}



/**
 * Save form via ajax after validation
 */
LIZERP.saveForm = function() {
  // change data to actual uppercase from just css transform
  $(LIZERP.formId).find('input,textarea').each(function(i) {
    if ($(this).css('text-transform') == 'uppercase') $(this).val($(this).val().toUpperCase());
  });

  // run validation on all header fields
  var error = false;
  for (i in LIZERP._FIELDSETS_HEADER) {
    error = error || LIZERP.validateFormContainerFields(LIZERP.formId + ' #' + LIZERP._FIELDSETS_HEADER[i]);
  }


  // If all data is validated, then submit
  // var error;
  if (!error && LIZERP.formMode == 'edit') {
    // just to avoid re-entry, the server should also check for double submission
    LIZERP.readMode();

    /* Prepare JSON */
    var jsonData = {
      'lines': []
    };
    $.each(LIZERP.formFieldSettings['header'], function(fieldName, attributes) {
      jsonData[fieldName] = $(LIZERP.formId + ' #' + fieldName).val();
    });
    


    /* Submit via ajax */
    var postData = {
      reqType: 'saveDoc',
      docobj: JSON.stringify(jsonData)
    };

    // add iddocument in case this is an Edit
    if ( $(LIZERP.formId + ' #' + LIZERP.DOC_DB_SET_READ_KAYFIELD).val().length > 0 ){
      postData[LIZERP.DOC_DB_SET_READ_KAYFIELD] = $(LIZERP.formId + ' #' + LIZERP.DOC_DB_SET_READ_KAYFIELD).val();
    } 
    // if ($(LIZERP.formId + ' #docnumber').val().length > 0) postData.docnumber = $(LIZERP.formId + ' #docnumber').val();
    console.log(postData);

    $.ajax({
      type: 'post',
      url: LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM],
      //dataType: 'json',/* if the return data is json */
      data: postData,
      success: function(data) {
          // if result is JSON, we're using the new API return format
          console.log(data);
          data = JSON.parse(data);
          if (!!data.errormsgs && data.errormsgs.length > 0) {
            console.log(data.errormsgs.join('\n'));
            alert(data.errormsgs.join('\n'));
            LIZERP.editMode();
          } else {
            // var next_href = window.location.origin + window.location.pathname + '?doctype=' + LIZERP._ERP_DOCACRONYM;
            // window.location.href = next_href;
            LISTDOC.redrawList();
            LIZERP.hideFormInterface();
          }
      }
    }).fail(function(e) {
      alert('Saving failed, please try again.');
      LIZERP.editMode();
    });
  }
  return;
}


/**
 * Save form via ajax after validation
 */
LIZERP.saveAndNewForm = function() {
  // change data to actual uppercase from just css transform
  $(LIZERP.formId).find('input,textarea').each(function(i) {
    if ($(this).css('text-transform') == 'uppercase') $(this).val($(this).val().toUpperCase());
  });

  // run validation on all header fields
  var error = false;
  for (i in LIZERP._FIELDSETS_HEADER) {
    error = error || LIZERP.validateFormContainerFields(LIZERP.formId + ' #' + LIZERP._FIELDSETS_HEADER[i]);
  }


  // If all data is validated, then submit
  // var error;
  if (!error && LIZERP.formMode == 'edit') {
    // just to avoid re-entry, the server should also check for double submission
    LIZERP.readMode();

    /* Prepare JSON */
    var jsonData = {
      'lines': []
    };
    $.each(LIZERP.formFieldSettings['header'], function(fieldName, attributes) {
      jsonData[fieldName] = $(LIZERP.formId + ' #' + fieldName).val();
    });
    


    /* Submit via ajax */
    var postData = {
      reqType: 'saveDoc',
      docobj: JSON.stringify(jsonData)
    };

    // add iddocument in case this is an Edit
    if ( $(LIZERP.formId + ' #' + LIZERP.DOC_DB_SET_READ_KAYFIELD).val().length > 0 ){
      postData[LIZERP.DOC_DB_SET_READ_KAYFIELD] = $(LIZERP.formId + ' #' + LIZERP.DOC_DB_SET_READ_KAYFIELD).val();
    } 
    // if ($(LIZERP.formId + ' #docnumber').val().length > 0) postData.docnumber = $(LIZERP.formId + ' #docnumber').val();
    console.log(postData);

    $.ajax({
      type: 'post',
      url: LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM],
      //dataType: 'json',/* if the return data is json */
      data: postData,
      success: function(data) {
          // if result is JSON, we're using the new API return format
          console.log(data);
          data = JSON.parse(data);
          if (!!data.errormsgs && data.errormsgs.length > 0) {
            console.log(data.errormsgs.join('\n'));
            alert(data.errormsgs.join('\n'));
            LIZERP.editMode();
          } else {
            LISTDOC.redrawList();
            LIZERP.blankForm();
          }
      }
    }).fail(function(e) {
      alert('Saving failed, please try again.');
      LIZERP.editMode();
    });
  }
  return;
}





/**
 * Handle form fields to show-hide/enable-disable/required/readonly etc.
 */
LIZERP.handleFormFields = function(crudmode) {
  var params = paramsToObj(window.location.search);
  var searchParams = params;
  if (searchParams.formtype === undefined) {
    searchParams.formtype = 'default';
  }
  delete searchParams.doctype;

  return $.get(LIZERP._URL_DOCDEFINEAPI[LIZERP._ERP_DOCACRONYM], searchParams, handleFormFields_results(), 'json');

  function handleFormFields_results(extraParams) {
    return function(data, textStatus, jqXHR) {
      /* Save to formFieldSettings for later use such as form lines */
      LIZERP.formFieldSettings = data;
      // alert(JSON.stringify(data));

      /* Handle header fields */
      $.each(data['header'], function(fieldName, attributes) {

        console.log(fieldName+ "---" + JSON.stringify(attributes));
        /* Handle required restriction */
        if (attributes['restriction'] == 'required') {
          $(LIZERP.formId + ' #' + fieldName).attr('required', 'required');
          $(LIZERP.formId + ' #' + fieldName).closest('div.formGroup').find('label').not('#'+fieldName).append('<span class="required">*</span>');
        } else {
          $(LIZERP.formId + ' #' + fieldName).removeAttr('required');
          $(LIZERP.formId + ' #' + fieldName).closest('div.formGroup').find('label span.required').remove();
        }

        /* Handle viewonly restriction */
        if (attributes['restriction'] == 'viewonly') {
          $(LIZERP.formId + ' #' + fieldName).attr('readonly', 'readonly');
          $(LIZERP.formId + ' #' + fieldName).attr('disabled', 'disabled');
        } else {
          $(LIZERP.formId + ' #' + fieldName).removeAttr('readonly');
          $(LIZERP.formId + ' #' + fieldName).removeAttr('disabled');
        }

        /* Handle hidden restriction */
        if (attributes['restriction'] == 'hidden') {
          $(LIZERP.formId + ' #' + fieldName).closest('div.formGroup').hide();
        }

        /* Handle defaults */
        if (!!attributes['default']) {
          if (attributes['default'].indexOf(':') == -1) {
            $(LIZERP.formId + ' #' + fieldName).val(attributes['default']);
          }
        }
        // After changing fields, must refresh

      });

    }
  }
}


/**
 * Show popup item code search form
 */
LIZERP.handleSearchForm = function(callingField, prepopulate) {
  LIZERP.searchLoupe_hide();
  if (callingField == 'itemcode') {
    var prepopJS = (!!prepopulate) ? 'var prepopulate = ' + JSON.stringify(prepopulate) + ';' : '';
    var content = LIZERP.itemSearchFormHTML + '<script> ' + prepopJS + '</script>';
  } else if (callingField == 'idlocation') {
    if (LIZERP._ERP_DOCACRONYM == 'GD' || LIZERP._ERP_DOCACRONYM == 'TO') {
      var $whlocation = $('select#sendlocation');
    } else if (LIZERP._ERP_DOCACRONYM == 'GR') {
      var $whlocation = $('select#recvlocation');
    } else {
      throw "FATAL ERROR: unrecognized doctype in handleSearchForm";
    }
    if ($whlocation.val() == '') {
      LIZERP.hightlightErrorField($whlocation);
      return;
    } else {
      var $tr2 = LIZERP.getLineBeingEdited();

      prepopulate = !!prepopulate ? prepopulate : {};
      prepopulate.whlocation = $whlocation.val();
      prepopulate.fulladdresscode = $tr2.find('.idlocation input').val();
      var prepopJS = 'var prepopulate = ' + JSON.stringify(prepopulate) + ';';
      var content = LIZERP.locationSearchFormHTML + '<script> ' + prepopJS + '</script>';
    }
  }
  $.fancybox({
    parent: LIZERP.formId,
    type: 'html',
    content: content,
    minWidth: 500,
    minHeight: 300,
    afterShow: function() {
      $('#searchForm .focusonme').first().focus();
      if (!!prepopulate) {
        for (field in prepopulate) {
          $('#searchForm').find('input,select').filter('[name=' + field + ']').val(prepopulate[field]);
        }
        $('#searchForm').find('input,select').filter('[name=whlocation]').attr('disabled', 'disabled');
        $('#searchForm button#search').first().click();
      }
    }
  });
  return;
}



//******************************************* MODE HANDLING
LIZERP.initialMode = function(){
  // all buttons need to show
  $('.btnNew').css('display', 'inline-block');
  $('.btnInitialMode').css('display', 'inline-block');

  // all buttons need to hide
  $('.btnNext').css('display', 'none');
  $('.btnEnterEditMode ').css('display', 'none');
  $('.btnSaveForm  ').css('display', 'none');
}

LIZERP.readMode = function() {
  $(LIZERP.formId).find(' #formLines tr').unbind('mouseenter mouseleave');
  $(LIZERP.formId).find('input,select,textarea').attr('disabled', 'disabled');
  $(LIZERP.formId).find(' input[type=button]').removeAttr('disabled');
  $('#fieldset_systeminformation').css('display', 'block');
  $('.btnEditMode ').css('display', 'none');
  $('.btnInitialMode').css('display', 'none');
  $('.btnReadMode ').css('display', 'inline-block');
  $('.btnAllMode ').css('display', 'inline-block');

  $('.datepicker').unmousewheel();

  if( $('#formDiv').is(":visible") ){
    $('#rightFormButtons .btnCancelForm').css('display', 'inline-block');
  }

  LIZERP.formMode = 'read';
}


LIZERP.editMode = function() {
  $(LIZERP.formId).find('input,select,textarea').removeAttr('disabled');
  LIZERP.lockCreateOnlyFields();
  $('#fieldset_systeminformation').css('display', 'none');
  $(' .btnEditMode').css('display', 'inline-block');
  $(' .btnReadMode').css('display', 'none');
  $(' .btnInitialMode').css('display', 'none');
  $(' .btnAllMode').css('display', 'inline-block');

  if( $('#formDiv').is(":visible") ){
    $(' .btnNew').css('display', 'none');
  }

  //-----------
  var DOC_DB_SET_READ_KAYFIELD  = LIZERP.formFieldSettings['DOC_DB_SET_READ_KAYFIELD'];
  var DOC_NUMBER_ALLOWED_MANUAL  = LIZERP.formFieldSettings['DOC_NUMBER_ALLOWED_MANUAL'];
  var DOC_NUMBER_PRIMARYKEY_AUTOINC  = LIZERP.formFieldSettings['DOC_NUMBER_PRIMARYKEY_AUTOINC'];
  if(DOC_NUMBER_ALLOWED_MANUAL == 'no'){
    $(LIZERP.formId + ' #' + DOC_DB_SET_READ_KAYFIELD).attr('disabled', 'disabled');
  } else if(DOC_NUMBER_ALLOWED_MANUAL == 'yes'){
    if(!!LIZERP.dataReadFromDB && LIZERP.dataReadFromDB == true){
      $(LIZERP.formId + ' #' + DOC_DB_SET_READ_KAYFIELD).attr('disabled', 'disabled');
    }
  }
  
  LIZERP.formMode = 'edit';
}



LIZERP.readThisDoc_N_FillInForm = function(docnumber){
  LIZERP.displayFormInterface();

  // var searchParams = {
  // 'reqType': 'readDoc',
  // 'docnumber': docnumber
  // };

  var DOC_DB_SET_READ_KAYFIELD = LIZERP.DOC_DB_SET_READ_KAYFIELD;
  var searchParams = {
    'reqType': 'readDoc',
    DOC_DB_SET_READ_KAYFIELD  : LIZERP.DOC_DB_SET_READ_KAYFIELD,
    DOC_DB_SET_READ_KAYVALUE  : docnumber,
  };


  $.get(LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM], searchParams, populateFromDb);
  function populateFromDb(data, textStatus, jqXHR) {
    data = JSON.parse(data);
    if (Object.keys(data).length > 0) {
        LIZERP.fillForm(data);
        LIZERP.readMode();
        LIZERP.dataReadFromDB = true;
        // window.scrollTo(0, 0);
    } else {
      LIZERP.editMode();
      alert('Document not found.');
    }
  }

}






LIZERP.fitListToFullWindow = function(){
    $('#listCntrDiv').css({
      'width': '',
      'max-width': ''
    });
}


/**
 * Locks all fields that can not be changed after document is saved.
 * This is done to keep consistency on the DB.
 * E.g. status of the related document has already been changed.
 */
LIZERP.lockCreateOnlyFields = function() {
  var fieldList = LIZERP._FIELDS_CREATEONLY;
  for (field in fieldList) {
    $(LIZERP.formId).find('input,textarea,select').filter('#' + fieldList[field]).attr('disabled', 'disabled');
  }
}

//******************************************* OTHER

LIZERP.wait = function(ms) {
  var deferred = $.Deferred();
  setTimeout(function() {
    deferred.resolve()
  }, ms);
  return deferred.promise();
}


LIZERP.adjustInterface = function(){
  /**
  * Make ratio later
  */
  var width = window.innerWidth
  || document.documentElement.clientWidth
  || document.body.clientWidth;

  var height = window.innerHeight
  || document.documentElement.clientHeight
  || document.body.clientHeight;

  var screenWidth = screen.width;
  var screenHeight = screen.height 
  // alert('screen width*height = ' + screenWidth + '*' + screenHeight);


  var windowWidth = window.innerWidth;
  var windowHeight = window.innerHeight;

  var minusWidth = 80;
  if(screenWidth > 1500) minusWidth = 135;

  var seventiPersenWidth = ( (windowWidth * 75)/100 ) - minusWidth;
  var thirtyPersenWidth = (windowWidth * 25)/100;

  var ofst = $("#listTable tr:first").find("th:first").offset();
  var Xleft = (ofst.left + thirtyPersenWidth);
  var Ytop = ofst.top;

  console.log('calculation: total width-' + windowWidth + ' seventiPersenWidth-' + seventiPersenWidth + ' thirtyPersenWidth' + thirtyPersenWidth);  
  console.log('Xleft' + Xleft);

  $('#listCntrDiv').css({
    'display':'block',
    'floal': 'left',
    'width': thirtyPersenWidth + 'px',
    'max-width': thirtyPersenWidth + 'px',
  });

  $('#formDiv').css({
    'display':'block',
    'floal': 'left',
    'left': Xleft,
    'top': Ytop,
    'width': seventiPersenWidth + 'px',
    'min-width': seventiPersenWidth + 'px',
    'min-height': '400px',
  });
  $('#rightFormDiv').css({
    'min-height': '400px',
  });

}