/**
 * Declare ERPLIST Namespace if not exist
 */
var ERPLIST = ERPLIST || {};

$.extend(ERPLIST, {
  mUrl: 'api/server_api.php',
  mType: 'get',
  mData: '',
  mAsync: false,
  mReqType: '',
  queryData: '',
  queryParam: '',
  _searchParams: '',
  _URL_API: 'list-po-lines_api.php',

  foo: 'here for no reason other than to be the last line, without a comma'
});


// ERPLIST.displayQueryData = function(jsonData){

//   var pagination = jsClient.makePagination(jsonData)

//   var data = JSON.parse(jsonData);
//   var listData = data['listData'];
//   var hasData = (data.noResult) ? 'no' : 'yes';
//   var listTable = ERPLIST.makeTable(jsonData, hasData);

//   $("#listDiv").html(pagination);
//   $("#listDiv").append(listTable);

//   ERPLIST.initSearchAction();

//   /**
//    * Css
//    */
//   $('#listTable').css({
//     'width':'100%'
//   });
//   $('#listTable tr#searchForm input').css({
//     'width':'95%',
//     'min-width': '60px',
//     'font-family':'Arial',
//     'padding':'2px',
//     'border':'1px solid #7F7F7F',
//     'border-radius':'3px'
//   });
//   $('#listTable tr#searchForm button').css({
//     'padding':'2px',
//     'border':'1px solid #7F7F7F',
//     'border-radius':'3px',
//     'vertical-align': 'middle'
//   });  
//   $('#listTable .hasCustomSearch').css({
//     'width':'70%'
//   });
//   jsClient.paginationCSS();
//   ERPLIST.changeTempleteCSS();
//   ERPLIST.applyCustomListCSS();

// }


ERPLIST.applyCustomListCSS = function(){

	$('#listTable tr#searchForm input').css({
	'width':'95%',
	'min-width': '60px',
	'font-family':'Arial',
	'padding':'2px',
	'border':'1px solid #7F7F7F',
	'border-radius':'3px'
	});
	// Custom CSS if required
	$('#listTable td.lineentrytime').css({
	'white-space':'nowrap'
	}); 
   // Custom CSS if required
  $('#listTable td.lineentrytime').css({
    'white-space':'nowrap'
  }); 
  $('#listTable td.itemdescription').css({
    'white-space':'nowrap',
    'min-width':'200px'
  }); 
  $('.material-icons').css('font-size','20px');
  $('#entryEditFieldForm .material-icons').css({'background':'none', 'border':'none'});
  jsClient.initDateTimePicker();
}

ERPLIST.makeTable = function(jsonData,hasData) {
  var data   = JSON.parse(jsonData);
  var mydata = data['listData'];
  pageNum      = parseInt(data['pageNum']-1);
  showLimit    = parseInt(data['showLimit']);
  var trDataId = parseInt(pageNum * showLimit) + 1;
  console.log(pageNum + '  ' +showLimit);

  var $table = $('<table border=1 id="listTable" class="listTable" />');
  var $thead = $('<thead />');
  var $tbody = $('<tbody/>');

  //for composition column
  ERPLIST.compositeColumns = {
    // docnumber:{
    //   docnumber: {
    //     style: 'font-weight:bold; color:blue',
    //     customsearch: true,
    //     composite: false,
    //     end: true
    //   }
    // },
    // rrnumber:{
    //   rrnumber:{
    //     composite: false,
    //     end: true        
    //   }
    // },    
    // // linenumber:{
    // //   linenumber:{
    // //     style: 'font-weight:bold; color:green',
    // //     composite: false,
    // //     end: true        
    // //   }
    // // },
    // // ubpolines:{
    // //   ubpolines:{
    // //     fielddesc: 'Under blanket PO Lines',
    // //     composite: false,
    // //     end: true        
    // //   }
    // // },    
    // formtype: {
    //   formtype:{
    //     style: 'font-weight:bold;',
    //     customsearch: true,
    //     islibrary: true,
    //     datasource: {
    //       'Direct': 'Blanket',
    //       // 'Projection': 'Blanket',
    //       'Confirmed': 'Under Blanket'
    //     },        
    //     fielddesc: 'Line Status',
    //     end: true       
    //   }
    // },    
    // amendmentstatus: {
    //   amendmentstatus:{
    //     // style: 'font-weight:bold; color:green',
    //     // customsearch: true,
    //     // islibrary: true,
    //     // datasource: {
    //     //   0: '',
    //     //   1: 'Request Sent',
    //     //   2: 'Amended'
    //     // },        
    //     // fielddesc: 'Amendment Status',
    //     // end: true   
    //     composite: false,
    //     end: true     
    //   }
    // },    
    // docstatus : {
    //   docstatus:{
    //     style: 'font-weight:bold; color:green',
    //     customsearch: true,
    //     islibrary: true,
    //     datasource: {
    //       0: 'Entered',
    //       1: 'Running',
    //       2: 'Closed'
    //     },        
    //     fielddesc: 'Line Status',
    //     end: true
    //   }
    // },
    // linestatus : {
    //   linestatus:{
    //     style: 'font-weight:bold; color:green',
    //     customsearch: true,
    //     islibrary: true,
    //     datasource: {
    //       0: 'Entered',
    //       1: 'Running',
    //       2: 'Closed'
    //     },        
    //     fielddesc: 'Line Status',
    //     end: true
    //   }
    // },    
    // inhousedstatus : {
    //   inhousedstatus:{
    //     style: 'font-weight:bold; color:green',
    //     customsearch: true,
    //     islibrary: true,
    //     datasource: {
    //       0: 'Entered',
    //       1: 'Running',
    //       2: 'Closed'
    //     },        
    //     fielddesc: 'Line Status',
    //     end: true
    //   }
    // },    
    
    // company:{
    //   company:{
    //     style: 'font-weight:bold; color:green',
    //     fielddesc: 'Company',
    //     composite: false,
    //     sql: "SELECT Code AS code, Description AS description FROM mrd_library WHERE LibraryName='company'", 
    //     islibrary: true,
    //     end: true        
    //   }
    // },
    // itemtype: {
    //   itemtype:{
    //     fielddesc: 'Item Type',
    //     style: 'font-weight:bold; color:green',
    //     islibrary: true,
    //     sql: "SELECT Code AS code, Description AS description FROM mrd_library WHERE LibraryName='itemtype_textile'",        
    //     customsearch: true,
    //     composite: false,
    //     end: true
    //   }
    // },
    // itemcode: {
    //   itemcode:{
    //     composite: false,
    //     end: true        
    //   }
    // },    
    // itemdescription: {
    //   itemdescription:{
    //     composite: false,
    //     end: true        
    //   }
    // },
  }

  // some trickery for nice formatting
  var params = jsClient.paramsToObj(window.location.search);
  if(params.formtype == 'Direct'){
    var hideColumns = ['idlines', 'doctype','linenumber','ubpolines'];
  }else{
    var hideColumns = ['idlines', 'doctype','linenumber'];
  }

  var translationsHardCode = {};
  translationsHardCode.docnumber = 'PO No.';
  translationsHardCode.formtype = 'PO Type';
  translationsHardCode.amendmentstatus = 'Amendment Status';
  translationsHardCode.linenumber = 'PO Line';
  translationsHardCode.ubpolines = 'Under blanket PO Lines';
  translationsHardCode.rrnumber = 'RR Number';
  translationsHardCode.company = 'Divison';
  translationsHardCode.itemtype = 'Item Type';
  translationsHardCode.itemcode = 'Item Code';
  translationsHardCode.itemdescription = 'Item Description';
  translationsHardCode.tnxqty = 'Order Qty';
  translationsHardCode.inhousedstatus = 'Inhoused Status';
  translationsHardCode.numberoflotrcv = 'No. of Lot Received';
  translationsHardCode.numberofqualitychecked = 'No. of Lot Quality Checked';

  translationsHardCode.consumtionstatus = 'Consumtion status';
  translationsHardCode.consumedqty = 'Consumed Qty';
  translationsHardCode.balanceqty = 'Balance Qty';
  translationsHardCode.shipdatetoapparel = 'Ship date to apparel';
  translationsHardCode.internalplannedeta = 'Internal Planned ETA';
  translationsHardCode.internalplannedqty = 'Internal Planned Qty';
  translationsHardCode.publishedplannedeta = 'Published Planned ETA';
  translationsHardCode.publishedplannedqty = 'Published planned Qty';
  translationsHardCode.doclinenumber = 'PO Line No.';

  translationsHardCode.salesorder = 'SO No.';
  translationsHardCode.company = 'Divison';
  translationsHardCode.iduom = 'UoM';
  translationsHardCode.elementuom = 'Elem. UoM';
  translationsHardCode.docstatus = 'PO Status';
  translationsHardCode.linestatus = 'PO Line Status';
  translationsHardCode.documentinformation = 'Document Information';
  translationsHardCode.itemspecification = 'Item Specification';
  translationsHardCode.linestatus__company__docdate  = 'Document Information';

  ERPLIST.translationsHardCode = translationsHardCode;



  /**
   * builds the table header
   */
  var mydata_json = JSON.stringify(mydata);
  var firstRow = mydata[0];

  var firstRowCopy = firstRow;
  var compositeColumnsLength = Object.keys(ERPLIST.compositeColumns).length;
  var countVisibleColumn = 1; // here start from 1 cz first td for option


  var $table = $('<table border=1 id="listTable" class="listTable" />');
  var $thead = $('<thead />');
  var $tbody = $('<tbody/>');
  /**
  * first header row------------------------------------------------------------------------------------------------------------------------------------------------------------
  */
  // var $tr = ERPLIST.generateFirstHeaderTr(firstRowCopy, translationsHardCode);
  var $tr = $("<tr/>");
  $td = $('<th/>');
  $td.html('');
  $td.appendTo($tr);

    $.each(firstRowCopy, function (fieldname, fieldvalue) {
    // for (var fieldname in firstRowCopy) {
      // var fieldvalue = firstRowCopy[fieldname];
      
      // search this field is in composite column
      // and assume that its not under in composite colums
      var groupName = '';
      var groupFields = {};
      var hasInCompositeColumn = false;
      if(compositeColumnsLength > 0){
        for (var groupName in ERPLIST.compositeColumns) {
          groupFields = ERPLIST.compositeColumns[groupName];
          for (var thisfieldname in groupFields) {
            if(thisfieldname == fieldname){
              hasInCompositeColumn = true;
              break;
            }
          }
          if(hasInCompositeColumn) break;
        }
      }

      
      if (hasInCompositeColumn) {   // if have then procceed composite column
      // hide first
      $.each(groupFields, function(fieldname, fieldStyle){
        var fielddesc = fieldname;
        $td = $('<th/>');
        if (!!translationsHardCode[fieldname]) fielddesc = translationsHardCode[fieldname];
        $td.html('<center>'+ fielddesc +'</center>');
        $td.css('display','none');
        $td.appendTo($tr);

        delete firstRowCopy[fieldname]; // its already procceed
      });

      $td = $('<th/>');
      $td.attr('class', groupName);
      if (!!translationsHardCode[groupName]) groupName = translationsHardCode[groupName];
      $td.html('<center>'+ groupName +'</center>');
      $td.appendTo($tr);
      countVisibleColumn++;

      } else {            //procceed normal column

      countVisibleColumn++;
      var fielddesc = fieldname;
      $td = $('<th/>');
      if (!!translationsHardCode[fieldname]) fielddesc = translationsHardCode[fieldname];
      $td.html('<center>'+ fielddesc +'</center>');
      if ( hideColumns.indexOf(fieldname) >= 0 ){ $td.css('display','none'); countVisibleColumn--};
      $td.appendTo($tr);

      }

    // }  
    });
  $tr.appendTo($thead);
  $thead.appendTo($table);
  // end -----------------------------------------------------------------------------------------------------------------


  /**
  * second header row-----------------------------------------------------------------------------------------------------------------------------------------------------------
  */
  var $tr = $("<tr/>").attr("id","searchForm");
  var $td;
  $td = $('<td/>');
  $td.html('<center>Option</center>');
  $td.appendTo($tr);

  var firstRowCopy = JSON.parse(mydata_json)[0];
    $.each(firstRowCopy, function (fieldname, fieldvalue) {
    // for (var fieldname in firstRowCopy) {
      // var fieldvalue = firstRowCopy[fieldname];
      
      // search this field is in composite column
      // and assume that its not under in composite colums
      var groupName = '';
      var groupFields = {};
      var hasInCompositeColumn = false;
      if(compositeColumnsLength > 0){
        for (var groupName in ERPLIST.compositeColumns) {
          groupFields = ERPLIST.compositeColumns[groupName];
          for (var thisfieldname in groupFields) {
            if(thisfieldname == fieldname){
              hasInCompositeColumn = true;
              break;
            }
          }
          if(hasInCompositeColumn) break;
        }
      }


      if (hasInCompositeColumn) {   // if have then procceed composite column
      var compositeClass = '';
      $td = $('<td/>');
      $td.attr('class', groupName);
      $.each(groupFields, function(fieldname, fieldpropties){

        compositeClass +=  ( !!fieldpropties.end) ? fieldname : fieldname + '__';          
        var customsearch_option = ( !!fieldpropties.showsearchimg) ?'<button type="button" onclick="ERPLIST.handleCustomSearch(this);"><img src="img/search_icon.png" alt="" height="15" width="15"></button>': '';
        var customsearch_click  = ( !!fieldpropties.customsearch) ?'onclick="ERPLIST.handleCustomSearch(this);"': 'onclick="ERPLIST.handleThisSearchInputFieldClick(this);"';
        var customsearch_class  = ( !!fieldpropties.customsearch ) ? '  hasCustomSearch' : '';

        var html = '<center><input type="text" name="'+ compositeClass +'" value="" id="'+compositeClass+'" class="'+compositeClass + customsearch_class +'" '+ customsearch_click +' />'+ customsearch_option +'</center><div id="'+compositeClass+'_displaySearchParams" style="background-color:white;"></div>';
        $td.html(html);

        delete firstRowCopy[fieldname]; // its already procceed
        if(!!fieldpropties.single && fieldpropties.single == true) return; // need to make one td in list
        $td_hide = $('<td/>');
        $td_hide.html('<center><input type="hidden" class="'+ fieldname +'" value="" id="'+fieldname+'" /></center>');
        $td_hide.css('display','none');
        $td_hide.appendTo($tr);

      });
      $td.appendTo($tr);    

      } else {

      var fielddesc = fieldname;
      $td = $('<td/>');
      $td.attr('class', fieldname);
      $td.html('<center><input type="text"  name="'+ fieldname +'" class="'+ fieldname +'" value="" id="'+fieldname+'" onclick="ERPLIST.handleThisSearchInputFieldClick(this);" /></center><div id="'+fieldname+'_displaySearchParams" style="background-color:white;"></div>');
      if ( hideColumns.indexOf(fieldname) >= 0 ) $td.css('display','none');
      $td.appendTo($tr);

      }

    // }  
    });

  $tr.appendTo($thead);
  $thead.appendTo($table);
  /**
  * second header row end -----------------------------------------------------------------------------------------------------------------------------------------------------------
  */


  if(hasData == 'no'){
    $thead.appendTo($table);
    //custom for no record found
    var $tr = $("<tr/>");
    var $td = $('<td/>').attr("colspan",countVisibleColumn);
    $td.html('No Data Found')
    .css({'text-align':'center','vertical-align':'middle'});
    $td.appendTo($tr);
    $tr.appendTo($table);
    return $table;
  }


  /**
  * populates with data--------------------------------------------------------------------------------------------------------------------------------------------------
  */
  var mydata = JSON.parse(mydata_json);
  $.each(mydata, function (index, value) {

    var $tr = $("<tr/>"); // it should be in here
    $tr.attr("data-id",trDataId);
    trDataId++;

    var thisRow = value;
    var thisRowCopy = thisRow;
    var thisRowCopy_Json =  JSON.stringify(thisRow);

    // retrive variable here which is needed
    var formtype = thisRow['formtype'];
    var linestatus = thisRow['linestatus'];

    // generate button if needed
    var btnLineChooser = '<center><input type="checkbox" class="multipleLineChooser" onclick="ERPLIST.handleLineChooserCheckboxClick(this);" ></center>';
    var btnThisLineAction = '';
    if(linestatus == 'Requisition Sent'){
      btnThisLineAction = '<button type="button" class="mbutton delete" onclick="ERPLIST.handleLineEvolutionBtnAction(this)">Cancel this line</button>';
    } else if(linestatus == 'Requisition Planned'){
      btnThisLineAction = '';
    }
    $td = $('<td/>');
    $td.html(btnLineChooser);
    $td.appendTo($tr);


      // looping over this row
      $.each(thisRow, function (fieldname, fieldvalue) {
      // for (var fieldname in firstRowCopy) {
        // var fieldvalue = firstRowCopy[fieldname];
        
        // search this field is in composite column
        // and assume that its not under in composite colums
        var groupName = '';
        var groupFields = {};
        var hasInCompositeColumn = false;
        if(compositeColumnsLength > 0){
          for (var groupName in ERPLIST.compositeColumns) {
            groupFields = ERPLIST.compositeColumns[groupName];
            for (var thisfieldname in groupFields) {
              if(thisfieldname == fieldname){
                hasInCompositeColumn = true;
                break;
              }
            }
            if(hasInCompositeColumn) break;
          }
        }

        
        if (hasInCompositeColumn) {     // if have then procceed composite column

        $td = $('<td/>');
        $td.attr('class', groupName);
        $td.attr('fieldname', groupName);
        var compositeColumnsHTML = '';
        var divRow = '';
        $.each(groupFields, function(fieldname, fieldpropties){

          var fieldvalue = thisRow[fieldname];
          var fielddesc = (!!fieldpropties.fielddesc) ? fieldpropties.fielddesc : fieldname;
          var style = ( !!fieldpropties.style ) ? 'style="' + fieldpropties.style + '"': '';

          // *** write custom code here ---

          var obj_thisRowCopy_Json =  JSON.parse(thisRowCopy_Json);
          fieldvalue = (fieldname == "docnumber") ? "<a href='erpdocument.php?docnumber="+fieldvalue+"&doctype=T7&formtype="+formtype+"' target='_blank''>"+fieldvalue+"</a>" : fieldvalue;

          // *** custom code end ----------

          divRow += '<div class="crow" '+ '' +'>';
          if( (!!!fieldpropties.single) || (!!fieldpropties.single && fieldpropties.single == false) ){
            divRow += '<div class="ccell1 '+ fieldname +'" '+ style +'>'+ fielddesc +'</div>';
            divRow += '<div class="ccell2 '+ fieldname +'">:</div>';
          }
          divRow += '<div class="ccell3 '+ fieldname +'_ccell3" '+ style +'>'+ fieldvalue +'</div>';
          divRow += "</div>";

          delete thisRowCopy[fieldname]; // its already procceed
          if(!!fieldpropties.single && fieldpropties.single == true) return; // need to make one td in list
          $td_hide = $('<td/>');
          $td_hide.html(fieldvalue);
          $td_hide.attr("fieldname",fieldname);
          $td_hide.css('display','none');
          $td_hide.appendTo($tr);

        });

        var divTable = "<div id='ctable'>"; 
        divTable += divRow;  
        divTable += "</div>"; 

        compositeColumnsHTML = divTable;
        $td.html(compositeColumnsHTML)
        .css("cursor","pointer")
        .hover(
          function(){bgOn = $(this).closest("tr").css("background-color"); $(this).closest("tr").css("background-color", "lightblue");},
          function(){$(this).closest("tr").css("background-color", bgOn);}
        );
        $td.appendTo($tr);


        } else {

        // *** write custom code here
        fieldvalue = (fieldname == "docnumber") ? "<a href='erpdocument.php?docnumber="+fieldvalue+"&doctype=PO&formtype="+formtype+"&docviewflag=apparel' target='_blank''>"+fieldvalue+"</a>" : fieldvalue;
        fieldvalue = (fieldname == "internalplannedeta") ? ERPLIST.makeEntryEditField(fieldname, fieldvalue, thisRowCopy['idlines']) : fieldvalue;
        fieldvalue = (fieldname == "internalplannedqty") ? ERPLIST.makeEntryEditField(fieldname, fieldvalue, thisRowCopy['idlines']) : fieldvalue;
        fieldvalue = (fieldname == "publishedplannedeta") ? ERPLIST.makeEntryEditField(fieldname, fieldvalue, thisRowCopy['idlines']) : fieldvalue;
        fieldvalue = (fieldname == "publishedplannedqty") ? ERPLIST.makeEntryEditField(fieldname, fieldvalue, thisRowCopy['idlines']) : fieldvalue;
        // *** custom code end

        $td = $('<td/>');
        $td.html(fieldvalue)
        .css("white-space","pre-wrap")
        .attr("fieldname",fieldname)
        .css("cursor","pointer")
        .hover(
          function(){bgOn = $(this).closest("tr").css("background-color"); $(this).closest("tr").css("background-color", "lightblue");},
          function(){$(this).closest("tr").css("background-color", bgOn);}
        );
        if ( hideColumns.indexOf(fieldname) >= 0 ) $td.css('display','none');
        $td.appendTo($tr);

        }

      // }  
      });

    // *** custom code start-----------------------------------------------------------------------------------------
    // $tr.find('td.requiredinformation').append(btnThisLineAction);
    // *** custom code end-------------------------------------------------------------------------------------------

      $tr.click( function() { 
          ERPLIST.sendBackSearchChoice($(this));
        })
        .appendTo($tbody);
    });

    $thead.appendTo($table)
    $tbody.appendTo($table)

    return $table;
};





/**
* Custom table generate code end ------------------------------------------------------------------------------------------------------
*/

/**
* Custom function code------------------------------------------------------------------------------------------------------
*/
ERPLIST.viewunderblunketlines = function() {
  var rrnumber = ERPLIST.rrnumber;
  var next_href = window.location.origin + '/erp-apparel/list-ub-po-lines.php?parentrrnumber=' + rrnumber;
  window.open(next_href);
}

ERPLIST.actionButton = function(){
  if ( $('#listSuccessDiv').css('display') == 'none' ){
    // element is hidden
    // $('#listSuccessDiv').find('#listSuccessMsg').text('this will be hidden');
    // var cloneDiv = $('#listSuccessMsg').parent("div");
    // // CurrentLi.clone().insertAfter(CurrentLi);
    // var cloneCopy = cloneDiv.clone();
    // cloneCopy.find('#listSuccessMsg').text('sdfsferwerewrewr');
    // cloneCopy.css({'display':'block'});
    // $('#listSuccessDiv').after(cloneCopy);

    var cloneDiv = $('#listSuccessDiv').clone();
    cloneDiv.css({'display':'block'})
        .insertBefore('#listSuccessDiv')
        .find('#listSuccessMsg').text('sdfsferwerewrewr');
    
  } else if($('#listSuccessDiv').css('display') == 'block'){
    // element is block
    var cloneDiv = $('#listSuccessDiv').clone();
    cloneDiv.css({'display':'block'})
        .insertBefore('#listSuccessDiv')
        .find('#listSuccessMsg').text('this is success');

    var cloneDiv = $('#listWarningDiv').clone();
    cloneDiv.css({'display':'block'})
        .insertBefore('#listWarningDiv')
        .find('#listWarningMsg').text('this is warning');

    var cloneDiv = $('#listErrorDiv').clone();
    cloneDiv.css({'display':'block'})
        .insertBefore('#listErrorDiv')
        .find('#listErrorMsg').text('this is error');

  }

}

ERPLIST.closeISWEMsg = function(thisf){
  var parentId = $(thisf).parent().attr('id');
  $(thisf).closest('div').css({'display':'none'});
  $(thisf).closest('div').find('#listSuccessMsg').text('');
}


/**
 * [makeEntryEditField description]
 * @param  {[type]} fieldname  [description]
 * @param  {[type]} fieldvalue [description]
 * @return {[type]}            [description]
 *
 * List entry edit field control -----------------------------------------------------------------------------------
 */
ERPLIST.makeEntryEditField = function(fieldname, fieldvalue, dbsetkey){

  var btnTranslator = {
    internalplannedeta: 'Internal planned ETA',
    internalplannedqty: 'Internal planned Qty',
    publishedplannedeta: 'Published planned ETA',
    publishedplannedqty: 'Published planned Qty',
  }
  var fielddesc = (!!btnTranslator[fieldname]) ? btnTranslator[fieldname] : fieldname;

  var isdate = fieldname.slice(-3);
  // var datetimepicker = (isdate == 'date') ? 'datepicker' : '';
  // datetimepicker = (isdate == 'eta') ? 'datepicker' : datetimepicker;
  var datetimepicker = (isdate == 'date') ? '' : '';
  datetimepicker = (isdate == 'eta') ? '' : datetimepicker;

  // var inputFieldDisplayBtn = (fieldvalue == ''|| fieldvalue == '0000-00-00 00' || fieldvalue == '0000-00-00 00:00:00') ? 'width:100px; float:left; display:inline-block' : 'width:100px; float:left; display:none';
  
 
  var spanCSS = (fieldvalue == '' || fieldvalue == '0000-00-00 00:00:00' || fieldvalue == '0000-00-00 00') ? 'width:100px; float:left; display:inline-block' : 'width:100px; float:left; display:none';
  
  var fieldvalue = (fieldvalue == '' || fieldvalue == '0000-00-00 00:00:00' || fieldvalue == '0000-00-00 00') ? '' : fieldvalue;

  var placeholder = '';
  var btnEnter = (fieldvalue == '') ? '<button type="button" onclick="ERPLIST.viewEntryEditField(this);" style="float:left; display:inline-block" title="">'+ '' + fielddesc +'</button>' : '';
  
  var btnSetEditText = (fieldvalue == '') ? 'Save' : 'edit';
  var btnSetEditClass = (fieldvalue == '') ? '' : 'material-icons';
  var btnSetEditCSS = (fieldvalue == '') ? 'height:25px; float:left; display:none' : 'height:25px; float:left; display:inline-block';
  var btnSetEdit = '<button type="button" onclick="ERPLIST.setEntryEditFieldValue(this ' +","+ '  \'' + dbsetkey + '\');" class="'+ btnSetEditClass +'" style="'+ btnSetEditCSS +'" title="Save">'+ btnSetEditText +'</button>';

  var inputfieldCSS = (fieldvalue == '') ? 'width:100px; float:left; display:none' : 'width:100px; float:left; display:none';

  var entryEditFieldForm = '<form id="entryEditFieldForm">\
  <div style="display:block; max-width:180px;">\
  <span style="float:left; padding-right:5px;">'+ fieldvalue +'</span>\
    <textarea name="'+ fieldname +'" class="'+ datetimepicker +'" style="'+ inputfieldCSS +'" '+ placeholder +' >'+ fieldvalue +'</textarea>\
    '+ btnSetEdit +'\
    '+ btnEnter +'\
  </div>\
  </form>';
  return entryEditFieldForm;
  // var entryEditFieldForm = '<form id="entryEditFieldForm">\
  // <div style="display:block; max-width:180px;">\
  // <span style="float:left; padding-right:5px;">'+ fieldvalue +'</span>\
  //   <input type="text" name="'+ fieldname +'" class="'+ datetimepicker +'" value="'+ fieldvalue +'" style="'+ inputfieldCSS +'" '+ placeholder +' />\
  //   '+ btnSetEdit +'\
  //   '+ btnEnter +'\
  // </div>\
  // </form>';
  // return entryEditFieldForm;
}

ERPLIST.viewEntryEditField = function(thisPtr){
  $(thisPtr).closest('form').find('input, select, textarea, button').css('display', 'inline-block');
  $(thisPtr).closest('form').find('button').text('Save');
  $(thisPtr).css('display', 'none');
}

ERPLIST.setEntryEditFieldValue = function(thisPtr, dbsetkey){
  // toggle action implement here
  if( $(thisPtr).closest('form').find('input, select, textarea').is(":visible") ){
  } else {
    $(thisPtr).closest('form').find('span').css({'float':'none', 'display':'block'});
    $(thisPtr).closest('form').find('input, select, textarea').css('display', 'inline-block');
    $(thisPtr).closest('form').find('button').removeClass('material-icons');
    $(thisPtr).closest('form').find('button').text('Save');
    return;
  }

  var fieldvalue = $(thisPtr).closest('form').find('input, select, textarea').val();
  var fieldname = $(thisPtr).closest('form').find('input, select, textarea').attr('name');
  var ponumber = $(thisPtr).closest('tr').find('td[fieldname=docnumber]').text();
  var rrnumber = $(thisPtr).closest('tr').find('td[fieldname=rrnumber]').text();

  var postparams         = {};
  postparams[fieldname]  = fieldvalue;
  postparams['rrnumber']  = rrnumber;
  postparams['dbsetkey'] = dbsetkey;
  var postData = JSON.stringify(postparams);

  var mType    = 'post';
  var mUrl     = ERPLIST._URL_API;
  var mReqType = "setEntryEditFieldValue";
  var returnData = jsClient.communicationToServer(mReqType, postData, mUrl, mType, false);
  returnData = JSON.parse(returnData);

  if(returnData.result == 'success' || true){
    $(thisPtr).parents('td').find('span').text(fieldvalue);
    $(thisPtr).closest('form').find('span').css({'float':'left', 'display':'block'});
    $(thisPtr).closest('form').find('input, select, textarea').css('display', 'none');
    $(thisPtr).addClass('material-icons');
    $(thisPtr).closest('form').find('button').text('edit');
    ERPLIST.applyEntryEditFieldCSS();

    // show success message
    var cloneDiv = $('#listSuccessDiv').clone();
    cloneDiv.css({'display':'block'})
        .insertBefore('#listSuccessDiv')
        .find('#listSuccessMsg').text('Successfully set ' + fieldname + ' ' + fieldvalue + ' of ' + rrnumber);

  }

}

ERPLIST.applyEntryEditFieldCSS = function(){
  $('.material-icons').css('font-size','20px');
  if( $('#entryEditFieldForm .material-icons').length > 0 ){
  	$('#entryEditFieldForm .material-icons').css({'background':'none', 'border':'none'});
  }
}
// List entry edit field control end ----------------------------------------------------------------------------






ERPLIST.handleLineChooserCheckboxClick = function(thisf){
  var thisrow = $(thisf).closest('tr').attr('data-id');
  var docnumber = $(thisf).closest('tr').find('td[fieldname=docnumber] .ccell3 a').text();
  var rrnumber = $(thisf).closest('tr').find('td[fieldname=rrnumber]').text();
  var tnxqty = $(thisf).closest('tr').find('td[fieldname=tnxqty]').text();
  var iduom = $(thisf).closest('tr').find('td[fieldname=iduom]').text();
  var itemcode = $(thisf).closest('tr').find('td[fieldname=itemcode]').text();

  var chooserType = $(thisf).prop('class');
  if(chooserType == 'multipleLineChooser'){
    // define array
    if(!!!ERPLIST.selectedLineInfo){
      ERPLIST.selectedLineInfo  = {};
      ERPLIST.selectedLineInfo.uniquekey = [];
      ERPLIST.selectedLineInfo.docnumbers = [];
    } 
    if($(thisf).prop('checked')){
      $(thisf).prop('checked', true);
      // push data in array
      ERPLIST.selectedLineInfo.uniquekey.push(thisrow);
      ERPLIST.selectedLineInfo.docnumbers.push(docnumber);

    } else {
      $(thisf).prop('checked', false);
      var index = ERPLIST.selectedLineInfo.uniquekey.indexOf(thisrow);
      // pop data in array
      ERPLIST.selectedLineInfo.uniquekey.splice(index, 1);
      ERPLIST.selectedLineInfo.docnumbers.splice(index, 1);
    }


  } else if (chooserType == 'singleLineChooser'){

    if($(thisf).prop('checked')){
      $('.singleLineChooser').prop('checked', false);
      $(thisf).prop('checked', true);
      // define variable
      if(!!!ERPLIST.docnumber) ERPLIST.docnumber = docnumber;
      if(!!!ERPLIST.rrnumber) ERPLIST.rrnumber = rrnumber;
      if(!!!ERPLIST.itemcode) ERPLIST.itemcode = itemcode;
      if(!!!ERPLIST.tnxqty) ERPLIST.tnxqty = tnxqty;
      if(!!!ERPLIST.iduom) ERPLIST.iduom = iduom;

    } else {
      $(thisf).prop('checked', false);
      delete ERPLIST.docnumber;
      delete ERPLIST.rrnumber;
      delete ERPLIST.itemcode;
      delete ERPLIST.tnxqty;
      delete ERPLIST.iduom;
    }
  }


}





ERPLIST.amendmentRequest = function(){

  if( !!!ERPLIST.docnumber || (ERPLIST.docnumber == '')){
    alert('You need to select at least one item line');
    return;
  }

  ERPLIST.amendmentitemcode = ERPLIST.itemcode;
  ERPLIST.amendmentqty = ERPLIST.tnxqty;

  ERPLIST.getAmendmentInfo(ERPLIST.rrnumber);

  var headTable = '';
  headTable += '<center>';
  headTable += '<table id="headTable" class="noBorder">';
  headTable += '<tr><td>Original Information</td><td>Amendmend Information</td></tr>';
  headTable += '<tr>';
  headTable += '<td class="border">';

  headTable += '<table class="noBorder">';
  headTable += '<tr><td>PO Number</td><td>:</td><td>'+ ERPLIST.docnumber +'</td></tr>';
  headTable += '<tr><td>RR Number</td><td>:</td><td>'+ ERPLIST.rrnumber +'</td></tr>'; 
  headTable += '<tr><td>Itemcode</td><td>:</td><td>'+ ERPLIST.itemcode +'</td></tr>'; 
  headTable += '<tr><td>Quantity</td><td>:</td><td>'+ ERPLIST.tnxqty +'</td></tr>'; 
  headTable += '<tr><td>UoM</td><td>:</td><td>'+ ERPLIST.iduom +'</td></tr>'; 
  headTable += '</table>';

  headTable += '</td>';

  headTable += '<td class="border" >';

  headTable += '<table class="noBorder" id="amendInfo">';
  headTable += '<tr><td>PO Number</td><td>:</td><td>'+ ERPLIST.docnumber +'</td></tr>';
  headTable += '<tr><td>RR Number</td><td>:</td><td>'+ ERPLIST.rrnumber +'</td></tr>'; 
  headTable += '<tr><td>Itemcode</td><td>:</td><td> <input type="text" class="break" name="itemcode" id="itemcode" value="'+ ERPLIST.amendmentitemcode +'" /></td></tr>'; 
  headTable += '<tr><td>Quantity</td><td>:</td><td> <input type="text" name="tnxqty" id="tnxqty" value="'+ ERPLIST.amendmentqty +'" /></td></tr>'; 
  headTable += '<tr><td>UoM</td><td>:</td><td>'+ ERPLIST.iduom +'</td></tr>'; 
  headTable += '</table>';

  headTable += '</td>';

  headTable += '</tr>';

  headTable += '</table>';
  headTable += '</center>';
  headTable += '<br/><br/>';


  var actionButtons = '<br/><br/><center><button type="button" class="" onclick="ERPLIST.amendmentPORequest();"><i class="material-icons">done</i>Confirm</button>';
  actionButtons += '&nbsp;&nbsp;&nbsp<button type="button" class="" onclick="ERPLIST.closeFancybox();"><i class="material-icons">close</i>Cancel</button></center>';

  var content = '<div id="popupSession">\
    <div id="loadingDiv">\
      <center></center>\
    </div>\
    <div id="popupContent" style="padding:10px;" >' + headTable + actionButtons +'</div>\
  </div>';
  content+= ''; // add some js

  $.fancybox({
    type: 'html',
    content: content,
    minWidth: 500,
    minHeight: 300,
    afterLoad: function(){
      this.title = "<b>Amendment Request</b>";
      // $.fancybox.update();
    },    
    afterShow: function() {
      $('table.noBorder').css({'border':'none'});
      $('table.noBorder tr td').css({'border':'none'});
      $('.border').css({'border':'1px solid black'});
      $.fancybox.update();
    },
    helpers: {
     title : {
      type : 'inside',
      position : 'top'
     },
     overlay : {
      css  : {/* 'background-color' : '#fff' */'overflow' : 'hidden'}
     }     
    }  
  });
  jQuery('.fancybox-title').css({'text-align':'center', 'margin-bottom':'10px'});


}


ERPLIST.closeFancybox = function(){
	$.fancybox.close();
}

ERPLIST.amendmentPORequest = function(){
	amendmentitemcode   = $('#amendInfo').find('input#itemcode').val();
	amendmentqty   = $('#amendInfo').find('input#tnxqty').val();

	console.log(amendmentitemcode + " " + amendmentqty);
	var mType    = 'post';
	var mUrl     = ERPLIST._URL_API;
	var mReqType = "sendPOAmtRequest";
	var postData = JSON.stringify({
		amendmentitemcode : amendmentitemcode,
		amendmentqty : amendmentqty,
		ponumber : ERPLIST.docnumber,
		rrnumber : ERPLIST.rrnumber
	});
	var returnData = jsClient.communicationToServer(mReqType, postData, mUrl, mType, false);
	$.fancybox.close();
}


ERPLIST.getAmendmentInfo = function(rrnumber){
	var searchParams = {
		'reqType': 'getAmendmentInfo',
		'rrnumber': rrnumber
	};

	var mType = 'get';
	var mUrl     = ERPLIST._URL_API;
	var mReqType = "";

	var returnData = jsClient.communicationToServer(mReqType, searchParams, mUrl, mType, false);

	console.log(returnData);
	data = JSON.parse(returnData);

	amendmentitemcode = data['amendmentitemcode'];
	amendmentqty = data['amendmentqty'];
	amendmentqty = parseFloat(amendmentqty);

	if(amendmentitemcode != "") ERPLIST.amendmentitemcode = amendmentitemcode;
	if(amendmentqty != 0) ERPLIST.amendmentqty = amendmentqty;

}