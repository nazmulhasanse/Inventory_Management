var ERPLIST = ERPLIST || {};

$.extend(ERPLIST, {
  _ERP_DOCACRONYM: '',
  _FIELDSETS_HEADER: ['fieldset_documentinformation', 'fieldset_logisticsinformation'],
  _FIELDSETS_LINES: ['fieldset_garmentdetails', 'fieldset_quantityandamount'],
  _URL_materiallistidSEARCHPAGE: 'html/materiallistid-search.html',
  _URL_materiallistidSEARCHJS: 'js/materiallistid-search.js', 
  _FIELDS_AUTOFILLUP: ['salesordertype', 'salesorder', 'ldcslnumber', 'buyerpo', 'endcustomer', 'styledescription', 'style', 'packqty', 'pieceperpack', 'pieceqty', 'docdate', 'productcategory', 'developmentcontactperson', 'referenceno', 'referencetype', 'company', 'modificationnote', 'consumptioninstruction'],

  foo: 'here for no reason other than to be the last line, without a comma'
});


ERPLIST.handleLookup = function(thisPtr){
  var fieldname = $(thisPtr).closest('.prCreator tr').find('input, select').prop('name');
  ERPLIST.showLoupeList(fieldname);
}


ERPLIST.showLoupeList =function(targetfieldname){
  // var params = paramsToObj(window.location.search);

   var prepopulate = {};
   ERPLIST.targetfieldname = targetfieldname;
   ERPLIST.descfieldname = 'desc'+targetfieldname;
   if(targetfieldname == 'LotCode'){
     ERPLIST.loupefieldname = 'itemlot';
     ERPLIST.loupedescription = 'itemlot';

   }else if(targetfieldname == 'TemplateCode'){
     ERPLIST.loupefieldname = 'templatecode';
     ERPLIST.loupedescription = 'description';

   }else if(targetfieldname == 'projectcode' || targetfieldname == 'destinationproject'){
     ERPLIST.loupefieldname = 'projectcode';
     ERPLIST.loupedescription = 'projectname';

   }else if(targetfieldname == 'itemtype' || targetfieldname == 'descitemtype'){
     ERPLIST.loupefieldname = 'Code';
     ERPLIST.loupedescription = 'Description';

   }else if(targetfieldname == 'workcenter' || targetfieldname == 'descworkcenter'){
     ERPLIST.loupefieldname = 'Description';
     ERPLIST.loupedescription = 'Description';

   }else if(targetfieldname == 'issuecostcenter'){
     ERPLIST.loupefieldname = 'costcenter';
     ERPLIST.loupedescription = 'costcenter';

   } else{
     ERPLIST.loupefieldname = 'CODE';
     ERPLIST.loupedescription = 'LONGDESCRIPTION';
   }

   if(targetfieldname == 'LocationCode'){
    ERPLIST.loupedescription = 'CODE';
   }
  
  if($('#docHeaderContainer #tbl_2 tbody tr').find('[fieldname=endcustomer]').text().length > 0){
    // prepopulate.endcustomer = $('#docHeaderContainer #tbl_2 tbody tr').find('[fieldname=endcustomer]').text(); 
  }  

  prepopulate.fieldname = targetfieldname;

  var prepopJS = (Object.keys(prepopulate).length > 0) ? 'var prepopulate = ' + JSON.stringify(prepopulate) + ';' : '';
  prepopJS = prepopJS + "var ERPLIST = ERPLIST || {};";
  prepopJS = prepopJS + "$(document).ajaxStop(function() {";

  prepopJS = prepopJS + "ERPLIST.sendBackSearchChoice = function( thisRow ) {";
  prepopJS = prepopJS + "  CODE = $(thisRow).find('td[fieldname=' +ERPLIST.loupefieldname+']').text();";
  prepopJS = prepopJS + "  loupedescription = $(thisRow).find('td[fieldname=' +ERPLIST.loupedescription+']').text();";
  prepopJS = prepopJS + "  $.fancybox.close();";
  prepopJS = prepopJS + "  $('.prCreator tr #' + ERPLIST.targetfieldname).val(CODE);";
  prepopJS = prepopJS + "  $('.prCreator tr td span#' + ERPLIST.descfieldname).text(loupedescription);";
  prepopJS = prepopJS + "  $('.prCreator tr #' + ERPLIST.targetfieldname).focus();";
  prepopJS = prepopJS + "};";  
  prepopJS = prepopJS + "});";

  var content = '<div id="popupListContent">\
    <div id="loadingDiv">\
      <center><img src="/images/loading_spinner.gif"></center>\
    </div>\
  </div>';
  content+= '<script> ' + prepopJS + '</script>'; // add some js

  $.fancybox({
    type: 'html',
    content: content,
    minWidth: 500,
    minHeight: 300,
    afterLoad: function(){
      this.title = "<b>Choose " + prepopulate.fieldname + "</b>";
    },    
    afterShow: function() {
      loadSessionContent();
      $.fancybox.update();
    },
    helpers: {
     title : {
      type : 'inside',
      position : 'top'
     },
     overlay : {
      css  : { /* 'background-color' : '#fff' */}
     }     
    }  
  });
  jQuery('.fancybox-title').css({'text-align':'center', 'margin-bottom':'10px'});

  function loadSessionContent(){
    $.ajax({
      async: false,
      type: 'get',
      url: '/zerp05/pkg/whs/nonposhowloupelist.php',
      success: function(htmlContent) {
        $('#popupListContent').empty().append(htmlContent);
        var searchParams = (Object.keys(prepopulate).length > 0) ? prepopulate : {};
        //                  show,   page,   api_url
        ERPLIST.getListData(20,   1,    ERPLIST._URL_API, searchParams);
        ERPLIST.updateFancyBox();
      }
    }).fail(function(e) {
      alert('Loading failed, please try again.');
    });
  }
}

ERPLIST.updateFancyBox = function(){
  $(document).ajaxStop(function() {
    // place code to be executed on completion of 
    // last outstanding ajax call here
    // this is needed// because ajax call is asyncronus
    $.fancybox.update(); 
  });
}


function OnSubmitForm(){
    var params = paramsToObj(window.location.search);
    var type = params.type;
    var itemtype  = $('#prcreatorform #itemtype').val();
    if(type == 'doc'){
        if(itemtype == 'ELS'){
            document.prcreatorform.action ="/erp-nonpo/erpdocument.php?doctype=PR&formtype=ELS";
        } else if(itemtype == 'CTN'){
            document.prcreatorform.action ="/erp-nonpo/erpdocument.php?doctype=PR&formtype=CTN";
        } else{
            document.prcreatorform.action ="/erp-nonpo/erpdocument.php?doctype=PR&formtype=PR";
        }
        return true;
    } else if(type == 'list'){
        document.prcreatorform.action ="list-rr-po-wo-creation.php?itemtype=" + itemtype;
    } else if(type == 'OStatusReport'){
        document.prcreatorform.action ="/zerp05/pkg/acs/main.php?rAPIFile=zerp05/pkg/acs/ACSOrderStstusList&itemtype=" + itemtype;
    } else if(type == 'TrackingList'){
        document.prcreatorform.action ="/zerp05/pkg/acs/main.php?rAPIFile=zerp05/pkg/acs/TrackingList&itemtype=" + itemtype;
    } else if(type == 'MIPCreationList'){
        document.prcreatorform.action ="/zerp05/pkg/acs/main.php?rAPIFile=zerp05/pkg/acs/ACSTrackingList&itemtype=" + itemtype;
    } else if(type == 'InhouseReport'){
        document.prcreatorform.action ="/zerp05/pkg/acs/main.php?rAPIFile=zerp05/pkg/acs/MIPLineList&itemtype=" + itemtype;
    }
}
