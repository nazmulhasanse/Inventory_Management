/**
 * Declare ERPLIST Namespace if not exist
 */
var ERPLIST = ERPLIST || {};

$.extend(ERPLIST, {
  mUrl: 'api/server_api.php',
  mType: 'get',
  mData: '',
  mAsync: false,
  mReqType: '',
  queryData: '',
  queryParam: '',
  _searchParams: '',
  _URL_API: 'list-pr-project_api.php',

  foo: 'here for no reason other than to be the last line, without a comma'
});



ERPLIST.displayQueryData = function(jsonData){

  var pagination = jsClient.makePagination(jsonData);

  var data = JSON.parse(jsonData);
  var listData = data['listData'];
  var hasData = (data.noResult) ? 'no' : 'yes';
  var listTable = ERPLIST.makeTable(listData, hasData);

  $("#listDiv").html(pagination);
  $("#listDiv").append(listTable);

  ERPLIST.initSearchAction();

  /**
   * Css
   */
  $('#listTable').css({
    'width':'100%'
  });
  $('#listTable tr#searchForm input').css({
    'width':'95%',
    'min-width': '60px',
    'font-family':'Arial',
    'padding':'2px',
    'border':'1px solid #7F7F7F',
    'border-radius':'3px'
  });
  $('#listTable tr#searchForm button').css({
    'padding':'2px',
    'border':'1px solid #7F7F7F',
    'border-radius':'3px',
    'vertical-align': 'middle'
  });  
  $('#listTable .hasCustomSearch').css({
    'width':'70%'
  });
  jsClient.paginationCSS();
  ERPLIST.changeTempleteCSS();

  // Custom CSS if required
  $('#listTable td.lineentrytime').css({
    'white-space':'nowrap'
  });
  // $('#listTable td.itemcode .ccell3 ').css({
  //   'white-space':'nowrap'
  // });
  $('#listTable td.itemdescription').css({
    'min-width':'200px'
  });

  $('.classRed ').css({
    'border-radius':'50%',
    'background-color':'red',
    'border':'none',
    // 'padding-top':'10px'
  });

  $('.classGreen ').css({
    'border-radius':'50%',
    'background-color':'green',
    'border':'none',
    // 'padding-top':'10px'
  });

}



ERPLIST.makeTable = function(mydata,hasData) {
  var $table = $('<table border=1 id="listTable" class="listTable" />');
  var $thead = $('<thead />');
  var $tbody = $('<tbody/>');

  //for composition column
    ERPLIST.compositeColumns = {
  //   rrnumber:{
  //     rrnumber: {
  //       style: 'font-weight:bold; color:blue',
  //       customsearch: false,
  //       composite: false,
  //       end: true
  //     }
  //   },
    
  //   rrstatus:{
  //     rrstatus: {
  //       fielddesc: 'RR Status',
  //       islibrary: true,
  //       datasource: {
  //         0: 'New',
  //         1: 'Allocated',
  //         2: 'Sent for Recalculation',
  //         3: 'PO Created',
  //         4: 'PO Sent (Executed)',
  //         5: 'WO Created',
  //         6: 'WO Sent (Executed)',
  //         7: 'Partially Consumed',
  //         8: 'Consumed',
  //         9: 'Closed',
  //         10: 'Frozen',
  //         11: 'Cancelled'
  //       },  
  //       customsearch: true,
  //       composite: false,
  //       end: true
  //     }
  //   },

  //   parentrrnumber:{
  //     parentrrnumber: {
  //       customsearch: false,
  //       composite: false,
  //       end: true
  //     }
  //   },
    
  //   rrtype:{
  //     rrtype:{
  //       fielddesc: 'RR Type',
  //       style: 'font-weight:bold; color:green',
  //       islibrary: true,
  //       datasource: {
  //         projection: 'Projection',
  //         under_projection: 'Confirmed',
  //         direct: 'Direct'
  //       },
  //       customsearch: true,
  //       composite: false,
  //       end: true
  //     }
  //   },
    
  //   powonumber:{
  //     powonumber:{
  //       fielddesc: 'PO Number',
  //       style: 'font-weight:bold;',
  //       customsearch: true,
  //       composite: false,
  //       end: true
  //     }
  //   },

  //   company:{
  //     company:{
  //       fielddesc: 'Division',
  //       style: 'font-weight:bold; color:green',
  //       islibrary: true,
  //       sql: "SELECT Code AS code, Description AS description FROM mrd_library WHERE LibraryName='company'", 
  //       customsearch: true,
  //       composite: false,
  //       end: true
  //     }
  //   },
    
  //   // customer:{
  //   //   customer:{
  //   //     fielddesc: 'Customer',
  //   //     islibrary: true,
  //   //     sql: "SELECT Code AS code, Description AS description FROM mrd_library WHERE LibraryName='Buyer'", 
  //   //     customsearch: true,
  //   //     composite: false,
  //   //     end: true
  //   //   }
  //   // },

  //   endcustomer:{
  //     endcustomer:{
  //       fielddesc: 'End Customer',
  //       islibrary: true,
  //       sql: "SELECT Code AS code, Description AS description FROM mrd_library WHERE LibraryName='Buyer'", 
  //       customsearch: true,
  //       composite: false,
  //       end: true
  //     }
  //   },

  //   itemtype:{
  //     itemtype: {
  //       customsearch: false,
  //       composite: false,
  //       end: true
  //     }
  //   },

  //   itemcode:{
  //     itemcode: {
  //       customsearch: false,
  //       composite: false,
  //       end: true
  //     }
  //   },
    
  //   itemdescription:{
  //     itemdescription: {
  //       customsearch: false,
  //       composite: false,
  //       end: true
  //     }
  //   },

  //    requiredgrossqty:{
  //     requiredgrossqty: {
  //       customsearch: false,
  //       composite: false,
  //       end: true
  //     }
  //   },    

  //   allocatedqty:{
  //     allocatedqty: {
  //       customsearch: false,
  //       composite: false,
  //       end: true
  //     }
  //   },


  //   actualdeductionqty:{
  //     actualdeductionqty: {
  //       customsearch: false,
  //       composite: false,
  //       end: true
  //     }
  //   },


  //   requirednetqty:{
  //     requirednetqty: {
  //       customsearch: false,
  //       composite: false,
  //       end: true
  //     }
  //   },

    
  //   iduom:{
  //     iduom: {
  //       customsearch: false,
  //       composite: false,
  //       end: true
  //     }
  //   },


  //   fabricinhousedate:{
  //       fabricinhousedate:{
  //       fielddesc: 'Fabric Inhouse Date',
  //       customsearch: true,
  //       composite: false,
  //       type: 'date',
  //       end: true        
  //     }
  //   },
     
  //   sewingstartdate:{
  //       sewingstartdate:{
  //       fielddesc: 'Sewing Start Date',
  //       customsearch: true,
  //       composite: false,
  //       type: 'date',
  //       end: true        
  //     }
  //   },

  //   sewingfinisheddate:{
  //       sewingfinisheddate:{
  //       fielddesc: 'Sewing Finished Date',
  //       customsearch: true,
  //       composite: false,
  //       type: 'date',
  //       end: true        
  //     }
  //   },

  //   sewingperiod:{
  //       sewingperiod:{
  //       fielddesc: 'Sewing Period in days',
  //       customsearch: false,
  //       composite: false,
  //       end: true        
  //     }
  //   },

    
  //   fabricusageperday:{
  //     fabricusageperday: {
  //       customsearch: false,
  //       composite: false,
  //       end: true
  //     }
  //   },
    
  //   processbeforesewing:{
  //     processbeforesewing: {
  //       customsearch: false,
  //       composite: false,
  //       end: true
  //     }
  //   },

  //   processaftersewing:{
  //     processaftersewing: {
  //       customsearch: false,
  //       composite: false,
  //       end: true
  //     }
  //   }

 
  }

  // some trickery for nice formatting
  var params = jsClient.paramsToObj(window.location.search);
  // if(params.rrtype == 'Direct'){
  //   var hideColumns = ['idlines', 'customer', 'doctype','workorderdocnumber','isrrfreezed','parentrrnumber','bomdocnumber','cpdocnumber','salesorder'];
  // }else{
  //   var hideColumns = ['idlines', 'customer', 'doctype','workorderdocnumber','isrrfreezed','bomdocnumber','cpdocnumber','salesorder'];
  // }
  var hideColumns = ['idlines'];
  var translationsHardCode = {};

  
  translationsHardCode.projectcode    = 'Project Code';
  translationsHardCode.projectname    = 'Project Name';
  translationsHardCode.costcenter     = 'Cost Center';
  translationsHardCode.costdepartment = 'Cost Department';

  




  // builds the table header
  var mydata_json = JSON.stringify(mydata);
  var firstRow = mydata[0];

  var firstRowCopy = firstRow;
  var compositeColumnsLength = Object.keys(ERPLIST.compositeColumns).length;
  var countVisibleColumn = 1; // here start from 1 cz first td for option
  /**
   * first header row------------------------------------------------------------------------------------------------------------------------------------------------------------
   */
  var $tr = $("<tr/>");
  // $td = $('<th/>');
  // $td.html('');
  // $td.appendTo($tr);

  // process composite column first if has
  if(compositeColumnsLength > 0){
    $.each(ERPLIST.compositeColumns, function(groupName, groupColumns){
      // hide first
      $.each(groupColumns, function(fieldname, fieldStyle){
        var fielddesc = fieldname;
        $td = $('<th/>');
        if (!!translationsHardCode[fieldname]) fielddesc = translationsHardCode[fieldname];
        $td.html('<center>'+ fielddesc +'</center>');
        $td.css('display','none');
        $td.appendTo($tr);

        delete firstRowCopy[fieldname]; // its already procceed
      });

      $td = $('<th/>');
      $td.attr('class', groupName);
      if ( hideColumns.indexOf(groupName) >= 0 ){ 
        $td.css('display','none'); countVisibleColumn--;
      }else{
        countVisibleColumn++;
      }
      if (!!translationsHardCode[groupName]) groupName = translationsHardCode[groupName];
      $td.html('<center>'+ groupName +'</center>');
      $td.appendTo($tr);
      // countVisibleColumn++;
    });
  }

  // precess rest of columns----------------------------------------------------------------------------------------------
  $.each(firstRowCopy, function (fieldname, fieldvalue) {
    countVisibleColumn++;
    var fielddesc = fieldname;
    $td = $('<th/>');
    if (!!translationsHardCode[fieldname]) fielddesc = translationsHardCode[fieldname];
    $td.html('<center>'+ fielddesc +'</center>');
    if ( hideColumns.indexOf(fieldname) >= 0 ){ $td.css('display','none'); countVisibleColumn--};
    $td.appendTo($tr);
  });
  $tr.appendTo($thead);
  $thead.appendTo($table);
  // end -----------------------------------------------------------------------------------------------------------------


  /**
   * second header row-----------------------------------------------------------------------------------------------------------------------------------------------------------
   */
  var $tr = $("<tr/>").attr("id","searchForm");
  var $td;
  // $td = $('<td/>');
  // $td.html('<center>Option</center>');
  // $td.appendTo($tr);

  if(compositeColumnsLength > 0){
    $.each(ERPLIST.compositeColumns, function(groupName, groupColumns){

      var compositeClass = '';
      $td = $('<td/>');
      $td.attr('class', groupName);
      $.each(groupColumns, function(fieldname, fieldpropties){

        compositeClass +=  ( !!fieldpropties.end) ? fieldname : fieldname + '__';          
        var customsearch_option = ( !!fieldpropties.showsearchimg) ?'<button type="button" onclick="ERPLIST.handleCustomSearch(this);"><img src="img/search_icon.png" alt="" height="15" width="15"></button>': '';
        var customsearch_click  = ( !!fieldpropties.customsearch) ?'onclick="ERPLIST.handleCustomSearch(this);"': 'onclick="ERPLIST.handleThisSearchInputFieldClick(this);"';
        var customsearch_class  = ( !!fieldpropties.customsearch ) ? '  hasCustomSearch' : '';

        var html = '<center><input type="text" name="'+ compositeClass +'" value="" id="'+compositeClass+'" class="'+compositeClass + customsearch_class +'" onclick="ERPLIST.handleCustomSearch(this);" />'+ customsearch_option +'</center><div id="'+compositeClass+'_displaySearchParams" style="background-color:white;"></div>';
        $td.html(html);

        // delete firstRowCopy[fieldname]; // its already procceed
        if(fieldpropties.composite == false) return;
        $td_hide = $('<td/>');
        $td_hide.html('<center><input type="hidden" class="'+ fieldname +'" value="" id="'+fieldname+'" /></center>');
        $td_hide.css('display','none');
        $td_hide.appendTo($tr);

      });
      if ( hideColumns.indexOf(groupName) >= 0 ) $td.css('display','none');
      $td.appendTo($tr);

    });
  }
  // end -----------------------------------------------------------------------------------------------------------------

  // precess rest of columns----------------------------------------------------------------------------------------------
  $.each(firstRowCopy, function (fieldname, fieldvalue) {    
    var fielddesc = fieldname;
    $td = $('<td/>');
    $td.attr('class', fieldname);
    $td.html('<center><input type="text"  name="'+ fieldname +'" class="'+ fieldname +'" value="" id="'+fieldname+'" onclick="ERPLIST.handleThisSearchInputFieldClick(this);" /></center><div id="'+fieldname+'_displaySearchParams" style="background-color:white;"></div>');
    if ( hideColumns.indexOf(fieldname) >= 0 ) $td.css('display','none');
    $td.appendTo($tr);
  });
  $tr.appendTo($thead);
  $thead.appendTo($table);
  // end -----------------------------------------------------------------------------------------------------------------
  /**
   * second header row end -----------------------------------------------------------------------------------------------------------------------------------------------------------
   */

  if(hasData == 'no'){
    $thead.appendTo($table);
    //custom for no record found
    var $tr = $("<tr/>");
    // var numberOfColumn = $("#listTable > thead > tr:first > th:visible").length;
    var $td = $('<td/>').attr("colspan",countVisibleColumn);
    $td.html('No Data Found')
      .css({'text-align':'center','vertical-align':'middle'});
    $td.appendTo($tr);
    $tr.appendTo($table);
    return $table;
  }

  /**
   * populates with data--------------------------------------------------------------------------------------------------------------------------------------------------
   */
  var mydata = JSON.parse(mydata_json);
  $.each(mydata, function (index, value) {
    var $tr = $("<tr/>"); // it should be in here

    var thisRow = value;
    var thisRowCopy = thisRow;
    var thisRowCopy_Json =  JSON.stringify(thisRow);

    var formtype = thisRow['formtype'];
    var linestatus = thisRow['linestatus'];
    var isrrfreezed = thisRow['isrrfreezed'];

    // generate button if needed
    // var btnLineChooser = '<center><input type="checkbox" class="multipleLineChooser" onclick="ERPLIST.handleLineChooserCheckboxClick(this);" ></center>';
    var thisLineActionBtn = '';
    if(isrrfreezed != '0'){
      thisLineActionBtn = '<center><input type="checkbox" class="multipleLineChooser" onclick="ERPLIST.handleLineChooserCheckboxClick(this);" ></center>';
      thisLineActionBtn += '<center><input type="button" class="classRed"></center>';
    } else{
      thisLineActionBtn = '<center><input type="checkbox" class="multipleLineChooser" onclick="ERPLIST.handleLineChooserCheckboxClick(this);" ></center>';
    }
    // $td = $('<td/>');
    // $td.html(thisLineActionBtn);
    // $td.appendTo($tr);

    // process composite column first if has----------------------------------------------------------------------------------
    if(compositeColumnsLength > 0){
      $.each(ERPLIST.compositeColumns, function(groupName, groupColumns){
        $td = $('<td/>');
        $td.attr('class', groupName);
        $td.attr('fieldname', groupName);
        var compositeColumnsHTML = '';
        var divRow = '';
        $.each(groupColumns, function(fieldname, fieldprop){

          var fieldvalue = thisRow[fieldname];
          var fielddesc = (!!fieldprop.fielddesc) ? fieldprop.fielddesc : fieldname;
          var style = ( !!fieldprop.style ) ? 'style="' + fieldprop.style + '"': '';

          // *** write custom code here

          var obj_thisRowCopy_Json =  JSON.parse(thisRowCopy_Json);
          fieldvalue = (fieldname == "docnumber") ? "<a href='erpdocument.php?docnumber="+fieldvalue+"&doctype=T7&formtype="+formtype+"' target='_blank''>"+fieldvalue+"</a>" : fieldvalue;
          fieldvalue = (fieldname == "powonumber") ? "<a href='erpdocument.php?docnumber="+fieldvalue+"&doctype=PO&formtype="+'formtype'+"' target='_blank''>"+fieldvalue+"</a>" : fieldvalue;
          
          // *** custom code end

          divRow += '<div class="crow" '+ '' +'>';
          if( !!fieldprop.composite ){
            divRow += '<div class="ccell1 '+ fieldname +'" '+ style +'>'+ fielddesc +'</div>';
            divRow += '<div class="ccell2 '+ fieldname +'">:</div>';
          }
          divRow += '<div class="ccell3 '+ fieldname +'_ccell3" '+ style +'>'+ fieldvalue +'</div>';
          divRow += "</div>";

          delete thisRowCopy[fieldname]; // its already procceed
          if(fieldprop.composite == false) return;
          $td_hide = $('<td/>');
          $td_hide.html(fieldvalue);
          $td_hide.attr("fieldname",fieldname);
          $td_hide.css('display','none');
          $td_hide.appendTo($tr);

        });

        var divTable = "<div id='ctable'>"; 
        divTable += divRow;  
        divTable += "</div>"; 

        compositeColumnsHTML = divTable;
        $td.html(compositeColumnsHTML)
          .css("cursor","pointer")
          .css("white-space","pre-wrap")
          .hover(
               function(){bgOn = $(this).closest("tr").css("background-color"); $(this).closest("tr").css("background-color", "lightblue");},
               function(){$(this).closest("tr").css("background-color", bgOn);}
             );
        if ( hideColumns.indexOf(groupName) >= 0 ) $td.css('display','none');  
        $td.appendTo($tr);

      });
    }
    // end -----------------------------------------------------------------------------------------------------------------

    // precess rest of columns----------------------------------------------------------------------------------------------
    $.each(thisRowCopy, function (fieldname, fieldvalue) {

      // *** write custom code here
      fieldvalue = (fieldname == "docnumber") ? "<a href='erpdocument.php?docnumber="+fieldvalue+"&doctype=DR&formtype="+formtype+"&docviewflag=apparel' target='_blank''>"+fieldvalue+"</a>" : fieldvalue;
      // *** custom code end

      $td = $('<td/>');
        $td.html(fieldvalue)
          .css("white-space","pre-wrap")
          .attr("fieldname",fieldname)
          .css("cursor","pointer")
          .hover(
               function(){bgOn = $(this).closest("tr").css("background-color"); $(this).closest("tr").css("background-color", "lightblue");},
               function(){$(this).closest("tr").css("background-color", bgOn);}
             );
        if ( hideColumns.indexOf(fieldname) >= 0 ) $td.css('display','none');
        $td.appendTo($tr);
    });


    // *** custom code start-----------------------------------------------------------------------------------------
    // $tr.find('td.requiredinformation').append(thisLineActionBtn);
    // *** custom code end-------------------------------------------------------------------------------------------


    $tr.click( function() { 
        // sendBackSearchChoice($(this));
        ERPLIST.sendBackSearchChoice($(this));
      })
      .appendTo($tbody);
  });

  $thead.appendTo($table)
  $tbody.appendTo($table)

  return $table;
};





/**
* Custom table generate code------------------------------------------------------------------------------------------------------
*/

ERPLIST.handleLineChooserCheckboxClick = function(thisf){
  var thisrow = $(thisf).parent().parent().parent().index();
  var idlines = $(thisf).closest('tr').find('td[fieldname=idlines]').text();
  var salesorder = $(thisf).closest('tr').find('td[fieldname=salesorder]').text();
  var rrnumber = $(thisf).closest('tr').find('td[fieldname=rrnumber]').text();
  var rrtype = $(thisf).closest('tr').find('td[fieldname=rrtype]').text();
  var rrstatus = $(thisf).closest('tr').find('td[fieldname=rrstatus]').text();
  var itemcode = $(thisf).closest('tr').find('td[fieldname=itemcode]').text();
  var ldcslnumber = $(thisf).closest('tr').find('td[fieldname=ldcslnumber]').text();
  var isrrfreezed = $(thisf).closest('tr').find('td[fieldname=isrrfreezed]').text();
  var company = $(thisf).closest('tr').find('td[fieldname=company]').text();
  var endcustomer = $(thisf).closest('tr').find('td[fieldname=endcustomer]').text();

  var chooserType = $(thisf).prop('class');
  if(!!!ERPLIST.selectedLineInfo){
    ERPLIST.selectedLineInfo  = {};
    ERPLIST.selectedLineInfo.uniquekey = [];
    ERPLIST.selectedLineInfo.idlines = [];
    ERPLIST.selectedLineInfo.salesorder = [];
    ERPLIST.selectedLineInfo.rrnumber = [];
    ERPLIST.selectedLineInfo.rrtype = [];
    ERPLIST.selectedLineInfo.rrstatus = [];
    ERPLIST.selectedLineInfo.itemcode = [];
    ERPLIST.selectedLineInfo.ldcslnumber = [];
    ERPLIST.selectedLineInfo.isrrfreezed = [];
    ERPLIST.selectedLineInfo.company = [];
    ERPLIST.selectedLineInfo.endcustomer = [];
  } 

  //if confirmed then check its blanket po exist or not
  if(rrtype == 'Confirmed'){
  }
  
  if($(thisf).prop('checked')){
    $(thisf).prop('checked', true);
    // push data in array
    ERPLIST.selectedLineInfo.uniquekey.push(thisrow);
    ERPLIST.selectedLineInfo.idlines.push(idlines);
    ERPLIST.selectedLineInfo.salesorder.push(salesorder);
    ERPLIST.selectedLineInfo.rrnumber.push(rrnumber);
    ERPLIST.selectedLineInfo.rrtype.push(rrtype);
    ERPLIST.selectedLineInfo.rrstatus.push(rrstatus);
    ERPLIST.selectedLineInfo.itemcode.push(itemcode);
    ERPLIST.selectedLineInfo.ldcslnumber.push(ldcslnumber);
    ERPLIST.selectedLineInfo.isrrfreezed.push(isrrfreezed);
    ERPLIST.selectedLineInfo.company.push(company);
    ERPLIST.selectedLineInfo.endcustomer.push(endcustomer);

  } else {
    $(thisf).prop('checked', false);
    var index = ERPLIST.selectedLineInfo.rrnumber.indexOf(rrnumber);
    // pop data in array
    ERPLIST.selectedLineInfo.uniquekey.splice(index, 1);
    ERPLIST.selectedLineInfo.idlines.splice(index, 1);
    ERPLIST.selectedLineInfo.salesorder.splice(index, 1);
    ERPLIST.selectedLineInfo.rrnumber.splice(index, 1);
    ERPLIST.selectedLineInfo.rrtype.splice(index, 1);
    ERPLIST.selectedLineInfo.rrstatus.splice(index, 1);
    ERPLIST.selectedLineInfo.itemcode.splice(index, 1);
    ERPLIST.selectedLineInfo.ldcslnumber.splice(index, 1);
    ERPLIST.selectedLineInfo.isrrfreezed.splice(index, 1);
    ERPLIST.selectedLineInfo.company.splice(index, 1);
    ERPLIST.selectedLineInfo.endcustomer.splice(index, 1);
  }

  var arrayLength = ERPLIST.selectedLineInfo.salesorder.length;
  console.log(arrayLength);
  if(arrayLength > 0 ){
    var rrtypeChk  = ERPLIST.selectedLineInfo.rrtype[0];
    var companyChk  = ERPLIST.selectedLineInfo.company[0];
    var endcustomerChk  = ERPLIST.selectedLineInfo.endcustomer[0];
    var blanketpoChk  = ERPLIST.selectedLineInfo.blanketpo[0];
    if(rrtypeChk != rrtype || companyChk != company || endcustomerChk != endcustomer ){
      var index = ERPLIST.selectedLineInfo.rrnumber.indexOf(rrnumber);
      // pop data in array
      ERPLIST.selectedLineInfo.uniquekey.splice(index, 1);
      ERPLIST.selectedLineInfo.idlines.splice(index, 1);
      ERPLIST.selectedLineInfo.salesorder.splice(index, 1);
      ERPLIST.selectedLineInfo.rrnumber.splice(index, 1);
      ERPLIST.selectedLineInfo.rrtype.splice(index, 1);
      ERPLIST.selectedLineInfo.rrstatus.splice(index, 1);
      ERPLIST.selectedLineInfo.itemcode.splice(index, 1);
      ERPLIST.selectedLineInfo.ldcslnumber.splice(index, 1);
      ERPLIST.selectedLineInfo.isrrfreezed.splice(index, 1);
      ERPLIST.selectedLineInfo.company.splice(index, 1);
      ERPLIST.selectedLineInfo.endcustomer.splice(index, 1);

      $(thisf).prop('checked', false);

      
      alert("RR Type, Division & End Customer need to be same.");
      return;
    }

    
  }  


    // console.log(JSON.stringify(ERPLIST.selectedLineInfo));
}


ERPLIST.getBlanketPO = function(rrnumber){

  var searchParams = {
    'reqType': 'getBlanketPO',
    'rrnumber': rrnumber
  };

  var mType = 'get';
  var mUrl     = "list-pocreation-rr-lines_api.php";
  var mReqType = "";

  var returnData = jsClient.communicationToServer(mReqType, searchParams, mUrl, mType, false);

  if (returnData.length > 0) {

    data = JSON.parse(returnData);
    blanketpo = data[0]['powonumber'];

    return blanketpo;
  }

}



ERPLIST.cancel = function(){

  var idlines = ERPLIST.selectedLineInfo.idlines;

  var r = confirm(ERPLIST.selectedLineInfo.rrnumber + ' will be gone to Allocated RR list');
  if(!r) return;


  var mType    = 'post';
  var mUrl     = ERPLIST._URL_API;
  var mReqType = "sendtoAllocatedRR";
  var postData = JSON.stringify({
    idlines  : ERPLIST.selectedLineInfo.idlines 
  });
  var returnData = jsClient.communicationToServer(mReqType, postData, mUrl, mType, false);

  returnData = JSON.parse(returnData);
  console.log(returnData.result);

  if(returnData.result == 'success'){
    ERPLIST.getListData(10,   1);
    var msgString  = 'success:: Successfully '+ ERPLIST.selectedLineInfo.rrnumber +' lines cancel for PO creation.';
    jsClient.msgDisplayer(msgString); // green
    delete(ERPLIST.selectedLineInfo);
  }  


}

ERPLIST.createInternalPO = function(){
  if(ERPLIST.selectedLineInfo.idlines.length == 0){
    alert('You need to select atleast one RR line');
    return;
  }

  length = ERPLIST.selectedLineInfo.rrstatus.length;
  arrayRRStatus = ERPLIST.selectedLineInfo.rrstatus;
  for(i=0 ; i < length ; i++){
    //check rr status is po created 
    if(arrayRRStatus[i] == 'PO Created'){
      alert('PO has already been created.');
      return;
    }
  }

  //check all rr are checked for same itemcode and ldcslnumber
  var mType    = 'post';
  var mUrl     = ERPLIST._URL_API;
  var mReqType = "isAllRRCheckedInSameItemcodeAndSOLine";
  var postData = JSON.stringify({
    rrlines  : ERPLIST.selectedLineInfo
  });
  var returnData = jsClient.communicationToServer(mReqType, postData, mUrl, mType, false);

  returnData = JSON.parse(returnData);
  console.log(returnData.result);

  if(returnData.result == 'success'){
  }else{
    var message = "You have to\n";
    length = returnData.rr.length;
    for(i = 0 ; i < length ; i++){
      message += "Select "+ returnData.rr[i] + " for Item code : " + returnData.itemcode[i] + " And SO Item Line No : "+ returnData.ldcslnumber[i] + "\n";
    }
    alert( message+ "For Create Internal Fabric PO" );
    return;
  } 


  var next_href = '/erp-apparel/erpdocument.php?doctype=PO&formtype='+ERPLIST.selectedLineInfo.rrtype[0]+'&idlines=' + ERPLIST.selectedLineInfo.idlines;
  window.location = next_href;
}




/**
* Custom function code------------------------------------------------------------------------------------------------------
*/
ERPLIST.customFunction1 = function(argument) {
}

ERPLIST.acknowledgeCancellation = function() {

  if(!!!ERPLIST.selectedLineInfo){
    alert("You have to select One or More RR Line");
    return;
  }

  if(ERPLIST.selectedLineInfo.idlines.length =='0'){
    alert("You have to select One or More RR Line");
    return;
  }

  var selectedLineInfo = ERPLIST.selectedLineInfo;
  var isrrfreezed = selectedLineInfo.isrrfreezed;

  if(isrrfreezed =='0'){
    alert("There have no request for Acknowledge Cancellation.");
    return;
  }


  //Start confirm dialog PopUp
  $('<div id="jQueryUIDialogDiv"></div>').dialog({
     width: 500,
      modal: true,
      title: "RR Modification/Cancellation",
      open: function () {
          var markup = "Are you sure, you want to Acknowledge the Cancellation?";
          $(this).html(markup);
      },
      buttons: {
          "Yes": function () {
              ERPLIST.approveacknowledgeCancellation();
          },
          No: function () {
              $(this).dialog("close");
          }
      }
  }); //end confirm dialog PopUp
}

ERPLIST.approveacknowledgeCancellation = function() {
  var selectedLineInfo = ERPLIST.selectedLineInfo;
  var idliness = selectedLineInfo.idlines;
  var rrnumber = selectedLineInfo.rrnumber;
  var isrrfreezed = selectedLineInfo.isrrfreezed[0];
  var reqType = '';
  if(isrrfreezed == '1'){
    var _url = 'docso_api.php';
    var reqType = 'modifyCancelAcknowledged_salesOrder';
  } else if(isrrfreezed == '2'){
    var _url = 'doccp_api.php';
    var reqType = 'modifyCancelAcknowledged_CapacityPlan';
  } else if(isrrfreezed == '3'){
    var _url = 'docbom_api.php';
    var reqType = 'modifyCancelAcknowledged_BOM';
  } else if(isrrfreezed == '4'){
    var _url = 'docfm_api.php';
    var reqType = 'modifyCancelAcknowledged_MaterialLine';
  } else if(isrrfreezed == '5'){
    var _url = 'docfm_api.php';
    var reqType = 'modifyCancelAcknowledged_MaterialListDoc';
  }


  var postData = {
    reqType: reqType,
    docnumber: JSON.stringify(idliness),
    fromWchich: 'RR'
   };
  $.ajax({
    type: 'post',
    url: _url,
    data: postData,
    success: function(data) {
        data = JSON.parse(data);
        if (!!data.errormsgs && data.errormsgs.length > 0) {
          console.log(data.errormsgs.join('\n'));
          alert("===>"+data.errormsgs.join('\n'));
        } else {
           ERPLIST.getListData(10,    1);
           delete ERPLIST.selectedLineInfo;
          jQuery('#jQueryUIDialogDiv').dialog('close');
          $('body').find('#jQueryUIDialogDiv').remove();

          var cloneDiv = $('#listSuccessDiv').clone();
          cloneDiv.css({'display':'block'})
          .insertBefore('#listSuccessDiv')
          .find('#listSuccessMsg').text(rrnumber +' Acknowledge Cancellation is success');
        }
    }
  }).fail(function(e) {
    alert('Assign failed, please try again.');
  });
}
