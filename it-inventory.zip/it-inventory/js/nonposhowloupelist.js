/**
 * Declare ERPLIST Namespace if not exist
 */
var ERPLIST = ERPLIST || {};

$.extend(ERPLIST, {
  mUrl: 'api/server_api.php',
  mType: 'get',
  mData: '',
  mAsync: false,
  mReqType: '',
  queryData: '',
  queryParam: '',
  _searchParams: '',
  _URL_API: 'nonposhowloupelist_api.php',

  foo: 'here for no reason other than to be the last line, without a comma'
});



/**
 * [getSearchData description]
 * @return {[type]} [description]
 */
ERPLIST.getSearchData = function(){
  var searchParams = {};
  $('table#listTable_session thead tr#searchForm').each(function() {
      $(this).find("td input:text,select").each(function() {
          textVal = this.value.trim();
          inputName = $(this).attr("name");
          tagName = $(this).prop("tagName");

          // if inputName is undefined then assume its combobox 
          if(inputName == undefined) return;
          // try to retrive name by closest select tag
          if(!!ERPLIST.libraryColumns[inputName]){
            // if(tagName == "SELECT") return;
            // $('table#listTable thead tr#searchForm td.'+ inputName +' select option').each(function() {
              // console.log(this.text + '---to----' + textVal);
              // if(this.text == textVal){
              //  textVal = this.value;
              // }
           // });
              if(textVal == '______'){ // define for empty
                textVal = "";
              }
          }

          if(textVal != ""){
            searchParams[inputName] = textVal;
          }            
      });
  });

  ERPLIST._searchParams = JSON.stringify(searchParams);
  //                  show,   page,   api_url search_param
  ERPLIST.getListData(50,   1,    '',   searchParams);
}


ERPLIST.displayQueryData = function(jsonData){

  var pagination = jsClient.makePagination(jsonData)

  var data = JSON.parse(jsonData);
  var hasData = (data.noResult) ? 'no' : 'yes';
  var listTable = ERPLIST.makeTable(jsonData, hasData);

  $("#loupelistDiv").html(pagination);
  $("#loupelistDiv").append(listTable);

  ERPLIST.initSearchAction();

  /**
   * Css
   */
  $('#listTable_session').css({
    'width':'100%'
  });
  $('#listTable_session tr#searchForm button').css({
    'padding':'2px',
    'border':'1px solid #7F7F7F',
    'border-radius':'3px',
    'vertical-align': 'middle'
  });  
  $('#listTable_session .hasCustomSearch').css({
    'width':'70%'
  });
  jsClient.paginationCSS();
  ERPLIST.applyCustomListCSS();
  ERPLIST.changeTempleteCSS();

  ERPLIST.initList();

}


ERPLIST.applyCustomListCSS = function(){
  $('#listTable_session tr#searchForm input').css({
    'width':'95%',
    'min-width': '80px',
    'font-family':'Arial',
    'padding':'2px',
    'border':'1px solid #7F7F7F',
    'border-radius':'3px'
  });
  // Custom CSS if required
  $('#listTable_session thead th').css({
    'background-color' : '#f1f1f1'
  });   

  $('#listTable_session th').css({
    'font-size': '9pt',
    'font-weight': 'normal',
    'color': '#555555',
    'border': '1px solid #ddd',
    'padding'        : '3px',
    'text-align'     : 'left',
    'vertical-align' : 'top',
  });

  $('#listTable_session td').css({
    'border': '1px solid #ddd',
    'padding'        : '3px',
    'text-align'     : 'left',
    'vertical-align' : 'top',
  });   

  $('#listTable_session>tbody>tr>td').css({
    'padding': '8px',
    'line-height': '1.42857143',
    'vertical-align': 'top',
    'border-top': '1px solid #ddd',
  }); 


}

ERPLIST.makeTable = function(jsonData,hasData) {
  console.log(jsonData);
  var data   = JSON.parse(jsonData);
  var mydata = data['listData'];
  var pageNum      = parseInt(data['pageNum']-1);
  var showLimit    = parseInt(data['showLimit']);
  var trDataId = parseInt(pageNum * showLimit) + 1;
  // console.log(pageNum + '  ' +showLimit);

  var $table = $('<table border=1 id="listTable_session" class="listTable_session" />');
  var $thead = $('<thead />');
  var $tbody = $('<tbody/>');

  //for composition column
  ERPLIST.compositeColumns = { 
    itemtype: {
      itemtype:{
        fielddesc: 'Item Type',
        islibrary: true,
        datasource: {
          'Knitted Finished Fabric': 'Knitted Finished Fabric', 
          'Knitted Greige Fabric': 'Knitted Greige Fabric', 
          'Yarn': 'Yarn',
          'Dyed Yarn': 'Dyed Yarn', 
        }, 
        // sql: "SELECT Description AS code, Description AS description FROM mrd_library WHERE LibraryName='itemtype_textile'", 
        customsearch: true,
        single: true,
        showsearchimg: false,
        end: true
      }
    },        
  }

  // some trickery for nice formatting
  var hideColumns = ['idlines'];

  var translationsHardCode = {};
  translationsHardCode.iduom = 'UoM';

  ERPLIST.translationsHardCode = translationsHardCode;


  /**
   * builds the table header
   */
  var mydata_json = JSON.stringify(mydata);
  var firstRow = mydata[0];

  var firstRowCopy = firstRow;
  var compositeColumnsLength = Object.keys(ERPLIST.compositeColumns).length;
  var countVisibleColumn = 1; // here start from 1 cz first td for option


  var $table = $('<table border=1 id="listTable_session" class="listTable_session" />');
  var $thead = $('<thead />');
  var $tbody = $('<tbody/>');
  /**
  * first header row------------------------------------------------------------------------------------------------------------------------------------------------------------
  */
  // var $tr = ERPLIST.generateFirstHeaderTr(firstRowCopy, translationsHardCode);
  var $tr = $("<tr/>");
  $td = $('<th/>');
  // $td.html('');
  // $td.appendTo($tr);

    $.each(firstRowCopy, function (fieldname, fieldvalue) {
    // for (var fieldname in firstRowCopy) {
      // var fieldvalue = firstRowCopy[fieldname];
      
      // search this field is in composite column
      // and assume that its not under in composite colums
      var groupName = '';
      var groupFields = {};
      var hasInCompositeColumn = false;
      if(compositeColumnsLength > 0){
        for (var groupName in ERPLIST.compositeColumns) {
          groupFields = ERPLIST.compositeColumns[groupName];
          for (var thisfieldname in groupFields) {
            if(thisfieldname == fieldname){
              hasInCompositeColumn = true;
              break;
            }
          }
          if(hasInCompositeColumn) break;
        }
      }

      // if have then procceed composite column
      if (hasInCompositeColumn) {
      // hide first
      $.each(groupFields, function(fieldname, fieldStyle){
        var fielddesc = fieldname;
        $td = $('<th/>');
        if (!!translationsHardCode[fieldname]) fielddesc = translationsHardCode[fieldname];
        $td.html('<center>'+ fielddesc +'</center>');
        $td.css('display','none');
        $td.appendTo($tr);

        delete firstRowCopy[fieldname]; // its already procceed
      });

      $td = $('<th/>');
      $td.attr('class', groupName);
      if (!!translationsHardCode[groupName]) groupName = translationsHardCode[groupName];
      $td.html('<center>'+ groupName +'</center>');
      $td.appendTo($tr);
      countVisibleColumn++;

      } else {

      countVisibleColumn++;
      var fielddesc = fieldname;
      $td = $('<th/>');
      if (!!translationsHardCode[fieldname]) fielddesc = translationsHardCode[fieldname];
      $td.html('<center>'+ fielddesc +'</center>');
      if ( hideColumns.indexOf(fieldname) >= 0 ){ $td.css('display','none'); countVisibleColumn--};
      $td.appendTo($tr);

      }

    // }  
    });
  $tr.appendTo($thead);
  $thead.appendTo($table);
  // end -----------------------------------------------------------------------------------------------------------------


  /**
  * second header row-----------------------------------------------------------------------------------------------------------------------------------------------------------
  */
  var $tr = $("<tr/>").attr("id","searchForm");
  var $td;
  $td = $('<td/>');
  // $td.html('<center>Acknowledgement</center>');
  // $td.appendTo($tr);

  var firstRowCopy = JSON.parse(mydata_json)[0];
    $.each(firstRowCopy, function (fieldname, fieldvalue) {
    // for (var fieldname in firstRowCopy) {
      // var fieldvalue = firstRowCopy[fieldname];
      
      // search this field is in composite column
      // and assume that its not under in composite colums
      var groupName = '';
      var groupFields = {};
      var hasInCompositeColumn = false;
      if(compositeColumnsLength > 0){
        for (var groupName in ERPLIST.compositeColumns) {
          groupFields = ERPLIST.compositeColumns[groupName];
          for (var thisfieldname in groupFields) {
            if(thisfieldname == fieldname){
              hasInCompositeColumn = true;
              break;
            }
          }
          if(hasInCompositeColumn) break;
        }
      }

      // if have then procceed composite column
      if (hasInCompositeColumn) {   
      var compositeClass = '';
      $td = $('<td/>');
      $td.attr('class', groupName);
      $.each(groupFields, function(fieldname, fieldpropties){

        compositeClass +=  ( !!fieldpropties.end) ? fieldname : fieldname + '__';          
        var customsearch_option = ( !!fieldpropties.showsearchimg) ?'<button type="button" onclick="ERPLIST.handleCustomSearch(this);"><img src="img/search_icon.png" alt="" height="15" width="15"></button>': '';
        var customsearch_click  = ( !!fieldpropties.customsearch) ?'onclick="ERPLIST.handleCustomSearch(this);"': 'onclick="ERPLIST.handleThisSearchInputFieldClick(this);"';
        var customsearch_class  = ( !!fieldpropties.customsearch ) ? '  hasCustomSearch' : '';

        var html = '<center><input type="text" name="'+ compositeClass +'" value="" id="'+compositeClass+'" class="'+compositeClass + customsearch_class +'" '+ customsearch_click +' />'+ customsearch_option +'</center><div id="'+compositeClass+'_displaySearchParams" style="background-color:white;"></div>';
        $td.html(html);

        delete firstRowCopy[fieldname]; // its already procceed
        if(!!fieldpropties.single && fieldpropties.single == true) return; // need to make one td in list
        $td_hide = $('<td/>');
        $td_hide.html('<center><input type="hidden" class="'+ fieldname +'" value="" id="'+fieldname+'" /></center>');
        $td_hide.css('display','none');
        $td_hide.appendTo($tr);

      });
      $td.appendTo($tr);    

      } else {

      var fielddesc = fieldname;
      $td = $('<td/>');
      $td.attr('class', fieldname);
      $td.html('<center><input type="text"  name="'+ fieldname +'" class="'+ fieldname +'" value="" id="'+fieldname+'" onclick="ERPLIST.handleThisSearchInputFieldClick(this);" /></center><div id="'+fieldname+'_displaySearchParams" style="background-color:white;"></div>');
      if ( hideColumns.indexOf(fieldname) >= 0 ) $td.css('display','none');
      $td.appendTo($tr);

      }

    // }  
    });
  
  $tr.find('td.numberoflines').html('');
  $tr.find('td.itemdescription').html('');

  $tr.appendTo($thead);
  $thead.appendTo($table);
  /**
  * second header row end -----------------------------------------------------------------------------------------------------------------------------------------------------------
  */


  if(hasData == 'no'){
    $thead.appendTo($table);
    //custom for no record found
    var $tr = $("<tr/>");
    var $td = $('<td/>').attr("colspan",countVisibleColumn);
    $td.html('No Data Found')
    .css({'text-align':'center','vertical-align':'middle'});
    $td.appendTo($tr);
    $tr.appendTo($table);
    return $table;
  }


  /**
  * populates with data--------------------------------------------------------------------------------------------------------------------------------------------------
  */
  var mydata = JSON.parse(mydata_json);
  $.each(mydata, function (index, value) {

    var $tr = $("<tr/>"); // it should be in here
    $tr.attr("data-id",trDataId);
    trDataId++;

    var thisRow = value;
    var thisRowCopy = thisRow;
    var thisRowCopy_Json =  JSON.stringify(thisRow);

    // retrive variable here which is needed
    var formtype = thisRow['formtype'];
    var docstatus = thisRow['docstatus'];

    var linestatus = thisRow['linestatus'];

    var pricedelivered  = thisRow['pricedelivered'];
    var priceacceped    = thisRow['priceacceped'];
    var pricenotacceped = thisRow['pricenotacceped'];
    var pricecancel     = thisRow['pricecancel'];

    // generate button if needed
    var thisLineActionBtn = '';
    if((!!pricedelivered && pricedelivered != "0") ||(!!priceacceped && priceacceped != "0") || (!!pricenotacceped && pricenotacceped != "0")){ 
      thisLineActionBtn = '<button onclick="ERPLIST.markAsRead(this)" style="width:70pt;">Mark as Read</button>';
      $tr.css({"background-color":"yellow"});
    }
    if(!!pricecancel && pricecancel != "0"){
      thisLineActionBtn = '<button onclick="ERPLIST.markAsRead(this)" style="width:105pt;">Cancel Acknowledgement</button>';
      $tr.css({"background-color":"yellow"});
    }


    $td = $('<td/>');
    // $td.html(thisLineActionBtn);
    // $td.appendTo($tr);


      // looping over this row
      $.each(thisRow, function (fieldname, fieldvalue) {
      // for (var fieldname in firstRowCopy) {
        // var fieldvalue = firstRowCopy[fieldname];
        
        // search this field is in composite column
        // and assume that its not under in composite colums
        var groupName = '';
        var groupFields = {};
        var hasInCompositeColumn = false;
        if(compositeColumnsLength > 0){
          for (var groupName in ERPLIST.compositeColumns) {
            groupFields = ERPLIST.compositeColumns[groupName];
            for (var thisfieldname in groupFields) {
              if(thisfieldname == fieldname){
                hasInCompositeColumn = true;
                break;
              }
            }
            if(hasInCompositeColumn) break;
          }
        }

        // if have then procceed composite column
        if (hasInCompositeColumn) {

        $td = $('<td/>');
        $td.attr('class', groupName);
        $td.attr('fieldname', groupName);
        var compositeColumnsHTML = '';
        var divRow = '';
        $.each(groupFields, function(fieldname, fieldpropties){

          var fieldvalue = thisRow[fieldname];
          var fielddesc = (!!fieldpropties.fielddesc) ? fieldpropties.fielddesc : fieldname;
          var style = ( !!fieldpropties.style ) ? 'style="' + fieldpropties.style + '"': '';

          // *** write custom code here ---

          var obj_thisRowCopy_Json =  JSON.parse(thisRowCopy_Json);
          fieldvalue = (fieldname == "docnumber") ? "<a href='erpdocument.php?docnumber="+fieldvalue+"&doctype=IR&formtype=default' target='_blank'>"+fieldvalue+"</a>" : fieldvalue;
          fieldvalue = (fieldname == "requestdocnumber") ? "<a href='erpdocument.php?docnumber="+fieldvalue+"&doctype=DR&formtype=SF&docviewflag=apparel' target='_blank'>"+fieldvalue+"</a>" : fieldvalue;

          // *** custom code end ----------

          divRow += '<div class="crow" '+ '' +'>';
          if( (!!!fieldpropties.single) || (!!fieldpropties.single && fieldpropties.single == false) ){
            divRow += '<div class="ccell1 '+ fieldname +'" '+ style +'>'+ fielddesc +'</div>';
            divRow += '<div class="ccell2 '+ fieldname +'">:</div>';
          }
          divRow += '<div class="ccell3 '+ fieldname +'_ccell3" '+ style +'>'+ fieldvalue +'</div>';
          divRow += "</div>";

          delete thisRowCopy[fieldname]; // its already procceed
          if(!!fieldpropties.single && fieldpropties.single == true) return; // need to make one td in list
          $td_hide = $('<td/>');
          $td_hide.html(fieldvalue);
          $td_hide.attr("fieldname",fieldname);
          $td_hide.css('display','none');
          $td_hide.appendTo($tr);

        });

        var divTable = "<div id='ctable'>"; 
        divTable += divRow;  
        divTable += "</div>"; 

        compositeColumnsHTML = divTable;
        $td.html(compositeColumnsHTML)
        .css("cursor","pointer")
        .hover(
          function(){bgOn = $(this).closest("tr").css("background-color"); $(this).closest("tr").css("background-color", "lightblue");},
          function(){$(this).closest("tr").css("background-color", bgOn);}
        );
        $td.appendTo($tr);


        } else {

        // *** write custom code here ---
        fieldvalue = (fieldname == "docnumber") ? "<a href='erpdocument.php?docnumber="+fieldvalue+"&doctype=IR&formtype=default&docviewflag=management-account' target='_blank'>"+fieldvalue+"</a>" : fieldvalue;
        // fieldvalue = (fieldname == "requestdocnumber") ? "<a href='erpdocument.php?docnumber="+fieldvalue+"&doctype=DR&formtype=SF&docviewflag=apparel' target='_blank'>"+fieldvalue+"</a>" : fieldvalue;
        // *** custom code end ----------

        $td = $('<td/>');
        $td.html(fieldvalue)
        .css("white-space","pre-wrap")
        .attr("fieldname",fieldname)
        .css("cursor","pointer")
        .hover(
          function(){bgOn = $(this).closest("tr").css("background-color"); $(this).closest("tr").css("background-color", "lightblue");},
          function(){$(this).closest("tr").css("background-color", bgOn);}
        );
        if ( hideColumns.indexOf(fieldname) >= 0 ) $td.css('display','none');
        $td.appendTo($tr);

        }

      // }  
      });

    // *** custom code start-----------------------------------------------------------------------------------------
    // $tr.find('td.requiredinformation').append(btnThisLineAction);
    // *** custom code end-------------------------------------------------------------------------------------------

      $tr.click( function() { 
          ERPLIST.sendBackSearchChoice($(this));
        })
        .appendTo($tbody);
    });

    $thead.appendTo($table)
    $tbody.appendTo($table)

    return $table;
};




/**
* Custom function code------------------------------------------------------------------------------------------------------
*/
ERPLIST.customFunction = function(argument) {
}



ERPLIST.sendBackSearchChoice = function(thisRow){
  // var docnumber = $(thisRow).find('td[fieldname=docnumber]').text();
  // alert(docnumber);
}


ERPLIST.checkAndRetriveSearchData = function(){
    var searchParams = {};
    $('table#listTable_session thead tr').each(function() {
        $(this).find("td input:text,select").each(function() {
            textVal = this.value;
            inputName = $(this).attr("name");
            if(textVal != "" && !!inputName ){
              searchParams[inputName] = textVal;
            }
        });
    });
    return searchParams;
}

jsClient.changeDisplayRowCount = function(numRecords) {
  var pagenum = $('#loupelistDiv #paginationContainer #pagination').find('span.current').text();
      var lineperpage = $('#loupelistDiv #paginationContainer #divRowLimit').find('select[name=show]').val();
      if(!!!pagenum) pagenum=1;
      if(!!!lineperpage) lineperpage=50;
  ERPLIST.getListData( lineperpage, pagenum );

  delete ERPLIST.selectedLineInfo;
}

ERPLIST.getListData = function(numRecords, pageNum, apiURL, searchParams) {

  var numRecords = (!!numRecords && numRecords != '') ? numRecords : '10';
  var pageNum    = (!!pageNum && pageNum != '') ? pageNum : '10';
  var apiURL     = (!!apiURL && apiURL != '') ? apiURL : ERPLIST._URL_API;
  if(!!!searchParams){
    // check search field value is exist 
    // user may click in pagination page after search
    searchParams = ERPLIST.checkAndRetriveSearchData();
  }
  var searchParams = (!!searchParams && Object.keys(searchParams).length > 0)? searchParams : {};

  var inputPlusUrlSearchParams = {};
  $.each(searchParams, function(key, val){
    inputPlusUrlSearchParams[key] = val; // push input search param
  });

  searchParams['fieldname'] = ERPLIST.targetfieldname;
  searchParams['showLimit'] = numRecords;
  searchParams['pageNum'] = pageNum;
  searchParams['reqType'] = 'getListData';

  var urlSearchParams = (!ERPLIST._sessionCall) ? jsClient.paramsToObj(window.location.search) : {}
  if( Object.keys(urlSearchParams).length > 0 ){
      // var inputSearchParams = (!!ERPLIST._searchParams && ERPLIST._searchParams.length > 0) ? JSON.parse(ERPLIST._searchParams) : {};
    // var inputPlusUrlSearchParams = (Object.keys(inputSearchParams).length > 0) ? inputSearchParams : {};
    $.each(urlSearchParams, function(key, val){
      searchParams[key] = val; // push url search data in search param object
      inputPlusUrlSearchParams[key] = val; // push url search data in search param object
    });
  }
  if( Object.keys(inputPlusUrlSearchParams).length > 0 ){
    ERPLIST._searchParams = JSON.stringify(inputPlusUrlSearchParams);
  }

    $.ajax({
      type: "GET",
      url: apiURL,
      data: searchParams,
      cache: false,
      beforeSend: function() {
          $('#popupListContent #loadingDiv').html('<center><img src="/images/loading_spinner.gif"></center>');
      },
      success: function(jsonData) {
        $('#popupListContent #loadingDiv').html('');
          var parseData = JSON.parse(jsonData);
          ERPLIST.displayQueryData(jsonData);

          // if(!!ERPLIST._searchParams){
          //   ERPLIST.setPriviousSearchParams(ERPLIST._searchParams);
          // }
      }
    });

}