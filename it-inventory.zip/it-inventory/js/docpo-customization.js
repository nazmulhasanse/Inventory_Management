/**
 * Declare the namespace LIZERP if not existent
 */
var LIZERP = LIZERP || {};

$.extend(LIZERP, {
  _ERP_DOCACRONYM: '',
  _FIELDSETS_HEADER: ['fieldset_documentinformation', 'fieldset_logisticsinformation'],
  _FIELDS_AUTOFILLUP: ['ldcslnumber'],

  foo: 'here for no reason other than to be the last line, without a comma'
});


LIZERP.changeDocStatus = function(docnumber, docstatus){
  var searchParams = {};
  searchParams.docnumber = docnumber;
  searchParams.docstatus = docstatus;
  searchParams.reqType = 'changeDocStatus';
  return $.post(LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM], searchParams, changeDocStatus_return(), 'json');

  function changeDocStatus_return(extraParams) {
    return function(data, textStatus, jqXHR) {
      if (data.result == 'success') {
        location.reload();
      } else {
        alert(data.errormsgs.join('\n'));
      }
    }
  }

}

LIZERP.updateRevisedPO = function(docnumber){

  LIZERP.autoFillup_newRR();


  var searchParams = {};
  searchParams.docnumber = docnumber;
  searchParams.reqType = 'updateRevisedPO';
  return $.post(LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM], searchParams, updateRevisedPO_return(), 'json');

  function updateRevisedPO_return(extraParams) {
    return function(data, textStatus, jqXHR) {
      console.log(data.result);
      if (data.result == 'success') {
        location.reload();
      } else {
        alert(data.errormsgs.join('\n'));
      }
    }
  }

}

LIZERP.poAmendment = function(docnumber, docstatus){
  var searchParams = {};
  searchParams.docnumber = docnumber;
  searchParams.docstatus = docstatus;
  searchParams.reqType = 'poAmendment';
  return $.post(LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM], searchParams, poAmendment_return(), 'json');

  function poAmendment_return(extraParams) {
    return function(data, textStatus, jqXHR) {
      if (data.result == 'success') {
        location.reload();
      } else {
        alert(data.errormsgs.join('\n'));
      }
    }
  }

}

LIZERP.getPOLineInfo = function(){
  var params     = paramsToObj(window.location.search);
  var idlines  = params.idlines; 

  var searchParams = {
    'reqType': 'getPOLineInfo',
    'idlines': idlines
  };

  var mType = 'get';
  var mUrl     = "docpo_api.php";
  var mReqType = "";

  var returnData = jsClient.communicationToServer(mReqType, searchParams, mUrl, mType, false);

  console.log(returnData);

  if (returnData.length > 0) {

    data = JSON.parse(returnData);
    $tr2 = LIZERP.getLineBeingEdited();

    $.each(data, function(index, line){

      // $tr2.find('input.saveLine:visible').first().click();
      $tr2.find('td.itemcode input').val(line.itemcode);
      $tr2.find('td.itemtype select').val(line.itemtype);
      $tr2.find('td.itemname input').val(line.itemname);
      $tr2.find('td.itemnature input').val(line.itemnature);
      $tr2.find('td.project input').val(line.project);
      $tr2.find('td.itemdescription textarea').val(line.itemdescription);
      $tr2.find('td.unitprice input').val(line.unitprice);
      $tr2.find('td.iduom input').val(line.iduom);
      // $tr2.find('td.iduom select').val(line.iduom);
      $tr2.find('td.fabricinhousedate input').val(line.fabricinhousedate);
      $tr2.find('td.rrnumber input').val(line.rrnumber);
      $tr2.find('td.parentrrnumber input').val(line.parentrrnumber);
      $tr2.find('td.tnxqty input').val(line.requirednetqty);
      $tr2.find('td.requisitionlinenumber input').val(line.doclinenumber);

      $tr2.find('td.extracost input').val(line.extracost);
      $tr2.find('td.deliverydate input').val(line.deliverydate);
      $tr2.find('td.orderqty input').val(line.orderqty);
      $tr2.find('td.sizeormeasurement input').val(line.sizeormeasurement);
      $tr2.find('td.brand input').val(line.brand);
      $tr2.find('td.color input').val(line.color);
      $tr2.find('td.costdept textarea').val(line.costdept);
      $tr2.find('td.costcenter input').val(line.costcenter);

      $tr2.find('td.amountwithoutdiscount input').val(line.amountwithoutdiscount);
      $tr2.find('td.discountamount input').val(line.discountamount);
      $tr2.find('td.amount input').val(line.amount);
      $tr2.find('td.currency input').val(line.currency);
      $tr2.find('td.capexno input').val(line.capexno);
      // $tr2.find('td.linesremarks input').val(line.linesremarks);
      // $tr2.find('td.company input').val(line.company);
      LIZERP.saveLine();
      $tr2 = LIZERP.getLineBeingEdited();


    });

    $('#fieldset_documentinformation').find('.formGroup input[name=suppliername]').val(data[0]['suppliername']);
    $('#fieldset_documentinformation').find('.formGroup input[name=suppliername]').attr('disabled','disabled');
    $('#fieldset_documentinformation').find('.formGroup textarea[name=supplieraddress]').val(data[0]['supplieraddress']);
    $('#fieldset_documentinformation').find('.formGroup textarea[name=supplieraddress]').attr('disabled','disabled');
    $('#fieldset_documentinformation').find('.formGroup input[name=purchasemode]').val(data[0]['purchasemode']);
    $('#fieldset_documentinformation').find('.formGroup input[name=purchasemode]').attr('disabled','disabled');
    $('#fieldset_documentinformation').find('.formGroup input[name=currency]').val(data[0]['currency']);
    $('#fieldset_documentinformation').find('.formGroup input[name=currency]').attr('disabled','disabled');
    $('#fieldset_documentinformation').find('.formGroup select[name=company]').val(data[0]['company']);
    $('#fieldset_documentinformation').find('.formGroup select[name=company]').attr('disabled','disabled');

    // LIZERP.getSOInfo(data[0]['salesorder']);
    LIZERP.handleFormLinesTrClick();

    // click first tr
    // $(LIZERP.formId + ' #formLines table tbody tr:first').click();
    $(LIZERP.formId + ' #formLines tr.new').remove();

    // System will click now in Save button in upper button
    // and document will create, then user will modify line
    
    if(!!params.idlines && params.idlines != ''){
      LIZERP.saveForm('autoLineFill_Save_Edit');
    }


  }

  console.log('\n\n ***delivery line auto fillup');

}


LIZERP.getAdditionalRRPOLineInfo = function(){
  var params     = paramsToObj(window.location.search);
  var docnumber  = params.docnumber; 

  var searchParams = {
    'reqType': 'getAdditionalRRPOLineInfo',
    'docnumber': docnumber
  };

  var mType = 'get';
  var mUrl     = "docpo_api.php";
  var mReqType = "";

  var returnData = jsClient.communicationToServer(mReqType, searchParams, mUrl, mType, false);

  console.log(returnData);

  LIZERP.editMode();

  if (returnData.length > 0) {

    data = JSON.parse(returnData);
    $tr2 = LIZERP.getLineBeingEdited();

    $.each(data, function(index, line){
      // $tr2.find('input.saveLine:visible').first().click();
      $tr2.find('td.itemcode input').val(line.itemcode);
      $tr2.find('td.project input').val(line.project);
      $tr2.find('td.itemnature select').val(line.itemnature);
      $tr2.find('td.itemtype input').val(line.itemtype);
      $tr2.find('td.itemdescription textarea').val(line.itemdescription);
      $tr2.find('td.pricerequisitionnumber input').val(line.pricerequisitionnumber);
      $tr2.find('td.unitprice input').val(line.unitprice);
      $tr2.find('td.iduom select').val(line.iduom);
      $tr2.find('td.fabricinhousedate input').val(line.fabricinhousedate);
      $tr2.find('td.rrnumber input').val(line.rrnumber);
      $tr2.find('td.parentrrnumber input').val(line.parentrrnumber);
      $tr2.find('td.tnxqty input').val(line.requirednetqty);
      $tr2.find('td.originalqty input').val(line.requirednetqty);
      $tr2.find('td.previousqty input').val(line.requirednetqty);
      $tr2.find('td.iduom input').val(line.iduom);
      $tr2.find('td.dlvbrktext textarea').val(line.dlvbrktext);
      $tr2.find('td.salesorder input').val(line.salesorder);
      LIZERP.saveLine();
      $tr2 = LIZERP.getLineBeingEdited();


    });

    
    LIZERP.handleFormLinesTrClick();

    // click first tr
    // $(LIZERP.formId + ' #formLines table tbody tr:first').click();
    $(LIZERP.formId + ' #formLines tr.new').remove();


    // LIZERP.saveForm();

  }
  console.log('\n\n ***delivery line auto fillup');

}


LIZERP.getSOInfo = function(salesorder){
  // var salesorder = $('#fieldset_documentinformation').find('.formGroup input[name=salesorder]').val(); 

  var searchParams = {
    'reqType': 'getSOInfo',
    'salesorder': salesorder
  };

  var mType = 'get';
  var mUrl     = "docpo_api.php";
  var mReqType = "";

  var returnData = jsClient.communicationToServer(mReqType, searchParams, mUrl, mType, false);

  console.log(returnData);

  if (returnData.length > 0) {

    data = JSON.parse(returnData);

    // $('#fieldset_documentinformation').find('.formGroup input[name=salesordertype]').val(data[0]['formtype']);
    // $('#fieldset_documentinformation').find('.formGroup input[name=salesordertype]').attr('disabled','disabled');
    // $('#fieldset_documentinformation').find('.formGroup input[name=salesorder]').val(salesorder);
    // $('#fieldset_documentinformation').find('.formGroup input[name=salesorder]').attr('disabled','disabled');

  }

}



/**
 * Customize doc review and approve by....Nazmul
 */

 LIZERP.docInfoTranslator_docPreview = {
  CP: 'Capacity Plan',
  projection: 'Projection',
  direct: 'Direct Confirm',
  under_projection: 'Projection Confirm'  
}

LIZERP.hideColumns_previewDoc_headTable = ['doctype', 'formtype', 'docnumber', 'docdate', 'docstatus', 'entrypersonbadge', 'doccreationtime'];
LIZERP.hideColumns_previewDoc_lineTable = ['idlines', 'linestatus'];
LIZERP.cancelPreviewDoc = function(){
  $.fancybox.close();
}
LIZERP.approvePreviewDoc = function(){
  var params = paramsToObj(window.location.search);

    //Start confirm dialog PopUp
    $('<div></div>').dialog({
       width: 500,
        modal: true,
        title: "Confirmation",
        open: function () {
            var markup = 'Warning: After Confirming this Capacity Plan, in future if you wish to Cancel/Modify, you will face problem.';
            $(this).html(markup);
        },
        buttons: {
            "Ok, Confirm Material Planner": function () {
               LIZERP.changeDocStatus(params.docnumber, '1');
            },

            cancel: function () {
                $(this).dialog("close");
            }
        }
    }); //end confirm dialog PopUp
 // if(confirm('Note that after approving this Capacity Plan info, if in future you wish to cancel/Modify you will face problem.')) LIZERP.changeDocStatus(params.docnumber, '1');
}



//------------27/04/17-----------------

LIZERP.initHead = function(){


  // LIZERP.searchHeaderInfo();

}

LIZERP.searchHeaderInfo = function() {

  var params     = paramsToObj(window.location.search);
  var ldcslnumber  = params.ldcslnumber; 

  var searchParams = {
    'reqType': 'searchHeaderInfo',
    'ldcslnumber': ldcslnumber
  };

  $.get(LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM], searchParams, searchHeaderInfo_results(searchParams));

  function searchHeaderInfo_results(extraParams) {
    return function(data, textStatus, jqXHR) {
      if (data.length > 0) {
        data = JSON.parse(data)[0];

        $(LIZERP.formId).find('#company').val(data.company);
        if(data.company != "") $(LIZERP.formId).find('#company').attr('disabled','disabled');

        $(LIZERP.formId).find('#salesordertype').val(data.formtype);
        if(data.formtype != "") $(LIZERP.formId).find('#salesordertype').attr('disabled','disabled');

        $(LIZERP.formId).find('#salesorder').val(data.docnumber);
        if(data.docnumber != "") $(LIZERP.formId).find('#salesorder').attr('disabled','disabled');

        $(LIZERP.formId).find('#customer').val(data.customer);
        if(data.customer != "") $(LIZERP.formId).find('#customer').attr('disabled','disabled');

        $(LIZERP.formId).find('#endcustomer').val(data.endcustomer);
        if(data.endcustomer != "") $(LIZERP.formId).find('#endcustomer').attr('disabled','disabled');

        $(LIZERP.formId).find('#season').val(data.season);
        if(data.season != "") $(LIZERP.formId).find('#season').attr('disabled','disabled');

        $(LIZERP.formId).find('#totalpackqty').val(data.totalpackqty);
        if(data.totalpackqty != "") $(LIZERP.formId).find('#totalpackqty').attr('disabled','disabled');

        $(LIZERP.formId).find('#totalpieceqty').val(data.totalpieceqty);
        if(data.totalpieceqty != "") $(LIZERP.formId).find('#totalpieceqty').attr('disabled','disabled');

        $(LIZERP.formId).find('#style').val(data.style);salesordertype
        if(data.style != "") $(LIZERP.formId).find('#style').attr('disabled','disabled');

        $(LIZERP.formId).find('#styledescription').val(data.styledescription);
        if(data.styledescription != "" && data.styledescription != null) $(LIZERP.formId).find('#styledescription').attr('disabled','disabled');

        $(LIZERP.formId).find('#productcategory').val(data.productcategory);
        if(data.productcategory != "" && data.productcategory != null) $(LIZERP.formId).find('#productcategory').attr('disabled','disabled');

        $(LIZERP.formId).find('#ldcslnumber').val(data.ldcslnumber);
        if(data.ldcslnumber != "") $(LIZERP.formId).find('#ldcslnumber').attr('disabled','disabled'); 

        $(LIZERP.formId).find('#buyerpo').val(data.buyerpo);
        if(data.buyerpo != "" && data.buyerpo != null) $(LIZERP.formId).find('#buyerpo').attr('disabled','disabled');

        $(LIZERP.formId).find('#processbeforesewing').val(data.processbeforesewing);
        if(data.processbeforesewing != "" && data.processbeforesewing != null) $(LIZERP.formId).find('#processbeforesewing').attr('disabled','disabled'); 

        $(LIZERP.formId).find('#processaftersewing').val(data.processaftersewing);
        if(data.processaftersewing != "" && data.processaftersewing != null) $(LIZERP.formId).find('#processaftersewing').attr('disabled','disabled');

        // $('#fieldset_documentinformation').find('#customer').val(data.docnumber);
        // $('#fieldset_documentinformation').find('#customer').attr('disabled','disabled');

      } else {
      }
    }
  }
}




LIZERP.readMode = function() {
  $(LIZERP.formId).find(' #formLines tr.new').remove();
  $(LIZERP.formId).find(' #formLines tr').unbind('mouseenter mouseleave');
  $(LIZERP.formId).find('input,select,textarea').attr('disabled', 'disabled');
  $(LIZERP.formId).find(' input[type=button]').removeAttr('disabled');

  $('#rightFormLines').css('display', 'none');
  $('.editLine').css('display', 'none');
  $('.copyAndNewLine').css('display', 'none');

  $('#fieldset_systeminformation').css('display', 'block');
  $(' .btnEditMode ').css('display', 'none');
  $(' .btnReadMode ').css('display', 'inline-block');
  $(' .datepicker').unmousewheel();
  $(LIZERP.formId).find(' #formLines tr .fileAttachmentContainer').css('display', 'block');
  $(LIZERP.formId).find(' #fieldset_documentfile .fileAttachmentContainer').css('display', 'block');
  $(LIZERP.formId).find(' #fieldset_lineinformation #spanBtnFileAttachment').css('display', 'none');
  


  var docStatus = $(LIZERP.formId).find('#docstatus').val();

  if(docStatus == "0"){ 
    $(LIZERP.formId + ' .btnAmend ').css('display', 'none');
  }
  
  $(LIZERP.formId + ' .btnSendToTextile ').css('display', 'none');
  if(docStatus == "1"){ 
    $(LIZERP.formId + ' .btnSendToTextile ').css('display', 'inline-block');
    $(LIZERP.formId + ' .btnEnterEditMode ').css('display', 'none');
    $(LIZERP.formId + ' .btnSentTextile ').css('display', 'none');
  }

  if(docStatus == "2"){ 
    $(LIZERP.formId + ' .btnConfirmation ').css('display', 'none');
    $(LIZERP.formId + ' .btnEnterEditMode ').css('display', 'none');
    $(LIZERP.formId + ' .btnSendToTextile ').css('display', 'none');
    $(LIZERP.formId + ' .btnSentTextile ').css('display', 'none');
  }
  
  if(docStatus == "9"){
    $(LIZERP.formId + ' .btnConfirmation ').css('display', 'none');
    $(LIZERP.formId + ' .btnEnterEditMode ').css('display', 'none');
    $(LIZERP.formId + ' .btnInformApparelPlanner ').css('display', 'none');
    $(LIZERP.formId + ' .btnChangeDocStatus ').css('display', 'none');
  }  


  //get partent po number by button
  previousponumber = $(LIZERP.formId + ' #fieldset_documentinformation').find('input#previousponumber').val();
  console.log(previousponumber);
  if(previousponumber == null || previousponumber == ''){
    $(LIZERP.formId + ' #upperButtonBar').find('.btnParentPO').css('display','none');
  }


  LIZERP.formMode = 'read';
  LIZERP.viewMode();
}



LIZERP.viewMode = function(){
  var params = paramsToObj(window.location.search);
  if(params.flag == 'view'){
    $('input[type=button]').addClass('btndisabled');
    $('button[type=button]').addClass('btndisabled');
    $(' .btndisabled ').css('display', 'none');
    $('.fileInputContainer').css('display','none');

    $('.btnPrintSheet').css('display','block');
  }
}

LIZERP.editMode_clickFromUpperBtn = function() {

  $(LIZERP.formId + ' #formLines tr').hover(function(e) {
    $(this).find('.div_editButton').css('display', 'block');
  }, function(e) {
    $(this).find('.div_editButton').css('display', 'none');
  });
  $(LIZERP.formId).find('input,select,textarea').removeAttr('disabled');
  LIZERP.lockCreateOnlyFields();
  $('#fieldset_systeminformation').css('display', 'none');
  $(' .btnEditMode ').css('display', 'inline-block');
  $(' .btnReadMode ').css('display', 'none');

  $(LIZERP.formId).find('.saveLine').attr('disabled', 'disabled');
  $(LIZERP.formId).find('.saveLineAndNew').attr('disabled', 'disabled');

  $(LIZERP.formId).find('.copyAndNewLine').attr('disabled', 'disabled');
  $(LIZERP.formId).find('.removeLine').attr('disabled', 'disabled');
  $(LIZERP.formId).find('.btnCancelDocLine').attr('disabled', 'disabled');

  // $(LIZERP.formId + ' .newLine').css('display', 'none');
  // $(LIZERP.formId + ' .saveLineAndNew').css('display', 'none');
  // $(LIZERP.formId + ' .copyAndNewLine').css('display', 'none');
  // $(LIZERP.formId + ' .removeLine').css('display', 'none');


  LIZERP.formMode = 'edit';
  LIZERP.disableHeader();

  LIZERP.lockAutoFillupFields();
}


LIZERP.disableHeader = function(){

}




LIZERP.checkCreateCapacityPlanDocFlag = function(){

  var params = paramsToObj(window.location.search); 
  if(!!params.docflag && params.docflag == "createcapacityplan"){
    LIZERP.editMode_clickFromUpperBtn();
    $(LIZERP.formId + ' #docnumber').val('');
    $(LIZERP.formId + ' #spandocnumber').text('');
    $(LIZERP.formId + ' #docstatus').val('');
    $(LIZERP.formId + ' #spandocstatus').text('');
    $(LIZERP.formId + ' #doctype').val(params.doctype);
    // $(LIZERP.formId + ' .newLine').css('display', 'none');
    // $(LIZERP.formId + ' .saveLineAndNew').css('display', 'none');

    $(LIZERP.formId + ' #salesorder').val(params.docnumber);
    $(LIZERP.formId + ' #sotype').val(params.formtype);

    $(LIZERP.formId + ' #fieldset_lineinformation .valid .idlines').find('input').val('');

    LIZERP.saveForm();

  }

  if(params.createcapacityplan == 'yes'){
    LIZERP.editMode_clickFromUpperBtn();
  }

}




LIZERP.loupeListRRnumber = function(xxx) {
  var prepopulate = {};

  var prepopJS = (Object.keys(prepopulate).length > 0) ? 'var prepopulate = ' + JSON.stringify(prepopulate) + ';' : '';
  prepopJS = prepopJS + "var ERPLIST = ERPLIST || {};";
  prepopJS = prepopJS + "$(document).ajaxStop(function() {";
  prepopJS = prepopJS + "ERPLIST.sendBackSearchChoice = function( thisRow ) {";
  prepopJS = prepopJS + "  rrnumber = $(thisRow).find('td[fieldname=rrnumber]').text();";
  prepopJS = prepopJS + "  $.fancybox.close();";
  prepopJS = prepopJS + "  $(LIZERP.formId + '#lg_rrnumber').val(rrnumber);";
  prepopJS = prepopJS + "  $(LIZERP.formId + '#lg_rrnumber').focus();";
  prepopJS = prepopJS + "};";
  prepopJS = prepopJS + "});";

  var content = '<div id="popupListContent">\
    <div id="loadingDiv">\
      <center><img src="/images/loading_spinner.gif"></center>\
    </div>\
  </div>';
  content+= '<script> ' + prepopJS + '</script>'; // add some js

  $.fancybox({
    type: 'html',
    content: content,
    minWidth: 500,
    minHeight: 300,
    afterLoad: function(){
      this.title = "<b>PO Creation RR List</b>";
    },    
    afterShow: function() {
      loadSessionContent();
      $.fancybox.update();
    },
    helpers: {
     title : {
      type : 'inside',
      position : 'top'
     },
     overlay : {
      css  : { /* 'background-color' : '#fff' */}
     }     
    }  
  });
  jQuery('.fancybox-title').css({'text-align':'center', 'margin-bottom':'10px'});

  function loadSessionContent(){
    $.ajax({
      async: false,
      type: 'get',
      url: 'list-pocreation-rr-lines-session.php',
      success: function(htmlContent) {
        $('#popupListContent').empty().append(htmlContent);
        $.fancybox.update();
      }
    }).fail(function(e) {
      alert('Assign failed, please try again.');
    });
  }

}

/**
 * Show loupe item code search form
 */
LIZERP.handleSearchForm = function(callingField, prepopulate) {
  LIZERP.searchLoupe_hide();
  console.log(callingField);
  if(callingField == 'lg_rrnumber'){
    LIZERP.loupeListRRnumber(true);
  }
  return;
}
//----------------------------------------- loupe list work end ----------------------------------------------------------------------------------------------------------------------


/**
 * Save form via ajax after validation
 */
 LIZERP.saveForm = function(flag) {
  // tries to save the line if it's dirty
  if ((LIZERP.lineIsDirty == true) || ($(LIZERP.formId + ' #formLines tr.editable:not(.new)').length > 0)) {
    $('#formLines input[type=text]:visible').closest('tr').find('.saveLine').first().click();
  }

  // change data to actual uppercase from just css transform
  $(LIZERP.formId).find('input,textarea').each(function(i) {
    if ($(this).css('text-transform') == 'uppercase') $(this).val($(this).val().toUpperCase());
  });

  // run validation on all header fields
  var error = false;
  for (i in LIZERP._FIELDSETS_HEADER) {
    error = error || LIZERP.validateFormContainerFields(LIZERP.formId + ' #' + LIZERP._FIELDSETS_HEADER[i]);
  }

  var error;
  // if no lines have been added, don't continue
  var validLines = $(LIZERP.formId + ' #formLines #fieldset_lineinformation tbody tr.valid').length;
  if (validLines == 0) {
    error = true;
    LIZERP.showFormError('Please provide at least one valid line information.');
  }

  // If all data is validated, then submit
  if (!error && LIZERP.formMode == 'edit') {
    // just to avoid re-entry, the server should also check for double submission
    LIZERP.readMode();

    /* Prepare JSON */
    var jsonData = {
      'lines': []
    };
    $.each(LIZERP.formFieldSettings['header'], function(fieldName, attributes) {

      if(attributes['html_InputTag'] == 'checkbox'){
        if(!!attributes['groupname']){
          $('.'+attributes['groupname'] ).each(function() {
            if($(this).prop('checked')){
             var checkboxid = $(this).prop('id');
             var text    = $('label[for='+ checkboxid +']').text();
             jsonData[fieldName] = text;
              // var or_this = $('#pre-payment').next('label').text();
              // var selectedVal = $(this).closest('label').text();
              // <input type="checkbox" name="PrePayment" value="Pre-Payment">Pre-Payment<br />
              // $(input).attr('value');
            } 
          });

        } else {
          jsonData[fieldName] = $(LIZERP.formId + ' #' + fieldName).prop("checked") ? 1 : 0;
        }
      } else {
        jsonData[fieldName] = $(LIZERP.formId + ' #' + fieldName).val();
      }
    });

    $(LIZERP.formId + ' #formLines #fieldset_lineinformation tbody tr.valid').each(function() {
      var fieldList = [];
      // Build field list from the visible form
      $('#formLines #fieldset_lineinformation tr th').each(function(e) {
        if (!!$(this).attr('class')) fieldList.push($(this).attr('class'));
      });
      // Build field list from the formFieldSettings variable
      // $.each( LIZERP.formFieldSettings['lines'], function( fieldName, attributes ) {
      //     fieldList.push( fieldName );
      // } );

    LIZERP.formFieldSettings_OBJ = JSON.parse(LIZERP.formFieldSettings_JSON)
    var allowFormLineFields = Object.keys(LIZERP.formFieldSettings_OBJ['lines']);
    var formLine = {};
    for (index in fieldList) {
      formField = fieldList[index];
      if(allowFormLineFields.indexOf(formField) == -1){
        continue;
      }

      var isGroupCheckBox = (formField.indexOf('groupcheckbox') > -1) ? true : false;

      formLine[formField] = $(this).find('td.' + formField).find('input,textarea,select').first().val();
      
    }
    jsonData['lines'].push(formLine);
  });




/* Submit via ajax */
var postData = {
  reqType: 'saveDoc',
  docobj: JSON.stringify(jsonData)
};


    // add iddocument in case this is an Edit
    if ($(LIZERP.formId + ' #docnumber').val().length > 0) postData.docnumber = $(LIZERP.formId + ' #docnumber').val();
    console.log(postData);
    




    $.ajax({
      type: 'post',
      url: LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM],
      //dataType: 'json',/* if the return data is json */
      data: postData,
      success: function(data) {
          // if result is JSON, we're using the new API return format
          console.log(data);
          data = JSON.parse(data);
          if (!!data.errormsgs && data.errormsgs.length > 0) {
            console.log(data.errormsgs.join('\n'));
            alert("===>"+data.errormsgs.join('\n'));
            LIZERP.editMode();
          } else {
            var params = paramsToObj(window.location.search);
            // if(data.createdocheader == 'yes' && params.docflag != 'createcapacityplan'){
              if(!!flag && flag == 'autoLineFill_Save_Edit'){
                var next_href = window.location.origin + window.location.pathname + '?doctype=' + LIZERP._ERP_DOCACRONYM + '&formtype=' + params.formtype + '&docnumber=' + data.docnumber + '&autoLineFill_Save_Edit=yes';
                window.location.href = next_href;
              } else {
                var params = paramsToObj(window.location.search);
                var next_href = window.location.origin + window.location.pathname + '?doctype=' + LIZERP._ERP_DOCACRONYM + '&formtype=' + params.formtype + '&docnumber=' + data.docnumber;
                window.location.href = next_href;
              }
            }
          }
        }).fail(function(e) {
          alert('Saving failed, please try again.');
          LIZERP.editMode();
        });
      }
      return;
    }




/**
 * Save a line
 */
 LIZERP._saveLine = function(line) {
  // edit = 1 if we're trying to save because we clicked on an edit button of another line
  if(!!line){
    var $tr2 = LIZERP.getLineBeingEdited(line);
  } else {
    // line not defined
    // so its a new line, add new line
    if ($(LIZERP.formId + ' #formLines tr.valid.new').length == 0) {
      LIZERP.addLine();
      var $tr2 = LIZERP.getLineBeingEdited();
      $tr2.removeClass('editable new').addClass('valid new'); // new added by Mamun
    }
    var $tr2 = LIZERP.getLineBeingEdited();
  }
  

  /**
   * Passing Value right div to left div
   * Take header data
   */
   var lineData = {};

   $.each(LIZERP.formFieldSettings['header'], function(fieldName, attributes) {
    if(attributes['html_InputTag'] == 'checkbox'){
      if(!!attributes['groupname']){
        $('.'+attributes['groupname'] ).each(function() {
          if($(this).prop('checked')){
           var checkboxid = $(this).prop('id');
           var text    = $('label[for='+ checkboxid +']').text();
           lineData[fieldName] = text;
         } 
       });
      } else {
        lineData[fieldName] = $(LIZERP.formId + ' #' + fieldName).prop("checked") ? 1 : 0;
      }
    } else {
      lineData[fieldName] = $(LIZERP.formId + ' #' + fieldName).val();
    }
  });


  /**
   *Take Line Data
   */
   var formFieldSettings = LIZERP.formFieldSettings['lines'];
   $.each(formFieldSettings, function(fieldName, attributes) {

    if(attributes['html_InputTag'] == 'checkbox'){

      if(!!attributes['groupname']){
        $('.'+attributes['groupname'] ).each(function() {
          if($(this).prop('checked')){
           var checkboxid = $(this).prop('id');
           var text    = $('label[for='+ checkboxid +']').text();
         } 
       });
      } else {
        var val = $(LIZERP.formId + ' #lg_' + fieldName).prop("checked") ? 'Yes' : 'No';
      }

    } else {
      var value = $(LIZERP.formId + ' #lg_' + fieldName).val();
      if(!value) value = "";
      lineData[fieldName] = value;
    }

  });

  // alert(JSON.stringify(lineData));
  // post line data in api

  var postdata = {};
  postdata.line = JSON.stringify(lineData);
  postdata.reqType = '_saveLine';

  // console.log(postdata.line);
  // return;


  $.post(LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM], postdata, postLineData_results);

  function postLineData_results(data, textStatus, jqXHR) {

    data = JSON.parse(data);
    var lines = data.lines;
    delete data.lines;

    var headerObj = data;
    var linesObj = lines;

    /**
     * for first time doc create
     */
     if(headerObj['doccreate'] == 'yes'){
      for (var key in headerObj) {
        if (key.substr(0, 1) == "_") {
          LIZERP.dbAuxData[key.substr(1)] = headerObj[key]
          continue;
        }
        $('#' + key).filter('input,select,textarea').val(headerObj[key]);
        if(key == "docnumber"){$('span#span' + key).text(headerObj[key]);}
        else if(key == 'docstatus'){
          $(LIZERP.formId +' #' + key).val(headerObj[key]);
          $(LIZERP.formId).find('span#span' + key).text(LIZERP.formFieldSettings['docstatus'][headerObj[key]]); 
        }
        else {$('span#' + key).text(headerObj[key]);}
      }
      // add docnumber in URL
      var currURL = window.location.pathname + window.location.search + '&docnumber=' + headerObj['docnumber'];
      window.history.pushState('', 'Title', currURL);
    }


    var fieldList = [];
    var requiredCols = [];
    $('#formLines #fieldset_lineinformation table tr th')
    .each(function(e) {
      if (!!$(this).attr('class')) fieldList.push($(this).attr('class'));
    });
    // remove from array, this field is not user-entered
    // fieldList.splice(fieldList.indexOf('idlines'), 1)
    // fieldList.splice(fieldList.indexOf('linenumber'), 1)

    /**
     * Putting value in line input field
     */
     for (var j = 0; j < fieldList.length; j++) {
      if (!!linesObj[0][fieldList[j]] && linesObj[0][fieldList[j]].length > 0) {
        $tr2.find('td.' + fieldList[j]).find('input,textarea,select').val(linesObj[0][fieldList[j]]);
      }
    }

    /**
     * Take line input field object
     */
     var $lineFields = {};
     for (key in fieldList) {
      $lineFields[fieldList[key]] = $tr2.find('.' + fieldList[key]).find('input,select,textarea');
    }

    /**
     * Show this line field value to span
     */
     var error = false;
     if (!error) {

      for (key in fieldList) {  
        if(fieldList[key] == 'linestatus'){
          $tr2.find('td.' + fieldList[key]).find('span').text(LIZERP.formFieldSettings['linestatus'][$lineFields[fieldList[key]].val()]);
        } else {
          $tr2.find('.' + fieldList[key]).find('span').text($lineFields[fieldList[key]].val());
        }   
      }
      $tr2.find('textarea').parent().find('span').css('white-space', 'pre-wrap');
      $tr2.removeClass('editable new').addClass('valid');

      LIZERP.handleFormLinesTrClick();
      LIZERP.cancelLine();

    }

    if (line == 1) {
      return error;
    }


  }


}


/**
 * Save a line and new
 */
 LIZERP._saveLineAndNew = function(line) {
  // edit = 1 if we're trying to save because we clicked on an edit button of another line
  if(!!line){
    var $tr2 = LIZERP.getLineBeingEdited(line);
  } else {
    // line not defined
    // so its a new line, add new line
    if ($(LIZERP.formId + ' #formLines tr.valid.new').length == 0) {
      LIZERP.addLine();
      var $tr2 = LIZERP.getLineBeingEdited();
      $tr2.removeClass('editable new').addClass('valid new'); // new added by Mamun
    }
    var $tr2 = LIZERP.getLineBeingEdited();
  }
  

  /**
   * Passing Value right div to left div
   * Take header data
   */
   var lineData = {};

   $.each(LIZERP.formFieldSettings['header'], function(fieldName, attributes) {
    if(attributes['html_InputTag'] == 'checkbox'){
      if(!!attributes['groupname']){
        $('.'+attributes['groupname'] ).each(function() {
          if($(this).prop('checked')){
           var checkboxid = $(this).prop('id');
           var text    = $('label[for='+ checkboxid +']').text();
           lineData[fieldName] = text;
         } 
       });
      } else {
        lineData[fieldName] = $(LIZERP.formId + ' #' + fieldName).prop("checked") ? 1 : 0;
      }
    } else {
      lineData[fieldName] = $(LIZERP.formId + ' #' + fieldName).val();
    }
  });


  /**
   *Take Line Data
   */
   var formFieldSettings = LIZERP.formFieldSettings['lines'];
   $.each(formFieldSettings, function(fieldName, attributes) {

    if(attributes['html_InputTag'] == 'checkbox'){

      if(!!attributes['groupname']){
        $('.'+attributes['groupname'] ).each(function() {
          if($(this).prop('checked')){
           var checkboxid = $(this).prop('id');
           var text    = $('label[for='+ checkboxid +']').text();
         } 
       });
      } else {
        var val = $(LIZERP.formId + ' #lg_' + fieldName).prop("checked") ? 'Yes' : 'No';
      }

    } else {
      var value = $(LIZERP.formId + ' #lg_' + fieldName).val();
      if(!value) value = "";
      lineData[fieldName] = value;
    }

  });

  // alert(JSON.stringify(lineData));
  // post line data in api

  var postdata = {};
  postdata.line = JSON.stringify(lineData);
  postdata.reqType = '_saveLine';
  $.post(LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM], postdata, postLineData_results);

  function postLineData_results(data, textStatus, jqXHR) {

    data = JSON.parse(data);
    var lines = data.lines;
    delete data.lines;

    var headerObj = data;
    var linesObj = lines;

    /**
     * for first time doc create
     */
     if(headerObj['doccreate'] == 'yes'){
      for (var key in headerObj) {
        if (key.substr(0, 1) == "_") {
          LIZERP.dbAuxData[key.substr(1)] = headerObj[key]
          continue;
        }
        $('#' + key).filter('input,select,textarea').val(headerObj[key]);
        if(key == "docnumber"){$('span#span' + key).text(headerObj[key]);}
        else if(key == 'docstatus'){
          $(LIZERP.formId +' #' + key).val(headerObj[key]);
          $(LIZERP.formId).find('span#span' + key).text(LIZERP.formFieldSettings['docstatus'][headerObj[key]]); 
        }
        else {$('span#' + key).text(headerObj[key]);}
      }
      // add docnumber in URL
      var currURL = window.location.pathname + window.location.search + '&docnumber=' + headerObj['docnumber'];
      window.history.pushState('', 'Title', currURL);
    }


    var fieldList = [];
    var requiredCols = [];
    $('#formLines #fieldset_lineinformation table tr th')
    .each(function(e) {
      if (!!$(this).attr('class')) fieldList.push($(this).attr('class'));
    });
    // remove from array, this field is not user-entered
    // fieldList.splice(fieldList.indexOf('idlines'), 1)
    // fieldList.splice(fieldList.indexOf('linenumber'), 1)

    /**
     * Putting value in line input field
     */
     for (var j = 0; j < fieldList.length; j++) {
      if (!!linesObj[0][fieldList[j]] && linesObj[0][fieldList[j]].length > 0) {
        $tr2.find('td.' + fieldList[j]).find('input,textarea,select').val(linesObj[0][fieldList[j]]);
      }
    }

    /**
     * Take line input field object
     */
     var $lineFields = {};
     for (key in fieldList) {
      $lineFields[fieldList[key]] = $tr2.find('.' + fieldList[key]).find('input,select,textarea');
    }

    /**
     * Show this line field value to span
     */
     var error = false;
     if (!error) {

      for (key in fieldList) {  
        if(fieldList[key] == 'linestatus'){
          $tr2.find('td.' + fieldList[key]).find('span').text(LIZERP.formFieldSettings['linestatus'][$lineFields[fieldList[key]].val()]);
        } else {
          $tr2.find('.' + fieldList[key]).find('span').text($lineFields[fieldList[key]].val());
        }   
      }
      $tr2.find('textarea').parent().find('span').css('white-space', 'pre-wrap');
      $tr2.removeClass('editable new').addClass('valid');

      LIZERP.handleFormLinesTrClick();
      // LIZERP.cancelLine();

    }

    if (line == 1) {
      return error;
    }


  }


}


LIZERP.editMode = function(formWhere) {


  if ($(' #formLines tr.editable').length == 0){
    LIZERP.addLine();
    // $tr2.removeClass('editable new').addClass('valid new');
  }

  $(LIZERP.formId + ' #formLines tr').hover(function(e) {
    $(this).find('.div_editButton').css('display', 'block');
  }, function(e) {
    $(this).find('.div_editButton').css('display', 'none');
  });
  $(LIZERP.formId).find('input,select,textarea').removeAttr('disabled');
  LIZERP.lockCreateOnlyFields();
  $('#fieldset_systeminformation').css('display', 'none');
  $(' .btnEditMode ').css('display', 'inline-block');
  $(' .btnReadMode ').css('display', 'none');


  var $tr2 = LIZERP.getLineBeingEdited();
  if(formWhere == 'nodoc' || formWhere == 'eee'){

    $tr2.removeClass('editable new').addClass('valid new'); // new added by Mamun
    $(LIZERP.formId).find('.saveLine').attr('disabled', 'disabled');
    $(LIZERP.formId).find('.saveLineAndNew').attr('disabled', 'disabled');

    $(LIZERP.formId).find('.copyAndNewLine').attr('disabled', 'disabled');
    $(LIZERP.formId).find('.removeLine').attr('disabled', 'disabled');
    $(LIZERP.formId).find('.btnCancelDocLine').attr('disabled', 'disabled');

  } 

  LIZERP.controlLineButtons();
    // added 2017-05-03
  $(LIZERP.formId).find('#formLinesButtonsBr').empty();

  LIZERP.formMode = 'edit';


  console.log('\n\n ***edit mode called');

  LIZERP.lockAutoFillupFields();
}



LIZERP.controlLineButtons = function(){
  // $(LIZERP.formId + ' .newLine').css('display', 'none');
  // $(LIZERP.formId + ' .saveLineAndNew').css('display', 'none');
  // $(LIZERP.formId + ' .copyAndNewLine').css('display', 'none');
  // $(LIZERP.formId + ' .removeLine').css('display', 'none');
}



LIZERP.editMode_clickFromUpperBtn = function() {

  $(LIZERP.formId + ' #formLines tr').hover(function(e) {
    $(this).find('.div_editButton').css('display', 'block');
  }, function(e) {
    $(this).find('.div_editButton').css('display', 'none');
  });
  $(LIZERP.formId).find('input,select,textarea').removeAttr('disabled');
  LIZERP.lockCreateOnlyFields();
  $(LIZERP.formId + '#fieldset_systeminformation').css('display', 'none');
  $(LIZERP.formId + ' .btnEditMode ').css('display', 'inline-block');
  $(LIZERP.formId + ' .btnReadMode ').css('display', 'none');

  $(LIZERP.formId).find('.saveLine').attr('disabled', 'disabled');
  $(LIZERP.formId).find('.saveLineAndNew').attr('disabled', 'disabled');

  $(LIZERP.formId).find('.copyAndNewLine').attr('disabled', 'disabled');
  $(LIZERP.formId).find('.removeLine').attr('disabled', 'disabled');
  $(LIZERP.formId).find('.btnCancelDocLine').attr('disabled', 'disabled');
  
  LIZERP.controlLineButtons();
  // added 2017-05-03
  $(LIZERP.formId).find('#formLinesButtonsBr').empty().append('<br/>');

  LIZERP.formMode = 'edit';
}

/**
 * Document RR line send to textile
 */
$('.btnSentTextile').click(function(){

  var r = confirm( 'Are you want to send it to textile ?' );
  if(!r) return;
  var params = paramsToObj(window.location.search);
  docnumber = params.docnumber;

  $('#fieldset_lineinformation table tbody tr').each(function(){
    rrnumber = $(this).find('td.rrnumber input').val();
    console.log(rrnumber);

    if(!!!LIZERP.selectedLineInfo){
      LIZERP.selectedLineInfo  = {};
      LIZERP.selectedLineInfo.rrnumber = [];
    }

    LIZERP.selectedLineInfo.rrnumber.push(rrnumber); 
  });

  var mType    = 'post';
  var mUrl     = LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM];
  var mReqType = "senttoTextile";
  var postData = JSON.stringify({
    rrnumber  : LIZERP.selectedLineInfo.rrnumber,
    docnumber : docnumber 
  });
  var returnData = jsClient.communicationToServer(mReqType, postData, mUrl, mType, false);

  returnData = JSON.parse(returnData);
  console.log(returnData.result);

  if(returnData.result == 'success'){
    // var msgString  = 'success:: Successfully sent it to textile.';
    // jsClient.msgDisplayer(msgString); // green
    // delete(LIZERP.selectedLineInfo);
    location.reload();
  } 

});


/**
 * Locks all fields that are auto fillup
 */
LIZERP.lockAutoFillupFields = function() {
  var fieldList = LIZERP._FIELDS_AUTOFILLUP;
  for (field in fieldList) {
    console.log('--------------->' + fieldList[field]);
    $(LIZERP.formId).find('input,textarea,select').filter('#' + fieldList[field]).attr('disabled', 'disabled');
  }
}



/**
 * Remove a line
 * @param line
 */
LIZERP.removeLine = function(line) {
  var idlines           = $(LIZERP.formId).find('input#lg_idlines').val();
  if (confirm('Are you sure to delete line ' + line + '?')) {
    $(LIZERP.formId + ' #formLines tr[data-id="' + line + '"]').remove();
    LIZERP.removePOLine(idlines);
    LIZERP.cancelLine();
  }
}

LIZERP.removePOLine = function(idlines) {

      var postData = {
        reqType: 'removePOLine',
        idlines: idlines
       };
      $.ajax({
        type: 'post',
        url: 'docpo_api.php',
        data: postData,
        success: function(data) {
            data = JSON.parse(data);
            if (!!data.errormsgs && data.errormsgs.length > 0) {
              console.log(data.errormsgs.join('\n'));
              alert("===>"+data.errormsgs.join('\n'));
            } else {
              // parent.location.reload(true);
            }
        }
      }).fail(function(e) {
        alert('Assign failed, please try again.');
      });
}



LIZERP.initRightFormLines = function() {
    // $(LIZERP.formId+' #formLinesContainer #rightFormLines').find('#lg_rrnumber')
    // .hover(function(e) {
    //   LIZERP.searchLoupe_show_forHeaderField(this);
    // }, function(e) {
    //   atop = $(this).offset().top;
    //   aleft = $(this).offset().left;
    //   abottom = atop + parseFloat($(this).css('height').replace('px', ''));
    //   aright = aleft + parseFloat($(this).css('width').replace('px', ''));
    //   if (atop > e.pageY || abottom < e.pageY || aleft > e.pageX || aright < e.pageX) LIZERP.searchLoupe_hide();
    // });


    $(LIZERP.formId+' #formLinesContainer #rightFormLines').find('#lg_requisitionlinenumber')
    .focus(function() {
      LIZERP.valAtFocus = $(this).val();
    })
    .blur(function() {
      LIZERP.valAtFocus = $(this).val();
      LIZERP.getRRLineInfo(LIZERP.valAtFocus);
    });

}


LIZERP.newLine = function(){

  $('#rightFormLines').css('display', 'block');
  LIZERP.adjustLineFormInterface();
  LIZERP.cleanLineEntryForm();
  LIZERP.initRightFormLines();

  $(LIZERP.formId).find('.saveLine').removeAttr('disabled');
  $(LIZERP.formId).find('.saveLineAndNew').removeAttr('disabled');

  $(LIZERP.formId).find('.copyAndNewLine').attr('disabled', 'disabled');
  $(LIZERP.formId).find('.removeLine').attr('disabled', 'disabled');
  $(LIZERP.formId).find('.btnCancelDocLine').attr('disabled', 'disabled');

  delete LIZERP.newLineNumber;
  // it will take from table tr length
  // so delete it which is one step above now

  $(LIZERP.formId + ' #rightFormLines').find('input,select,textarea').removeAttr('disabled');
  // alert('aa');

}


LIZERP.showParentPO = function(){
  var params = paramsToObj(window.location.search);
  previousponumber = $(LIZERP.formId + ' #fieldset_documentinformation').find('input#previousponumber').val();
  
  window.open(window.location.origin + window.location.pathname + '?docnumber=' + previousponumber + '&doctype=' + params.doctype + '&formtype='+params.formtype );
}




/**
* Auto URL fillup document line
*/
//  $.when.apply($, populatePromises).then(function() {
//   var params = jsClient.paramsToObj(window.location.search); 
//   var idlines = params.idlines;
//   if(!!idlines){
//     LIZERP.isgetPOLineInfo = true; 
//     LIZERP.getPOLineInfo();
//     LIZERP.getSOInfo();
//   } else {
//     LIZERP.isgetPOLineInfo = false;
//   }    
// });



LIZERP.getRRLineInfo = function(requisitionlinenumber){


  var firstRowSupplier = $('#fieldset_documentinformation').find('.formGroup input[name=suppliername]').val();
  var firstRowCurrency = $('#fieldset_documentinformation').find('.formGroup input[name=currency]').val();
  var firstRowProcurer = $('#fieldset_documentinformation').find('.formGroup input[name=purchasemode]').val();
  var firstRowCompany = $('#fieldset_documentinformation').find('.formGroup select[name=company]').val();


  var searchParams = {
    'reqType': 'getRRLineInfo',
    'requisitionlinenumber': requisitionlinenumber
  };

  var mType = 'get';
  var mUrl     = "docpo_api.php";
  var mReqType = "";
  var returnData = jsClient.communicationToServer(mReqType, searchParams, mUrl, mType, false);

  $(LIZERP.formId + ' #rightFormLines :input').prop("disabled",false);
  // $(LIZERP.formId + ' #rightFormLines .btnEditMode').prop("disabled",false);
  // $(LIZERP.formId + ' #rightFormLines #lg_requisitionlinenumber').prop("disabled",false);


  if (returnData.length > 0) {
    data = JSON.parse(returnData);



    var getSupplier = data[0]['suppliername'];
    var getCurrency = data[0]['currency'];
    var getProcurer = data[0]['purchasemode'];
    var getCompany = data[0]['company'];

    if(getSupplier != firstRowSupplier){
      alert('Supplier Name must be same.');
      $(LIZERP.formId + ' #rightFormLines :input').val("");
      return;

    }else if(getCurrency != firstRowCurrency){
      alert('Currency must be same.');
      $(LIZERP.formId + ' #rightFormLines :input').val("");
      return;
      
    }else if(getProcurer != firstRowProcurer){
      alert('Procurer must be same.');
      $(LIZERP.formId + ' #rightFormLines :input').val("");
      return;
      
    }else if(getCompany != firstRowCompany){
      alert('Division must be same.');
      $(LIZERP.formId + ' #rightFormLines :input').val("");
      return;
      
    }


    $(LIZERP.formId + '#lg_itemcode').val(data[0]['itemcode']);
    $(LIZERP.formId + '#lg_itemcode').attr('disabled','disabled');

    $(LIZERP.formId + '#lg_itemname').val(data[0]['itemname']);
    $(LIZERP.formId + '#lg_itemname').attr('disabled','disabled');

    $(LIZERP.formId + '#lg_itemdescription').val(data[0]['itemdescription']);
    $(LIZERP.formId + '#lg_itemdescription').attr('disabled','disabled');

    $(LIZERP.formId + '#lg_requisitionlinenumber').val(data[0]['doclinenumber']);
    // $(LIZERP.formId + '#lg_requisitionlinenumber').attr('disabled','disabled');
    
    $(LIZERP.formId + '#lg_extracost').val(data[0]['extracost']);
    $(LIZERP.formId + '#lg_extracost').attr('disabled','disabled');
    
    $(LIZERP.formId + '#lg_deliverydate').val(data[0]['deliverydate']);
    $(LIZERP.formId + '#lg_deliverydate').attr('disabled','disabled');
    
    $(LIZERP.formId + '#lg_orderqty').val(data[0]['orderqty']);
    $(LIZERP.formId + '#lg_orderqty').attr('disabled','disabled');
    
    $(LIZERP.formId + '#lg_sizeormeasurement').val(data[0]['sizeormeasurement']);
    $(LIZERP.formId + '#lg_sizeormeasurement').attr('disabled','disabled');
    
    $(LIZERP.formId + '#lg_brand').val(data[0]['brand']);
    $(LIZERP.formId + '#lg_brand').attr('disabled','disabled');

    $(LIZERP.formId + '#lg_iduom').val(data[0]['iduom']);
    $(LIZERP.formId + '#lg_iduom').attr('disabled','disabled');
    
    $(LIZERP.formId + '#lg_costdept').val(data[0]['costdept']);
    $(LIZERP.formId + '#lg_costdept').attr('disabled','disabled');
    
    $(LIZERP.formId + '#lg_costcenter').val(data[0]['costcenter']);
    $(LIZERP.formId + '#lg_costcenter').attr('disabled','disabled');
    
    $(LIZERP.formId + '#lg_amountwithoutdiscount').val(data[0]['amountwithoutdiscount']);
    $(LIZERP.formId + '#lg_amountwithoutdiscount').attr('disabled','disabled');
    
    $(LIZERP.formId + '#lg_discountamount').val(data[0]['discountamount']);
    $(LIZERP.formId + '#lg_discountamount').attr('disabled','disabled');
    
    $(LIZERP.formId + '#lg_amount').val(data[0]['amount']);
    $(LIZERP.formId + '#lg_amount').attr('disabled','disabled');
    
    $(LIZERP.formId + '#lg_currency').val(data[0]['currency']);
    $(LIZERP.formId + '#lg_currency').attr('disabled','disabled');
    
    $(LIZERP.formId + '#lg_color').val(data[0]['color']);
    $(LIZERP.formId + '#lg_color').attr('disabled','disabled');
    
    $(LIZERP.formId + '#lg_capexno').val(data[0]['capexno']);
    $(LIZERP.formId + '#lg_capexno').attr('disabled','disabled');
    
    $(LIZERP.formId + '#lg_unitprice').val(data[0]['unitprice']);
    $(LIZERP.formId + '#lg_unitprice').attr('disabled','disabled');
    
    $(LIZERP.formId + '#lg_linesremarks').val(data[0]['linesremarks']);
    $(LIZERP.formId + '#lg_linesremarks').attr('disabled','disabled');

   
  }




}




LIZERP.autoRevisedPO = function(){

  var params = paramsToObj(window.location.search);
  docnumber = params.docnumber;

  var searchParams = {
    'reqType': 'autoRevisedButtonVisibility',
    'docnumber': docnumber
  };

  var mType = 'get';
  var mUrl     = "docpo_api.php";
  var mReqType = "";
  var returnData = jsClient.communicationToServer(mReqType, searchParams, mUrl, mType, false);

  if(returnData == '1'){
    $(LIZERP.formId + ' .btnAutoRevised').css('display', 'inline-block');
  }else{
    $(LIZERP.formId + ' .btnAutoRevised').css('display', 'none');
  }

}




/**
 * [autoFillup_byURLParams description]
 * @return {[type]} [description]
 */
LIZERP.autoFillup_byURLParams = function(){
  // need to make dependency for auto line fillup
  // this for header data auto fillup
  var params = jsClient.paramsToObj(window.location.search);
  if(!!!params.idlines) return;

  var populateFunctions = $.when(
    LIZERP.getSOInfo()    
  );
  populateFunctions.then(function() {                 
    if(!!params.idlines){
      LIZERP.isgetPOLineInfo = true; 
      LIZERP.getPOLineInfo();
    } else {
      LIZERP.isgetPOLineInfo = false;
    }         
  });
  return;
}

/**
 * [autoFillup_newRR description]
 * @return {[type]} [description]
 */
LIZERP.autoFillup_newRR = function(){
  // need to make dependency for auto line fillup
  // this for header data auto fillup
  var params = jsClient.paramsToObj(window.location.search);
  var populateFunctionsAddRR = $.when(
  );

  populateFunctionsAddRR.then(function() {                 
    
    LIZERP.getAdditionalRRPOLineInfo();         
  });
  return;
}

LIZERP.poCancelLine = function(idlines){
  console.log(idlines);
  var searchParams = {};
  searchParams.idlines = idlines;
  searchParams.reqType = 'cancelPOLine';
  return $.post(LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM], searchParams, cancelPOLine_return(), 'json');

  function cancelPOLine_return(extraParams) {
    return function(data, textStatus, jqXHR) {
      console.log(data);
      if (data.result == 'success') {
        location.reload();
      } else {
        alert(data.errormsgs.join('\n'));
      }
    }
  }
}


LIZERP.poDeleteLine = function(idlines){
  console.log(idlines);
  var searchParams = {};
  searchParams.idlines = idlines;
  searchParams.reqType = 'deletePOLine';
  return $.post(LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM], searchParams, deletePOLine_return(), 'json');

  function deletePOLine_return(extraParams) {
    return function(data, textStatus, jqXHR) {
      console.log(data);
      // if (data.result == 'success') {
      //   location.reload();
      // } else {
      //   alert(data.errormsgs.join('\n'));
      // }
    }
  }
}



LIZERP.sendToTextile = function(){

  var params = paramsToObj(window.location.search);
  if (!params.docnumber) {
    alert('Error: iddocument not available. Please tell ERP department.');
    return;
  }

  var r = confirm('Are you sure want to send this PO to NOW?');
  if(!r)return;

  var searchParams = {};
  searchParams.docnumber = params.docnumber;
  // return $.post('/connector_erp_to_db2-so-import/erp_to_db2-so-import.php', searchParams, sendToWMS_return(), 'json');
  return $.post('/connector_erp_to_db2-so-import/erp_to_db2-so-import.php', searchParams, sendToWMS_return());

  function sendToWMS_return(extraParams) {

    return function(data, textStatus, jqXHR) {
      console.log(data);
      data = JSON.parse(data);
      if (data.result == 'success') {
        location.reload();
      } else {
        alert(data.errormsgs.join('\n'));
      }
    }
  }

}

LIZERP.autoFillTermsAndCondition = function(){

  $('#formERP #termsandcondition').val('1. Payment: A/C Payee Cheque will be issued within 30days after delivery the goods in favour of ""\n2. VAT & TAX : As Per Govt Rules\n3. Delivery Terms: A. EXW B. Door to Door delivery at suppliers transport cost.\n4. Required Delivery: Supplier shall comply with Buyers required delivery date stated above, or as per the delivery schedule mutually agreed in writing.\n5. Quality Requirements: The supplier shall comply with the Quality requirements and deliver according to, and meet, buyers standards or otherwise as agreed in writing.\n6. Warranty/After Sales Service:\n7. Documents Requirements: Suppliers Bill/Invoice together with Challan shall clearly state the Non PO Ref.No. for a smooth processing or payment to be done by buyer.\n8. Claim Terms & Cancellation: Buyer reserve the full right to require supplier for making replenish/free replacement at its own cost or even terminate the order or any part thereof any time without any responsibility in case of late delivery, short quantity and poor quality or service; meanwhile, the supplier shall be responsible for any economic loss arising herein.');
}




$.extend(LIZERP, {
  /**
   * Start up function
   * @description Any JS code to be run on start up
   * @returns {undefined}
   */



   init: function() {
    /* executable JS */
    return;
  },
  enableRead: function() {
    LIZERP.readMode();
    return;
  },
  enableEdit: function() {
    LIZERP.editMode();
    return;
  },
  enableReceive: function() {
    LIZERP.receiveMode();
    return;
  },

  /**
   * Process Purchase Request Form
   * @param selector formId
   * @returns {undefined}
   */
   processForm: function(purchaseFormId, _ERP_DOCACRONYM, _URL_DOCUMENTAPI, _URL_DOCDEFINEAPI) {
    LIZERP.formId = purchaseFormId + ' ';
    LIZERP.formMode = 'edit';
    LIZERP._ERP_DOCACRONYM = _ERP_DOCACRONYM;
    LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM] = _URL_DOCUMENTAPI;
    LIZERP._URL_DOCDEFINEAPI[LIZERP._ERP_DOCACRONYM] = _URL_DOCDEFINEAPI;
    if(!LIZERP.newLineNumber) LIZERP.newLineNumber = 1;

    var populatePromises = [];
    populatePromises.push(LIZERP.populateDropdown('customer', 'Buyer'));
    populatePromises.push(LIZERP.populateDropdown('endcustomer', 'Buyer'));

    populatePromises.push(LIZERP.populateDropdown('itemtype', 'itemtype_PO_NONPO'));
    populatePromises.push(LIZERP.populateDropdown('lg_itemtype', 'itemtype_PO_NONPO'));
    
    populatePromises.push(LIZERP.populateDropdown('iduom', 'UOM'));
    populatePromises.push(LIZERP.populateDropdown('lg_iduom', 'UOM'));
    populatePromises.push(LIZERP.populateDropdown('orderqtycondition', 'YesNo'));
    populatePromises.push(LIZERP.populateDropdown('lg_orderqtycondition', 'YesNo'));
    
    populatePromises.push(LIZERP.populateDropdown('company', 'company'));
    populatePromises.push(LIZERP.populateDropdown('lg_company', 'company'));

    populatePromises.push(LIZERP.populateDropdown('currency', 'Currency'));
    populatePromises.push(LIZERP.populateDropdown('lg_currency', 'Currency'));


    // populatePromises.push(LIZERP.populateDropdown('itemnature', 'NonPOItemNature', '', 'codevalequal'));
    // populatePromises.push(LIZERP.populateDropdown('lg_itemnature', 'NonPOItemNature', '', 'codevalequal'));

    // populatePromises.push(LIZERP.populateDropdown('brand', 'NonPOBrand', '', 'codevalequal'));
    // populatePromises.push(LIZERP.populateDropdown('lg_brand', 'NonPOBrand', '', 'codevalequal'));

    // populatePromises.push(LIZERP.populateDropdown('color', 'NonPOColor', '', 'codevalequal'));
    // populatePromises.push(LIZERP.populateDropdown('lg_color', 'NonPOColor', '', 'codevalequal'));

    // populatePromises.push(LIZERP.populateDropdown('itemname', 'NonPOitemname', '', 'codevalequal'));
    // populatePromises.push(LIZERP.populateDropdown('lg_itemname', 'NonPOitemname', '', 'codevalequal'));
    
    $.when.apply($, populatePromises).then(function() {
      // Caches the HTML of a new line
      LIZERP.lineHTML_template = $('#fieldset_lineinformation table tr[data-id=1]')[0].outerHTML;
      LIZERP.adjustLineFormInterface();
    });

    LIZERP.handle_docdate_field();
    /* Show/Hide/Enable/Disable fields on document load */
    populatePromises.push(LIZERP.handleFormFields('create'));
    $.when.apply($, populatePromises).then(function() {}); 

    // Change line legend name
    $('#fieldset_documentinformation legend').text('Header');
    $('#formLines #legend').text('Purchase Line');





    LIZERP.initHead();
    LIZERP.initLine(); // Enables functionality of the Line entry
    LIZERP.editMode();      


    $(window).keydown(function(e) {
      if (e.ctrlKey || e.metaKey) {
        switch (String.fromCharCode(e.which).toLowerCase()) {
          case 's':
          e.preventDefault();
          $(LIZERP.formId + ' .btnSaveForm').click();
          break;
        }
      }
    });



    $(LIZERP.formId + ' .btnSaveForm').on('click', function(e) {
      e.preventDefault();
      LIZERP.saveForm();
    });     

    $(LIZERP.formId + ' .btnCancelForm').on('click', function(e) {
      e.preventDefault();
      var params = paramsToObj(window.location.search);
      if (!!params.docnumber) location.reload();
    });

    $(' .btnEnterEditMode').on('click', function(e) {
      e.preventDefault();
      LIZERP.editMode_clickFromUpperBtn();
      LIZERP.editLineMode = true;
      LIZERP.newLineMode = false;
    });

$(LIZERP.formId + ' .btnSendToTextile').on('click', function(e) {
  e.preventDefault();
  LIZERP.sendToTextile();
});


    // $(LIZERP.formId + ' .btnConfirmation').on('click', function(e) {
    //   e.preventDefault();
    //   LIZERP.reviewAndApproveDoc(LIZERP.docobj);
    // });
    
    $(LIZERP.formId + ' .btnPrintSheet').on('click', function(e) {
      e.preventDefault();
      var params = paramsToObj(window.location.search);
      window.open('printdoc-v3.php?doctype=' + params.doctype + '&formtype='+params.formtype+'&docnumber=' + params.docnumber);
    });
    


    // $(LIZERP.formId + ' .btnChangeDocStatus').on('click', function(e) {
    //   e.preventDefault();
    //   var params = paramsToObj(window.location.search);
    //   var r = confirm('Click OK to close this document.');
    //   if(!r) return;
    //   LIZERP.changeDocStatus(params.docnumber, '1');
    // });

$(LIZERP.formId + ' .btnSendRequest').on('click', function(e) {
  e.preventDefault();
  var params = paramsToObj(window.location.search);
  if (!params.docnumber) {
    alert('Error: iddocument not available. Please contact system.support@lizfashion.com.');
    return;
  }
  if (confirm('Click OK to send to request')) LIZERP.changeDocStatus(params.docnumber, '1');
});



$(LIZERP.formId + ' .btnAmend').on('click', function(e) {
  e.preventDefault();
  var params = paramsToObj(window.location.search);
  if (!params.docnumber) {
    alert('Error: iddocument not available. Please contact system.support@lizfashion.com.');
    return;
  }
  if (confirm('Click OK to Amend the PO')) LIZERP.poAmendment(params.docnumber, '0');
});


$(LIZERP.formId + ' .btnAutoRevised').on('click', function(e) {
  e.preventDefault();
  var params = paramsToObj(window.location.search);
  if (!params.docnumber) {
    alert('Error: iddocument not available. Please contact system.support@lizfashion.com.');
    return;
  }
  if (confirm('Click OK to PO Revised auto update')) LIZERP.updateRevisedPO(params.docnumber);
});

$(LIZERP.formId + ' .btnFileAttachment').on('click', function(e) {
  e.preventDefault();
  LIZERP.fileAttachmentMode();
});


$(LIZERP.formId + ' .btnCopyAndNew').on('click', function(e) {
  e.preventDefault();
  var params = paramsToObj(window.location.search);
  window.open(window.location.origin + window.location.pathname + '?docnumber=' + params.docnumber + '&doctype=' + params.doctype + '&formtype='+params.formtype+"&docflag=copyandnew" );
});

$(LIZERP.formId + ' .btnInformApparelPlanner').on('click', function(e) {
  e.preventDefault();
  // LIZERP.approvePreviewDoc();
  LIZERP.reviewAndApproveDoc(LIZERP.docobj);
  // var params = paramsToObj(window.location.search);
  // if (confirm('Are you sure to Inform Apparel Planner?')) LIZERP.changeDocStatus(params.docnumber, '2');
});


$(LIZERP.formId + ' .newLine').on('click', function(e) {
  e.preventDefault();
  $(LIZERP.formId).find('.newLine').attr('disabled', 'disabled');
  LIZERP.newLineMode = true;
  LIZERP.editLineMode = false;
  LIZERP.newLine();
});

$(LIZERP.formId + ' .saveLine').on('click', function(e) {
  e.preventDefault();
  if(!!LIZERP.currentLineNumber && LIZERP.editLineMode && !LIZERP.newLineMode){

    LIZERP._saveLine(LIZERP.currentLineNumber);
  } else {

    LIZERP._saveLine();
  }
  LIZERP.cleanLineEntryForm();
  LIZERP.handleFormLinesTrClick();
  $(LIZERP.formId).find('.newLine').removeAttr('disabled');

});

$(LIZERP.formId + ' .saveLineAndNew').on('click', function(e) {
  e.preventDefault();
  if(!!LIZERP.currentLineNumber && LIZERP.editLineMode && !LIZERP.newLineMode){

    LIZERP.newLineMode = true;
    LIZERP.editLineMode = false;

    LIZERP._saveLineAndNew(LIZERP.currentLineNumber);
  } else {

    LIZERP._saveLineAndNew();
  }
  LIZERP.cleanLineEntryForm();
  LIZERP.handleFormLinesTrClick();
});

// $(LIZERP.formId + ' .copyAndNewLine').on('click', function(e) {
//   e.preventDefault();
//   LIZERP.copyAndNewLine();

// });

$(LIZERP.formId + ' .cancelLine').on('click', function(e) {
  e.preventDefault();
  LIZERP.cancelLine();

      // save form in  db
      // LIZERP.saveForm();
    });

$(LIZERP.formId + ' .removeLine').on('click', function(e) {
  e.preventDefault();
  if(!!!LIZERP.currentLineNumber) return;
  if (confirm('Click OK to Delete the PO Line')) LIZERP.poDeleteLine(LIZERP.currentLineidlines);
  LIZERP.removeLine(LIZERP.currentLineNumber);
});


$(LIZERP.formId + ' .btnCancelDocLine').on('click', function(e) {
  e.preventDefault();
  if(!!!LIZERP.currentLineidlines) return;
  if (confirm('Click OK to Cancel the PO Line')) LIZERP.poCancelLine(LIZERP.currentLineidlines);
});


$(LIZERP.formId + ' .btnParentPO').on('click', function(e) {
  e.preventDefault();
  LIZERP.showParentPO();
});

// LIZERP.initHead();
//     LIZERP.initLine(); // Enables functionality of the Line entry
//     LIZERP.editMode();

    // If the page was called with a document ID, try to read the record
    var params = paramsToObj(window.location.search);
    if (!!params.docnumber) {
      var searchParams = {
        'reqType': 'readDoc',
        'docnumber': params.docnumber
      };
      $.when.apply($, populatePromises).then(function() {
        $.get(LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM], searchParams, populateFromDb);
      });

    } else {
        LIZERP.editMode('nodoc');
        $.when.apply($, populatePromises).then(function() {
          /**
          * remove processing overlay */
          LIZERP.removeProcessingOverlay_2();
          LIZERP.autoFillTermsAndCondition();   
          /*
          *
          **/
        });
    }

    function populateFromDb(data, textStatus, jqXHR) {
      // alert(data);
      LIZERP.docobj = data;
      data = JSON.parse(data);
      var lines = data.lines;
      delete data.lines;
      if (Object.keys(data).length > 0) {
        $.when.apply($, populatePromises).then(function() {
          LIZERP.editMode('populateFromDb');
          LIZERP.fillForm(data, lines);
          LIZERP.updateFormTitle('read');
          LIZERP.readMode();
          LIZERP.handleFormLinesTrClick();
          LIZERP.checkCopyAndNewDocFlag();  
          LIZERP.autoLineFill_Save_Edit();    
          window.scrollTo(0, 0);

          /**
          * remove processing overlay */
          LIZERP.removeProcessingOverlay_2(); /*
          *
          **/

        });
      } else {
        LIZERP.editMode();
        alert('Document not found.');
      }
    }

    /**
     * Auto URL fillup document header
     * Auto URL fillup document line
     *
     * this for all library data populate 
     */
    $.when.apply($, populatePromises).then(function() {
      // when all things are populate, then call
      LIZERP.autoFillup_byURLParams();
      
    });

    /**
     * LIZERP.autoFillup_afterPopulateFromDb();
     */




     return;
   }
 });