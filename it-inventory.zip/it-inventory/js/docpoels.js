/**
 * Declare the namespace LIZERP if not existent
 */
var LIZERP = LIZERP || {};

$.extend(LIZERP, {
  _ERP_DOCACRONYM: '',
  _FIELDSETS_HEADER: ['fieldset_documentinformation', 'fieldset_logisticsinformation'],

  _FIELDS_CREATEONLY: ['purchasemode','suppliername','supplieraddress','currency','totalamountwords','company','totalamount','docdate','ponettotal'],

  foo: 'here for no reason other than to be the last line, without a comma'
});


LIZERP.readURL_4 = function(input, container, width, height) {
  if( container.is(":visible") ){
  } else {
    container.css({'display':'block'});
  }
  for (var i = 0; i < input.files.length; i++) {
    LIZERP.multipleImagePreview(input, container, width, height, i);
  }
}


LIZERP.multipleImagePreview = function(input, container, width, height, i){

    var d = new Date();
    var s = d.getSeconds();
    var m = d.getMinutes();
    var ms = m+s+i;

    var imgContainerID = "#previewIMG"+ms;
    var pdfContainerID = "#previewPDF"+ms;
    var othContainerID = "#previewOTH"+ms;
    var fileNameContainerID = "#fileName"+ms;
    var previewHolderID = "#previewHolder"+ms;

    var imgContainer = '<img style="float:left" id="previewIMG'+ ms +'" src="#" alt="preview"/>';
    var pdfContainer = '<iframe id="previewPDF'+ ms +'" frameborder="1" scrolling="" width="50" height="50"></iframe>';
    var othContainer = '<label style="float:left" id="previewOTH'+ ms +'"></label>';
    var fileNameContainer = '<label style="display: inline-block; width: 60px;  white-space: nowrap;  overflow:hidden !important; text-overflow: ellipsis;" id="fileName'+ ms +'"></label><br>';    

    var previewHolder = '<div style="float:left; border: 1px solid gray;" id="previewHolder'+ ms +'"></div>'; 
      
  if (input.files && input.files[i]) {

    var file = input.files[i];
    var fileName = file.name;

    var ext = fileName.substr(fileName.lastIndexOf('.') + 1);
    if(ext == "pdf"){
      container.append(previewHolder);
      $(previewHolderID).append(fileNameContainer);
      $(previewHolderID).append(pdfContainer);
    } else if(ext == "xlsx" || ext == "doc" || ext == "docx"|| ext == "xlsx"){
      container.append(previewHolder);
      $(previewHolderID).append(othContainer);
    } else {
      container.append(previewHolder);
      $(previewHolderID).append(fileNameContainer);     
      $(previewHolderID).append(imgContainer);
    }

      var reader = new FileReader();
      reader.onload = function (e) {
        if(ext == "pdf"){
            $(pdfContainerID)
              .attr('src', e.target.result)
              .width(200)
              .height(height);
          $(fileNameContainerID).text(fileName);
        } else if(ext == "xlsx" || ext == "doc" || ext == "docx"|| ext == "xlsx"){
            $(othContainerID).text(fileName);
        } else {      
            $(imgContainerID)
              .attr('src', e.target.result)
              .width(width)
              .height(height);
            $(fileNameContainerID).text(fileName);
        }

      };
      reader.readAsDataURL(input.files[i]);
  }

}


LIZERP.fileAttachmentMode = function() {  

  if (!$(LIZERP.formId + ' .btnFileAttachment').hasClass('btn-orange')) {
    $(LIZERP.formId + ' .btnFileAttachment').removeClass('btn-grey');
    $(LIZERP.formId + ' .btnFileAttachment').addClass('btn-orange');

    // for line
    $(LIZERP.formId).find(' #formLines tr .fileAttachmentContainer').css('display', 'block');
    $(LIZERP.formId).find(' #formLines tr .fileAttachmentContainer .fileInputContainer').css('display', 'block');
    $(LIZERP.formId).find(' #formLines tr .fileAttachmentContainer .fileInputContainer input').removeAttr('disabled');
    $(LIZERP.formId).find(' #formLines tr .fileAttachmentContainer .label').remove();

    // for header
    $(LIZERP.formId).find(' #fieldset_documentfile .fileAttachmentContainer').css('display', 'block');
    $(LIZERP.formId).find(' #fieldset_documentfile .fileAttachmentContainer .fileInputContainer').css('display', 'block');
    $(LIZERP.formId).find(' #fieldset_documentfile .fileAttachmentContainer .fileInputContainer input').removeAttr('disabled');
    $(LIZERP.formId).find(' #fieldset_documentfile .fileAttachmentContainer .label').remove();    

  } else {
    $(LIZERP.formId + ' .btnFileAttachment').removeClass('btn-orange');
    $(LIZERP.formId + ' .btnFileAttachment').addClass('btn-grey');
    parent.location.reload(true);
  }

}


LIZERP.fileUploader = function(formData){

  $.ajax({
    url : LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM],
    type : 'POST',
    data : formData,
    processData: false,  // tell jQuery not to process the data
    contentType: false,  // tell jQuery not to set contentType
    success : function(data) {
       console.log("-->"+data);
    }
  });

}


LIZERP.uploadFile = function(input){
  // show file preview
  var fieldname      = $(input).closest('td').attr('class');
  var container    = $(input).closest('tr').find('td.'+ fieldname +' .fileAttachmentContainer .fileViewerContainer');
  LIZERP.readURL_4(input, container, '50', '50');

  // first check this button is in under header or line?
  var className = $(input).parent().prop('className');
  // alert(className);
  // if(className == 'formGroup'){ // header
  if($(input).parents('.formGroup').length){ // header

    var docnumber     = $(LIZERP.formId + ' #docnumber').val();
    var directoryPath = "/attachments/template/"+ docnumber +"/" + docnumber;

    var formData = new FormData();
    for (var i = 0; i < input.files.length; i++) {
        if (input.files && input.files[i]) {
            var file = input.files[i];
            var fileName = file.name;
        }
        formData.append('file_'+i, file);
    }

    formData.append('docnumber', docnumber);
    formData.append('directorypath', directoryPath);
    formData.append('filepathsavingcolumnname', 'docfilepaths');

  } else {

    // linefilepaths
    var fileUploadType = $(input).closest('td').attr('class');
    if(fileUploadType == 'linefilepaths'){

      var linenumber    = $(input).closest('tr').find('td.linenumber input').val();
      var docnumber     = $(LIZERP.formId + ' #docnumber').val();
      var directoryPath = "/attachments/template/"+ docnumber +"/" + docnumber + "-" + linenumber;

      var formData = new FormData();
      for (var i = 0; i < input.files.length; i++) {
          if (input.files && input.files[i]) {
              var file = input.files[i];
              var fileName = file.name;
          }
          formData.append('file_'+i, file);
      }

      formData.append('linenumber', linenumber);
      formData.append('docnumber', docnumber);
      formData.append('directorypath', directoryPath);
      formData.append('filepathsavingcolumnname', 'linefilepaths');

    } 

  }


  formData.append('reqType', 'uploadFile');
  LIZERP.fileUploader(formData);

}


LIZERP.deleteFile = function (thisL, filePath, fieldname){
  // remove file from container
  var idlines        = $(thisL).closest('tr').find('td.idlines input').val();
  var fieldname      = $(thisL).closest('td').attr('class');
  var fileDeleteType = $(thisL).closest('td').attr('class');

  if(fileDeleteType == "linefilepaths"){
    var keycolumnname = 'idlines';
  } else if(fileDeleteType == "costingsheet"){
    var keycolumnname = 'idlines';
  }

  $.ajax({
      type: 'POST',
      data: {
          reqType: 'deleteFile',
          filePath: filePath,
          filepathcolumnname: fieldname,
          keycolumnname: keycolumnname,
          keycolumnvalue: idlines
      },
      url: LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM],
      success: function(msg) {
          console.log("------>"+msg)
            var fieldname      = $(thisL).closest('.fileViewerBox').empty();
      },
      error: function(){
          alert("error");
      }
  }); 

}


//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
LIZERP.adjustLineFormInterface = function(){
  /**
   * Make ratio later
   */
  if( $(LIZERP.formId + ' #rightFormLines').is(":visible") ){

    var windowWidth = $(window).width();
    var windowWidth_I = parseInt(windowWidth);
    var minusLeft, minusRight;
    if(windowWidth_I < 1400){
      minusLeft = 250;
      minusRight = 150;
    } else if(windowWidth_I < 2000){
      minusLeft = 380;
      minusRight = 200;
    }
    console.log('-<>'+windowWidth + '---' + minusLeft + '----' + minusRight);

    // var leftFormLinesWidth = (windowWidth/2) - minusLeft;
    // var rightFormLinesWidth = (windowWidth/2) - minusRight;

    var leftFormLinesWidth = ((windowWidth*35)/100) - minusLeft;
    var rightFormLinesWidth = ((windowWidth*65)/100) - minusRight;

    $('#leftFormLines').css({
      'max-width': leftFormLinesWidth+'pt',  
      'float':'left',
      'z-index': '0',
      'display': 'block',
    });
    
    $(LIZERP.formId + ' #leftFormLines table').css({
      'z-index': '0'    
    });

    $('#rightFormLines').css({
      'max-width': rightFormLinesWidth+'pt', 
      'float':'left',
      'margin-top': '15pt',
      'z-index': '1',
      'position': 'relative',
      'background-color':'white'
    });

    var rightFormDivHeight = $('#rightFormLines').height();
    $(LIZERP.formId + ' #rightFormLines #dragbar').css({
      'height': rightFormDivHeight,
      'background-color': 'black',
      'float': 'left',
      'width': '2pt',
      'cursor': 'col-resize'
    });

  } else {

    // var w = window.innerWidth;
    var fieldset_documentinformationWidth = $('#fieldset_documentinformation').width();
    fieldset_documentinformationWidth = fieldset_documentinformationWidth + 20;
    $('#formLinesFieldset').css({
      'min-width': fieldset_documentinformationWidth+'px',  
    });


    var windowWidth = $(window).width();
    var leftFormLinesWidth = (windowWidth) - 30;
    $('#leftFormLines').css({
      'max-width': leftFormLinesWidth+'pt', 
      'width': '100%',      
      'float':'left',
      'z-index': '0',
      'display': 'block',
    });
    
    $(LIZERP.formId + ' #leftFormLines table').css({
      'z-index': '0'    
    });

  }



}


LIZERP.readMode = function() {
  $(LIZERP.formId).find(' #formLines tr.new').remove();
  $(LIZERP.formId).find(' #formLines tr').unbind('mouseenter mouseleave');
  $(LIZERP.formId).find('input,select,textarea').attr('disabled', 'disabled');
  $(LIZERP.formId).find(' input[type=button]').removeAttr('disabled');

  $('#rightFormLines').css('display', 'none');
  $('.editLine').css('display', 'none');
  $('.copyAndNewLine').css('display', 'none');

  $('#fieldset_systeminformation').css('display', 'block');
  $(' .btnEditMode ').css('display', 'none');
  $(' .btnReadMode ').css('display', 'inline-block');
  $(' .datepicker').unmousewheel();
  $(LIZERP.formId).find(' #formLines tr .fileAttachmentContainer').css('display', 'block');
  $(LIZERP.formId).find(' #fieldset_documentfile .fileAttachmentContainer').css('display', 'block');
  
  var docStatus = $(LIZERP.formId).find('#spandocstatus').text();
  if(docStatus == "Closed"){
    $(LIZERP.formId + ' .btnEnterEditMode ').css('display', 'none');
    $(LIZERP.formId + ' .btnChangeDocStatus ').css('display', 'none');
  }  

  // if doc number not exist hide line entry form @Mamun
  if ($(LIZERP.formId + ' #docnumber').val().length != 0){
    $(LIZERP.formId + ' #formLinesContainer').css({'display':'block'});
  }


  LIZERP.formMode = 'read';

  var params = paramsToObj(window.location.search);
  if(params.createdocheader == 'yes'){
    // go to edit mode
    LIZERP.editMode_clickFromUpperBtn();
    $(LIZERP.formId + ' .newLine').click();
    // LIZERP.newLineNumber = 1;
    LIZERP.currentLineNumber = 1;
    LIZERP.newLineMode = false;
    LIZERP.editLineMode = true;
  }

}


LIZERP.checkCopyAndNewDocFlag = function(){
  var params = paramsToObj(window.location.search); 
  if(!!params.docflag && params.docflag == "copyandnew"){
    LIZERP.editMode();
    $(LIZERP.formId + ' #docnumber').val('');
    $(LIZERP.formId + ' #docstatus').text('');
    $(LIZERP.formId + ' #fieldset_lineinformation .valid .idlines').find('input').val('');
  }
}



LIZERP.newLine = function(){

  $('#rightFormLines').css('display', 'block');

  LIZERP.adjustLineFormInterface();
  LIZERP.cleanLineEntryForm();

  $(LIZERP.formId).find('.saveLine').removeAttr('disabled');
  $(LIZERP.formId).find('.saveLineAndNew').removeAttr('disabled');

  $(LIZERP.formId).find('.copyAndNewLine').attr('disabled', 'disabled');
  $(LIZERP.formId).find('.removeLine').attr('disabled', 'disabled');
  $(LIZERP.formId).find('.btnCancelDocLine').attr('disabled', 'disabled');

  delete LIZERP.newLineNumber;
  // it will take from table tr length
  // so delete it which is one step above now


}


LIZERP.cancelLine = function(){

  $(LIZERP.formId + '#rightFormLines').css('display', 'none');
  LIZERP.adjustLineFormInterface();  

  $(LIZERP.formId).find('.saveLine').attr('disabled', 'disabled');
  $(LIZERP.formId).find('.saveLineAndNew').attr('disabled', 'disabled');

  $(LIZERP.formId).find('.copyAndNewLine').attr('disabled', 'disabled');
  $(LIZERP.formId).find('.removeLine').attr('disabled', 'disabled');
  $(LIZERP.formId).find('.btnCancelDocLine').attr('disabled', 'disabled');
  $(LIZERP.formId).find('.newLine').removeAttr('disabled');

}

LIZERP.cleanLineEntryForm =  function(){

  $(LIZERP.formId + ' #rightFormLines input')
    .each(function(e) {
      var id = $(this).attr('id');
      $(LIZERP.formId + ' #rightFormLines #' + id).val('');
    });
  $(LIZERP.formId + ' #rightFormLines select')
    .each(function(e) {
      var id = $(this).attr('id');
      $(LIZERP.formId + ' #rightFormLines #' + id).val('');
      // if (!!$(this).attr('class')) fieldList.push($(this).attr('class'));
    });  
  $(LIZERP.formId + ' #rightFormLines textarea')
    .each(function(e) {
      var id = $(this).attr('id');
      $(LIZERP.formId + ' #rightFormLines #' + id).val('');
    });       

}



/**
 * Save a line
 */
LIZERP._saveLine = function(line) {
  // edit = 1 if we're trying to save because we clicked on an edit button of another line
  if(!!line){
    var $tr2 = LIZERP.getLineBeingEdited(line);
  } else {
    // line not defined
    // so its a new line, add new line
    if ($(LIZERP.formId + ' #formLines tr.valid.new').length == 0) {
      LIZERP.addLine();
      var $tr2 = LIZERP.getLineBeingEdited();
      $tr2.removeClass('editable new').addClass('valid new'); // new added by Mamun
    }
    var $tr2 = LIZERP.getLineBeingEdited();
  }
  

  /**
   * Passing Value right div to left div
   * Take header data
   */
  var lineData = {};

  $.each(LIZERP.formFieldSettings['header'], function(fieldName, attributes) {
    if(attributes['html_InputTag'] == 'checkbox'){
      if(!!attributes['groupname']){
        $('.'+attributes['groupname'] ).each(function() {
          if($(this).prop('checked')){
             var checkboxid = $(this).prop('id');
             var text    = $('label[for='+ checkboxid +']').text();
             lineData[fieldName] = text;
          } 
        });
      } else {
        lineData[fieldName] = $(LIZERP.formId + ' #' + fieldName).prop("checked") ? 1 : 0;
      }
    } else {
      lineData[fieldName] = $(LIZERP.formId + ' #' + fieldName).val();
    }
  });


  /**
   *Take Line Data
   */
  var formFieldSettings = LIZERP.formFieldSettings['lines'];
  $.each(formFieldSettings, function(fieldName, attributes) {

    if(attributes['html_InputTag'] == 'checkbox'){

      if(!!attributes['groupname']){
        $('.'+attributes['groupname'] ).each(function() {
          if($(this).prop('checked')){
             var checkboxid = $(this).prop('id');
             var text    = $('label[for='+ checkboxid +']').text();
          } 
        });
      } else {
        var val = $(LIZERP.formId + ' #lg_' + fieldName).prop("checked") ? 'Yes' : 'No';
      }

    } else {
      var value = $(LIZERP.formId + ' #lg_' + fieldName).val();
      if(!value) value = "";
      lineData[fieldName] = value;
    }

  });

  // alert(JSON.stringify(lineData));
  // post line data in api

  var postdata = {};
  postdata.line = JSON.stringify(lineData);
  postdata.reqType = '_saveLine';
  $.post(LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM], postdata, postLineData_results);

  function postLineData_results(data, textStatus, jqXHR) {

    data = JSON.parse(data);
    var lines = data.lines;
    delete data.lines;

    var headerObj = data;
    var linesObj = lines;

    /**
     * for first time doc create
     */
    if(headerObj['doccreate'] == 'yes'){
      for (var key in headerObj) {
        if (key.substr(0, 1) == "_") {
          LIZERP.dbAuxData[key.substr(1)] = headerObj[key]
          continue;
        }
        $('#' + key).filter('input,select,textarea').val(headerObj[key]);
        if(key == "docnumber"){$('span#span' + key).text(headerObj[key]);}
        else if(key == 'docstatus'){
          $(LIZERP.formId +' #' + key).val(headerObj[key]);
          $(LIZERP.formId).find('span#span' + key).text(LIZERP.formFieldSettings['docstatus'][headerObj[key]]); 
        }
        else {$('span#' + key).text(headerObj[key]);}
      }
      // add docnumber in URL
      var currURL = window.location.pathname + window.location.search + '&docnumber=' + headerObj['docnumber'];
      window.history.pushState('', 'Title', currURL);
    }


    var fieldList = [];
    var requiredCols = [];
    $('#formLines #fieldset_lineinformation table tr th')
      .each(function(e) {
        if (!!$(this).attr('class')) fieldList.push($(this).attr('class'));
    });
    // remove from array, this field is not user-entered
    // fieldList.splice(fieldList.indexOf('idlines'), 1)
    // fieldList.splice(fieldList.indexOf('linenumber'), 1)

    /**
     * Putting value in line input field
     */
    for (var j = 0; j < fieldList.length; j++) {
      if (!!linesObj[0][fieldList[j]] && linesObj[0][fieldList[j]].length > 0) {
        $tr2.find('td.' + fieldList[j]).find('input,textarea,select').val(linesObj[0][fieldList[j]]);
      }
    }

    /**
     * Take line input field object
     */
    var $lineFields = {};
    for (key in fieldList) {
      $lineFields[fieldList[key]] = $tr2.find('.' + fieldList[key]).find('input,select,textarea');
    }

    /**
     * Show this line field value to span
     */
    var error = false;
    if (!error) {

      for (key in fieldList) {  
        if(fieldList[key] == 'linestatus'){
          $tr2.find('td.' + fieldList[key]).find('span').text(LIZERP.formFieldSettings['linestatus'][$lineFields[fieldList[key]].val()]);
        } else {
          $tr2.find('.' + fieldList[key]).find('span').text($lineFields[fieldList[key]].val());
        }   
      }
      $tr2.find('textarea').parent().find('span').css('white-space', 'pre-wrap');
      $tr2.removeClass('editable new').addClass('valid');

      LIZERP.handleFormLinesTrClick();
      LIZERP.cancelLine();

    }

    if (line == 1) {
      return error;
    }


  }


}


/**
 * Save a line and new
 */
LIZERP._saveLineAndNew = function(line) {
  // edit = 1 if we're trying to save because we clicked on an edit button of another line
  if(!!line){
    var $tr2 = LIZERP.getLineBeingEdited(line);
  } else {
    // line not defined
    // so its a new line, add new line
    if ($(LIZERP.formId + ' #formLines tr.valid.new').length == 0) {
      LIZERP.addLine();
      var $tr2 = LIZERP.getLineBeingEdited();
      $tr2.removeClass('editable new').addClass('valid new'); // new added by Mamun
    }
    var $tr2 = LIZERP.getLineBeingEdited();
  }
  

  /**
   * Passing Value right div to left div
   * Take header data
   */
  var lineData = {};

  $.each(LIZERP.formFieldSettings['header'], function(fieldName, attributes) {
    if(attributes['html_InputTag'] == 'checkbox'){
      if(!!attributes['groupname']){
        $('.'+attributes['groupname'] ).each(function() {
          if($(this).prop('checked')){
             var checkboxid = $(this).prop('id');
             var text    = $('label[for='+ checkboxid +']').text();
             lineData[fieldName] = text;
          } 
        });
      } else {
        lineData[fieldName] = $(LIZERP.formId + ' #' + fieldName).prop("checked") ? 1 : 0;
      }
    } else {
      lineData[fieldName] = $(LIZERP.formId + ' #' + fieldName).val();
    }
  });


  /**
   *Take Line Data
   */
  var formFieldSettings = LIZERP.formFieldSettings['lines'];
  $.each(formFieldSettings, function(fieldName, attributes) {

    if(attributes['html_InputTag'] == 'checkbox'){

      if(!!attributes['groupname']){
        $('.'+attributes['groupname'] ).each(function() {
          if($(this).prop('checked')){
             var checkboxid = $(this).prop('id');
             var text    = $('label[for='+ checkboxid +']').text();
          } 
        });
      } else {
        var val = $(LIZERP.formId + ' #lg_' + fieldName).prop("checked") ? 'Yes' : 'No';
      }

    } else {
      var value = $(LIZERP.formId + ' #lg_' + fieldName).val();
      if(!value) value = "";
      lineData[fieldName] = value;
    }

  });

  // alert(JSON.stringify(lineData));
  // post line data in api

  var postdata = {};
  postdata.line = JSON.stringify(lineData);
  postdata.reqType = '_saveLine';
  $.post(LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM], postdata, postLineData_results);

  function postLineData_results(data, textStatus, jqXHR) {

    data = JSON.parse(data);
    var lines = data.lines;
    delete data.lines;

    var headerObj = data;
    var linesObj = lines;

    /**
     * for first time doc create
     */
    if(headerObj['doccreate'] == 'yes'){
      for (var key in headerObj) {
        if (key.substr(0, 1) == "_") {
          LIZERP.dbAuxData[key.substr(1)] = headerObj[key]
          continue;
        }
        $('#' + key).filter('input,select,textarea').val(headerObj[key]);
        if(key == "docnumber"){$('span#span' + key).text(headerObj[key]);}
        else if(key == 'docstatus'){
          $(LIZERP.formId +' #' + key).val(headerObj[key]);
          $(LIZERP.formId).find('span#span' + key).text(LIZERP.formFieldSettings['docstatus'][headerObj[key]]); 
        }
        else {$('span#' + key).text(headerObj[key]);}
      }
      // add docnumber in URL
      var currURL = window.location.pathname + window.location.search + '&docnumber=' + headerObj['docnumber'];
      window.history.pushState('', 'Title', currURL);
    }


    var fieldList = [];
    var requiredCols = [];
    $('#formLines #fieldset_lineinformation table tr th')
      .each(function(e) {
        if (!!$(this).attr('class')) fieldList.push($(this).attr('class'));
    });

    /**
     * Putting value in line input field
     */
    for (var j = 0; j < fieldList.length; j++) {
      if (!!linesObj[0][fieldList[j]] && linesObj[0][fieldList[j]].length > 0) {
        $tr2.find('td.' + fieldList[j]).find('input,textarea,select').val(linesObj[0][fieldList[j]]);
      }
    }

    /**
     * Take line input field object
     */
    var $lineFields = {};
    for (key in fieldList) {
      $lineFields[fieldList[key]] = $tr2.find('.' + fieldList[key]).find('input,select,textarea');
    }

    /**
     * Show this line field value to span
     */
    var error = false;
    if (!error) {

      for (key in fieldList) {  
        if(fieldList[key] == 'linestatus'){
          $tr2.find('td.' + fieldList[key]).find('span').text(LIZERP.formFieldSettings['linestatus'][$lineFields[fieldList[key]].val()]);
        } else {
          $tr2.find('.' + fieldList[key]).find('span').text($lineFields[fieldList[key]].val());
        }   
      }
      $tr2.find('textarea').parent().find('span').css('white-space', 'pre-wrap');
      $tr2.removeClass('editable new').addClass('valid');

      LIZERP.handleFormLinesTrClick();
      // LIZERP.cancelLine();

    }

    if (line == 1) {
      return error;
    }


  }


}




LIZERP.setThisLineDataInRightFormLines = function(line){
  var $tr2 = LIZERP.getLineBeingEdited(line);
  var fieldsWithData = 0;
  var lineData = {};
  $tr2.find('input,textarea,select')
    .each(function(index, element) {
      if ($(element).attr('type') == "button") return;
      if ($(element).val().trim().length > 0){
       fieldsWithData++;
       // var keyName = $(element).attr('name');
       // var myString = "abcdefg";
       // var newString = myString.substr(2); 
       // newString is now "cdefg"
       // var keyName = keyName.substr(9);
       // var myString = "abcdefg";
       // var newString = myString.substr(0, myString.length-4); 
       // newString is now "abc"
       var keyName = $(element).closest('td').attr('class');
       lineData[keyName] = $(element).val();
      }
    });

  if(fieldsWithData == 0) return;  

  $.each(lineData, function(key, value){
    $(LIZERP.formId + ' #rightFormLines #lg_'+key).val(value);
  });
}


LIZERP.handleFormLinesTrClick = function(){
  $(LIZERP.formId + ' #formLines table tbody tr').click(function(e) {
      e.stopPropagation();
      var $this = $(this);
      $(LIZERP.formId + ' #formLines table tbody tr').removeClass('clicked');
      $this.addClass('clicked');
      var trNum = $this.closest('tr').data('id');
      if(LIZERP.formMode == 'read') return;
      if(LIZERP.formMode == 'edit'){
        if(! $(LIZERP.formId + ' #rightFormLines').is(":visible") ){
            $('#rightFormLines').css('display', 'block');
            LIZERP.adjustLineFormInterface();

            $(LIZERP.formId).find('.saveLine').removeAttr('disabled');
            $(LIZERP.formId).find('.saveLineAndNew').removeAttr('disabled');

            if ($(LIZERP.formId + ' #formLines tr.valid.new').length > 0) {
              /* User wishes to edit a saved line and a new line exists and is editable. So remove the new line */
              $(LIZERP.formId + ' #formLines tr.new').remove();
            }

        }
      }
      LIZERP.clickLineNum = trNum;
      LIZERP.currentLineNumber = trNum;
      LIZERP.newLineMode = false;
      LIZERP.editLineMode = true;
      LIZERP.currentLineidlines = $this.closest('tr').find('td.idlines input').val();

      $(LIZERP.formId).find('.copyAndNewLine').removeAttr('disabled');
      $(LIZERP.formId).find('.removeLine').removeAttr('disabled');
      $(LIZERP.formId).find('.btnCancelDocLine').removeAttr('disabled');

      console.log('Current line--->' +  LIZERP.clickLineNum);
      LIZERP.setThisLineDataInRightFormLines(trNum);
      console.log(trNum);
      $(LIZERP.formId + ' #rightFormLines #dragbar').css({'background-color': '#D6EAF8'});
      // alert("TR ID " + trNum);
      // var tdid = $this.find('td[data-id]').data('id');
      // alert("TD ID " + tdid);

      //custom code for disable all field if requisition line field not empty
      var requisitionLine = $(LIZERP.formId + ' #rightFormLines #lg_requisitionlinenumber').val();
      console.log(requisitionLine);
      if(requisitionLine != ''){
        $(LIZERP.formId + ' #rightFormLines :input').prop("disabled", true);
      }
      
      $(LIZERP.formId + ' #rightFormLines .cancelLine').prop("disabled", false);
     
  });
}


LIZERP.populateDropdown_rightFormLines = function(){

    var populatePromises = $.when(
      LIZERP.populateDropdown('constructiontype', 'ConstructionType')
    );
    populatePromises.then(function() {

      var leftDivWidth = $('#righteditmode').width();
      var windowWidth = $(window).width();
      var rightWidthDivSB = windowWidth - leftDivWidth - 150;
      $('#leftreadmode').css({'max-width': rightWidthDivSB+'px', 'overflow-x':'scroll', 'float':'left'});
 
      $('#righteditmode #fdEditForm .colorcode')
      .on('click', function() {
      LIZERP.fillupColorCodeWithName_REPXX();     
      });
      $('#righteditmode #fdEditForm .physicalreferenceavailability')
      .on('click', function() {
      LIZERP.fillupPhysicalReferenceAvailability_SBXX();      
      });

      LIZERP.fillupThisLineDataInSB_FD();

    });
}



LIZERP.changeDocStatus = function(docnumber, docstatus){
  var searchParams = {};
  searchParams.docnumber = docnumber;
  searchParams.docstatus = docstatus;
  searchParams.reqType = 'changeDocStatus';
  return $.post(LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM], searchParams, changeDocStatus_return(), 'json');

  function changeDocStatus_return(extraParams) {
    return function(data, textStatus, jqXHR) {
      if (data.result == 'success') {
        location.reload();
      } else {
        alert(data.errormsgs.join('\n'));
      }
    }
  }

}



LIZERP.copyAndNewLine = function(){

$(LIZERP.formId).find('.copyAndNewLine').attr('disabled', 'disabled');

LIZERP.newLineMode = true;
LIZERP.editLineMode = false;
delete LIZERP.currentLineNumber;
delete LIZERP.newLineNumber; // 2017-01-31 added

$(LIZERP.formId + ' #rightFormLines #lg_idlines').val('');
$(LIZERP.formId + ' #formLines table tbody tr').removeClass('clicked');
$(LIZERP.formId + ' #rightFormLines #dragbar').css({'background-color': 'black'});        

}

//------------------ From Customization----------------------------------------------------------------------------------------------------------------

LIZERP.handleCheckBoxClick = function(thisfield){
  var isGroupCheckBox = $(thisfield).hasClass('group');
  // first check this checkbox is in under header or line?
  var className = $(thisfield).parent().prop('className');
  if(className == 'formGroup'){ 
    if(isGroupCheckBox){
      var groupName = $(thisfield).prop('class').split(' ')[1];
      // $('.' + groupName + ' input[type=checkbox]').prop('checked', false);
      if($(thisfield).prop('checked')){
        $('.' + groupName).prop('checked', false);
        $(thisfield).prop('checked', true);
      } else {
        $('.' + groupName).prop('checked', false);
        $(thisfield).prop('checked', false);      
      } 
    }

  } else if($thisfield.parents('#rightFormLines').length){
    // if ($elem.parents('.left').length) {}
    if(isGroupCheckBox){
      var groupName = $(thisfield).prop('class').split(' ')[1];
      // $('.' + groupName + ' input[type=checkbox]').prop('checked', false);
      if($(thisfield).prop('checked')){
        $('.' + groupName).prop('checked', false);
        $(thisfield).prop('checked', true);
      } else {
        $('.' + groupName).prop('checked', false);
        $(thisfield).prop('checked', false);      
      } 
    }

  } else {
    // this is for line
    if(isGroupCheckBox){
      var groupName = $(thisfield).prop('class').split(' ')[1];
      $(thisfield).closest('tr').find('.' + groupName).prop('checked', false);
      $(thisfield).prop('checked', true);
    }
  }

}


LIZERP.handleThisButtonAction = function(thisbtn){
  // first check this button is in under header or line?
  var className = $(thisbtn).parent().prop('className');
  if(className == 'formGroup'){ // header

    var fieldname  = $(thisbtn).attr('id');
    if(fieldname == '_btn_downloadcostingsheet'){
      alert('baby what you want?');
    } else if(fieldname == ''){
    }

  } else {                      // line

    var fieldname  = $(thisbtn).closest('td').attr('class');
    if(fieldname == '_btn_priceproposal'){
      var idlines = $(thisbtn).closest('tr').find('td.idlines input').val();
      alert(idlines);
    } else if(fieldname == ''){
      
    }
  }

}




//******************************************* FORM HANDLING

/**
 * Receives data from the API and populates the respective fields of the form
 * @param  {docobj} headerObj is the docobj from the API, minus the lines element
 * @param  {docboj.lines} linesObj is the lines element of docobj
 * @return {boolean}           true for success, false for failure
 */
LIZERP.fillForm = function(headerObj, linesObj) {
  // First, check if data is complete
  if (linesObj.length == 0) {
    return false;
  }

  // Complete the header fields
  for (var key in headerObj) {
    if (key.substr(0, 1) == "_") {
      LIZERP.dbAuxData[key.substr(1)] = headerObj[key]
      continue;
    }
    var attributes = LIZERP.formFieldSettings['header'][key];
    if(!!attributes['html_InputTag'] && attributes['html_InputTag'] == 'checkbox'){
      if(!!attributes['groupname']){
        $('.'+attributes['groupname'] ).each(function() {
            var checkboxid = $(this).prop('id');
            var text    = $('label[for='+ checkboxid +']').text();
            if(text == headerObj[key]){
              $(this).prop('checked', true);
            }
        });
      } else {

          (headerObj[key] == '1') ? $(LIZERP.formId +' #' + key).prop('checked', true) : $(LIZERP.formId +' #' + key).prop('checked', false);
      
      }

    } else if(LIZERP.formFieldSettings['header'][key]['html_InputTag'] == '_file_'){
    // if(LIZERP.formFieldSettings['header'][key]['html_InputTag'] == '_file_'){
        //-------------------------------------------------------------------------------------------------------------
        $(LIZERP.formId).find('#fieldset_documentfile .fileAttachmentContainer .fileViewerContainer').empty();
        var docfilepaths = headerObj[key];
        console.log('docfilepaths--->'+docfilepaths);

        if(docfilepaths != null && docfilepaths != ""){
          docfilepaths = docfilepaths.split('::');

          for (var f = 0; f < docfilepaths.length; f++){

            var linefilepath = docfilepaths[f];
            if(linefilepath == "") continue;
            var fileExt = linefilepath.split(".")[3];
            if(fileExt == "pdf"){
              linefilepaths_prv = "img/previewPDF.png";
            } else if (fileExt == "xlsx"){
              linefilepaths_prv = "img/previewXLSX.png";
            } else {
              linefilepaths_prv = linefilepath;
            }

            var imgTag = '<img src="'+ linefilepaths_prv +'" alt="Smiley face" height="42" width="42">';
            var hrefTag = '<a class="fancybox" target="_blank"  href="'+ linefilepaths_prv +'" >'+ imgTag +'</a>';
            var btnTag = '<input type="button" value="Delete" onclick="LIZERP.deleteFile(this   ' +","+ '    \'' + linefilepaths_prv+ '\'   ' +","+ '    \'' + fieldname+ '\'); "/>';
            var divTag = '<div class="fileViewerBox">'+ hrefTag +  btnTag +'</div>';
            $(LIZERP.formId).find('#fieldset_documentfile .fileAttachmentContainer .fileViewerContainer').append(divTag);

          }

        } else {
           $tr2.find('td.'+ fieldname +' .fileAttachmentContainer .fileViewerContainer').css({'display':'none'});
           $tr2.find('td.'+ fieldname +' .fileAttachmentContainer').append('<label class="label">No file attach yet</lebel>');
        }
        //-------------------------------------------------------------------------------------------------------------



    } else if(key == 'docstatus'){
      $(LIZERP.formId +' #' + key).val(headerObj[key]);
      $(LIZERP.formId).find('span#span' + key).text(LIZERP.formFieldSettings['docstatus'][headerObj[key]]); 

    } else {
      $(LIZERP.formId +' #' + key).val(headerObj[key]);
      $(LIZERP.formId).find('span#span' + key).text(headerObj[key]); 
    }

  }


  // Get a list of the TH columns marked as required
  var requiredCols = [];
  $('#formLines #fieldset_lineinformation table tr th[required=required]')
    .each(function(key, element) {
      requiredCols.push($(element).attr('class'));
    });
  // Complete the line fields
  for (var i = 0; i < linesObj.length; i++) {
    // Check if all required columns are present in the data from the DB, skip malformed lines
    for (var j = 0; j < requiredCols.length; j++) {
      if (!linesObj[i][requiredCols[j]] || linesObj[i][requiredCols[j]].trim().length == 0) {
        alert('Skipping line ' + i + ' because ' + requiredCols[j] + ' is missing.');
        alert('A line has been lost because the data coming from the system is incomplete.');
        continue;
      }
    };

    // Build field list from the visible or hidden form
    var fieldList = [];
    $('#formLines #fieldset_lineinformation tr th').each(function(e) {
      if (!!$(this).attr('class')) fieldList.push($(this).attr('class'));
    });
    // Start copying data to the fields
    var $tr2 = LIZERP.getLineBeingEdited();
    var lineFormFieldSettings = LIZERP.formFieldSettings['lines'];

    for (var j = 0; j < fieldList.length; j++) {
      var fieldname = fieldList[j];      



      if (!!linesObj[i][fieldList[j]] && linesObj[i][fieldList[j]].length > 0) { // data not 0, so some data exist

    if(fieldname == 'linestatus'){
          // $tr2.find('td.' + fieldList[j]).find('input').first().val(LIZERP.formFieldSettings['linestatus'][linesObj[i][fieldList[j]]]);
          $tr2.find('td.' + fieldList[j]).find('input,textarea,select').first().val(linesObj[i][fieldList[j]]);

        } else if(lineFormFieldSettings[fieldList[j]]['html_InputTag'] != '_file_'){


            $tr2.find('td.' + fieldList[j]).find('input,textarea,select').first().val(linesObj[i][fieldList[j]]);

        } else {

            //-------------------------------------------------------------------------------------------------------------
            $tr2.find('td.'+ fieldname +' .fileAttachmentContainer .fileViewerContainer').empty();
            var linefilepaths = linesObj[i][fieldname];
            console.log('linefilepaths--->'+linefilepaths);

            if(linefilepaths != null && linefilepaths != ""){
              linefilepaths = linefilepaths.split('::');

              for (var f = 0; f < linefilepaths.length; f++){

                var linefilepath = linefilepaths[f];
                if(linefilepath == "") continue;
                var fileExt = linefilepath.split(".")[3];
                if(fileExt == "pdf"){
                  linefilepaths_prv = "img/previewPDF.png";
                } else if (fileExt == "xlsx"){
                  linefilepaths_prv = "img/previewXLSX.png";
                } else {
                  linefilepaths_prv = linefilepath;
                }

                var imgTag = '<img src="'+ linefilepaths_prv +'" alt="Smiley face" height="42" width="42">';
                var hrefTag = '<a class="fancybox" target="_blank"  href="'+ linefilepaths_prv +'" >'+ imgTag +'</a>';
                var btnTag = '<input type="button" value="Delete" onclick="LIZERP.deleteFile(this   ' +","+ '    \'' + linefilepaths_prv+ '\'   ' +","+ '    \'' + fieldname+ '\'); "/>';
                var divTag = '<div class="fileViewerBox">'+ hrefTag +  btnTag +'</div>';
                $tr2.find('td.'+ fieldname +' .fileAttachmentContainer .fileViewerContainer').append(divTag);

              }

            } else {
               $tr2.find('td.'+ fieldname +' .fileAttachmentContainer .fileViewerContainer').css({'display':'none'});
               $tr2.find('td.'+ fieldname +' .fileAttachmentContainer').append('<label class="label">No file attach yet</lebel>');
            }
            //-------------------------------------------------------------------------------------------------------------



        }

      }
    }


    // Set the line number to match the DB
    var linenumber = linesObj[i]['linenumber'];
    $tr2.attr('data-id', linenumber);
    $tr2.find('td.linenumber span').text(linenumber);
    $tr2.find('input,select,textarea').each(function(e) {
      var currName = $(this).attr('name');
      if (!!currName) $(this).attr('name', currName.replace(/\[\d+\]/, "[" + linenumber + "]"));
    });
    // $tr2.find('input.saveLine:visible').first().click();
    LIZERP.newLineNumber = linenumber;  // Mamun // processing line number, now this line need to be save
    // need to make it real data-id, not for 1 (which is first time)
    LIZERP.saveLine();

  }
  return true;
}




/**
 * Save form via ajax after validation
 */
LIZERP.saveForm = function() {
  // tries to save the line if it's dirty
  if ((LIZERP.lineIsDirty == true) || ($(LIZERP.formId + ' #formLines tr.editable:not(.new)').length > 0)) {
    $('#formLines input[type=text]:visible').closest('tr').find('.saveLine').first().click();
  }

  // change data to actual uppercase from just css transform
  $(LIZERP.formId).find('input,textarea').each(function(i) {
    if ($(this).css('text-transform') == 'uppercase') $(this).val($(this).val().toUpperCase());
  });


  var error;
  // if no lines have been added, don't continue
  var validLines = $(LIZERP.formId + ' #formLines #fieldset_lineinformation tbody tr.valid').length;
  if (validLines == 0) {
    error = true;
    LIZERP.showFormError('Please provide at least one valid line information.');
  }

  // If all data is validated, then submit
  if (!error && LIZERP.formMode == 'edit') {
    // just to avoid re-entry, the server should also check for double submission
    LIZERP.readMode();

    /* Prepare JSON */
    var jsonData = {
      'lines': []
    };
    $.each(LIZERP.formFieldSettings['header'], function(fieldName, attributes) {
      
      if(attributes['html_InputTag'] == 'checkbox'){
        if(!!attributes['groupname']){
          $('.'+attributes['groupname'] ).each(function() {
            if($(this).prop('checked')){
               var checkboxid = $(this).prop('id');
               var text    = $('label[for='+ checkboxid +']').text();
               jsonData[fieldName] = text;
              // var or_this = $('#pre-payment').next('label').text();
              // var selectedVal = $(this).closest('label').text();
              // <input type="checkbox" name="PrePayment" value="Pre-Payment">Pre-Payment<br />
              // $(input).attr('value');
            } 
          });

        } else {
          jsonData[fieldName] = $(LIZERP.formId + ' #' + fieldName).prop("checked") ? 1 : 0;
        }
      } else {
        jsonData[fieldName] = $(LIZERP.formId + ' #' + fieldName).val();
      }
    });

    $(LIZERP.formId + ' #formLines #fieldset_lineinformation tbody tr.valid').each(function() {
      var fieldList = [];
      // Build field list from the visible form
      $('#formLines #fieldset_lineinformation tr th').each(function(e) {
        if (!!$(this).attr('class')) fieldList.push($(this).attr('class'));
      });
      // Build field list from the formFieldSettings variable
      // $.each( LIZERP.formFieldSettings['lines'], function( fieldName, attributes ) {
      //     fieldList.push( fieldName );
      // } );

      LIZERP.formFieldSettings_OBJ = JSON.parse(LIZERP.formFieldSettings_JSON)
      var allowFormLineFields = Object.keys(LIZERP.formFieldSettings_OBJ['lines']);
      var formLine = {};
      for (index in fieldList) {
        formField = fieldList[index];
        if(allowFormLineFields.indexOf(formField) == -1){
          continue;
        }

        var isGroupCheckBox = (formField.indexOf('groupcheckbox') > -1) ? true : false;

          formLine[formField] = $(this).find('td.' + formField).find('input,textarea,select').first().val();
      
      }
      jsonData['lines'].push(formLine);
    });


    // first doc header save
    // push an empty line with dummy 1 line number
    if ($(LIZERP.formId + ' #docnumber').val().length == 0){
      jsonData['lines'].push({'idlines':'', 'linenumber':'1'});
    }
    
    /* Submit via ajax */
    var postData = {
      reqType: 'saveDoc',
      docobj: JSON.stringify(jsonData)
    };
    // add iddocument in case this is an Edit
    if ($(LIZERP.formId + ' #docnumber').val().length > 0) postData.docnumber = $(LIZERP.formId + ' #docnumber').val();
    console.log(postData);
    




    $.ajax({
      type: 'post',
      url: LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM],
      //dataType: 'json',/* if the return data is json */
      data: postData,
      success: function(data) {
          // if result is JSON, we're using the new API return format
          console.log(data);
          data = JSON.parse(data);
          if (!!data.errormsgs && data.errormsgs.length > 0) {
            console.log(data.errormsgs.join('\n'));
            alert("===>"+data.errormsgs.join('\n'));
            LIZERP.editMode();
          } else {
            var params = paramsToObj(window.location.search);
            if(data.createdocheader == 'yes' && params.docflag != 'createcapacityplan'){
              var next_href = window.location.origin + window.location.pathname + '?doctype=' + LIZERP._ERP_DOCACRONYM + '&docnumber=' + data.docnumber + '&createdocheader=yes';
              window.location.href = next_href;
            } else {
              var params = paramsToObj(window.location.search);
              var next_href = window.location.origin + window.location.pathname + '?doctype=' + LIZERP._ERP_DOCACRONYM + '&docnumber=' + data.docnumber;
              window.location.href = next_href;
            }
          }
      }
    }).fail(function(e) {
      alert('Saving failed, please try again.');
      LIZERP.editMode();
    });
  }
  return;
}


LIZERP.editMode = function(formWhere) {


  if ($(' #formLines tr.editable').length == 0){
    LIZERP.addLine();
    // $tr2.removeClass('editable new').addClass('valid new');
  }

  $(LIZERP.formId + ' #formLines tr').hover(function(e) {
    $(this).find('.div_editButton').css('display', 'block');
  }, function(e) {
    $(this).find('.div_editButton').css('display', 'none');
  });
  $(LIZERP.formId).find('input,select,textarea').removeAttr('disabled');
  LIZERP.lockCreateOnlyFields();
  $('#fieldset_systeminformation').css('display', 'none');
  $(' .btnEditMode ').css('display', 'inline-block');
  $(' .btnReadMode ').css('display', 'none');


  var $tr2 = LIZERP.getLineBeingEdited();
  if(formWhere == 'nodoc' || formWhere == 'eee'){

    $tr2.removeClass('editable new').addClass('valid new'); // new added by Mamun
    $(LIZERP.formId).find('.saveLine').attr('disabled', 'disabled');
    $(LIZERP.formId).find('.saveLineAndNew').attr('disabled', 'disabled');

    $(LIZERP.formId).find('.copyAndNewLine').attr('disabled', 'disabled');
    $(LIZERP.formId).find('.removeLine').attr('disabled', 'disabled');
    $(LIZERP.formId).find('.btnCancelDocLine').attr('disabled', 'disabled');

  } else {
    // $tr2.removeClass('editable new').addClass('valid new'); // new added by Mamun    
  }


  LIZERP.formMode = 'edit';
}


//------------------ From Customization end----------------------------------------------------------------------------------------------------------------


LIZERP.checkDocHeaderCreated = function(){

  // if doc number not exist hide line entry form @Mamun
  if ($(LIZERP.formId + ' #docnumber').val().length == 0){
    $(LIZERP.formId + ' #formLinesContainer').css({'display':'none'});
  }

  // if doc number not exist hide line entry form @Mamun
  if ($(LIZERP.formId + ' #docnumber').val().length != 0){
    $(LIZERP.formId + ' #formLinesContainer').css({'display':'block'});
  }
  var params = paramsToObj(window.location.search);
  if(params.createdocheader == 'yes'){
    // go to edit mode
    LIZERP.editMode_clickFromUpperBtn();
    $(LIZERP.formId + ' .newLine').click();
    // LIZERP.newLineNumber = 1;
    LIZERP.currentLineNumber = 1;
    LIZERP.newLineMode = false;
    LIZERP.editLineMode = true;
  } else {
      $(LIZERP.formId + ' #leftFormLines').css({'width':'100%'});
  }

}

LIZERP.autoLineFill_Save_Edit = function(){
  var params = paramsToObj(window.location.search);
  if(!!params.autoLineFill_Save_Edit && params.autoLineFill_Save_Edit == 'yes'){
    LIZERP.editMode_clickFromUpperBtn();
  }
}




$.extend(LIZERP, {
  /**
   * Start up function
   * @description Any JS code to be run on start up
   * @returns {undefined}
   */



  init: function() {
    /* executable JS */
    return;
  },
  enableRead: function() {
    LIZERP.readMode();
    return;
  },
  enableEdit: function() {
    LIZERP.editMode();
    return;
  },
  enableReceive: function() {
    LIZERP.receiveMode();
    return;
  },

  /**
   * Process Purchase Request Form
   * @param selector formId
   * @returns {undefined}
   */
  processForm: function(purchaseFormId, _ERP_DOCACRONYM, _URL_DOCUMENTAPI, _URL_DOCDEFINEAPI) {
    LIZERP.formId = purchaseFormId + ' ';
    LIZERP.formMode = 'edit';
    LIZERP._ERP_DOCACRONYM = _ERP_DOCACRONYM;
    LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM] = _URL_DOCUMENTAPI;
    LIZERP._URL_DOCDEFINEAPI[LIZERP._ERP_DOCACRONYM] = _URL_DOCDEFINEAPI;
    if(!LIZERP.newLineNumber) LIZERP.newLineNumber = 1;

    var populatePromises = [];
    populatePromises.push(LIZERP.populateDropdown('company', 'company', 'LFI'));
    populatePromises.push(LIZERP.populateDropdown('buyername', 'Buyer'));
    populatePromises.push(LIZERP.populateDropdown('itemtype', 'itemtype_PO_NONPO'));
    populatePromises.push(LIZERP.populateDropdown('lg_itemtype', 'itemtype_PO_NONPO'));
    populatePromises.push(LIZERP.populateDropdown('iduom', 'UOM'));
    populatePromises.push(LIZERP.populateDropdown('lg_iduom', 'UOM'));
    $.when.apply($, populatePromises).then(function() {
      // Caches the HTML of a new line
      LIZERP.lineHTML_template = $('#fieldset_lineinformation table tr[data-id=1]')[0].outerHTML;
      LIZERP.adjustLineFormInterface();
    });

    LIZERP.handle_docdate_field();
    /* Show/Hide/Enable/Disable fields on document load */
    LIZERP.handleFormFields('create');

    $(window).keydown(function(e) {
      if (e.ctrlKey || e.metaKey) {
        switch (String.fromCharCode(e.which).toLowerCase()) {
          case 's':
            e.preventDefault();
            $(LIZERP.formId + ' .btnSaveForm').click();
            break;
        }
      }
    });

    $(LIZERP.formId + ' .btnSaveForm').on('click', function(e) {
      e.preventDefault();
      LIZERP.saveForm();
    });     

    $(LIZERP.formId + ' .btnCancelForm').on('click', function(e) {
      e.preventDefault();
      var params = paramsToObj(window.location.search);
      if (!!params.docnumber) location.reload();
    });
    $(' .btnEnterEditMode').on('click', function(e) {
      e.preventDefault();
      LIZERP.editMode_clickFromUpperBtn();
      LIZERP.editLineMode = true;
      LIZERP.newLineMode = false;
    });

    $(LIZERP.formId + ' .btnPrintSheet').on('click', function(e) {
      e.preventDefault();
      var params = paramsToObj(window.location.search);
      window.open('printdoc-v3.php?doctype=' + params.doctype + '&docnumber=' + params.docnumber);
    });

    $(LIZERP.formId + ' .btnChangeDocStatus').on('click', function(e) {
      e.preventDefault();
      var params = paramsToObj(window.location.search);
      if (confirm('Click OK to close this document')) LIZERP.changeDocStatus(params.docnumber, '1');
    });

    $(LIZERP.formId + ' .btnSendRequest').on('click', function(e) {
      e.preventDefault();
      var params = paramsToObj(window.location.search);
      if (!params.docnumber) {
        alert('Error: iddocument not available. Please tell ERP department.');
        return;
      }
      if (confirm('Click OK to send to request')) LIZERP.changeDocStatus(params.docnumber, '1');
    });
    $(LIZERP.formId + ' .btnPlanforInquiry').on('click', function(e) {
      e.preventDefault();
      var params = paramsToObj(window.location.search);
      LIZERP.planForInquiry(params.docnumber, '1');
    });

    $(LIZERP.formId + ' .btnFileAttachment').on('click', function(e) {
      e.preventDefault();
      LIZERP.fileAttachmentMode();
    });
    
    $(LIZERP.formId + ' .btnCopyAndNew').on('click', function(e) {
      e.preventDefault();
      var params = paramsToObj(window.location.search);
      window.open(window.location.origin + window.location.pathname + '?docnumber=' + params.docnumber + '&doctype=' + params.doctype + '&formtype='+params.formtype+"&docflag=copyandnew" );
    });



    $(LIZERP.formId + ' .newLine').on('click', function(e) {
      e.preventDefault();
      $(LIZERP.formId).find('.newLine').attr('disabled', 'disabled');
      LIZERP.newLineMode = true;
      LIZERP.editLineMode = false;
      LIZERP.newLine();
    });

    $(LIZERP.formId + ' .saveLine').on('click', function(e) {
      e.preventDefault();
      if(!!LIZERP.currentLineNumber && LIZERP.editLineMode && !LIZERP.newLineMode){

        LIZERP._saveLine(LIZERP.currentLineNumber);
      } else {

        LIZERP._saveLine();
      }
      LIZERP.cleanLineEntryForm();
      LIZERP.handleFormLinesTrClick();
      $(LIZERP.formId).find('.newLine').removeAttr('disabled');

      // save form in  db
      // LIZERP.saveForm();

    });

    $(LIZERP.formId + ' .saveLineAndNew').on('click', function(e) {
      e.preventDefault();
      if(!!LIZERP.currentLineNumber && LIZERP.editLineMode && !LIZERP.newLineMode){

        LIZERP.newLineMode = true;
        LIZERP.editLineMode = false;

        LIZERP._saveLineAndNew(LIZERP.currentLineNumber);
      } else {

        LIZERP._saveLineAndNew();
      }
      LIZERP.cleanLineEntryForm();
      LIZERP.handleFormLinesTrClick();
    });
    
    $(LIZERP.formId + ' .copyAndNewLine').on('click', function(e) {
      e.preventDefault();
      LIZERP.copyAndNewLine();

    });



    $(LIZERP.formId + ' .cancelLine').on('click', function(e) {
      e.preventDefault();
      LIZERP.cancelLine();

      // save form in  db
      LIZERP.saveForm();
    });

    $(LIZERP.formId + ' .removeLine').on('click', function(e) {
      e.preventDefault();
      if(!!!LIZERP.currentLineNumber) return;
      LIZERP.removeLine(LIZERP.currentLineNumber);
    });

    LIZERP.initLine(); // Enables functionality of the Line entry
    LIZERP.editMode();

    // If the page was called with a document ID, try to read the record
    var params = paramsToObj(window.location.search);
    if (!!params.docnumber) {
      var searchParams = {
        'reqType': 'readDoc',
        'docnumber': params.docnumber
      };
      $.when.apply($, populatePromises).then(function() {
        $.get(LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM], searchParams, populateFromDb);
      });
    } else {
          LIZERP.editMode('nodoc');
    }

    function populateFromDb(data, textStatus, jqXHR) {
      // alert(data);
      data = JSON.parse(data);
      var lines = data.lines;
      delete data.lines;
      if (Object.keys(data).length > 0) {
        $.when.apply($, populatePromises).then(function() {
          LIZERP.editMode('populateFromDb');
          LIZERP.fillForm(data, lines);
          LIZERP.readMode();
          LIZERP.handleFormLinesTrClick();
          LIZERP.checkCopyAndNewDocFlag();          
          window.scrollTo(0, 0);
        });
      } else {
        LIZERP.editMode();
        alert('Document not found.');
      }
    }

    return;
  }
});

var erpdocument = {};
erpdocument.processForm = function(formId, _ERP_DOCACRONYM, _URL_DOCUMENTAPI, _URL_DOCDEFINEAPI) {
  LIZERP.processForm(formId, _ERP_DOCACRONYM, _URL_DOCUMENTAPI, _URL_DOCDEFINEAPI);
}






























var dragging = false;
   $('#dragbar').mousedown(function(e){
       e.preventDefault();
       
       dragging = true;
       var main = $('#rightFormLines');
       var ghostbar = $('<div>',
                        {id:'ghostbar',
                         css: {
                                height: main.outerHeight(),
                                top: main.offset().top,
                                left: main.offset().left
                               }
                        }).appendTo('body');
       
        $(document).mousemove(function(e){
          ghostbar.css("left",e.pageX+2);
       });
       
    });

   $(document).mouseup(function(e){
       if (dragging) 
       {
           var percentage = (e.pageX / window.innerWidth) * 100;
           var mainPercentage = 100-percentage;
           
           $('#leftFormLines').css("width",percentage + "%");
           $('#rightFormLines').css("width",mainPercentage + "%");
           $('#ghostbar').remove();
           $(document).unbind('mousemove');
           dragging = false;
       }
    });
