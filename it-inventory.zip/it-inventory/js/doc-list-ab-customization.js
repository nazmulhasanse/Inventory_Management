/**
 * Declare the namespace LIZERP if not existent
 */
var LIZERP = LIZERP || {};

$.extend(LIZERP, {
  _ERP_DOCACRONYM: '',
  _FIELDSETS_HEADER: ['fieldset_documentinformation', 'fieldset_logisticsinformation', 'fieldset_projectinformation'],

  foo: 'here for no reason other than to be the last line, without a comma'
});


//.................... Calculation of Total Required Gross Quantity Start ....................................

$("input#Consumption").change(function(){
    LIZERP.reqQtyCalculation();
});

$("input#ReqQty").change(function(){
    LIZERP.reqQtyCalculation();
});

$("input#ProcessLoss").change(function(){
    LIZERP.reqQtyCalculation();
});


LIZERP.reqQtyCalculation = function(){
  var consumption = $(LIZERP.formId).find('input#Consumption').val();
  var garmentqty  = $(LIZERP.formId).find('input#ReqQty').val();
  var processloss = $(LIZERP.formId).find('input#ProcessLoss').val();

  if(consumption != "" && garmentqty !="" && processloss != ""){
      var totalreqqty = ((consumption*garmentqty)/12)+((consumption*garmentqty)/12)*(processloss/100);
  
      $(LIZERP.formId).find('input#FinalReqQty').val(totalreqqty);
      $(LIZERP.formId).find('input#FinalReqQty').attr('disabled', 'disabled');
  }
}


//.......................  Calculation of Total Required Gross Quantity End ............................

LIZERP.initForm = function(){
var params = paramsToObj(window.location.search);
  if(!!params.ldcslnumber){
    $(LIZERP.formId).find('input#ldcslnumber').val(params.ldcslnumber);
    // alert(params.subdoclinenumber);
  }

}



LIZERP.copyAndNewDoc = function(){
  LIZERP.editMode();
  $(LIZERP.formId + ' #docnumber').val('');
  LIZERP.hideUpperButton();
  LIZERP.hideFormInterface();
}


LIZERP.copyMultipleAndNewDoc = function(){
 
  var num = prompt("How Many Line You Want?", "");
  if(num >= "1"){
    for(var i=1; i<=num; i++){
  		LIZERP.copyMultipleNewDocAndSave();
    	// LIZERP.saveFormXX();
    }
  }
}

LIZERP.copyMultipleNewDocAndSave = function(){
  LIZERP.editMode();
  $(LIZERP.formId + ' #docnumber').val('');
  LIZERP.hideUpperButton();
  LIZERP.saveFormXX();
  LISTDOC.getListData(50,   1,    '');  
  
}

LIZERP.removeLine = function(){

  var doclinenumber = LIZERP.doclinenumber;
  var r = confirm("Are you sure to Delete " +doclinenumber+ " Line?");
  if(r == true){
    /* Submit via ajax */
    var postData = {
      reqType: 'removeLine',
      doclinenumber: doclinenumber
     };
    $.ajax({
      type: 'post',
      url: 'doc-list-ab_api.php',
      data: postData,
      success: function(data) {
          data = JSON.parse(data);
          if (!!data.errormsgs && data.errormsgs.length > 0) {
            console.log(data.errormsgs.join('\n'));
            alert("===>"+data.errormsgs.join('\n'));
          } else {
            // window.location.reload();
            LISTDOC.getListData(50,   1,    '');
            LIZERP.hideFormInterface();
          }
      }
    }).fail(function(e) {
      alert('Assign failed, please try again.');
    });
  }else{
    return;
  }

}

LIZERP.viewBOM =function() {
  var params = paramsToObj(window.location.search);
  // alert(params.flag);
  if(params.flag == 'abl'){
    $('.btnNew').css('display', 'none');
    $('.btnImportBOM').css('display', 'none');
    $('.btnMultipleEdit').css('display', 'none');
  }
}



LIZERP.readMode = function() {
  $(LIZERP.formId).find(' #formLines tr').unbind('mouseenter mouseleave');
  $(LIZERP.formId).find('input,select,textarea').attr('disabled', 'disabled');
  $(LIZERP.formId).find(' input[type=button]').removeAttr('disabled');
  $('#fieldset_systeminformation').css('display', 'block');
  $('.btnEditMode ').css('display', 'none');
  $('.btnInitialMode').css('display', 'none');
  $('.btnReadMode ').css('display', 'inline-block');
  $('.btnAllMode ').css('display', 'inline-block');

  $('.datepicker').unmousewheel();


  if( $('#formDiv').is(":visible") ){
    $('#rightFormButtons .btnCancelForm').css('display', 'inline-block');
  }

  LIZERP.viewBOM();

  LIZERP.formMode = 'read';
}

//Special Save Form for Multiple line Copy and New Doc Creation

LIZERP.saveFormXX = function() {
  // change data to actual uppercase from just css transform
  $(LIZERP.formId).find('input,textarea').each(function(i) {
    if ($(this).css('text-transform') == 'uppercase') $(this).val($(this).val().toUpperCase());
  });

  // run validation on all header fields
  var error = false;
  for (i in LIZERP._FIELDSETS_HEADER) {
    error = error || LIZERP.validateFormContainerFields(LIZERP.formId + ' #' + LIZERP._FIELDSETS_HEADER[i]);
  }


  // If all data is validated, then submit
  // var error;
  if (!error && LIZERP.formMode == 'edit') {
    // just to avoid re-entry, the server should also check for double submission
    LIZERP.readMode();

    /* Prepare JSON */
    var jsonData = {
      'lines': []
    };
    $.each(LIZERP.formFieldSettings['header'], function(fieldName, attributes) {
      jsonData[fieldName] = $(LIZERP.formId + ' #' + fieldName).val();
    });
    


    /* Submit via ajax */
    var postData = {
      reqType: 'saveDoc',
      docobj: JSON.stringify(jsonData)
    };
    // add iddocument in case this is an Edit
    if ($(LIZERP.formId + ' #docnumber').val().length > 0) postData.docnumber = $(LIZERP.formId + ' #docnumber').val();
    console.log(postData);
    $.ajax({
      type: 'post',
      async: false,
      url: LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM],
      //dataType: 'json',/* if the return data is json */
      data: postData,
      success: function(data) {
          // if result is JSON, we're using the new API return format
          console.log(data);
          data = JSON.parse(data);
          if (!!data.errormsgs && data.errormsgs.length > 0) {
            console.log(data.errormsgs.join('\n'));
            alert(data.errormsgs.join('\n'));
            LIZERP.editMode();
          } else {
            // LIZERP.copyMultipleNewDocAndSave();
            // location.reload();
            // var next_href = window.location.origin + window.location.pathname + '?doctype=' + LIZERP._ERP_DOCACRONYM;
            // window.location.href = next_href;
            LISTDOC.getListData(50,   1,    '');
            LIZERP.hideFormInterface();
            // LIZERP.hideUpperButton();
          }
      }
    }).fail(function(e) {
      alert('Saving failed, please try again.');
      LIZERP.editMode();
    });
  }
  return;
}





LIZERP.accesoryBOMImport = function(){

  var prepopulate = {};
  // var buyername = $('#docHeaderContainer table tbody tr').find('td[fieldname=buyername]').text();

  // if($(LIZERP.formId + ' #prdoclinenumber').val().length > 0) prepopulate.doclinenumber = $(LIZERP.formId + ' #prdoclinenumber').val();
  // if(!!buyername) prepopulate.buyername = buyername;

  var prepopJS = (Object.keys(prepopulate).length > 0) ? 'var prepopulate = ' + JSON.stringify(prepopulate) + ';' : '';
  prepopJS = prepopJS + "var ERPLIST = ERPLIST || {};";
  prepopJS = prepopJS + "$(document).ajaxStop(function() {";
  prepopJS = prepopJS + "ERPLIST.sendBackSearchChoice = function( thisRow ) {";
  prepopJS = prepopJS + "  ldcslnumber = $(thisRow).find('td[fieldname=ldcslnumber]').text();";
  prepopJS = prepopJS + "  $.fancybox.close();";
  prepopJS = prepopJS + "  $(LIZERP.formId + '#ldcslnumber').val(ldcslnumber);";
  prepopJS = prepopJS + "  LIZERP.importAccesoryBOM(ldcslnumber);";
  // prepopJS = prepopJS + "  $(LIZERP.formId + '#ldcslnumber').focus();";
  // prepopJS = prepopJS + "  $(LIZERP.formId + '#ldcslnumber').blur();";
  prepopJS = prepopJS + "};";
  prepopJS = prepopJS + "});";

  var content = '<div id="popupListContent">\
    <div id="loadingDiv">\
      <center><img src="/images/loading_spinner.gif"></center>\
    </div>\
  </div>';
  content+= '<script> ' + prepopJS + '</script>'; // add some js

  $.fancybox({
    type: 'html',
    content: content,
    minWidth: 500,
    minHeight: 300,
    afterLoad: function(){
      this.title = "<b>Accessory BOM List</b>";
    },    
    afterShow: function() {
      loadSessionContent();
      $.fancybox.update();
    },
    helpers: {
     title : {
      type : 'inside',
      position : 'top'
     },
     overlay : {
      css  : { /* 'background-color' : '#fff' */}
     }     
    }  
  });
  jQuery('.fancybox-title').css({'text-align':'center', 'margin-bottom':'10px'});

  function loadSessionContent(){
    $.ajax({
      async: false,
      type: 'get',
      url: '/erp-apparel/list-accesories-bom-session.php',
      success: function(htmlContent) {
        $('#popupListContent').empty().append(htmlContent);
        // $.fancybox.update(); 
        var searchParams = (Object.keys(prepopulate).length > 0) ? prepopulate : {};
        //                  show,   page,   api_url
        ERPLIST.getListData(30,   1,    ERPLIST._URL_API, searchParams);
        updateFancyBox();
      }
    }).fail(function(e) {
      alert('Loading failed, please try again.');
    });
  }

  function updateFancyBox(){
    $(document).ajaxStop(function() {
      // place code to be executed on completion of 
      // last outstanding ajax call here
      // this is needed// because ajax call is asyncronus
      $.fancybox.update(); 
    });
  }
}



LIZERP.importAccesoryBOM = function(ldcslnumber){
  var params = paramsToObj(window.location.search);
  var toldcslnumber = params.ldcslnumber;
/* Submit via ajax */
  var postData = {
    reqType: 'importAccesoryBOM',
    ldcslnumber: ldcslnumber,
    toldcslnumber: toldcslnumber
   };
  $.ajax({
    type: 'post',
    url: 'doc-list-ab_api.php',
    data: postData,
    success: function(data) {
        data = JSON.parse(data);
        if (!!data.errormsgs && data.errormsgs.length > 0) {
          console.log(data.errormsgs.join('\n'));
          alert("===>"+data.errormsgs.join('\n'));
        } else {
          // location.reload();
          LISTDOC.getListData(50,   1,    '');
        }
    }
  }).fail(function(e) {
    alert('Assign failed, please try again.');
  });
}








LIZERP.hideUpperButton = function(){
  // alert(params.flag);
  var params = jsClient.paramsToObj(window.location.search);
  if(params.flag == '1'){
    $('.btnNew').css('display', 'none');
    $('.btnImportBOM').css('display', 'none');
    $('.btnMultipleEdit').css('display', 'none');
  }


  $('.btnLabdipRequest').css('display', 'none');
  $('.btnSampleFabricRequest').css('display', 'none');
  $('.btn3rdPartyTestingRequest').css('display', 'none');
}


LIZERP.readThisDoc_N_FillInForm = function(docnumber){
  LIZERP.displayFormInterface();
  var searchParams = {
  'reqType': 'readDoc',
  'docnumber': docnumber
  };
  $.get(LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM], searchParams, populateFromDb);
  function populateFromDb(data, textStatus, jqXHR) {
    data = JSON.parse(data);
    if (Object.keys(data).length > 0) {
        LIZERP.fillForm(data);
        LIZERP.readMode();
        // window.scrollTo(0, 0);
    } else {
      LIZERP.editMode();
      alert('Document not found.');
    }
  }

  LIZERP.hideUpperButton();

}


$.extend(LIZERP, {
  /**
   * Start up function
   * @description Any JS code to be run on start up
   * @returns {undefined}
   */
  init: function() {
    /* executable JS */
    return;
  },
  enableRead: function() {
    LIZERP.readMode();
    return;
  },
  enableEdit: function() {
    LIZERP.editMode();
    return;
  },
  enableReceive: function() {
    LIZERP.receiveMode();
    return;
  },

  /**
   * Process Purchase Request Form
   * @param selector formId
   * @returns {undefined}
   */
  processForm: function(purchaseFormId, _ERP_DOCACRONYM, _URL_DOCUMENTAPI, _URL_DOCDEFINEAPI, isBlankForm) {
    LIZERP.formId = purchaseFormId + ' ';
    LIZERP.formMode = 'edit';
    LIZERP._ERP_DOCACRONYM = _ERP_DOCACRONYM;
    LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM] = _URL_DOCUMENTAPI;
    LIZERP._URL_DOCDEFINEAPI[LIZERP._ERP_DOCACRONYM] = _URL_DOCDEFINEAPI;

    var populatePromises = [];
    populatePromises.push(LIZERP.populateDropdown('company', 'company', 'LFI'));
    populatePromises.push(LIZERP.populateDropdown('buyername', 'Buyer','','codevalequal'));
    populatePromises.push(LIZERP.populateDropdown('orderstatus', 'OrderStatus', '', 'codevalequal'));        
    populatePromises.push(LIZERP.populateDropdown('UOM', 'UOM'));
    populatePromises.push(LIZERP.populateDropdown('ReadyForBooking', 'yes_no'));
    populatePromises.push(LIZERP.populateDropdown('BookingApproval', 'yes_no'));
    $.when.apply($, populatePromises).then(function() {
      // Caches the HTML of a new line
      // LIZERP.lineHTML_template = $('#fieldset_lineinformation table tr[data-id=1]')[0].outerHTML;
    });

    LIZERP.handle_docdate_field();
    /* Show/Hide/Enable/Disable fields on document load */
    LIZERP.handleFormFields('create');

    LIZERP.initForm(); 
    LIZERP.editMode();
    LIZERP.viewBOM();
    // LIZERP.readMode();


    $(window).keydown(function(e) {
      if (e.ctrlKey || e.metaKey) {
        switch (String.fromCharCode(e.which).toLowerCase()) {
          case 's':
            e.preventDefault();
            $('#upperButtonBar .btnSaveForm').click();
            break;
        }
      }
    });

    $('.btnSaveForm').on('click', function(e) {
      e.preventDefault();
      LIZERP.saveForm();
    });     

    $('#upperButtonBar .btnNew').on('click', function(e) {
      e.preventDefault();
      LIZERP.blankForm();
    });    

    $(LIZERP.formId + ' .btnNext').on('click', function(e) {
      e.preventDefault();
      var docnumber = $(LIZERP.formId + ' #docnumber').val();
      var next_href = window.location.origin + window.location.pathname + '?doctype=FL&formtype=default&dprnumber=' + docnumber + '&tabcontent=1';
      window.location.href = next_href;
      // LIZERP.blankForm();
    });     

    $(LIZERP.formId + ' .btnNext2').on('click', function(e) {
      e.preventDefault();
      var docnumber = $(LIZERP.formId + ' #docnumber').val();
      var next_href = window.location.origin + window.location.pathname + '?doctype=FL&formtype=default&dprnumber=' + docnumber + '&tabcontent=2';
      window.location.href = next_href;
      // LIZERP.blankForm();
    });

    $('#upperButtonBar .btnCancelForm').on('click', function(e) {
      e.preventDefault();
      location.reload();
      LIZERP.hideFormInterface();
      // LISTDOC.getListData(50,   1,    '');  
    });
    $('#rightFormButtons .btnCancelForm').on('click', function(e) {
      e.preventDefault();
      location.reload();
      LIZERP.hideFormInterface();
      // LISTDOC.getListData(50,   1,    '');  
    });


    $(' .btnEnterEditMode').on('click', function(e) {
      e.preventDefault();
      LIZERP.editMode();
    });

    $(LIZERP.formId + ' .btnPrintSheet').on('click', function(e) {
      e.preventDefault();
      var params = paramsToObj(window.location.search);
      window.open('printdoc-v3.php?doctype=' + params.doctype + '&docnumber=' + params.docnumber);
    });

    $(LIZERP.formId + ' .btnChangeDocStatus').on('click', function(e) {
      e.preventDefault();
      if (confirm('Click OK to send to WMS')) LIZERP.changeDocStatus();
    });

    $('#upperButtonBar .btnImportBOM').on('click', function(e) {
      e.preventDefault();
      LIZERP.accesoryBOMImport();
    });    

    $('#upperButtonBar .btnCopyAndNew').on('click', function(e) {
      e.preventDefault();
      LIZERP.copyAndNewDoc();
    });

    $('#upperButtonBar .btnMultipleCopyAndNew').on('click', function(e) {
      e.preventDefault();
      LIZERP.copyMultipleAndNewDoc();
    });    

    $('#upperButtonBar .removeLine').on('click', function(e) {
      e.preventDefault();
      LIZERP.removeLine();
    });

    $('#upperButtonBar .btnMultipleEdit').on('click', function(e) {
      e.preventDefault();
      LISTDOC.enableMultipleEdit();
    });


    // If the page was called with a document ID, try to read the record
    var params = paramsToObj(window.location.search);
    if (!!params.docnumber) {
      var searchParams = {
        'reqType': 'readDoc',
        'docnumber': params.docnumber
      };
      $.when.apply($, populatePromises).then(function() {
        $.get(LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM], searchParams, populateFromDb);
      });
    } else {
        // not call from blank form
        // and has not doc number
        // if(!isBlankForm) LIZERP.addRelatedDocsTable();
    }

    function populateFromDb(data, textStatus, jqXHR) {
      // alert(data);
      data = JSON.parse(data);
      var lines = data.lines;
      delete data.lines;
      if (Object.keys(data).length > 0) {
        $.when.apply($, populatePromises).then(function() {
          LIZERP.fillForm(data, lines);
          LIZERP.readMode();
          window.scrollTo(0, 0);
        });
      } else {
        LIZERP.editMode();
        alert('Document not found.');
      }
    }

    return;
  }
});




