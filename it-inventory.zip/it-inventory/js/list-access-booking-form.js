/**
 * Declare ERPLIST Namespace if not exist
 */
var ERPLIST = ERPLIST || {};

$.extend(ERPLIST, {
  mUrl: 'api/server_api.php',
  mType: 'get',
  mData: '',
  mAsync: false,
  mReqType: '',
  queryData: '',
  queryParam: '',
  _searchParams: '',
  _URL_API: 'list-access-booking-form_api.php',

  foo: 'here for no reason other than to be the last line, without a comma'
});


ERPLIST.applyCustomListCSS = function(){
  $('#listTable tr#searchForm input').css({
    'width':'95%',
    'min-width': '100px',
    'font-family':'Arial',
    'padding':'2px',
    'border':'1px solid #7F7F7F',
    'border-radius':'3px'
  });
  // Custom CSS if required
  $('#listTable td.lineentrytime').css({
    'white-space':'nowrap'
  }); 
}

ERPLIST.makeTable = function(jsonData,hasData) {

  var data      = JSON.parse(jsonData);
  var mydata    = data['listData'];
  var pageNum   = parseInt(data['pageNum']-1);
  var showLimit = parseInt(data['showLimit']);
  var trDataId  = parseInt(pageNum * showLimit) + 1;


  //for composition column
  ERPLIST.compositeColumns = {
    endcustomer: {
      endcustomer:{
        fielddesc: 'End Customer',
        customsearch: true,
        islibrary: true,
        sql: "SELECT Code AS code, Description AS description FROM mrd_library WHERE LibraryName='Buyer'", 
        single: true,
        end: true        
      }    
    },
    // shipmentdate: {
    //   shipmentdate:{
    //     fielddesc: 'Goods Ready date',
    //     customsearch: true,
    //     type: 'date',
    //     single: true,
    //     end: true        
    //   }    
    // },
    // exfactorydate: {
    //   exfactorydate:{
    //     fielddesc: 'Ex-factory Date',
    //     customsearch: true,
    //     type: 'date',
    //     single: true,
    //     end: true        
    //   }    
    // }
  }

  // some trickery for nice formatting
  var hideColumns = ['idlines',  'doctype', 'idsodeliverylines'];

  var translationsHardCode = {};
  translationsHardCode.iduom = 'UoM';
  translationsHardCode.season = 'Season';
  translationsHardCode.bookingformid = 'Accessories Booking Form No.';
  translationsHardCode.entitynumber = 'BOM No.';
  translationsHardCode.avgunitpriceperpack = 'Avg Unit Price Per Pack';
  translationsHardCode.destination = 'Destination';
  translationsHardCode.currency = 'Currency';
  translationsHardCode.setorder = 'Setorder';
  translationsHardCode.referencetype = 'Reference Type';
  translationsHardCode.referenceno = 'Reference No';
  translationsHardCode.productcategory = 'Product Category';
  translationsHardCode.elementuom = 'Elem. UoM';
  translationsHardCode.docstatus = 'Document Status';
  translationsHardCode.documentinformation = 'Document Information';
  translationsHardCode.itemspecification = 'Item Specification';
  translationsHardCode.docnumber = 'Sales Order No.';
  translationsHardCode.idsodeliverylines = 'Sales Order Delivery Line ID';
  translationsHardCode.subdoclinenumber = 'Delivery Line No.';
  translationsHardCode.buyerpo = 'End Customer PO No.';
  translationsHardCode.shipmentdate = 'Goods Ready Date';
  translationsHardCode.exfactorydate = 'Ex-factory Date';
  translationsHardCode.pieceqty = 'Order Qty Pcs';
  translationsHardCode.packqty = 'Pack Qty';
  translationsHardCode.pieceperpack = 'Piece Per Pack';
  translationsHardCode.balanceqty = 'Balance Qty';
  translationsHardCode.shipmentqty = 'Shipment Qty';
  translationsHardCode.customer = 'Customer';
  translationsHardCode.endcustomer = 'End Customer';
  translationsHardCode.style = 'Style No.';
  translationsHardCode.styledescription = 'Style Description';
  translationsHardCode.company = 'Division';
  translationsHardCode.formtype = 'Sales Order Type';
  translationsHardCode.ldcslnumber = 'Sales Order Item Line No.';
  translationsHardCode.linestatus__company__docdate  = 'Document Information';

  ERPLIST.translationsHardCode = translationsHardCode;


  /**
   * builds the table header
   */
  var mydata_json = JSON.stringify(mydata);
  var firstRow = mydata[0];

  var firstRowCopy = firstRow;
  var compositeColumnsLength = Object.keys(ERPLIST.compositeColumns).length;
  var countVisibleColumn = 1; // here start from 1 cz first td for option


  var $table = $('<table border=1 id="listTable" class="listTable" />');
  var $thead = $('<thead />');
  var $tbody = $('<tbody/>');
  /**
  * first header row------------------------------------------------------------------------------------------------------------------------------------------------------------
  */
  // var $tr = ERPLIST.generateFirstHeaderTr(firstRowCopy, translationsHardCode);
  var $tr = $("<tr/>");
  // $td = $('<th/>');
  // $td.html('');
  // $td.appendTo($tr);

    $.each(firstRowCopy, function (fieldname, fieldvalue) {
    // for (var fieldname in firstRowCopy) {
      // var fieldvalue = firstRowCopy[fieldname];
      
      // search this field is in composite column
      // and assume that its not under in composite colums
      var groupName = '';
      var groupFields = {};
      var hasInCompositeColumn = false;
      if(compositeColumnsLength > 0){
        for (var groupName in ERPLIST.compositeColumns) {
          groupFields = ERPLIST.compositeColumns[groupName];
          for (var thisfieldname in groupFields) {
            if(thisfieldname == fieldname){
              hasInCompositeColumn = true;
              break;
            }
          }
          if(hasInCompositeColumn) break;
        }
      }

      // if have then procceed composite column
      if (hasInCompositeColumn) {
      // hide first
      $.each(groupFields, function(fieldname, fieldStyle){
        var fielddesc = fieldname;
        $td = $('<th/>');
        if (!!translationsHardCode[fieldname]) fielddesc = translationsHardCode[fieldname];
        $td.html('<center>'+ fielddesc +'</center>');
        $td.css('display','none');
        $td.appendTo($tr);

        delete firstRowCopy[fieldname]; // its already procceed
      });

      $td = $('<th/>');
      $td.attr('class', groupName);
      if (!!translationsHardCode[groupName]) groupName = translationsHardCode[groupName];
      $td.html('<center>'+ groupName +'</center>');
      $td.appendTo($tr);
      countVisibleColumn++;

      } else {

      countVisibleColumn++;
      var fielddesc = fieldname;
      $td = $('<th/>');
      if (!!translationsHardCode[fieldname]) fielddesc = translationsHardCode[fieldname];
      $td.html('<center>'+ fielddesc +'</center>');
      if ( hideColumns.indexOf(fieldname) >= 0 ){ $td.css('display','none'); countVisibleColumn--};
      $td.appendTo($tr);

      }

    // }  
    });
  $tr.appendTo($thead);
  $thead.appendTo($table);
  // end -----------------------------------------------------------------------------------------------------------------


  /**
  * second header row-----------------------------------------------------------------------------------------------------------------------------------------------------------
  */
  var $tr = $("<tr/>").attr("id","searchForm");
  var $td;
  // $td = $('<td/>');
  // $td.html('<center>Option</center>');
  // $td.appendTo($tr);

  var firstRowCopy = JSON.parse(mydata_json)[0];
    $.each(firstRowCopy, function (fieldname, fieldvalue) {
    // for (var fieldname in firstRowCopy) {
      // var fieldvalue = firstRowCopy[fieldname];
      
      // search this field is in composite column
      // and assume that its not under in composite colums
      var groupName = '';
      var groupFields = {};
      var hasInCompositeColumn = false;
      if(compositeColumnsLength > 0){
        for (var groupName in ERPLIST.compositeColumns) {
          groupFields = ERPLIST.compositeColumns[groupName];
          for (var thisfieldname in groupFields) {
            if(thisfieldname == fieldname){
              hasInCompositeColumn = true;
              break;
            }
          }
          if(hasInCompositeColumn) break;
        }
      }

      // if have then procceed composite column
      if (hasInCompositeColumn) {   
      var compositeClass = '';
      $td = $('<td/>');
      $td.attr('class', groupName);
      $.each(groupFields, function(fieldname, fieldpropties){

        compositeClass +=  ( !!fieldpropties.end) ? fieldname : fieldname + '__';          
        var customsearch_option = ( !!fieldpropties.showsearchimg) ?'<button type="button" onclick="ERPLIST.handleCustomSearch(this);"><img src="img/search_icon.png" alt="" height="15" width="15"></button>': '';
        var customsearch_click  = ( !!fieldpropties.customsearch) ?'onclick="ERPLIST.handleCustomSearch(this);"': 'onclick="ERPLIST.handleThisSearchInputFieldClick(this);"';
        var customsearch_class  = ( !!fieldpropties.customsearch ) ? '  hasCustomSearch' : '';

        var html = '<center><input type="text" name="'+ compositeClass +'" value="" id="'+compositeClass+'" class="'+compositeClass + customsearch_class +'" '+ customsearch_click +' />'+ customsearch_option +'</center><div id="'+compositeClass+'_displaySearchParams" style="background-color:white;"></div>';
        $td.html(html);

        delete firstRowCopy[fieldname]; // its already procceed
        if(!!fieldpropties.single && fieldpropties.single == true) return; // need to make one td in list
        $td_hide = $('<td/>');
        $td_hide.html('<center><input type="hidden" class="'+ fieldname +'" value="" id="'+fieldname+'" /></center>');
        $td_hide.css('display','none');
        $td_hide.appendTo($tr);

      });
      $td.appendTo($tr);    

      } else {

      var fielddesc = fieldname;
      $td = $('<td/>');
      $td.attr('class', fieldname);
      $td.html('<center><input type="text"  name="'+ fieldname +'" class="'+ fieldname +'" value="" id="'+fieldname+'" onclick="ERPLIST.handleThisSearchInputFieldClick(this);" /></center><div id="'+fieldname+'_displaySearchParams" style="background-color:white;"></div>');
      if ( hideColumns.indexOf(fieldname) >= 0 ) $td.css('display','none');
      $td.appendTo($tr);

      }

    // }  
    });

    $tr.find('td.entitynumber').html('');
    $tr.find('td.ldcslnumber').html('');

  $tr.appendTo($thead);
  $thead.appendTo($table);
  /**
  * second header row end -----------------------------------------------------------------------------------------------------------------------------------------------------------
  */


  if(hasData == 'no'){
    $thead.appendTo($table);
    //custom for no record found
    var $tr = $("<tr/>");
    var $td = $('<td/>').attr("colspan",countVisibleColumn);
    $td.html('No Data Found')
    .css({'text-align':'center','vertical-align':'middle'});
    $td.appendTo($tr);
    $tr.appendTo($table);
    return $table;
  }


  /**
  * populates with data--------------------------------------------------------------------------------------------------------------------------------------------------
  */
  var mydata = JSON.parse(mydata_json);
  $.each(mydata, function (index, value) {

    var $tr = $("<tr/>"); // it should be in here
    $tr.attr("data-id",trDataId);
    trDataId++;

    var thisRow = value;
    var thisRowCopy = thisRow;
    var thisRowCopy_Json =  JSON.stringify(thisRow);

    // retrive variable here which is needed
    var formtype = thisRow['formtype'];
    var linestatus = thisRow['linestatus'];
    var ldcslnumber = thisRow['ldcslnumber'];

    // generate button if needed
    var btnLineChooser = '<center><input type="checkbox" class="multipleLineChooser" onclick="ERPLIST.handleLineChooserCheckboxClick(this);" ></center>';
    var btnThisLineAction = '';
    if(linestatus == 'Requisition Sent'){
      btnThisLineAction = '<button type="button" class="mbutton delete" onclick="ERPLIST.handleLineEvolutionBtnAction(this)">Cancel this line</button>';
    } else if(linestatus == 'Requisition Planned'){
      btnThisLineAction = '';
    }
    $td = $('<td/>');
    // $td.html(btnLineChooser);
    // $td.appendTo($tr);


      // looping over this row
      $.each(thisRow, function (fieldname, fieldvalue) {
      // for (var fieldname in firstRowCopy) {
        // var fieldvalue = firstRowCopy[fieldname];
        
        // search this field is in composite column
        // and assume that its not under in composite colums
        var groupName = '';
        var groupFields = {};
        var hasInCompositeColumn = false;
        if(compositeColumnsLength > 0){
          for (var groupName in ERPLIST.compositeColumns) {
            groupFields = ERPLIST.compositeColumns[groupName];
            for (var thisfieldname in groupFields) {
              if(thisfieldname == fieldname){
                hasInCompositeColumn = true;
                break;
              }
            }
            if(hasInCompositeColumn) break;
          }
        }

        var rowldcslnumber = thisRow['ldcslnumber'];

        // if have then procceed composite column
        if (hasInCompositeColumn) {

        $td = $('<td/>');
        $td.attr('class', groupName);
        $td.attr('fieldname', groupName);
        var compositeColumnsHTML = '';
        var divRow = '';
        $.each(groupFields, function(fieldname, fieldpropties){

          var fieldvalue = thisRow[fieldname];
          var fielddesc = (!!fieldpropties.fielddesc) ? fieldpropties.fielddesc : fieldname;
          var style = ( !!fieldpropties.style ) ? 'style="' + fieldpropties.style + '"': '';

          // *** write custom code here ---

          var obj_thisRowCopy_Json =  JSON.parse(thisRowCopy_Json);
          fieldvalue = (fieldname == "bookingformid") ? "<a href='list-ab-booking.php?bookingformid='+fieldvalue></a>" : fieldvalue;

          // *** custom code end ----------

          divRow += '<div class="crow" '+ '' +'>';
          if( (!!!fieldpropties.single) || (!!fieldpropties.single && fieldpropties.single == false) ){
            divRow += '<div class="ccell1 '+ fieldname +'" '+ style +'>'+ fielddesc +'</div>';
            divRow += '<div class="ccell2 '+ fieldname +'">:</div>';
          }
          divRow += '<div class="ccell3 '+ fieldname +'_ccell3" '+ style +'>'+ fieldvalue +'</div>';
          divRow += "</div>";

          delete thisRowCopy[fieldname]; // its already procceed
          if(!!fieldpropties.single && fieldpropties.single == true) return; // need to make one td in list
          $td_hide = $('<td/>');
          $td_hide.html(fieldvalue);
          $td_hide.attr("fieldname",fieldname);
          $td_hide.css('display','none');
          $td_hide.appendTo($tr);

        });

        var divTable = "<div id='ctable'>"; 
        divTable += divRow;  
        divTable += "</div>"; 

        compositeColumnsHTML = divTable;
        $td.html(compositeColumnsHTML)
        .css("cursor","pointer")
        .hover(
          function(){bgOn = $(this).closest("tr").css("background-color"); $(this).closest("tr").css("background-color", "lightblue");},
          function(){$(this).closest("tr").css("background-color", bgOn);}
        );
        $td.appendTo($tr);


        } else {

        // *** write custom code here ---
        var params = jsClient.paramsToObj(window.location.search);
        if(params.docviewflag == 'mp'){
            fieldvalue = (fieldname == "bookingformid") ? "<a href='list-ab-booking.php?bookingformid="+fieldvalue+"&docviewflag=mp'>"+fieldvalue+"</a>" : fieldvalue;
        } else if(params.docviewflag == 'sm'){
            fieldvalue = (fieldname == "bookingformid") ? "<a href='list-ab-booking.php?bookingformid="+fieldvalue+"&docviewflag=sm'>"+fieldvalue+"</a>" : fieldvalue;
        }else{
            fieldvalue = (fieldname == "bookingformid") ? "<a href='list-ab-booking.php?bookingformid="+fieldvalue+"&docviewflag=sm'>"+fieldvalue+"</a>" : fieldvalue;
        }
        // fieldvalue = (fieldname == "bookingformid") ? "<a href='list-ab-booking.php?bookingformid="+fieldvalue+"'>"+fieldvalue+"</a>" : fieldvalue;

        if(fieldname == "entitynumber" && fieldvalue != null  && fieldvalue != ""){
          var entitynumbers = fieldvalue.split(', ');
          var ldcslnumbers = rowldcslnumber.split(', ');

          if(entitynumbers.length == 1){
            fieldvalue = "<a href='list-doc-ab.php?doctype=AB&ldcslnumber="+ldcslnumbers+"&flag=abl' target='_blank'>"+entitynumbers+"</a>";
          } else {
            fieldvalue = "";
            for (var i = 0; i < entitynumbers.length; i++) {
              var entitynumber = entitynumbers[i];
              var ldcslnumber = ldcslnumbers[i];
              fieldvalue += "<a href='list-doc-ab.php?doctype=AB&ldcslnumber="+ldcslnumber+"&flag=abl' target='_blank'>"+entitynumber+"</a><br/>";
            }
          }
        }

        $td = $('<td/>');
        $td.html(fieldvalue)
        .css("white-space","pre-wrap")
        .attr("fieldname",fieldname)
        .css("cursor","pointer")
        .hover(
          function(){bgOn = $(this).closest("tr").css("background-color"); $(this).closest("tr").css("background-color", "lightblue");},
          function(){$(this).closest("tr").css("background-color", bgOn);}
        );
        if ( hideColumns.indexOf(fieldname) >= 0 ) $td.css('display','none');
        $td.appendTo($tr);

        }

      // }  
      });

    // *** custom code start-----------------------------------------------------------------------------------------
    // $tr.find('td.requiredinformation').append(btnThisLineAction);
    // *** custom code end-------------------------------------------------------------------------------------------

      $tr.click( function() { 
          ERPLIST.sendBackSearchChoice($(this));
        })
        .appendTo($tbody);
    });

    $thead.appendTo($table)
    $tbody.appendTo($table)

    return $table;
};



/**
* Custom function code------------------------------------------------------------------------------------------------------
*/
ERPLIST.customFunction = function(argument) {
}



ERPLIST.sendBackSearchChoice = function(thisRow){
  // var deliverylinenumber = $(thisRow).find('td[fieldname=subdoclinenumber]').text();
  // alert(deliverylinenumber);
}




ERPLIST.handleLineChooserCheckboxClick = function(thisf){
  var thisrow = $(thisf).closest('tr').attr('data-id');
  console.log(thisrow);
  // var docnumber = $(thisf).closest('tr').find('td[fieldname=docnumber] .ccell3 a').text();
  var entitynumber = $(thisf).closest('tr').find('td[fieldname=entitynumber]').text();
  // var bomlinestatus = $(thisf).closest('tr').find('td[fieldname=bomlinestatus]').text();

  var chooserType = $(thisf).prop('class');
  if(chooserType == 'multipleLineChooser'){
    // define array
    if(!!!ERPLIST.selectedLineInfo){
      ERPLIST.selectedLineInfo  = {};
      ERPLIST.selectedLineInfo.uniquekey = [];
      ERPLIST.selectedLineInfo.entitynumbers = [];
    } 
    if($(thisf).prop('checked')){
      $(thisf).prop('checked', true);
      // push data in array
      ERPLIST.selectedLineInfo.uniquekey.push(thisrow);
      ERPLIST.selectedLineInfo.entitynumbers.push(entitynumber);

    } else {
      $(thisf).prop('checked', false);
      var index = ERPLIST.selectedLineInfo.uniquekey.indexOf(thisrow);
      // pop data in array
      ERPLIST.selectedLineInfo.uniquekey.splice(index, 1);
      ERPLIST.selectedLineInfo.entitynumbers.splice(index, 1);
      console.log(JSON.stringify(ERPLIST.selectedLineInfo.entitynumbers) + '---' + index);
    }


  } else if (chooserType == 'singleLineChooser'){

    if($(thisf).prop('checked')){
      $('.singleLineChooser').prop('checked', false);
      $(thisf).prop('checked', true);
      // define variable
      // if(!!!ERPLIST.docnumber) ERPLIST.docnumber = docnumber;
      if(!!!ERPLIST.subdoclinenumber) ERPLIST.subdoclinenumber = subdoclinenumber;
      // if(!!!ERPLIST.bomlinestatus) ERPLIST.bomlinestatus = 'xxxx';

    } else {
      $(thisf).prop('checked', false);
      delete ERPLIST.subdoclinenumber;
      // delete ERPLIST.bomlinestatus;
    }
  }


}


ERPLIST.createBooking = function(){
  if(!!!ERPLIST.selectedLineInfo.entitynumbers){
    alert('Please select one line!');
    return;
  }

  // var next_href = window.location.origin + '/erp-apparel/list-doc-ab.php?doctype=AB&subdoclinenumber=' + ERPLIST.subdoclinenumber;
  // window.location.href = next_href;

    var postData = {
      reqType: 'assignBookingID',
      docobj: JSON.stringify(ERPLIST.selectedLineInfo.entitynumbers)
    };


      $.ajax({
        type: 'post',
        url: 'list-accesories-bom_api.php',
        data: postData,
        success: function(data) {
          // if result is JSON, we're using the new API return format
          // console.log(data);
          data = JSON.parse(data);
          if (!!data.result && data.result == "success") {
              var next_href = window.location.origin + '/erp-apparel/list-access-booking-form.php?bookingformid='+data.bookingID;
               window.location.href = next_href;
          } else {
              // location.reload();
            }

          
        }

      }).fail(function(e) {
        alert('Saving failed, please try again.');
      });





}

