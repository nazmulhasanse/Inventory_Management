/**
 * Check if jQuery is loaded
 */
if (!window.jQuery) {
  var jq = document.createElement('script');
  jq.type = 'text/javascript';
  jq.src = '/js/jquery-2.1.3.min.js';
  document.getElementsByTagName('head')[0].appendChild(jq);
}
/**
 * Declare ERPLIST Namespace if not exist
 */
var ERPLIST = ERPLIST || {};

$.extend(ERPLIST, {
  mUrl: 'api/server_api.php',
  mType: 'get',
  mData: '',
  mAsync: false,
  mReqType: '',
  queryData: '',
  queryParam: '',
  _searchParams: '',
  _URL_API: 'list-recalculation-rr-request_api.php',

  foo: 'here for no reason other than to be the last line, without a comma'
});

// fetching records



/**
 * How to use 
 * just call this function
 */
ERPLIST.initSearchAction = function(){
    $('#searchForm input').keypress(function (event) {
        if (event.which == 13) {
            ERPLIST.getSearchData();        
        }
    });
}



ERPLIST.makeTable = function(mydata,hasData) {
  var $table = $('<table border=1 id="listTable" class="listTable" />');
  var $thead = $('<thead />');
  var $tbody = $('<tbody/>');

  //for composition column
  ERPLIST.compositeColumns = {
    rrnumber:{
      rrnumber: {
        style: 'font-weight:bold; color:blue',
        customsearch: false,
        composite: false,
        end: true
      }
    },
    
    rrtype:{
      rrtype:{
        fielddesc: 'RR Type',
        style: 'font-weight:bold; color:green',
        islibrary: true,
        datasource: {
          projection: 'Projection',
          under_projection: 'Confirmed',
          direct: 'Direct'
        },
        customsearch: true,
        composite: false,
        end: true
      }
    },
    
    // rrstatus:{
    //   rrstatus: {
    //     fielddesc: 'RR Status',
    //     islibrary: true,
    //     datasource: {
    //       1: 'Allocated',
    //       2: 'Sent for Recalculation'
    //     },  
    //     customsearch: true,
    //     composite: false,
    //     end: true
    //   }
    // },

    bommoduleflag:{
      bommoduleflag: {
        fielddesc: 'Status',
        islibrary: true,
        datasource: {
          1: 'Pending',
          2: 'Confirmed'
        },  
        customsearch: true,
        composite: false,
        end: true
      }
    },

    company:{
      company:{
        fielddesc: 'Division',
        style: 'font-weight:bold; color:green',
        islibrary: true,
        sql: "SELECT Code AS code, Description AS description FROM mrd_library WHERE LibraryName='company'", 
        customsearch: true,
        composite: false,
        end: true
      }
    },
    
    // customer:{
    //   customer:{
    //     fielddesc: 'Customer',
    //     islibrary: true,
    //     sql: "SELECT Code AS code, Description AS description FROM mrd_library WHERE LibraryName='Buyer'", 
    //     customsearch: true,
    //     composite: false,
    //     end: true
    //   }
    // },

    endcustomer:{
      endcustomer:{
        fielddesc: 'End Customer',
        islibrary: true,
        sql: "SELECT Code AS code, Description AS description FROM mrd_library WHERE LibraryName='Buyer'", 
        customsearch: true,
        composite: false,
        end: true
      }
    },

    itemtype:{
      itemtype: {
        customsearch: false,
        composite: false,
        end: true
      }
    },

    itemcode:{
      itemcode: {
        customsearch: false,
        composite: false,
        end: true
      }
    },
    
    itemdescription:{
      itemdescription: {
        customsearch: false,
        composite: false,
        end: true
      }
    },

     requiredgrossqty:{
      requiredgrossqty: {
        customsearch: false,
        composite: false,
        end: true
      }
    },    

    // allocatedqty:{
    //   allocatedqty: {
    //     customsearch: false,
    //     composite: false,
    //     end: true
    //   }
    // },


    // actualdeductionqty:{
    //   actualdeductionqty: {
    //     customsearch: false,
    //     composite: false,
    //     end: true
    //   }
    // },


    // requirednetqty:{
    //   requirednetqty: {
    //     customsearch: false,
    //     composite: false,
    //     end: true
    //   }
    // },

    iduom:{
      iduom: {
        customsearch: false,
        composite: false,
        end: true
      }
    },

    fabricinhousedate:{
        fabricinhousedate:{
        fielddesc: 'Fabric Inhouse Date',
        customsearch: true,
        composite: false,
        type: 'date',
        end: true        
      }
    },

    sewingstartdate:{
        sewingstartdate:{
        fielddesc: 'Sewing Start Date',
        customsearch: true,
        composite: false,
        type: 'date',
        end: true        
      }
    },

    sewingfinisheddate:{
        sewingfinisheddate:{
        fielddesc: 'Sewing Finished Date',
        customsearch: true,
        composite: false,
        type: 'date',
        end: true        
      }
    },

    sewingperiod:{
        sewingperiod:{
        fielddesc: 'Sewing Period in days',
        customsearch: true,
        composite: false,
        type: 'date',
        end: true        
      }
    },

    
    fabricusageperday:{
      fabricusageperday: {
        customsearch: false,
        composite: false,
        end: true
      }
    },
    
    processbeforesewing:{
      processbeforesewing: {
        customsearch: false,
        composite: false,
        end: true
      }
    },

    processaftersewing:{
      processaftersewing: {
        customsearch: false,
        composite: false,
        end: true
      }
    },    
  }

  var params = jsClient.paramsToObj(window.location.search);
  if(params.rrtype == 'Direct'){
    var hideColumns = ['idlines', 'rridlines', 'customer', 'doctype','workorderdocnumber','bomdocnumber','cpdocnumber','salesorder','isrrfreezed','parentrrnumber','recalculationbit','linestatus','rrstatus','isseenbom','fabricinhousedate','sewingstartdate','sewingfinisheddate','sewingperiod','fabricusageperday','processbeforesewing','processaftersewing','salesorder','salesorderdeliverylinenumber'];
  }else{
    var hideColumns = ['idlines', 'rridlines', 'customer', 'doctype','workorderdocnumber','bomdocnumber','cpdocnumber','salesorder','isrrfreezed','recalculationbit','linestatus','rrstatus','isseenbom','fabricinhousedate','sewingstartdate','sewingfinisheddate','sewingperiod','fabricusageperday','processbeforesewing','processaftersewing','salesorder','salesorderdeliverylinenumber'];
  }
  // some trickery for nice formatting
  
  var translationsHardCode = {};
  translationsHardCode.iduom                        = 'UoM';
  translationsHardCode.elementuom                   = 'Elem. UoM';
  translationsHardCode.docstatus                    = 'Document Status';
  translationsHardCode.documentinformation          = 'Document Information';
  translationsHardCode.itemspecification            = 'Item Specification';
  translationsHardCode.docnumber                    = 'Document';
  translationsHardCode.allocatedqty                 = 'Allocated Qty';
  translationsHardCode.actualdeductionqty           = 'Equivalent Qty';
  translationsHardCode.requirednetqty               = 'Required Net Qty';
  translationsHardCode.salesorderdeliverylinenumber = 'SO Delivery Line No.';
  translationsHardCode.doclinenumber                = 'Bom Line No.';
  translationsHardCode.processbeforesewing          = 'Process Before Sewing';
  translationsHardCode.processaftersewing           = 'Process After Sewing';
  translationsHardCode.rrtype                       = 'RR Type';
  translationsHardCode.rrnumber                     = 'RR No.';
  translationsHardCode.rrstatus                     = 'RR Status';
  translationsHardCode.requiredgrossqty             = 'Required Gross Qty';
  translationsHardCode.parentrrnumber               = 'Projection RR';
  translationsHardCode.bommoduleflag                = 'Status';
  translationsHardCode.recalrequestdate             = 'Request Date';
  translationsHardCode.recalrequester               = 'Requester';
  
  translationsHardCode.cpdocnumber                  = 'CP No.';
  translationsHardCode.bomlinenumber                = 'BOM Line No.';
  translationsHardCode.bomdocnumber                 = 'BOM No.';
  translationsHardCode.company                      = 'Division';
  translationsHardCode.formtype                     = 'Form Type';
  translationsHardCode.itemtype                     = 'Item Type';
  translationsHardCode.itemcode                     = 'Item Code';
  translationsHardCode.itemdescription              = 'Item Description';
  translationsHardCode.tnxqty                       = 'Quantity';
  translationsHardCode.ldcslnumber                  = 'SO Item Line No.';
  translationsHardCode.customer                     = 'Customer';
  translationsHardCode.endcustomer                  = 'End Customer';
  translationsHardCode.sewingperiod                 = 'Sewing Period in Days';
  translationsHardCode.fabricusageperday            = 'Fabric Usage per Day';
  translationsHardCode.processesbeforesewing        = 'Processes Before Sewing';
  translationsHardCode.salesorder                   = 'Sales Order No.';
  translationsHardCode.salesorderdeliverylinenumber = 'Sales Order Delivery Line No.';
  translationsHardCode.sewingstartdate              = 'Sewing Start Date';
  translationsHardCode.sewingfinisheddate           = 'Sewing Finished Date';
  translationsHardCode.fabricinhousedate            = 'Fabric Inhouse Date';
  translationsHardCode.itemlot                      = 'Internal Lot';
  translationsHardCode.whlocation                   = 'Ware-House Location';
  translationsHardCode.binlocation                  = 'Bin Location';
  translationsHardCode.fabricwidth                  = 'Dia';

  ERPLIST.rrLinesTranslationsHardCode = translationsHardCode;


  // builds the table header
  var mydata_json = JSON.stringify(mydata);
  var firstRow = mydata[0];

  var firstRowCopy = firstRow;
  var compositeColumnsLength = Object.keys(ERPLIST.compositeColumns).length;
  var countVisibleColumn = 1; // here start from 1 cz first td for option
  /**
   * first header row------------------------------------------------------------------------------------------------------------------------------------------------------------
   */
  var $tr = $("<tr/>");
  $td = $('<th/>');
  $td.html('');
  $td.appendTo($tr);

  // process composite column first if has
  if(compositeColumnsLength > 0){
    $.each(ERPLIST.compositeColumns, function(groupName, groupColumns){
      // hide first
      $.each(groupColumns, function(fieldname, fieldStyle){
        var fielddesc = fieldname;
        $td = $('<th/>');
        if (!!ERPLIST.rrLinesTranslationsHardCode[fieldname]) fielddesc = ERPLIST.rrLinesTranslationsHardCode[fieldname];
        $td.html('<center>'+ fielddesc +'</center>');
        $td.css('display','none');
        $td.appendTo($tr);

        delete firstRowCopy[fieldname]; // its already procceed
      });

      $td = $('<th/>');
      $td.attr('class', groupName);
      if ( hideColumns.indexOf(groupName) >= 0 ){ 
        $td.css('display','none'); countVisibleColumn--;
      }else{
        countVisibleColumn++;
      }
      if (!!ERPLIST.rrLinesTranslationsHardCode[groupName]) groupName = ERPLIST.rrLinesTranslationsHardCode[groupName];
      $td.html('<center>'+ groupName +'</center>');
      $td.appendTo($tr);
      // countVisibleColumn++;
    });
  }

  // precess rest of columns----------------------------------------------------------------------------------------------
  $.each(firstRowCopy, function (fieldname, fieldvalue) {
    countVisibleColumn++;
    var fielddesc = fieldname;
    $td = $('<th/>');
    if (!!ERPLIST.rrLinesTranslationsHardCode[fieldname]) fielddesc = ERPLIST.rrLinesTranslationsHardCode[fieldname];
    $td.html('<center>'+ fielddesc +'</center>');
    if ( hideColumns.indexOf(fieldname) >= 0 ){ $td.css('display','none'); countVisibleColumn--};
    $td.appendTo($tr);
  });
  $tr.appendTo($thead);
  $thead.appendTo($table);
  // end -----------------------------------------------------------------------------------------------------------------


  /**
   * second header row-----------------------------------------------------------------------------------------------------------------------------------------------------------
   */
  var $tr = $("<tr/>").attr("id","searchForm");
  var $td;
  $td = $('<td/>');
  $td.html('Option');
  $td.appendTo($tr);

  if(compositeColumnsLength > 0){
    $.each(ERPLIST.compositeColumns, function(groupName, groupColumns){

      var compositeClass = '';
      $td = $('<td/>');
      $td.attr('class', groupName);
      $.each(groupColumns, function(fieldname, fieldpropties){

        compositeClass +=  ( !!fieldpropties.end) ? fieldname : fieldname + '__';          
        var customsearch_option = ( !!fieldpropties.showsearchimg) ?'<button type="button" onclick="ERPLIST.handleCustomSearch(this);"><img src="img/search_icon.png" alt="" height="15" width="15"></button>': '';
        var customsearch_click  = ( !!fieldpropties.customsearch) ?'onclick="ERPLIST.handleCustomSearch(this);"': 'onclick="ERPLIST.handleThisSearchInputFieldClick(this);"';
        var customsearch_class  = ( !!fieldpropties.customsearch ) ? '  hasCustomSearch' : '';

        var html = '<center><input type="text" name="'+ compositeClass +'" value="" id="'+compositeClass+'" class="'+compositeClass + customsearch_class +'" onclick="ERPLIST.handleCustomSearch(this);" />'+ customsearch_option +'</center><div id="'+compositeClass+'_displaySearchParams" style="background-color:white;"></div>';
        $td.html(html);

        // delete firstRowCopy[fieldname]; // its already procceed
        if(fieldpropties.composite == false) return;
        $td_hide = $('<td/>');
        $td_hide.html('<center><input type="hidden" class="'+ fieldname +'" value="" id="'+fieldname+'" /></center>');
        $td_hide.css('display','none');
        $td_hide.appendTo($tr);

      });
      if ( hideColumns.indexOf(groupName) >= 0 ) $td.css('display','none');
      $td.appendTo($tr);

    });
  }
  // end -----------------------------------------------------------------------------------------------------------------

  // precess rest of columns----------------------------------------------------------------------------------------------
  $.each(firstRowCopy, function (fieldname, fieldvalue) {    
    var fielddesc = fieldname;
    $td = $('<td/>');
    $td.attr('class', fieldname);
    $td.html('<center><input type="text"  name="'+ fieldname +'" class="'+ fieldname +'" value="" id="'+fieldname+'" onclick="ERPLIST.handleThisSearchInputFieldClick(this);" /></center><div id="'+fieldname+'_displaySearchParams" style="background-color:white;"></div>');
    if ( hideColumns.indexOf(fieldname) >= 0 ) $td.css('display','none');
    $td.appendTo($tr);
  });
  $tr.appendTo($thead);
  $thead.appendTo($table);
  // end -----------------------------------------------------------------------------------------------------------------
  /**
   * second header row end -----------------------------------------------------------------------------------------------------------------------------------------------------------
   */

  if(hasData == 'no'){
    $thead.appendTo($table);
    //custom for no record found
    var $tr = $("<tr/>");
    // var numberOfColumn = $("#listTable > thead > tr:first > th:visible").length;
    var $td = $('<td/>').attr("colspan",countVisibleColumn);
    $td.html('No Data Found')
      .css({'text-align':'center','vertical-align':'middle'});
    $td.appendTo($tr);
    $tr.appendTo($table);
    return $table;
  }

  /**
   * populates with data--------------------------------------------------------------------------------------------------------------------------------------------------
   */
  var mydata = JSON.parse(mydata_json);
  $.each(mydata, function (index, value) {
    var $tr = $("<tr/>"); // it should be in here

    var thisRow = value;
    var thisRowCopy = thisRow;
    var thisRowCopy_Json =  JSON.stringify(thisRow);

    var formtype = thisRow['formtype'];
    var linestatus = thisRow['linestatus'];
    var isseenbom = thisRow['isseenbom'];
    // generate button if needed
    var thisLineActionBtn = '';
    if(isseenbom == '0'){
      thisLineActionBtn = '<center><input type="checkbox" class="chkrrline" name="" onclick="ERPLIST.lineChooser(this);"></center>';
      thisLineActionBtn += '</br>';
      thisLineActionBtn += '<center><input type="image" src="img/eye_icon.png" style="width:40pt" onclick="ERPLIST.markasRead(this);"></center>';
    } else{
      thisLineActionBtn = '<center><input type="checkbox" class="chkrrline" name="" onclick="ERPLIST.lineChooser(this);"></center>';
    }

    $td = $('<td/>');
    $td.html(thisLineActionBtn);
    $td.appendTo($tr);

    // process composite column first if has----------------------------------------------------------------------------------
    if(compositeColumnsLength > 0){
      $.each(ERPLIST.compositeColumns, function(groupName, groupColumns){
        $td = $('<td/>');
        $td.attr('class', groupName);
        $td.attr('fieldname', groupName);
        var compositeColumnsHTML = '';
        var divRow = '';
        $.each(groupColumns, function(fieldname, fieldprop){

          var fieldvalue = thisRow[fieldname];
          var fielddesc = (!!fieldprop.fielddesc) ? fieldprop.fielddesc : fieldname;
          var style = ( !!fieldprop.style ) ? 'style="' + fieldprop.style + '"': '';

          // *** write custom code here

          var obj_thisRowCopy_Json =  JSON.parse(thisRowCopy_Json);
          fieldvalue = (fieldname == "rrnumber") ? "<a href='erpdocument.php?rrnumber="+fieldvalue+"&doctype=T7&formtype="+formtype+"' target='_blank''>"+fieldvalue+"</a>" : fieldvalue;

          // *** custom code end

          divRow += '<div class="crow" '+ '' +'>';
          if( !!fieldprop.composite ){
            divRow += '<div class="ccell1 '+ fieldname +'" '+ style +'>'+ fielddesc +'</div>';
            divRow += '<div class="ccell2 '+ fieldname +'">:</div>';
          }
          divRow += '<div class="ccell3 '+ fieldname +'_ccell3" '+ style +'>'+ fieldvalue +'</div>';
          divRow += "</div>";

          delete thisRowCopy[fieldname]; // its already procceed
          if(fieldprop.composite == false) return;
          $td_hide = $('<td/>');
          $td_hide.html(fieldvalue);
          $td_hide.attr("fieldname",fieldname);
          $td_hide.css('display','none');
          $td_hide.appendTo($tr);

        });

        var divTable = "<div id='ctable'>"; 
        divTable += divRow;  
        divTable += "</div>"; 

        compositeColumnsHTML = divTable;
        $td.html(compositeColumnsHTML)
          .css("cursor","pointer")
          .hover(
               function(){bgOn = $(this).closest("tr").css("background-color"); $(this).closest("tr").css("background-color", "lightblue");},
               function(){$(this).closest("tr").css("background-color", bgOn);}
             );
        if ( hideColumns.indexOf(groupName) >= 0 ) $td.css('display','none');
        $td.appendTo($tr);

      });
    }
    // end -----------------------------------------------------------------------------------------------------------------

    // precess rest of columns----------------------------------------------------------------------------------------------
    $.each(thisRowCopy, function (fieldname, fieldvalue) {

      // *** write custom code here
      fieldvalue = (fieldname == "docnumber") ? "<a href='erpdocument.php?docnumber="+fieldvalue+"&doctype=DR&formtype="+formtype+"&docviewflag=apparel' target='_blank''>"+fieldvalue+"</a>" : fieldvalue;

      // *** custom code end

      $td = $('<td/>');
        $td.html(fieldvalue)
          .css("white-space","pre-wrap")
          .attr("fieldname",fieldname)
          .attr("class",fieldname)
          .css("cursor","pointer")
          .hover(
               function(){bgOn = $(this).closest("tr").css("background-color"); $(this).closest("tr").css("background-color", "lightblue");},
               function(){$(this).closest("tr").css("background-color", bgOn);}
             );
        if ( hideColumns.indexOf(fieldname) >= 0 ) $td.css('display','none');
        $td.appendTo($tr);
    });


    // *** custom code start-----------------------------------------------------------------------------------------
    // $tr.find('td.requiredinformation').append(thisLineActionBtn);
    // *** custom code end-------------------------------------------------------------------------------------------


    $tr.click( function() { 
        // sendBackSearchChoice($(this));
      })
      .appendTo($tbody);
  });

  $thead.appendTo($table)
  $tbody.appendTo($table)

  return $table;
};





ERPLIST.lineChooser = function(thisf){
  var thisrow = $(thisf).parent().parent().parent().index();
  var idlines = $(thisf).closest('tr').find('td[fieldname=idlines]').text();
  var rrnumber = $(thisf).closest('tr').find('td[fieldname=rrnumber]').text();
  var requirednetqty = $(thisf).closest('tr').find('td[fieldname=requirednetqty]').text();
  var fabricinhousedate = $(thisf).closest('tr').find('td[fieldname=fabricinhousedate]').text();
  var itemcode = $(thisf).closest('tr').find('td[fieldname=itemcode]').text();
  var linestatus = $(thisf).closest('tr').find('td[fieldname=linestatus]').text();
  var isrrfreezed = $(thisf).closest('tr').find('td[fieldname=isrrfreezed]').text();
  var recalculationbit = $(thisf).closest('tr').find('td[fieldname=recalculationbit]').text();
  var bommoduleflag = $(thisf).closest('tr').find('td[fieldname=bommoduleflag]').text();
  var chooserType = $(thisf).prop('class');
  console.log(recalculationbit);

  if(!!!ERPLIST.selectedLineInfo){
    ERPLIST.selectedLineInfo  = {};
    ERPLIST.selectedLineInfo.uniquekey = [];
    ERPLIST.selectedLineInfo.idlines = [];
    ERPLIST.selectedLineInfo.rrnumbers = [];
    ERPLIST.selectedLineInfo.requirednetqty = [];
    ERPLIST.selectedLineInfo.fabricinhousedate = [];
    ERPLIST.selectedLineInfo.itemcode = [];
    ERPLIST.selectedLineInfo.linestatus = [];
    ERPLIST.selectedLineInfo.isrrfreezed = [];
    ERPLIST.selectedLineInfo.recalculationbit = [];
    ERPLIST.selectedLineInfo.bommoduleflag = [];
  } 
  if($(thisf).prop('checked')){
    $(thisf).prop('checked', true);
    // push data in array
    ERPLIST.selectedLineInfo.uniquekey.push(thisrow);
    ERPLIST.selectedLineInfo.idlines.push(idlines);
    ERPLIST.selectedLineInfo.rrnumbers.push(rrnumber);
    ERPLIST.selectedLineInfo.requirednetqty.push(requirednetqty);
    ERPLIST.selectedLineInfo.fabricinhousedate.push(fabricinhousedate);
    ERPLIST.selectedLineInfo.itemcode.push(itemcode);
    ERPLIST.selectedLineInfo.linestatus.push(linestatus);
    ERPLIST.selectedLineInfo.isrrfreezed.push(isrrfreezed);
    ERPLIST.selectedLineInfo.recalculationbit.push(recalculationbit);
    ERPLIST.selectedLineInfo.bommoduleflag.push(bommoduleflag);

  } else {
    $(thisf).prop('checked', false);
    var index = ERPLIST.selectedLineInfo.rrnumbers.indexOf(rrnumber);
    // pop data from array
    ERPLIST.selectedLineInfo.uniquekey.splice(index, 1);
    ERPLIST.selectedLineInfo.idlines.splice(index, 1);
    ERPLIST.selectedLineInfo.rrnumbers.splice(index, 1);
    ERPLIST.selectedLineInfo.requirednetqty.splice(index, 1);
    ERPLIST.selectedLineInfo.fabricinhousedate.splice(index, 1);
    ERPLIST.selectedLineInfo.itemcode.splice(index, 1);
    ERPLIST.selectedLineInfo.linestatus.splice(index, 1);
    ERPLIST.selectedLineInfo.isrrfreezed.splice(index, 1);
    ERPLIST.selectedLineInfo.recalculationbit.splice(index, 1);
    ERPLIST.selectedLineInfo.bommoduleflag.splice(index, 1);
    console.log(JSON.stringify(ERPLIST.selectedLineInfo.idlines) + '---' + index);
  }

  console.log(ERPLIST.selectedLineInfo.bommoduleflag);

}




ERPLIST.markasRead = function(thisline){
  
  rrnumber = $(thisline).closest('tr').find('td[fieldname=rrnumber]').text();
  console.log(rrnumber);
  var mType    = 'post';
  var mUrl     = "list-recalculation-rr-request_api.php";
  var mReqType = "updateSeenStatus";
  var postData = JSON.stringify({
    rrnumber : rrnumber
  });
  var returnData = jsClient.communicationToServer(mReqType, postData, mUrl, mType, false);

  resultParse = JSON.parse(returnData);
  console.log(resultParse['result']);
  ERPLIST.getListData();
}



ERPLIST.checkRecalculationRequest = function(){
  length = ERPLIST.selectedLineInfo.rrnumbers.length;
  if(length != 1){
    alert('You have to select only one RR line for Recalculation');
    return;
  }

  // arrayRecalculationbit = ERPLIST.selectedLineInfo.recalculationbit;
  // for(i=0 ; i < length ; i++){
  //   //check recalculation
  //   if(arrayRecalculationbit[i] != '1'){
  //     alert('You have to select only recalculation(Red) RR lines send it to BOM.');
  //     return;
  //   }

  // }

  var content = '<fieldset>';
  content += '<form id="form_allocationPopup">';

  content += '<div id="loadingDiv">';
  content += '</div>';

  content += '<div id="requestInfo">';
  content += '</div>';
  content += '<br><br>';

  content += '<div id="popup_rrlinetab">';
  content += '<span>Replenishment Requisiton Lines</span>';
  content += '</div>';
  content += '<br><br>';

  content += '<div id="popup_bulkinventorytab">';
  content += '<span>Inventory Stock</span>';
  content += '</div>';
  content += '<br><br>';

  content += '<div id="bomandattachment">';
  content += '<div id="popup_bomlineinfo" class="inline">';
  content += '<span>BOM Information</span>';
  content += '</div>';
  content += '<div id="attachment" class="inline">';
  content += '<br>';
  content += '</div>';
  content += '</div>';

  content += '</table>';
  content += '<br><br><br>';
  content += '<center id="center_submit"><input type="button" id="btnConfirmToMaterialPlanner" value="Confirm To Material Planner" class="button"></center>';
  content += '</form>';
  content += '</fieldset>';


  $.fancybox({
   'autoScale': true,
   'transitionIn': 'elastic',
   'transitionOut': 'elastic',
   'speedIn': 500,
   'speedOut': 300,
   'autoDimensions': true,
   'centerOnScroll': true,
   'content': content,
   'href' : '#fancybox_colorcode',
    afterLoad: function(){
      this.title = '<p style="font-size:12pt;"><b>Recalculation Request</b></p>';
    },
    afterShow: function() {
      ERPLIST.getBulkInventoryLineTable_popup();
      ERPLIST.getRRLineTablePopup();
      ERPLIST.getBOMLineInfo_popup();
      ERPLIST.sendToMaterialPlanner();
      $.fancybox.update();

      if(ERPLIST.selectedLineInfo.bommoduleflag[0] == 'Confirmed'){
        $('#center_submit').css("display","none");
      }
      //css for attachment
      $('#bomandattachment').css("display","flex");
      $('#popup_bomlineinfo').css("width","200px");
      $('#attachment').css({"flex":"1"});
      $('.inline').css("margin-right","20px");
    },
    helpers: {
     title : {
      type : 'inside',
      position : 'top'
     },
     overlay : {
      css  : { /* 'background-color' : '#fff' */}
     }     
    }   
  });
  jQuery('.fancybox-title').css({'text-align':'center', 'margin-bottom':'10px'});


}



ERPLIST.sendToMaterialPlanner = function(){

  $('#btnConfirmToMaterialPlanner').click(function(){

    r = confirm('Are you sure to confirm this Request to Material Planner?');
    if(!r) return;

    rrnumber = ERPLIST.selectedLineInfo.rrnumbers[0];
    console.log(rrnumber);
    var postData = JSON.stringify({rrnumber:rrnumber});
    var mType    = 'post';
    var mUrl     = ERPLIST._URL_API;
    var mReqType = "sendToMaterialPlanner";
    var returnData = jsClient.communicationToServer(mReqType, postData, mUrl, mType, false);

    returnData = JSON.parse(returnData);
    delete(ERPLIST.selectedLineInfo);
    ERPLIST.getListData();
    $.fancybox.close();
  });
}

/**
 * This function will make popup bulk inventory line table
 */
ERPLIST.getBulkInventoryLineTable_popup = function(){
  searchParams = "";
  inventoryLinetable = "";
  if(rrnumber != '')  searchParams += "rrnumber=" + ERPLIST.selectedLineInfo.rrnumbers;

  $.ajax({
      type: "GET",
      url: ERPLIST._URL_API,
      data: "reqType=getBulkAllocation&" + searchParams,
      cache: false,
      beforeSend: function() {
          $('#form_allocationPopup #loadingDiv').html('<center><img src="/images/loading_spinner.gif"></center>');
      },
      success: function(jsonData) {
        $('#form_allocationPopup #loadingDiv').html('');
        var parseData = JSON.parse(jsonData);
        var listData = parseData['listData'];
        inventoryLinetable = ERPLIST.makeInventoryLineTable_popup(JSON.stringify(listData));
        $('#popup_bulkinventorytab').append(inventoryLinetable);
        $.fancybox.update();
      }
  });
}


ERPLIST.makeInventoryLineTable_popup = function(mydata) {
  mydata = JSON.parse(mydata);
  var formtypeTranslation = {projection:'Projection', under_projection:'Projection Confirm', direct:'Direct Confirm'}
  var docStatusTranslation = {0:'Entered', 1:'Informed to Capacity Plan', 2:'Informed to BOM', 3:'Informed to BOM and Capacity Plan', 9:'Closed'}

  // some trickery for nice formatting
  var hideColumns = ['idlines','idaccount','rridlines','rrnumber','itemtype','itemcode','itemlot','whlocation','binlocation','endcustomer'];
  var translationsHardCode = {};
  if(!!ERPLIST.rrLinesTranslationsHardCode) translationsHardCode  = ERPLIST.rrLinesTranslationsHardCode;
  // you can override translationsHardCode if you needed
  translationsHardCode.iduom = 'UOM';
  translationsHardCode.quantity = 'Allocated Quantity';
  translationsHardCode.deductionqty = 'Equivalent Quantity';


  var $table = $('<table border=1 id="listTable" class="listTable" />');
  var $thead = $('<thead />');
  var $tbody = $('<tbody/>');

  // builds the table header
  var firstRow = mydata[0];
  var $td;
  var $tr = $("<tr/>");

  $.each(firstRow, function (key, val) {
    $td = $('<th/>');
    $td.html(key);
    if (!!translationsHardCode[key]) $td.html(translationsHardCode[key]);
    if ( hideColumns.indexOf(key) >= 0 ) $td.css('display','none');
    $td.appendTo($tr);
  });
  $tr.appendTo($thead);

  // populates with data
  $.each(mydata, function (index, value) {
    var thisRow = value;
    var $tr = $("<tr/>");

    $.each(value, function (key, val) {
      
      var thisrowval = value;
      var formtype = thisrowval['formtype'];

      val = (key == "docnumber") ? "<a href='/erp-apparel/erpdocument.php?docnumber="+val+"&doctype=SO&formtype="+formtype+"' target='_blank'>"+val+"</a>" : val;

      if(key == "deductionqty" && ERPLIST.selectedLineInfo.bommoduleflag[0] != 'Confirmed'){
        val = ERPLIST.generateHTMLdeductionQty(thisrowval,key, val);
      }

      $td = $('<td/>');
      $td.html(val)
        .css("white-space","pre-wrap")
        .attr("fieldname",key)
        .css("cursor","pointer")
        .hover(function(){ $(this).closest("tr").css("background-color", "lightblue");},
             function(){ $(this).closest("tr").css("background-color", "");}
           );
      if (key == 'formtype' && !!formtypeTranslation[val]) $td.html(formtypeTranslation[val]);  
      if (key == 'docstatus' && !!docStatusTranslation[val]) $td.html(docStatusTranslation[val]);  
      if ( hideColumns.indexOf(key) >= 0 ) $td.css('display','none');
      $td.appendTo($tr);
    });
    $tr.click( function() { 
        // sendBackSearchChoice($(this));
      })
      .appendTo($tbody);
  });

  $thead.appendTo($table);
  $tbody.appendTo($table);

  return $table;
};





ERPLIST.generateHTMLdeductionQty = function(thisRowCopy,fieldname, fieldvalue){
  var deductionQty = fieldvalue;

  if(fieldvalue == "" || fieldvalue == null || fieldvalue == "0"){
    var content = '<div id="formDiv" style="display:none;">'
    content += '<input type="number" name="deductionqty" value="" id="deductionqty">';
    content += '<input type="button" value="Done" onclick="ERPLIST.setDeductionQty(this ' +","+ '  \'' + thisRowCopy['idlines'] + '\')"/>';
    content += '</div>';

    var content2 = '<div id="btnDiv1">';
    content2 += '<input type="button" value="Equivalent Qty" onclick="ERPLIST.showDeductionQty(this)"/>';
    content2 += '</div>';

    var content3 = '<div id="btnDiv2" style="float:left;display:none;">';
    content3 += '<a href="javascript:void(0)" onclick="ERPLIST.showDeductionQty(this)"><img src="img/edit.png"></a>';
    content3 += '</div>';

    var content4 = '<div id="showDeductionQty" style="float:left;display:none;">';
    content4 += '<span>' +deductionQty+ '</span>';
    content4 += '</div>';

    fieldvalue = content4;
    fieldvalue += content;
    fieldvalue += content2;
    fieldvalue += content3;
  }else{
    var content = '<div id="formDiv" style="display:none;">'
    content += '<input type="number" name="deductionQty" value="'+deductionQty+'" id="deductionQty">';
    content += '<input type="button" value="Done" onclick="ERPLIST.setDeductionQty(this ' +","+ '  \'' + thisRowCopy['idlines'] + '\')"/>';
    content += '</div>';

    var content2 = '<div id="btnDiv2" style="float:left;">';
    content2 += '<a href="javascript:void(0)" onclick="ERPLIST.showDeductionQty(this)"><img src="img/edit.png"></a>';
    content2 += '</div>';

    var content3 = '<div id="showDeductionQty" style="float:left;">';
    content3 += '<span>' +deductionQty+ '</span>';
    content3 += '</div>';

    fieldvalue = content3;
    fieldvalue += content;
    fieldvalue += content2;          
  }  

  return fieldvalue;
}



ERPLIST.showDeductionQty = function (thisbtn){
  $(thisbtn).parents('td').find('#formDiv').css({'display':'block'});
  $(thisbtn).parents('td').find('#btnDiv1').css({'display':'none'});
  $(thisbtn).parents('td').find('#btnDiv2').css({'display':'none'});
  jsClient.initDateTimePicker();
}

ERPLIST.setDeductionQty = function(thisbtn, idlines){
  var deductionqty = $(thisbtn).parents('td').find('#formDiv input#deductionqty').val();
  var rrnumber     = $(thisbtn).closest('tr').find('td[fieldname=rrnumber]').text();
  var rridlines    = $(thisbtn).closest('tr').find('td[fieldname=rridlines]').text();
  var idlines      = $(thisbtn).closest('tr').find('td[fieldname=idlines]').text();

  if(deductionqty == "" || deductionqty == null){
    deductionqty = 0;
  }

  var postData = JSON.stringify({idlines:idlines, rridlines:rridlines, deductionqty:deductionqty});
  var mType    = 'post';
  var mUrl     = ERPLIST._URL_API;
  var mReqType = "setDeductionQty";
  var returnData = jsClient.communicationToServer(mReqType, postData, mUrl, mType, false);

  returnData = JSON.parse(returnData);
  if(returnData.result == 'success'){
    $(thisbtn).parents('td').find('#formDiv').css({'display':'none'});
    $(thisbtn).parents('td').find('#btnDiv1').css({'display':'none'});
    $(thisbtn).parents('td').find('#btnDiv2').css({'display':'block'});

    $(thisbtn).parents('td').find('#showDeductionQty').css({'display':'block'});

    $(thisbtn).parents('td').find('#showDeductionQty').find('span').text(deductionqty);

    jsClient.msgDisplayer('success:: Successfully updated deductionqty '+rrnumber); // green
  }

}

/**
 * This function will make RR  line table
 */
ERPLIST.getRRLineTablePopup = function(){
  searchParams = "";
  inventoryLinetable = "";
  if(rrnumber != '')  searchParams += "rrnumber=" + ERPLIST.selectedLineInfo.rrnumbers;

  $.ajax({
      type: "GET",
      url: ERPLIST._URL_API,
      data: "reqType=getRRLineTablePopup&" + searchParams,
      cache: false,
      beforeSend: function() {
          $('#form_allocationPopup #loadingDiv').html('<center><img src="/images/loading_spinner.gif"></center>');
      },
      success: function(jsonData) {
        $('#form_allocationPopup #loadingDiv').html('');
        var parseData = JSON.parse(jsonData);
        var listData = parseData['listData'];
        rrLinetable = ERPLIST.makeRRLineTable_popup(JSON.stringify(listData));
        requestInfo = ERPLIST.makeRequestInfo_popup(JSON.stringify(listData));
        $('#popup_rrlinetab').append(rrLinetable);
        $('#requestInfo').append(requestInfo);
        $.fancybox.update();
      }
  });
}


/**
 * This function will make popup BOM line Info
 */
ERPLIST.getBOMLineInfo_popup = function(){
  rrnumber = ERPLIST.selectedLineInfo.rrnumbers[0];
  $.ajax({
      type: "GET",
      url:  ERPLIST._URL_API,
      data: "reqType=getBOMInformation&rrnumber=" + rrnumber,
      cache: false,
      beforeSend: function() {
      },
      success: function(jsonData) {
        var rrLineTable = ERPLIST.makeBOMTable_popup(jsonData);
        $('#popup_bomlineinfo').append(rrLineTable);
        attachment = JSON.parse(jsonData)[0]['docnumber'];
        $('#attachment').append(attachment);
      }
  });
}


ERPLIST.makeBOMTable_popup = function(jsonData){

  var data = JSON.parse(jsonData)[0];
  var table = '<table border=1 id="listTable" class="listTable">';
  $.each(data,function(key,value){

    if(!!ERPLIST.rrLinesTranslationsHardCode) translationsHardCode  = ERPLIST.rrLinesTranslationsHardCode;
    translationsHardCode.consumption = "Consumption";
    translationsHardCode.processloss = "Process Loss(%)";
    translationsHardCode.style = "Style#";

    hideColumns = ['docnumber'];
    userField = key;
    if (!!translationsHardCode[key]) userField = translationsHardCode[key];

    if ( hideColumns.indexOf(key) >= 0 ){
    }else{
      table += "<tr><td><b>"+userField+"</b></td><td>"+value+"</td></tr>";
    }
     
  });

  table += "</table>";

  return table;
}



ERPLIST.makeRequestInfo_popup = function(mydata){
  mydata = JSON.parse(mydata);
  var firstRow = mydata[0];

  var requester = firstRow['recalrequester'];
  var requestdate = firstRow['recalrequestdate'];

  var table = '<table class="no_border">';
  table += '<tr><th>Request Date<th><td>:</td><td>'+requestdate+'</td></tr>'; 
  table += '<tr><th>Requester<th><td>:</td><td>'+requester+'</td></tr>'; 
  table += '</table>'; 

  return table;
}

ERPLIST.makeRRLineTable_popup = function(mydata) {
  mydata = JSON.parse(mydata);
  var formtypeTranslation = {projection:'Projection', under_projection:'Projection Confirm', direct:'Direct Confirm'}
  var docStatusTranslation = {0:'Entered', 1:'Informed to Capacity Plan', 2:'Informed to BOM', 3:'Informed to BOM and Capacity Plan', 9:'Closed'}

  // some trickery for nice formatting
  var hideColumns = ['rrfiles','idlines','idaccount','salesorder','sewingstartdate','sewingfinisheddate','processbeforesewing','processaftersewing','sewingperiod','fabricusageperday','fabricinhousedate','rrtype','rrstatus','company','endcustomer','itemtype','itemcode','allocatedqty','actualdeductionqty','requirednetqty','ldcslnumber','bomdocnumber','cpdocnumber','recalrequester','recalrequestdate'];
  var translationsHardCode = {};
  if(!!ERPLIST.rrLinesTranslationsHardCode) translationsHardCode  = ERPLIST.rrLinesTranslationsHardCode;
  // you can override translationsHardCode if you needed
  translationsHardCode.iduom = 'UOM';


  var $table = $('<table border=1 id="listTable" class="listTable" />');
  var $thead = $('<thead />');
  var $tbody = $('<tbody/>');

  // builds the table header
  var firstRow = mydata[0];
  var $td;
  var $tr = $("<tr/>");

  $.each(firstRow, function (key, val) {
    $td = $('<th/>');
    $td.html(key);
    if (!!translationsHardCode[key]) $td.html(translationsHardCode[key]);
    if ( hideColumns.indexOf(key) >= 0 ) $td.css('display','none');
    $td.appendTo($tr);
  });
  $tr.appendTo($thead);

  // populates with data
  $.each(mydata, function (index, value) {
    var thisRow = value;
    var $tr = $("<tr/>");

    $.each(value, function (key, val) {
      
      var thisrowval = value;
      var formtype = thisrowval['formtype'];

      val = (key == "docnumber") ? "<a href='/erp-apparel/erpdocument.php?docnumber="+val+"&doctype=SO&formtype="+formtype+"' target='_blank'>"+val+"</a>" : val;
      $td = $('<td/>');
      $td.html(val)
        .css("white-space","pre-wrap")
        .attr("fieldname",key)
        .css("cursor","pointer")
        .hover(function(){ $(this).closest("tr").css("background-color", "lightblue");},
             function(){ $(this).closest("tr").css("background-color", "");}
           );
      if (key == 'formtype' && !!formtypeTranslation[val]) $td.html(formtypeTranslation[val]);  
      if (key == 'docstatus' && !!docStatusTranslation[val]) $td.html(docStatusTranslation[val]);  
      if ( hideColumns.indexOf(key) >= 0 ) $td.css('display','none');
      $td.appendTo($tr);
    });
    $tr.click( function() { 
        // sendBackSearchChoice($(this));
      })
      .appendTo($tbody);
  });

  $thead.appendTo($table);
  $tbody.appendTo($table);

  return $table;
};






































































jsClient.makePagination = function(jsonData){

  var data = JSON.parse(jsonData);
  pageNum      = data['pageNum'];
  lastPageNum  = data['lastPageNum'];
  queryRowsNum = data['queryRowsNum'];
  showLimit    = data['showLimit'];

  var rowLimit =  jsClient.makeRowLimit(showLimit);
  var pagTable =  jsClient.getPagination(showLimit, queryRowsNum, pageNum);

  var paginationDiv = '<div style="display:inline-block" id="paginationContainer">';
  paginationDiv += '<div style="float:left;" id="divRowCounter">';
  paginationDiv += '<span>';
  paginationDiv += queryRowsNum;
  paginationDiv += ' records found ';
  paginationDiv += '</span>';
  paginationDiv += '</div>';
  paginationDiv += '<div style="float:left;" id="divPage">';
  paginationDiv += pagTable;
  paginationDiv += '</div>';
  paginationDiv += '<div style="float:left;" id="divRowLimit">';
  paginationDiv += rowLimit;
  paginationDiv += '</div>';
  paginationDiv += '</div>';

  return paginationDiv;
}


jsClient.makeRowLimit = function(show){

    var rowLimit = "";
    rowLimit += '<label> <span id="spanRowLimit">Rows Limit:</span>' 
    rowLimit += '<select name="show" onChange="jsClient.changeDisplayRowCount(this.value);">';
    rowLimit += (show == 5) ? '<option value="5" selected="selected" >5</option>' : '<option value="5">5</option>';
    rowLimit += (show == 10) ? '<option value="10" selected="selected" >10</option>' : '<option value="10">10</option>';
    rowLimit += (show == 20) ? '<option value="20" selected="selected" >20</option>' : '<option value="20">20</option>';
    rowLimit += (show == 30) ? '<option value="30" selected="selected" >30</option>' : '<option value="30">30</option>';
    rowLimit += (show == 40) ? '<option value="40" selected="selected" >40</option>' : '<option value="40">40</option>';
    rowLimit += (show == 50) ? '<option value="50" selected="selected" >50</option>' : '<option value="50">50</option>';
    rowLimit += '</select>';
    rowLimit += '</label>';

    return rowLimit;

    return rowLimit;

}

jsClient.changeDisplayRowCount = function(numRecords) {
    ERPLIST.getListData(numRecords, 1);
}

jsClient.getPagination = function(showLimit, rows, page){ 

    var limit = showLimit;
    var adjacents = 3;
    show = showLimit;

    pagination='';
    if (page == 0) page = 1;                    //if no page var is given, default to 1.
    prev = page - 1;                            //previous page is page - 1
    next = page + 1;                            //next page is page + 1
    prev_='';
    first='';
    // lastpage = Math.round(rows/limit);  
    lastpage = Math.ceil(rows/limit);  
    next_='';
    last='';

    if(lastpage > 1)
    {   
        
        //previous button
        if (page > 1) 
            // prev_+= "<a class='page-numbers' href=\"?page=prev\">previous</a>";
            prev_  += '<a href="javascript:void(0);" class="page-numbers page-'+ prev +'"  onclick="ERPLIST.getListData(  \''+ show +'\'      ' +","+ '    \'' + prev+ '\');" > previous </a>';

        else {
            //pagination.= "<span class=\"disabled\">previous</span>";  
            }
        


        //pages 
        if (lastpage < 5 + (adjacents * 2)) //not enough pages to bother breaking it up
        {   
        first='';
            for (counter = 1; counter <= lastpage; counter++)
            {
                if (counter == page)
                    pagination+= "<span class='current'>" + counter + "</span>";
                else
                    // pagination+= "<a class='page-numbers' href='?page=" +counter+ "' " + "> " + counter + "</a>"; 
                    pagination  += '<a href="javascript:void(0);" class="page-numbers page-'+ counter +'"  onclick="ERPLIST.getListData(  \''+ show +'\'      ' +","+ '    \'' + counter+ '\');" > ' + counter + ' </a>';
            }
            last='';
        }
        else if(lastpage > 3 + (adjacents * 2))  //enough pages to hide some
        {
            //close to beginning; only hide later pages
            first='';
            if(page < 1 + (adjacents * 2))      
            {
                for (counter = 1; counter < 4 + (adjacents * 2); counter++)
                {
                    if (counter == page)
                        pagination+= "<span class='current'>" + counter + "</span>";
                    else
                        // pagination+= "<a class='page-numbers' href='?page="+counter + "' "+ "> " +counter+ "</a>"; 
                    pagination  += '<a href="javascript:void(0);" class="page-numbers page-'+ counter +'"  onclick="ERPLIST.getListData(  \''+ show +'\'      ' +","+ '    \'' + counter+ '\');" > ' + counter + ' </a>';

                }
            last+= "<a class='page-numbers' href='?page="+lastpage + "' " + ">Last</a>";          
            }
            
            //in middle; hide some front and some back
            else if(lastpage - (adjacents * 2) > page && page > (adjacents * 2))
            {
               first+= "<a class='page-numbers' href='?page=1'>First</a>";    
            for (counter = page - adjacents; counter <= page + adjacents; counter++)
                {
                    if (counter == page)
                        pagination+= "<span class=current>" + counter + "</span>";
                    else
                        // pagination+= "<a class='page-numbers' href='?page=" + counter + "' " + ">counter</a>"; 
                    pagination  += '<a href="javascript:void(0);" class="page-numbers page-'+ counter +'"  onclick="ERPLIST.getListData(  \''+ show +'\'      ' +","+ '    \'' + counter+ '\');" > ' + counter + ' </a>';

                }
                last+= "<a class='page-numbers' href='?page='"+lastpage +"' " + ">Last</a>";          
            }
            //close to end; only hide early pages
            else
            {
                first+= "<a class='page-numbers' href='?page=1'>First</a>";   
                for (counter = lastpage - (2 + (adjacents * 2)); counter <= lastpage; counter++)
                {
                    if (counter == page)
                        pagination+= "<span class='current'>"+counter+"</span>";
                    else
                        // pagination+= "<a class='page-numbers' href='?page="+counter+"' " + ">counter</a>";   
                    pagination  += '<a href="javascript:void(0);" class="page-numbers page-'+ counter +'"  onclick="ERPLIST.getListData(  \''+ show +'\'      ' +","+ '    \'' + counter+ '\');" > ' + counter + ' </a>';

                }
                last='';
            }
            
            }





        if (page < counter - 1) 
            // next_+= "<a class='page-numbers' href='?page='"+next+">next</a>";
            next_  += '<a href="javascript:void(0);" class="page-numbers page-'+ next +'"  onclick="ERPLIST.getListData(  \''+ show +'\'      ' +","+ '    \'' + next+ '\');" > next </a>';


        else{
            //pagination.= "<span class=\"disabled\">next</span>";
            }
        pagination = "<div id='pagination' class='pagination'>" + first + prev_ + pagination + next_ + last;
        //next button
        
        pagination += "</div>\n";        



    }

    // pagination = "<div class='pagination'>" + first + prev_ + pagination + next_ + last;
    
    return pagination;  
}


jsClient.paginationCSS = function(){

  $('#paginationContainer #divRowCounter').css({
    'padding':'4px 10px',
    'color':'black',
    'font-weight':'bold',
    // 'border': '2px solid blue',
    // 'vertical-align': 'text-bottom',
    'margin-top': '3pt',
    'height': '20pt'
  });

  $('#paginationContainer #divPage').css({
    'padding':'4px 10px',
  });

  $('#paginationContainer #divRowLimit').css({
    'padding':'4px 10px',
    'color':'black',
    'font-weight':'bold',
    // 'border': '2px solid blue',
    // 'vertical-align': 'text-bottom',
    'height': '20pt'
  });

  $('#paginationContainer #divRowLimit #spanRowLimit').css({
    'padding-right':'4pt'
  });

  //------------------------
  $('.pagination').css({
    // 'width':'600px',
    'margin':'0px auto'
  });
  $('.pagination .current').css({
    'padding':'4px 10px',
    'color':'black',
    'margin':'1px 0px 9px 6px',
    'display':'block',
    'text-decoration':'none',
    'float':'left',
    'text-transform':'capitalize',
    'background':'whitesmoke'
  });
  $('.pagination .page-numbers').css({
    'padding':'4px 10px',
    'color':'white !important',
    'margin':'1px 0px 9px 6px',
    'display':'block',
    'text-decoration':'none',
    'float':'left',
    'text-transform':'capitalize',
    'background':'#00b4cc'
  });


}

ERPLIST.initLibFieldsForSearch = function(){
  ERPLIST.libraryColumns = {
    //   linestatus:{
    //     style: 'font-weight:bold; color:green',
    //     customsearch: true,
    //     islibrary: true,
    //     datasource: {
    //         0: 'Entered',
    //         1: 'Running',
    //         2: 'Closed'
    //      },        
    //     fielddesc: 'Line Status',
    //     showsearchimg: true,
    // },
    company: {
      fielddesc: 'Company',
      sql: "SELECT Code AS code, Description AS description FROM mrd_library WHERE LibraryName='company'",
    },
    customer: {
      fielddesc: 'Customer',
      islibrary: true,
      sql: "SELECT Code AS code, Description AS description FROM mrd_library WHERE LibraryName='Buyer'", 
    },
    endcustomer: {
      fielddesc: 'End Customer',
      islibrary: true,
      sql: "SELECT Code AS code, Description AS description FROM mrd_library WHERE LibraryName='Buyer'", 
    },    
  };  
  return ERPLIST.libraryColumns;
}