/**
 * Declare ERPLIST Namespace if not exist
 */
var ERPLIST = ERPLIST || {};

$.extend(ERPLIST, {
  mUrl: 'api/server_api.php',
  mType: 'get',
  mData: '',
  mAsync: false,
  mReqType: '',
  queryData: '',
  queryParam: '',
  _searchParams: '',
  _URL_API: 'list-rr-po-wo-creation_api.php',

  foo: 'here for no reason other than to be the last line, without a comma'
});




// ERPLIST.displayQueryData = function(jsonData){

//   var pagination = jsClient.makePagination(jsonData)

//   var data = JSON.parse(jsonData);
//   var listData = data['listData'];
//   var hasData = (data.noResult) ? 'no' : 'yes';
//   var listTable = ERPLIST.makeTable(listData, hasData);

//   $("#listDiv").html(pagination);
//   $("#listDiv").append(listTable);

//   ERPLIST.initSearchAction();

//   /**
//    * Css
//    */
//   $('#listTable').css({
//     'width':'100%'
//   });
//   $('#listTable tr#searchForm input').css({
//     'width':'95%',
//     'min-width': '60px',
//     'font-family':'Arial',
//     'padding':'2px',
//     'border':'1px solid #7F7F7F',
//     'border-radius':'3px'
//   });
//   $('#listTable tr#searchForm button').css({
//     'padding':'2px',
//     'border':'1px solid #7F7F7F',
//     'border-radius':'3px',
//     'vertical-align': 'middle'
//   });  
//   $('#listTable .hasCustomSearch').css({
//     'width':'70%'
//   });
//   jsClient.paginationCSS();
//   ERPLIST.changeTempleteCSS();

//   // Custom CSS if required
//   $('#listTable td.lineentrytime').css({
//     'white-space':'nowrap'
//   });
//   // $('#listTable td.itemcode .ccell3 ').css({
//   //   'white-space':'nowrap'
//   // });
//   $('#listTable td.itemdescription').css({
//     'min-width':'220px'
//   });

//   $('.classRed ').css({
//     'border-radius':'50%',
//     'background-color':'red',
//     'border':'none',
//     // 'padding-top':'10px'
//   });

//   $('.classGreen ').css({
//     'border-radius':'50%',
//     'background-color':'green',
//     'border':'none',
//     // 'padding-top':'10px'
//   });

// }



ERPLIST.exportToExecl = function(){
  var searchParams = {};
  $('table#listTable thead tr#searchForm').each(function() {
    $(this).find("td input:text,select").each(function() {
      var textVal   = this.value.trim();
      var inputName = $(this).attr("name");
      var tagName   = $(this).prop("tagName");

      // if inputName is undefined then assume its combobox 
      if(inputName == undefined) return;
      // try to retrive name by closest select tag
      if(!!ERPLIST.libraryColumns[inputName]){
          if(textVal == '______'){ // define for empty
            textVal = "";
          }
      }
      if(textVal != ""){
        searchParams[inputName] = textVal;
      }            
    });
  });
// return encodeURIComponent(key) + '=' + encodeURIComponent(params[key]);
  var qrystr = $.param( searchParams );
  var expURL = '/erp-nonpo/list-rr-po-wo-creation_api.php?reqType=exportListData&' + qrystr;
  window.open(expURL);
}

ERPLIST.makeTable = function(mydata,hasData) {
  var $table = $('<table border=1 id="listTable" class="listTable" />');
  var $thead = $('<thead />');
  var $tbody = $('<tbody/>');

  //for composition column
  ERPLIST.compositeColumns = {
    
    
   linestatus:{
      linestatus: {
        fielddesc: 'Status',
        islibrary: true,
        datasource: {
          0: 'Entered',
          1: 'Complete',
          2: 'Released',
          9: 'Cancelled',
          3: 'Closed'
        },  
        customsearch: true,
        composite: false,
        end: true
      }
    },

   //  docnumber : {
   //    docnumber : {
   //      fielddesc: 'Requisition No.',
   //      composite: false,
   //      customsearch: false,
   //      single: true,
   //      end: true
   //    },        
   //  },


   //  doclinenumber : {
   //    doclinenumber : {
   //      fielddesc: 'Requisition Line No.',
   //      composite: false,
   //      customsearch: false,
   //      single: true,
   //      end: true
   //    },        
   //  },

    docdate : {
      docdate : {
        fielddesc: 'PR Date',
        composite: false,
        customsearch: true,
        single: true,
        type: 'date',
        end: true
      },        
    },

   //  company : {
   //    company : {
   //      fielddesc: 'Division',
   //      composite: false,
   //      customsearch: false,
   //      single: true,
   //      end: true
   //    },        
   //  },    

    // customer : {
    //   customer : {
    //     fielddesc: 'Customer',
    //     composite: false,
    //     customsearch: false,
    //     single: true,
    //     end: true
    //   },        
    // },

    // ponumber : {
    //   ponumber : {
    //     fielddesc: 'PO No.',
    //     composite: false,
    //     customsearch: false,
    //     single: true,
    //     end: true
    //   },        
    // },

    podocdate : {
      podocdate : {
        fielddesc: 'PO Date',
        composite: false,
        customsearch: true,
        single: true,
        type: 'date',
        end: true
      },        
    },  

    // masterreference : {
    //   masterreference : {
    //     fielddesc: 'Master Ref#',
    //     composite: false,
    //     customsearch: false,
    //     single: true,
    //     end: true
    //   },        
    // },
    // project : {
    //   project : {
    //     fielddesc: 'WO No./Project',
    //     composite: false,
    //     customsearch: false,
    //     single: true,
    //     end: true
    //   },        
    // },

    // itemcode : {
    //   itemcode : {
    //     fielddesc: 'Item Code',
    //     composite: false,
    //     customsearch: false,
    //     single: true,
    //     end: true
    //   },        
    // },

    // itemname : {
    //   itemname : {
    //     fielddesc: 'Item Name',
    //     composite: false,
    //     customsearch: false,
    //     single: true,
    //     end: true
    //   },        
    // },

    // itemnature : {
    //   itemnature : {
    //     fielddesc: 'Item Nature',
    //     composite: false,
    //     customsearch: false,
    //     single: true,
    //     end: true
    //   },        
    // },

    // itemdescription : {
    //   itemdescription : {
    //     fielddesc: 'Item Description',
    //     composite: false,
    //     customsearch: false,
    //     single: true,
    //     end: true
    //   },        
    // },

    // purchasemode : {
    //   purchasemode : {
    //     fielddesc: 'Procurer',
    //     composite: false,
    //     customsearch: false,
    //     single: true,
    //     end: true
    //   },        
    // },

    // suppliername : {
    //   suppliername : {
    //     fielddesc: 'Supplier Name',
    //     composite: false,
    //     customsearch: false,
    //     single: true,
    //     end: true
    //   },        
    // },

    // supplieraddress : {
    //   supplieraddress : {
    //     fielddesc: 'Supplier Address',
    //     composite: false,
    //     customsearch: false,
    //     single: true,
    //     end: true
    //   },        
    // },

    // unitprice : {
    //   unitprice : {
    //     fielddesc: 'Unit Price',
    //     composite: false,
    //     customsearch: false,
    //     single: true,
    //     end: true
    //   },        
    // },

    deliverydate : {
      deliverydate : {
        fielddesc: 'Delivery Date',
        composite: false,
        customsearch: true,
        single: true,
        type: 'date',
        end: true
      },        
    },
  }
  var translationsHardCode = {};

  var params = jsClient.paramsToObj(window.location.search);

    if(params.itemtype == 'ELS'){
	   var hideColumns = [ 'idlines', 'doctype','formtype', 'poformtype', 'itemname','itemnature','receivedqty','purchasemode', 'supplieraddress', 'deliverydate', 'brand', 'sizeormeasurement', 'costcenter', 'costdept', 'extracost', 'extracostdescription', 'amountwithoutdiscount', 'discountamount', 'amount', 'capexno', 'requestername', 'requestercontactno', 'linesremarks', 'purpose', 'chemicalcharecter', 'supplierorigin', 'itemdescription', 'color', 'cartontype', 'subcode11', 'subcode12', 'receivedqty'];

      var fieldSequence = [ 'idlines', 'linestatus', 'itemtype', 'formtype', 'poformtype', 'docnumber', 'doclinenumber', 'docdate', 'masterreference', 'trackingNum', 'ponumber', 'polinenumber', 'podocdate', 'company', 'customer', 'project', 'itemcode', 'itemname', 'itemnature', 'itemdescription', 'orderqty', 'receivedqty', 'iduom', 'subcode01', 'purchasemode', 'suppliername', 'supplieraddress', 'unitprice', 'deliverydate', 'brand', 'color', 'sizeormeasurement', 'costcenter', 'costdept', 'extracost', 'extracostdescription', 'amountwithoutdiscount', 'discountamount', 'amount', 'currency', 'capexno', 'requestername', 'requestercontactno', 'linesremarks', 'purpose', 'chemicalcharecter', 'supplierorigin', 'trimscatagory', 'cartontype', 'subcode02', 'subcode03', 'subcode04', 'subcode05', 'subcode06', 'subcode07', 'subcode08', 'subcode09', 'subcode10', 'subcode11', 'subcode12'];

        translationsHardCode.subcode01 = 'Item Description';
        translationsHardCode.subcode02 = 'Construction';
        translationsHardCode.subcode03 = 'Composition';
        translationsHardCode.subcode04 = 'Item Color';
        translationsHardCode.subcode05 = 'Shade No.';
        translationsHardCode.subcode06 = 'Elastic Code';
        translationsHardCode.subcode07 = 'Width';
        translationsHardCode.subcode08 = 'Width UoM';  
        translationsHardCode.subcode09 = 'Size';  
        translationsHardCode.subcode10 = 'Supplier Reference/ Product Code';  
        translationsHardCode.project           = 'WO No./Project';
    } else if(params.itemtype == 'CTN'){
        var hideColumns = [ 'idlines', 'doctype','formtype','itemname','itemnature','receivedqty','purchasemode', 'supplieraddress', 'deliverydate', 'brand', 'sizeormeasurement', 'costcenter', 'costdept', 'extracost', 'extracostdescription', 'amountwithoutdiscount', 'discountamount', 'amount', 'capexno', 'requestername', 'requestercontactno', 'linesremarks', 'purpose', 'chemicalcharecter', 'supplierorigin', 'itemdescription', 'color', 'trimscatagory', 'subcode12', 'receivedqty'];
      var fieldSequence = [ 'idlines', 'linestatus', 'itemtype', 'formtype', 'docnumber', 'doclinenumber', 'docdate', 'masterreference', 'trackingNum', 'ponumber', 'polinenumber', 'podocdate', 'company', 'customer', 'project', 'itemcode', 'itemname', 'itemnature', 'itemdescription', 'orderqty', 'receivedqty', 'iduom', 'subcode01', 'purchasemode', 'suppliername', 'supplieraddress', 'unitprice', 'deliverydate', 'brand', 'color', 'sizeormeasurement', 'costcenter', 'costdept', 'extracost', 'extracostdescription', 'amountwithoutdiscount', 'discountamount', 'amount', 'currency', 'capexno', 'requestername', 'requestercontactno', 'linesremarks', 'purpose', 'chemicalcharecter', 'supplierorigin', 'trimscatagory', 'cartontype', 'subcode02', 'subcode03', 'subcode04', 'subcode05', 'subcode06', 'subcode07', 'subcode08', 'subcode09', 'subcode10', 'subcode11', 'subcode12'];
        translationsHardCode.subcode01 = 'No. of Ply';
        translationsHardCode.subcode02 = 'GSM';
        translationsHardCode.subcode03 = 'Garment Size';
        translationsHardCode.subcode04 = 'Length';
        translationsHardCode.subcode05 = 'Width';
        translationsHardCode.subcode06 = 'Height';
        translationsHardCode.subcode07 = 'Measurement Unit';
        translationsHardCode.subcode08 = 'SQM';  
        translationsHardCode.subcode09 = 'Carton Color';  
        translationsHardCode.subcode10 = 'Shipping Mark';  
        translationsHardCode.subcode11 = 'Shipping Color';  
        translationsHardCode.project           = 'WO No./Project';
    } else{
		  var hideColumns = [ 'idlines', 'doctype','workorderdocnumber','bomdocnumber', 'formtype', 'poformtype','cpdocnumber','isrrfreezed','recalculationbit', 'actualdeductionqty', 'requirednetqty', 'masterreference', 'trimscatagory', 'cartontype', 'subcode01', 'subcode02', 'subcode03', 'subcode04', 'subcode05', 'subcode06', 'subcode07', 'subcode08', 'subcode09', 'subcode10', 'subcode11', 'subcode12',  'customer', 'trackingNum'];
      var fieldSequence = [ 'idlines',   'linestatus', 'itemtype', 'formtype', 'poformtype', 'docnumber', 'doclinenumber', 'docdate', 'company', 'customer', 'ponumber', 'podocdate', 'masterreference', 'project', 'itemcode', 'itemname', 'itemnature', 'itemdescription', 'subcode01', 'purchasemode','suppliername', 'supplieraddress', 'unitprice', 'deliverydate', 'orderqty', 'receivedqty', 'iduom', 'brand', 'color', 'sizeormeasurement', 'costcenter', 'costdept', 'extracost', 'extracostdescription', 'amountwithoutdiscount', 'discountamount', 'amount', 'currency', 'capexno', 'requestername', 'requestercontactno', 'linesremarks', 'polinenumber', 'purpose', 'chemicalcharecter', 'supplierorigin', 'trimscatagory', 'cartontype', 'subcode02', 'subcode03', 'subcode04', 'subcode05', 'subcode06', 'subcode07', 'subcode08', 'subcode09', 'subcode10', 'subcode11', 'subcode12', 'trackingNum'];

        translationsHardCode.project           = 'Project Code';
	}
  
    // some trickery for nice formatting
  
  translationsHardCode.iduom                 = 'UoM';
  translationsHardCode.docnumber             = 'Requisition No.';
  translationsHardCode.docdate               = 'PR Date';
  translationsHardCode.costcenter            = 'Cost Center';
  translationsHardCode.costdept              = 'Cost Dept.';
  translationsHardCode.itemname              = 'Item Name';
  translationsHardCode.brand                 = 'Brand';
  translationsHardCode.color                 = 'Color';
  translationsHardCode.sizeormeasurement     = 'Size or Measurement';
  translationsHardCode.orderqty              = 'Order Quantity';
  translationsHardCode.receivedqty           = 'Received Quantity';
  translationsHardCode.deliverydate          = 'Delivery Date';
  translationsHardCode.purchasemode          = 'Procurer';
  translationsHardCode.suppliername          = 'Supplier Name';
  translationsHardCode.unitprice             = 'Unit Price';
  translationsHardCode.currency              = 'Currency';
  translationsHardCode.extracost             = 'Extra cost';
  translationsHardCode.trackingNum             = 'Tracking No.';
  
  translationsHardCode.amountwithoutdiscount = 'Amount Without Discount';
  translationsHardCode.discountamount        = 'Discount Amount';
  translationsHardCode.amount                = 'Amount';
  
  translationsHardCode.capexno               = 'Capex No';
  translationsHardCode.linesremarks          = 'Remarks';
  translationsHardCode.linestatus            = 'Status';
  translationsHardCode.ponumber              = 'PO No.';
  translationsHardCode.podocdate             = 'PO Date';
  translationsHardCode.supplieraddress       = 'Supplier Address';
  translationsHardCode.extracostdescription  = 'Extra Cost Description';

  translationsHardCode.requestername         = 'Requestor Name';
  translationsHardCode.requestercontactno    = 'Requestor Contact No.';
  translationsHardCode.customer              = 'Customer';
  translationsHardCode.masterreference       = 'Master Ref#';
  translationsHardCode.itemtype              = 'Item Type';
  translationsHardCode.trimscatagory         = 'Trims Catagory';
  translationsHardCode.cartontype         = 'Carton Type';
  
  translationsHardCode.doclinenumber     = 'Requisition Line No.';
  translationsHardCode.company           = 'Division';
  translationsHardCode.itemcode          = 'Item Code';
  translationsHardCode.itemdescription   = 'Item Description';
  translationsHardCode.itemnature        = 'Item Nature';
  translationsHardCode.purpose           = 'Purpose of Use';
  translationsHardCode.chemicalcharecter = 'Chemical Charecteristics';
  translationsHardCode.supplierorigin    = 'Supplier Origin';
  translationsHardCode.polinenumber      = 'PO line No.';

  ERPLIST.translationsHardCode = translationsHardCode;


  // builds the table header
  var mydata1 = [];
  $.each(mydata, function (index, row) {
    item = {}
    $.each(fieldSequence, function(index, fieldname){
        item [fieldname] = row[fieldname];
    });
    mydata1.push(item);
  });
  mydata = mydata1;

  var mydata_json = JSON.stringify(mydata);
  var firstRow = mydata[0];

  var firstRowCopy = firstRow;
  var compositeColumnsLength = Object.keys(ERPLIST.compositeColumns).length;
  var countVisibleColumn = 1; // here start from 1 cz first td for option
  /**
   * first header row------------------------------------------------------------------------------------------------------------------------------------------------------------
   */
  var $tr = $("<tr/>");
  $td = $('<th/>');
  thisLineActionBtn = '<center>Check All</center>';
  $td.html(thisLineActionBtn);
  $td.appendTo($tr);

  // process composite column first if has
  if(compositeColumnsLength > 0){
    $.each(ERPLIST.compositeColumns, function(groupName, groupColumns){
      // hide first
      $.each(groupColumns, function(fieldname, fieldStyle){
        var fielddesc = fieldname;
        $td = $('<th/>');
        if (!!translationsHardCode[fieldname]) fielddesc = translationsHardCode[fieldname];
        $td.html('<center>'+ fielddesc +'</center>');
        $td.css('display','none');
        $td.appendTo($tr);

        delete firstRowCopy[fieldname]; // its already procceed
      });

      $td = $('<th/>');
      $td.attr('class', groupName);
      if ( hideColumns.indexOf(groupName) >= 0 ){ 
        $td.css('display','none'); countVisibleColumn--;
      }else{
        countVisibleColumn++;
      }
      if (!!translationsHardCode[groupName]) groupName = translationsHardCode[groupName];
      $td.html('<center>'+ groupName +'</center>');
      $td.appendTo($tr);
      // countVisibleColumn++;
    });
  }

  // precess rest of columns----------------------------------------------------------------------------------------------
  $.each(firstRowCopy, function (fieldname, fieldvalue) {
    countVisibleColumn++;
    var fielddesc = fieldname;
    $td = $('<th/>');
    if (!!translationsHardCode[fieldname]) fielddesc = translationsHardCode[fieldname];
    $td.html('<center>'+ fielddesc +'</center>');
    if ( hideColumns.indexOf(fieldname) >= 0 ){ $td.css('display','none'); countVisibleColumn--};
    $td.appendTo($tr);
  });
  $tr.appendTo($thead);
  $thead.appendTo($table);
  // end -----------------------------------------------------------------------------------------------------------------


  /**
   * second header row-----------------------------------------------------------------------------------------------------------------------------------------------------------
   */
  var $tr = $("<tr/>").attr("id","searchForm");
  var $td;
  $td = $('<td/>');
  thisLineActionBtn = '<center><input type="checkbox" class="chkallrrline" name="" onclick="ERPLIST.alllineChooser(this);"></center>';
  $td.html(thisLineActionBtn);
  $td.appendTo($tr);

  if(compositeColumnsLength > 0){
    $.each(ERPLIST.compositeColumns, function(groupName, groupColumns){

      var compositeClass = '';
      $td = $('<td/>');
      $td.attr('class', groupName);
      $.each(groupColumns, function(fieldname, fieldpropties){

        compositeClass +=  ( !!fieldpropties.end) ? fieldname : fieldname + '__';          
        var customsearch_option = ( !!fieldpropties.showsearchimg) ?'<button type="button" onclick="ERPLIST.handleCustomSearch(this);"><img src="img/search_icon.png" alt="" height="15" width="15"></button>': '';
        var customsearch_click  = ( !!fieldpropties.customsearch) ?'onclick="ERPLIST.handleCustomSearch(this);"': 'onclick="ERPLIST.handleThisSearchInputFieldClick(this);"';
        var customsearch_class  = ( !!fieldpropties.customsearch ) ? '  hasCustomSearch' : '';

        var html = '<center><input type="text" name="'+ compositeClass +'" value="" id="'+compositeClass+'" class="'+compositeClass + customsearch_class +'" onclick="ERPLIST.handleCustomSearch(this);" />'+ customsearch_option +'</center><div id="'+compositeClass+'_displaySearchParams" style="background-color:white;"></div>';
        $td.html(html);

        // delete firstRowCopy[fieldname]; // its already procceed
        if(fieldpropties.composite == false) return;
        $td_hide = $('<td/>');
        $td_hide.html('<center><input type="hidden" class="'+ fieldname +'" value="" id="'+fieldname+'" /></center>');
        $td_hide.css('display','none');
        $td_hide.appendTo($tr);

      });
      if ( hideColumns.indexOf(groupName) >= 0 ) $td.css('display','none');
      $td.appendTo($tr);

    });
  }
  // end -----------------------------------------------------------------------------------------------------------------

  // precess rest of columns----------------------------------------------------------------------------------------------
  $.each(firstRowCopy, function (fieldname, fieldvalue) {    
    var fielddesc = fieldname;
    $td = $('<td/>');
    $td.attr('class', fieldname);
    $td.html('<center><input type="text"  name="'+ fieldname +'" class="'+ fieldname +'" value="" id="'+fieldname+'" onclick="ERPLIST.handleThisSearchInputFieldClick(this);" /></center><div id="'+fieldname+'_displaySearchParams" style="background-color:white;"></div>');
    if ( hideColumns.indexOf(fieldname) >= 0 ) $td.css('display','none');
    $td.appendTo($tr);
  });
  $tr.appendTo($thead);
  $thead.appendTo($table);
  // end -----------------------------------------------------------------------------------------------------------------
  /**
   * second header row end -----------------------------------------------------------------------------------------------------------------------------------------------------------
   */

  if(hasData == 'no'){
    $thead.appendTo($table);
    //custom for no record found
    var $tr = $("<tr/>");
    // var numberOfColumn = $("#listTable > thead > tr:first > th:visible").length;
    var $td = $('<td/>').attr("colspan",countVisibleColumn);
    $td.html('No Data Found')
      .css({'text-align':'center','vertical-align':'middle'});
    $td.appendTo($tr);
    $tr.appendTo($table);
    return $table;
  }

  /**
   * populates with data--------------------------------------------------------------------------------------------------------------------------------------------------
   */
  var mydata = JSON.parse(mydata_json);
  $.each(mydata, function (index, value) {
    var $tr = $("<tr/>"); // it should be in here

    var thisRow = value;
    var thisRowCopy = thisRow;
    var thisRowCopy_Json =  JSON.stringify(thisRow);

    var formtype = thisRow['formtype'];
    var poformtype = thisRow['poformtype'];
    var linestatus = thisRow['linestatus'];
    var isrrfreezed = thisRow['isrrfreezed'];
    var recalculationbit = thisRow['recalculationbit'];

    var idlines = thisRow['idlines'];
    // generate button if needed
    var thisLineActionBtn = '';
    if(isrrfreezed != '0'){
      if(!!ERPLIST.selectedLineInfo){
        if( ERPLIST.selectedLineInfo.idlines.indexOf(idlines) > -1 ){
          thisLineActionBtn = '<center><input type="checkbox" class="chkrrline" name="" onclick="ERPLIST.lineChooser(this);" checked></center>';
        }else{
          thisLineActionBtn = '<center><input type="checkbox" class="chkrrline" name="" onclick="ERPLIST.lineChooser(this);"></center>';
        }  
      }else{
        thisLineActionBtn = '<center><input type="checkbox" class="chkrrline" name="" onclick="ERPLIST.lineChooser(this);"></center>';
      }
      
    } else{
      if(!!ERPLIST.selectedLineInfo){
        if( ERPLIST.selectedLineInfo.idlines.indexOf(idlines) > -1 ){
          thisLineActionBtn = '<center><input type="checkbox" class="chkrrline" name="" onclick="ERPLIST.lineChooser(this);" checked></center>';
        }else{
          thisLineActionBtn = '<center><input type="checkbox" class="chkrrline" name="" onclick="ERPLIST.lineChooser(this);"></center>';
        }
      }else{
        thisLineActionBtn = '<center><input type="checkbox" class="chkrrline" name="" onclick="ERPLIST.lineChooser(this);"></center>';
      }
    }


    $td = $('<td/>');
    $td.html(thisLineActionBtn);
    $td.appendTo($tr);

    // process composite column first if has----------------------------------------------------------------------------------
    if(compositeColumnsLength > 0){
      $.each(ERPLIST.compositeColumns, function(groupName, groupColumns){
        $td = $('<td/>');
        $td.attr('class', groupName);
        $td.attr('fieldname', groupName);
        var compositeColumnsHTML = '';
        var divRow = '';
        $.each(groupColumns, function(fieldname, fieldprop){

          var fieldvalue = thisRow[fieldname];
          var fielddesc = (!!fieldprop.fielddesc) ? fieldprop.fielddesc : fieldname;
          var style = ( !!fieldprop.style ) ? 'style="' + fieldprop.style + '"': '';

          // *** write custom code here

          var obj_thisRowCopy_Json =  JSON.parse(thisRowCopy_Json);
          fieldvalue = (fieldname == "powonumber") ? "<a href='erpdocument.php?docnumber="+fieldvalue+"&doctype=PO&formtype="+formtype+"' target='_blank''>"+fieldvalue+"</a>" : fieldvalue;
          
          fieldvalue = (fieldname == "docnumber") ? "<a href='erpdocument.php?docnumber="+fieldvalue+"&doctype=PR&formtype="+formtype+"' target='_blank''>"+fieldvalue+"</a>" : fieldvalue;

          fieldvalue = (fieldname == "ponumber") ? "<a href='erpdocument.php?docnumber="+fieldvalue+"&doctype=PO&formtype="+poformtype+"' target='_blank''>"+fieldvalue+"</a>" : fieldvalue;
          if(fieldname == "podocdate" && fieldvalue == null) fieldvalue="";
          if(fieldname == "fabricinhousedate"){
           fieldvalue = ERPLIST.generateHTMLinHouse(thisRowCopy,fieldname, fieldvalue);
          }
          // *** custom code end

          divRow += '<div class="crow" '+ '' +'>';
          if( !!fieldprop.composite ){
            divRow += '<div class="ccell1 '+ fieldname +'" '+ style +'>'+ fielddesc +'</div>';
            divRow += '<div class="ccell2 '+ fieldname +'">:</div>';
          }
          divRow += '<div class="ccell3 '+ fieldname +'_ccell3" '+ style +'>'+ fieldvalue +'</div>';
          divRow += "</div>";

          delete thisRowCopy[fieldname]; // its already procceed
          if(fieldprop.composite == false) return;
          $td_hide = $('<td/>');
          $td_hide.html(fieldvalue);
          $td_hide.attr("fieldname",fieldname);
          $td_hide.css('display','none');
          $td_hide.appendTo($tr);

        });

        var divTable = "<div id='ctable'>"; 
        divTable += divRow;  
        divTable += "</div>"; 

        compositeColumnsHTML = divTable;
        $td.html(compositeColumnsHTML)
          .css("cursor","pointer")
          .hover(
               function(){bgOn = $(this).closest("tr").css("background-color"); $(this).closest("tr").css("background-color", "lightblue");},
               function(){$(this).closest("tr").css("background-color", bgOn);}
             );
        if ( hideColumns.indexOf(groupName) >= 0 ) $td.css('display','none');
        $td.appendTo($tr);

      });
    }
    // end -----------------------------------------------------------------------------------------------------------------

    // precess rest of columns----------------------------------------------------------------------------------------------
    $.each(thisRowCopy, function (fieldname, fieldvalue) {

      // *** write custom code here
      fieldvalue = (fieldname == "docnumber") ? "<a href='erpdocument.php?docnumber="+fieldvalue+"&doctype=PR&formtype="+formtype+"' target='_blank''>"+fieldvalue+"</a>" : fieldvalue;
      fieldvalue = (fieldname == "ponumber") ? "<a href='erpdocument.php?docnumber="+fieldvalue+"&doctype=PO&formtype="+poformtype+"' target='_blank''>"+fieldvalue+"</a>" : fieldvalue;
      if(fieldname == "fabricinhousedate"){
        fieldvalue = ERPLIST.generateHTMLinHouse(thisRowCopy,fieldname, fieldvalue);
      }

      // *** custom code end

      $td = $('<td/>');
        $td.html(fieldvalue)
          .css("white-space","pre-wrap")
          .attr("fieldname",fieldname)
          .attr("class",fieldname)
          .css("cursor","pointer")
          .hover(
               function(){bgOn = $(this).closest("tr").css("background-color"); $(this).closest("tr").css("background-color", "lightblue");},
               function(){$(this).closest("tr").css("background-color", bgOn);}
             );
        if ( hideColumns.indexOf(fieldname) >= 0 ) $td.css('display','none');
        $td.appendTo($tr);
    });


    // *** custom code start-----------------------------------------------------------------------------------------
    // $tr.find('td.requiredinformation').append(thisLineActionBtn);
    // *** custom code end-------------------------------------------------------------------------------------------

    if(linestatus == 'Complete'){
      $tr.css("background-color", "#FFFFCC");
    }else if(linestatus == 'Released'){
      $tr.css("background-color", "#AEF5D4");
    }

    $tr.click( function() { 
        // sendBackSearchChoice($(this));
      })
      .appendTo($tbody);
  });

  $thead.appendTo($table)
  $tbody.appendTo($table)

  return $table;
};





/**
* Custom table generate code------------------------------------------------------------------------------------------------------
*/










/**
* Custom function code------------------------------------------------------------------------------------------------------
*/
ERPLIST.showPlannedDateForm = function (thisbtn){
  $(thisbtn).parents('td').find('#formDiv').css({'display':'block'});
  $(thisbtn).parents('td').find('#btnDiv1').css({'display':'none'});
  $(thisbtn).parents('td').find('#btnDiv2').css({'display':'none'});
  jsClient.initDateTimePicker();
}

ERPLIST.setFabricInhouseDate = function(thisbtn, idlines){
  var fabricinhousedate = $(thisbtn).parents('td').find('#formDiv #fabricinhousedate').val();
  var rrnumber = $(thisbtn).closest('tr').find('td[fieldname=rrnumber]').text();
  
  //click checkbox for uncheck when set fabric inhouse date
  if($(thisbtn).closest('tr').find('td input.chkrrline').prop('checked')){
    $(thisbtn).closest('tr').find('td input.chkrrline').trigger('click');
  }
  
  var postData = JSON.stringify({idlines:idlines, fabricinhousedate:fabricinhousedate});
  var mType    = 'post';
  var mUrl     = ERPLIST._URL_API;
  var mReqType = "setFabricInhouseDate";
  var returnData = jsClient.communicationToServer(mReqType, postData, mUrl, mType, false);

  returnData = JSON.parse(returnData);
  if(returnData.result == 'success'){
    $(thisbtn).parents('td').find('#formDiv').css({'display':'none'});
    $(thisbtn).parents('td').find('#btnDiv1').css({'display':'none'});
    $(thisbtn).parents('td').find('#btnDiv2').css({'display':'block'});

    $(thisbtn).parents('td').find('#showInhouseDate').css({'display':'block'});
    $(thisbtn).parents('td').find('#showInhouseDate').find('span').text(fabricinhousedate);

    jsClient.msgDisplayer('success:: Successfully updated inhouse date '+rrnumber); // green
  }

}

ERPLIST.generateHTMLinHouse = function(thisRowCopy,fieldname, fieldvalue){
  var fabricinhousedate = fieldvalue;

  if(fieldvalue == "" || fieldvalue == null || fieldvalue == "0000-00-00"){
    var content = '<div id="formDiv" style="display:none;">'
    content += '<input type="text" class="datepicker" name="fabricinhousedate" value="" id="fabricinhousedate">';
    content += '<input type="button" value="Done" onclick="ERPLIST.setFabricInhouseDate(this ' +","+ '  \'' + thisRowCopy['idlines'] + '\')"/>';
    content += '</div>';

    var content2 = '<div id="btnDiv1">';
    content2 += '<input type="button" value="Enter In-house Date" onclick="ERPLIST.showPlannedDateForm(this)"/>';
    content2 += '</div>';

    var content3 = '<div id="btnDiv2" style="float:left;display:none;">';
    content3 += '<a href="javascript:void(0)" onclick="ERPLIST.showPlannedDateForm(this)"><img src="img/edit.png"></a>';
    content3 += '</div>';

    var content4 = '<div id="showInhouseDate" style="float:left;display:none;">';
    content4 += '<span>' +fabricinhousedate+ '</span>';
    content4 += '</div>';

    fieldvalue = content4;
    fieldvalue += content;
    fieldvalue += content2;
    fieldvalue += content3;
  }else{
    var content = '<div id="formDiv" style="display:none;">'
    content += '<input type="text" class="datepicker" name="fabricinhousedate" value="'+fabricinhousedate+'" id="fabricinhousedate">';
    content += '<input type="button" value="Done" onclick="ERPLIST.setFabricInhouseDate(this ' +","+ '  \'' + thisRowCopy['idlines'] + '\')"/>';
    content += '</div>';

    var content2 = '<div id="btnDiv2" style="float:left;">';
    content2 += '<a href="javascript:void(0)" onclick="ERPLIST.showPlannedDateForm(this)"><img src="img/edit.png"></a>';
    content2 += '</div>';

    var content3 = '<div id="showInhouseDate" style="float:left;">';
    content3 += '<span>' +fabricinhousedate+ '</span>';
    content3 += '</div>';

    fieldvalue = content3;
    fieldvalue += content;
    fieldvalue += content2;          
  }  

  return fieldvalue;
}

ERPLIST.alllineChooser = function(thisflag){
  if($(thisflag).prop('checked')){
    $('.chkrrline').each(function(){
      $(this).prop('checked', true);
      var r = ERPLIST.lineChooser(this);
      if(r == false)return false;
    });
  }else{
    $('.chkrrline').each(function(){
      $(this).prop('checked', false);
      var r = ERPLIST.lineChooser(this);
      if(r == false)return false;
    });
  }

}


ERPLIST.lineChooser = function(thisf){
  var thisrow = $(thisf).parent().parent().parent().index();
  
  var idlines = $(thisf).closest('tr').find('td[fieldname=idlines]').text();
  var linestatus = $(thisf).closest('tr').find('td[fieldname=linestatus]').text();
  var supplier = $(thisf).closest('tr').find('td[fieldname=suppliername]').text();
  var purchasemode = $(thisf).closest('tr').find('td[fieldname=purchasemode]').text();
  var currency = $(thisf).closest('tr').find('td[fieldname=currency]').text();
  var company = $(thisf).closest('tr').find('td[fieldname=company]').text();
  var ponumber = $(thisf).closest('tr').find('td[fieldname=ponumber]').text();
  var polinenumber = $(thisf).closest('tr').find('td[fieldname=polinenumber]').text();
  var doclinenumber = $(thisf).closest('tr').find('td[fieldname=doclinenumber]').text();
  var itemtype = $(thisf).closest('tr').find('td[fieldname=itemtype]').text();
  var formtype = $(thisf).closest('tr').find('td[fieldname=formtype]').text();
  var masterreference = $(thisf).closest('tr').find('td[fieldname=masterreference]').text();
  var customer = $(thisf).closest('tr').find('td[fieldname=customer]').text();

	if(linestatus != 'Complete'){
		alert("Status Should be Complete");
		$(thisf).prop('checked', false);
		// ERPLIST.popUncheckedValue(thisrow);

		return false;
	}

  console.log(linestatus);
    // define array
    if(!!!ERPLIST.selectedLineInfo){
      ERPLIST.selectedLineInfo  = {};
      ERPLIST.selectedLineInfo.uniquekey = [];
      ERPLIST.selectedLineInfo.idlines = [];
      ERPLIST.selectedLineInfo.linestatus = [];
      ERPLIST.selectedLineInfo.supplier = [];
      ERPLIST.selectedLineInfo.purchasemode = [];
      ERPLIST.selectedLineInfo.currency = [];
      ERPLIST.selectedLineInfo.company = [];
      ERPLIST.selectedLineInfo.ponumber = [];
      ERPLIST.selectedLineInfo.polinenumber = [];
      ERPLIST.selectedLineInfo.doclinenumber = [];
      ERPLIST.selectedLineInfo.itemtype = [];
      ERPLIST.selectedLineInfo.formtype = [];
      ERPLIST.selectedLineInfo.masterreference = [];
      ERPLIST.selectedLineInfo.customer = [];
    } 


    if($(thisf).prop('checked')){
      $(thisf).prop('checked', true);

      // push data in array
      ERPLIST.selectedLineInfo.uniquekey.push(thisrow);
      ERPLIST.selectedLineInfo.idlines.push(idlines);
      ERPLIST.selectedLineInfo.supplier.push(supplier);
      ERPLIST.selectedLineInfo.linestatus.push(linestatus);
      ERPLIST.selectedLineInfo.purchasemode.push(purchasemode);
      ERPLIST.selectedLineInfo.currency.push(currency);
      ERPLIST.selectedLineInfo.company.push(company);
      ERPLIST.selectedLineInfo.ponumber.push(ponumber);
      ERPLIST.selectedLineInfo.polinenumber.push(polinenumber);
      ERPLIST.selectedLineInfo.doclinenumber.push(doclinenumber);
      ERPLIST.selectedLineInfo.itemtype.push(itemtype);
      ERPLIST.selectedLineInfo.formtype.push(formtype);
      ERPLIST.selectedLineInfo.masterreference.push(masterreference);
      ERPLIST.selectedLineInfo.customer.push(customer);

     // Check end customer, division and SO type... which need to be same

      var arrayLengthSupplier = ERPLIST.selectedLineInfo.supplier.length;
      var chkSupplier  = ERPLIST.selectedLineInfo.supplier[0];      

      var arrayLengthLinestatus = ERPLIST.selectedLineInfo.linestatus.length;
      var chkLinestatus  = ERPLIST.selectedLineInfo.linestatus[0];     

      var arrayLengthPurchasemode = ERPLIST.selectedLineInfo.purchasemode.length;
      var chkPurchasemode  = ERPLIST.selectedLineInfo.purchasemode[0];

      var arrayLengthCurrency = ERPLIST.selectedLineInfo.currency.length;
      var chkCurrency  = ERPLIST.selectedLineInfo.currency[0];

      var arrayLengthCompany = ERPLIST.selectedLineInfo.company.length;
      var chkCompany  = ERPLIST.selectedLineInfo.company[0];      

      var arrayLengthItemtype = ERPLIST.selectedLineInfo.itemtype.length;
      var chkItemtype  = ERPLIST.selectedLineInfo.itemtype[0];      

      var arrayLengthMasterReference = ERPLIST.selectedLineInfo.masterreference.length;
      var chkMasterReference  = ERPLIST.selectedLineInfo.masterreference[0];      

      var arrayLengthCustomer = ERPLIST.selectedLineInfo.customer.length;
      var chkCustomer  = ERPLIST.selectedLineInfo.customer[0];

      if(arrayLengthSupplier > 0 || arrayLengthLinestatus > 0 || arrayLengthPurchasemode > 0 || arrayLengthCurrency > 0 || arrayLengthCompany > 0 || arrayLengthItemtype > 0 || arrayLengthMasterReference > 0 || arrayLengthCustomer > 0){
        if(masterreference != chkMasterReference){
          alert("Master Reference need to be same.");
          $(thisf).prop('checked', false);
          ERPLIST.popUncheckedValue(thisrow);

          return false;
        }          
        if(customer != chkCustomer){
          alert("Customer need to be same.");
          $(thisf).prop('checked', false);
          ERPLIST.popUncheckedValue(thisrow);

          return false;
        }          
        if(itemtype != chkItemtype){
          alert("Item Type need to be same.");
          $(thisf).prop('checked', false);
          ERPLIST.popUncheckedValue(thisrow);

          return false;
        }        
        if(supplier != chkSupplier){
          alert("Supplier need to be same.");
          $(thisf).prop('checked', false);
          ERPLIST.popUncheckedValue(thisrow);

          return false;
        }
        if(company != chkCompany){
          alert("Division need to be same.");
          $(thisf).prop('checked', false);
          ERPLIST.popUncheckedValue(thisrow);

          return false;
        }
        if(purchasemode != chkPurchasemode){
          alert("Purchase mode need to be same.");
          $(thisf).prop('checked', false);
          ERPLIST.popUncheckedValue(thisrow);

          return false;
        }
        if(currency != chkCurrency){
          alert("Currency need to be same.");
          $(thisf).prop('checked', false);
          ERPLIST.popUncheckedValue(thisrow);

          return false;
        }

      }

    } else {
      $(thisf).prop('checked', false);


      var index = ERPLIST.selectedLineInfo.uniquekey.indexOf(thisrow);

      // pop data in array
      ERPLIST.popUncheckedValue(thisrow);
    }

}

ERPLIST.popUncheckedValue = function(thisrow){
    var index = ERPLIST.selectedLineInfo.uniquekey.indexOf(thisrow);
    ERPLIST.selectedLineInfo.uniquekey.splice(index, 1);
    ERPLIST.selectedLineInfo.idlines.splice(index, 1);
    ERPLIST.selectedLineInfo.supplier.splice(index, 1);
    ERPLIST.selectedLineInfo.linestatus.splice(index, 1);
    ERPLIST.selectedLineInfo.purchasemode.splice(index, 1);
    ERPLIST.selectedLineInfo.currency.splice(index, 1);
    ERPLIST.selectedLineInfo.company.splice(index, 1);
    ERPLIST.selectedLineInfo.ponumber.splice(index, 1);
    ERPLIST.selectedLineInfo.polinenumber.splice(index, 1);
    ERPLIST.selectedLineInfo.doclinenumber.splice(index, 1);
    ERPLIST.selectedLineInfo.itemtype.splice(index, 1);
    ERPLIST.selectedLineInfo.formtype.splice(index, 1);
    ERPLIST.selectedLineInfo.masterreference.splice(index, 1);
    ERPLIST.selectedLineInfo.customer.splice(index, 1);
    console.log(JSON.stringify(ERPLIST.selectedLineInfo.idlines) + '---' + index);

}



ERPLIST.cancel = function(){
   if(!!!ERPLIST.selectedLineInfo || ERPLIST.selectedLineInfo.idlines.length == 0){
    alert('You need to select atleast one RR line');
    return;
  }

  var idlines = ERPLIST.selectedLineInfo.idlines;

  var r = confirm(ERPLIST.selectedLineInfo.rrnumbers + ' will be gone to Allocated RR list');
  if(!r) return;


  var mType    = 'post';
  var mUrl     = ERPLIST._URL_API;
  var mReqType = "sendtoAllocatedRR";
  var postData = JSON.stringify({
    idlines  : ERPLIST.selectedLineInfo.idlines 
  });
  var returnData = jsClient.communicationToServer(mReqType, postData, mUrl, mType, false);

  returnData = JSON.parse(returnData);
  console.log(returnData.result);

  if(returnData.result == 'success'){
    ERPLIST.getListData(10,   1);
    var msgString  = 'success:: Successfully '+ ERPLIST.selectedLineInfo.rrnumber +' lines cancel for PO creation.';
    jsClient.msgDisplayer(msgString); // green
    delete(ERPLIST.selectedLineInfo);
  }  


}


ERPLIST.createPO = function(){
  if(!!!ERPLIST.selectedLineInfo || ERPLIST.selectedLineInfo.idlines.length == 0){
    alert('You need to select atleast one Requisition line');
    return;
  }

  length = ERPLIST.selectedLineInfo.idlines.length;
  requisitionStatus = ERPLIST.selectedLineInfo.linestatus;
  for(i=0 ; i < length ; i++){
    //check rr status is po created 
    if(requisitionStatus[i] != 'Complete'){
      alert('Can not create PO expcept Complete status.');
      return;
    }
  }

  if(ERPLIST.selectedLineInfo.formtype[0] != 'PR'){
    
    if(ERPLIST.selectedLineInfo.formtype[0] == 'ELS'){
        var url = '/erp-nonpo/docpoels_api.php';
    } else if(ERPLIST.selectedLineInfo.formtype[0] == 'CTN'){
        var url = '/erp-nonpo/docpoctn_api.php';
    }

    var idlines = ERPLIST.selectedLineInfo.idlines;
    $.ajax({
        type: "POST",
        url: url,
        data: {reqType:'createPOACS', idlines: JSON.stringify(idlines)},
        success: function(data) {
		    var data = JSON.parse(data);
		    var docnumber = data['docnumber'];
		    var formtype = data['formtype'];

		    if(data.isCreated == 'yes'){
			    alert('Can not create PO expcept Complete status.');
			    return;
		    }
		    if(docnumber !=''){
			    var next_href = window.location.origin + '/erp-nonpo/erpdocument.php?doctype=PO&formtype='+ formtype +'&docnumber=' + docnumber;
			    window.location = next_href;
		    } else{
			    alert('ERROR!!!Something is wrong.');
			    return;
		    }
        }
    });
      
  } else{
      //Start confirm dialog PopUp
      $('<div id="jQueryUIDialogDiv"></div>').dialog({
        width: 500,
          modal: true,
          title: "Confirmation for Creating PO",
          open: function () {
              var markup = '<table><tr><th></th><th>Yes</th><th>Not Required</th></tr>';
              markup += '<tr><td>Capex Approved</td><td><input type="checkbox" class="approvalChk radioCapex" id="" name="" onclick=""></td><td><input type="checkbox" class="approvalChk radioCapex" id="" name="" onclick=""></td></tr>';
              markup += '<tr><td>Requisition Approved</td><td><input type="checkbox" class="approvalChk radioRequisition" id="" name="" onclick=""></td><td><input type="checkbox" class="approvalChk radioRequisition" id="" name="" onclick=""></td></tr>';
              markup += '<tr><td>Quotation Approved</td><td><input type="checkbox" class="approvalChk radioQuotation" id="" name="" onclick=""></td><td><input type="checkbox" class="approvalChk radioQuotation" id="" name="" onclick=""></td></tr>';
              markup += '<tr><td>CS Approved</td><td><input type="checkbox" class="approvalChk radioCS" id="" name="" onclick=""></td><td><input type="checkbox" class="approvalChk radioCS" id="" name="" onclick=""></td></tr></table>';
              
              // var markup = '<table><tr><td><input type="checkbox" class="approvalChk" id="" name="" onclick=""></td><td>Capex Approved</td></tr>';
              // markup += '<tr><td><input type="checkbox" class="approvalChk" id="" name="" onclick=""></td><td>Requisition Approved</td></tr>';
              // markup += '<tr><td><input type="checkbox" class="approvalChk" id="" name="" onclick=""></td><td>Quotation Approved</td></tr>';
              // markup += '<tr><td><input type="checkbox" class="approvalChk" id="" name="" onclick=""></td><td>CS Approved</td></tr></table>';
              $(this).html(markup);
              ERPLIST.checkboxAsRadio();
          },
          buttons: {
              "Yes": function () {
                  var allChk = 1;
                  var count = 0;
                  $('.approvalChk').each(function(){
                    if($(this).is(":checked")){
                      count++;
                    }else{
                      allChk = 0;
                    }
                  });

                  console.log(count);

                  if(count != 4){
                    alert("All Condition must be checked else can not create PO.");
                  }else{
                    var next_href = '/erp-nonpo/erpdocument.php?doctype=PO&formtype=PO&idlines=' + ERPLIST.selectedLineInfo.idlines;
                    window.location = next_href; 
                  }
                  
              },
              No: function () {
                  $(this).dialog("close");
              }
          }
      }); //end confirm dialog PopUp
  }
  
}

ERPLIST.createGRN = function(){
  if(!!!ERPLIST.selectedLineInfo || ERPLIST.selectedLineInfo.idlines.length == 0){
    alert('You need to select atleast one Requisition line');
    return;
  }

  length = ERPLIST.selectedLineInfo.idlines.length;
  requisitionStatus = ERPLIST.selectedLineInfo.linestatus;
  for(i=0 ; i < length ; i++){
    //check rr status is po created 
    if(requisitionStatus[i] != 'Released'){
      alert('Only Released Requisition is allowed for create GRN');
      return;
    }
  }

  var next_href = '/erp-nonpo/erpdocument.php?doctype=GRN&formtype=GRN&polinenumber='+ ERPLIST.selectedLineInfo.polinenumber;
  window.location = next_href;
}


ERPLIST.checkboxAsRadio = function(){

  $(".radioCapex").change(function() {
    var checked = $(this).is(':checked');
    $(".radioCapex").prop('checked',false);
    if(checked) {
      $(this).prop('checked',true);
    }
  });

  $(".radioRequisition").change(function() {
    var checked = $(this).is(':checked');
    $(".radioRequisition").prop('checked',false);
    if(checked) {
        $(this).prop('checked',true);
    }
  });

  $(".radioQuotation").change(function() {
    var checked = $(this).is(':checked');
    $(".radioQuotation").prop('checked',false);
    if(checked) {
        $(this).prop('checked',true);
    }
  });

  $(".radioCS").change(function() {
    var checked = $(this).is(':checked');
    $(".radioCS").prop('checked',false);
    if(checked) {
        $(this).prop('checked',true);
    }
  });

}

ERPLIST.getAutoCompleteInfo = function(){
  var searchParams = {
    'reqType': 'getProcurer'
  };

  var mType = 'get';
  var mUrl     = "list-rr-po-wo-creation_api.php";
  var mReqType = "";

  var returnData = jsClient.communicationToServer(mReqType, searchParams, mUrl, mType, false);

  console.log(returnData);
   if (returnData.length > 0) {

    data = JSON.parse(returnData);
   

    var purchasemodeTags = JSON.parse(data['purchasemode']);


    $( ".modal_procurer" ).autocomplete({
      source: purchasemodeTags
    });

   }

}


ERPLIST.setProcurer = function(){
  if(!!!ERPLIST.selectedLineInfo || ERPLIST.selectedLineInfo.idlines.length == 0){
    alert('You need to select atleast one Requisition line');
    return;
  }

  length = ERPLIST.selectedLineInfo.idlines.length;
  requisitionStatus = ERPLIST.selectedLineInfo.linestatus;
  for(i=0 ; i < length ; i++){
    //check rr status is po created 
    if(requisitionStatus[i] == 'Released'){
      alert('PO has already been created.');
      return;
    }
  }

  //Start confirm dialog PopUp
  $('<div id="jQueryUIDialogDiv"></div>').dialog({
     width: 500,
      modal: true,
      title: "Set Procurer",
      open: function () {
          var markup = '<table class="no_border"><tr><td>Procurer :</td><td><input type="text" id="modal_procurer" name="" class="modal_procurer" onclick="ERPLIST.getAutoCompleteInfo();"></td></tr></table>';
          $(this).html(markup);

          // ERPLIST.getAutoCompleteInfo();
      },
      buttons: {
          "Yes": function () {
              ERPLIST.assignProcurerName(this);
              $(this).dialog("close");
              
          },
          No: function () {
              $(this).dialog("close");
          }
      }
  }); //end confirm dialog PopUp



  
}




ERPLIST.assignProcurerName = function(thismodal) {
  var selectedRRLines = ERPLIST.selectedLineInfo;
  var idlines = selectedRRLines.idlines;
  var procurer = $(thismodal).find('table input#modal_procurer').val();


  var postData = {
    reqType: 'setProcurer',
    idlines: JSON.stringify(idlines),
    procurer: procurer
  };

  console.log(postData);


  $.ajax({
    type: 'post',
    url: 'list-rr-po-wo-creation_api.php',
    data: postData,
    success: function(data) {
        // data = JSON.parse(data);
        // if (!!data.errormsgs && data.errormsgs.length > 0) {
          
        // } else {
        //   ERPLIST.getListData(100,    1);
        // }
        delete(ERPLIST.selectedLineInfo);
        ERPLIST.getListData(100,    1);
    }
  }).fail(function(e) {
    alert('Assign failed, please try again.');
  });

}





ERPLIST.actionButton = function(){
  var cloneDiv = $('#listSuccessDiv').clone();
  cloneDiv.css({'display':'block'})
      .insertBefore('#listSuccessDiv')
      .find('#listSuccessMsg').text('this is success');

  var cloneDiv = $('#listWarningDiv').clone();
  cloneDiv.css({'display':'block'})
      .insertBefore('#listWarningDiv')
      .find('#listWarningMsg').text('this is warning');

  var cloneDiv = $('#listErrorDiv').clone();
  cloneDiv.css({'display':'block'})
      .insertBefore('#listErrorDiv')
      .find('#listErrorMsg').text('this is error');
}

ERPLIST.initLibFieldsForSearch = function(){
  ERPLIST.libraryColumns = {
    //   linestatus:{
    //     style: 'font-weight:bold; color:green',
    //     customsearch: true,
    //     islibrary: true,
    //     datasource: {
    //         0: 'Entered',
    //         1: 'Running',
    //         2: 'Closed'
    //      },        
    //     fielddesc: 'Line Status',
    //     showsearchimg: true,
    // },
    company: {
      fielddesc: 'Company',
      sql: "SELECT Code AS code, Description AS description FROM mrd_library WHERE LibraryName='company'",
    },
    customer: {
      fielddesc: 'Customer',
      islibrary: true,
      sql: "SELECT Description AS code, Description AS description FROM mrd_library WHERE LibraryName='Buyer'", 
    },
    endcustomer: {
      fielddesc: 'End Customer',
      islibrary: true,
      sql: "SELECT Code AS code, Description AS description FROM mrd_library WHERE LibraryName='Buyer'", 
    },    
  };  
  return ERPLIST.libraryColumns;
}