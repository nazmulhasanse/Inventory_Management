/**
 * Declare the namespace LIZERP if not existent
 */
var LIZERP = LIZERP || {};

$.extend(LIZERP, {
  _ERP_DOCACRONYM: '',
  _FIELDSETS_HEADER: ['fieldset_documentinformation', 'fieldset_logisticsinformation', 'fieldset_projectinformation'],

  foo: 'here for no reason other than to be the last line, without a comma'
});


LIZERP.initForm = function(){

}

LIZERP.displayFormInterface = function(){
  $('#formDiv').css({
    'display':'block',
    'floal': 'left',
  });
  LIZERP.adjustInterface();
}

LIZERP.hideFormInterface = function(){
  if($('#formDiv').length > 0){
    $('#formDiv').css({
      'display':'none',
    });
    LIZERP.initialMode();
    LIZERP.fitListToFullWindow();
  }
}


LIZERP.setDefaultFieldValue = function(){
  $('#CompanyName').val('LFI');
  LIZERP.handle_docdate_field();
}

LIZERP.blankForm = function(){
  LIZERP.dataReadFromDB = false;

  LIZERP.displayFormInterface();
  LIZERP.editMode();
  var formId =  $("#formERP");
  jsClient.resetForm(formId);
  jsClient.clearForm(formId);
  LIZERP.setDefaultFieldValue();
}



LIZERP.customFucntion = function(){
  // write your custom function
  // bla bla ...........
}


LIZERP.copyAndNewModeForm = function(){
  LIZERP.dataReadFromDB = false;
  var DOC_DB_SET_READ_KAYFIELD  = LIZERP.formFieldSettings['DOC_DB_SET_READ_KAYFIELD'];
  $(LIZERP.formId + ' #' + DOC_DB_SET_READ_KAYFIELD).val('');
  LIZERP.editMode();
}



LIZERP.readFile = function(directory, container){

  
  var attachmentImages = "";
            // var dir = "given directory";
  var fileextension = [".png", ".PNG", ".jpg", ".pdf", ".xlsx"];
  $.ajax({
              //This will retrieve the contents of the folder if the folder is configured as 'browsable'
    async: false,
    url  : directory,
      success: function (data) {

        console.log(data)

                //Lsit all png file names in the page
          $(data).find("a:contains(" + (fileextension[0]) + "), a:contains(" + (fileextension[1]) + "), a:contains(" + (fileextension[2]) + "), a:contains(" + (fileextension[3]) + "), a:contains(" + (fileextension[4]) + ")").each(function () {
            var dt = new Date();
              var filename = $(this).attr("href");
                // filename = filename.replace('%20', ' ');
                filename=filename.replace(/%20/gi,' ');
              var ext = filename.substr(filename.lastIndexOf('.') + 1);
              // var btnDelete = "<input type='button' value='delete' onclick='LIZERP.deleteFile(\""+ directory +"\"   " +','+ " \""+ filename +"\" " +','+ " \""+ container +"\" )'/></div>";
              var btnDelete = "";
              if(ext == "pdf"){
                attachmentImages = "<div class='file'><a class='fancybox' target='_blank' href='"+directory+"/"+filename+"'><div class='caption_wrapper'><img class='border' src='css/previewPDF.png' height='150px' width='180px'></img><div class='caption_description'><p class='caption_description_content'>"+ filename +"</p></div></div></a>" + btnDelete;
              } else if(ext == "xlsx"){
                attachmentImages = "<div class='file'><a class='fancybox' target='_blank' href='"+directory+"/"+filename+"'><div class='caption_wrapper'><img class='border' src='css/previewXLSX.png' height='150px' width='180px'></img><div class='caption_description'><p class='caption_description_content'>"+ filename +"</p></div></div></a>" + btnDelete;
              } else {
                attachmentImages = "<div class='file'><a class='fancybox' target='_blank' href='"+directory+"/"+filename+"'><div class='caption_wrapper'><img class='border' src='" + directory +"/" + filename + "?mpic="+ dt +"' height='150px' width='180px'></img><div class='caption_description'><p class='caption_description_content'>"+ filename +"</p></div></div></a>" + btnDelete;
              }
                  // $("body").append($("<img src=" + dir +"/" + filename + "></img>"));
              $(container).append(attachmentImages);

              // $('head').append('<link rel="stylesheet" href="css/filegallery.css" type="text/css" />');

            });
      }, 
      error: function(){
        attachmentImages = "";
      }

  }); 

}



// File Attachment work Start --------------------------------------------------------------------------------------------------------------------------
LIZERP.handleDocFileAttacment = function(){

 $('#fieldset_documentfile_textile').remove();
 var attachmentHTML = '\
 <fieldset id="fieldset_documentfile_textile" style="border: 1px solid #B7B7B7; border-radius:5px;  margin-top:10px; margin-bottom:10px; padding-left: 5px; padding-bottom: 20px;" >\
    <legend style="border: 1px solid #B7B7B7; padding: 5px; border-radius:5px; font-weight: bold; padding: 5px; margin: 15px; color:black;">Textile File</legend>\
    <div class="formGroup">\
      <div class="fileAttachmentContainer" style="display: block;">\
        <div style="clear:both;"></div>\
        <div class="fileViewerContainer" style="float:left;">\
          <a href="" target="_blank"><img src="img/fileicon.png" width="30" height="20"></a>\
        </div>\
      </div>\
    </div>\
  </fieldset>'; 

 $('#fieldset_nominatedsupplierinformation').after(attachmentHTML);

 LIZERP.readMLFileUsingSO();
 // alert($('#fieldset_salesorderinformation input#salesorder').val());

 // materiallistid = '';

  // var directoryPath = "/attachments/erp-apparel/"+ materiallistid+ "/textile";
  // LIZERP.readFile(directoryPath, '#fieldset_documentfile_textile .fileViewerContainer');

  // css append
  $('head').append('<link rel="stylesheet" href="css/filegallery.css" type="text/css" />');

}


LIZERP.readMLFileUsingSO = function(){
  salesorder = $('#fieldset_salesorderinformation input#salesorder').val();
  var searchParams = {
    'reqType': 'readMLUsingSo',
    'salesorder'  : salesorder
  };


  $.get(LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM], searchParams, populateFileUsingML);
  function populateFileUsingML(data, textStatus, jqXHR) {
    console.log(data);
    data = JSON.parse(data);

    $('#fieldset_documentfile_textile .fileViewerContainer').empty();
    for(var i=0; i<data.length; i++){
      materiallistid = data[i];

      var directoryPath = "/attachments/erp-apparel/"+ materiallistid+ "/textile";
      LIZERP.readFile(directoryPath, '#fieldset_documentfile_textile .fileViewerContainer');
    }
  }
}



$.extend(LIZERP, {
  /**
   * Start up function
   * @description Any JS code to be run on start up
   * @returns {undefined}
   */
  init: function() {
    /* executable JS */
    return;
  },
  enableRead: function() {
    LIZERP.readMode();
    return;
  },
  enableEdit: function() {
    LIZERP.editMode();
    return;
  },
  enableReceive: function() {
    LIZERP.receiveMode();
    return;
  },

  /**
   * Process Purchase Request Form
   * @param selector formId
   * @returns {undefined}
   */
  processForm: function(formId, params) {

    LIZERP.formId = formId + ' ';
    LIZERP.formMode = 'edit';
    LIZERP._ERP_DOCACRONYM = params['_ERP_DOCACRONYM'];
    LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM] = params['_URL_DOCUMENTAPI'];
    LIZERP._URL_DOCDEFINEAPI[LIZERP._ERP_DOCACRONYM] = params['_URL_DOCDEFINEAPI'];
    LIZERP._URL_MODULEDIR = params['_URL_MODULEDIR'];
    LIZERP.DOC_DB_SET_READ_KAYFIELD = params['DOC_DB_SET_READ_KAYFIELD'];

    var populatePromises = [];
    populatePromises.push(LIZERP.populatePdmDropdown('company', 'company', 'LFI'));
    populatePromises.push(LIZERP.populatePdmDropdown('buyername', 'Buyer','','codevalequal'));
    populatePromises.push(LIZERP.populatePdmDropdown('iduom', 'UOM'));
    populatePromises.push(LIZERP.populateDropdown('orderstatus', 'OrderStatus', '', 'codevalequal'));        
    $.when.apply($, populatePromises).then(function() {
      // Caches the HTML of a new line
      // LIZERP.lineHTML_template = $('#fieldset_lineinformation table tr[data-id=1]')[0].outerHTML;
    });

    LIZERP.handle_docdate_field();
    /* Show/Hide/Enable/Disable fields on document load */
    LIZERP.handleFormFields('create');

    LIZERP.initForm(); 
    LIZERP.initialMode();


    $(window).keydown(function(e) {
      if (e.ctrlKey || e.metaKey) {
        switch (String.fromCharCode(e.which).toLowerCase()) {
          case 's':
            e.preventDefault();
            $('#upperButtonBar .btnSaveForm').click();
            break;
        }
      }
    });

    $('.btnSaveForm').on('click', function(e) {
      e.preventDefault();
      LIZERP.saveForm();
    });   
    $('.btnSaveAndNew').on('click', function(e) {
      e.preventDefault();
      LIZERP.saveAndNewForm();
    });   

    $('.btnCopyAndNew').on('click', function(e) {
      e.preventDefault();
      LIZERP.copyAndNewModeForm();
    });   

    $('.btnMultipleLineCopy').on('click', function(e) {
      e.preventDefault();
      LIZERP.multipleLineCopy();
    });   

    $('.btnDelete').on('click', function(e) {
      e.preventDefault();
      LIZERP.deleteLine();
    });   

    $('#upperButtonBar .btnNew').on('click', function(e) {
      e.preventDefault();
      LIZERP.blankForm();
    });    

    $('.btnEnableExcelMode').on('click', function(e) {
      e.preventDefault();
      LISTDOC.enableExcelMode();
    });     


    $(LIZERP.formId + ' .btnNext').on('click', function(e) {
      e.preventDefault();
      var docnumber = $(LIZERP.formId + ' #docnumber').val();
      var next_href = window.location.origin + window.location.pathname + '?doctype=FL&formtype=default&dprnumber=' + docnumber + '&tabcontent=1';
      window.location.href = next_href;
      // LIZERP.blankForm();
    });     


    $('#upperButtonBar .btnCancelForm').on('click', function(e) {
      e.preventDefault();
      // location.reload();
      LIZERP.hideFormInterface();
    });
    $('#rightFormButtons .btnCancelForm').on('click', function(e) {
      e.preventDefault();
      // location.reload();
      LIZERP.hideFormInterface();
    });


    $(' .btnEnterEditMode').on('click', function(e) {
      e.preventDefault();
      LIZERP.editMode();
    });

    $(LIZERP.formId + ' .btnPrintSheet').on('click', function(e) {
      e.preventDefault();
      var params = paramsToObj(window.location.search);
      window.open('printdoc-v3.php?doctype=' + params.doctype + '&docnumber=' + params.docnumber);
    });

    $(LIZERP.formId + ' .btnChangeDocStatus').on('click', function(e) {
      e.preventDefault();
      if (confirm('Click OK to send to WMS')) LIZERP.changeDocStatus();
    });

    
    return;
  }
});





var erpdocument = {};
erpdocument.processForm = function(formId, params) {
  LIZERP.processForm(formId, params);
}




LIZERP.readThisDoc_N_FillInForm = function(docnumber){
  LIZERP.displayFormInterface();

  // var searchParams = {
  // 'reqType': 'readDoc',
  // 'docnumber': docnumber
  // };

  var DOC_DB_SET_READ_KAYFIELD = LIZERP.DOC_DB_SET_READ_KAYFIELD;
  var searchParams = {
    'reqType': 'readDoc',
    DOC_DB_SET_READ_KAYFIELD  : LIZERP.DOC_DB_SET_READ_KAYFIELD,
    DOC_DB_SET_READ_KAYVALUE  : docnumber,
  };


  $.get(LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM], searchParams, populateFromDb);
  function populateFromDb(data, textStatus, jqXHR) {
    console.log(data);
    data = JSON.parse(data);
    if (Object.keys(data).length > 0) {
        LIZERP.fillForm(data);
        LIZERP.readMode();
        LIZERP.dataReadFromDB = true;
        // window.scrollTo(0, 0);
        LIZERP.handleDocFileAttacment();
    } else {
      LIZERP.editMode();
      alert('Document not found.');
    }
  }

}
























var dragging = false;
   $('#dragbar').mousedown(function(e){
       e.preventDefault();
       
       dragging = true;
       var main = $('#rightFormDiv');
       var ghostbar = $('<div>',
                        {id:'ghostbar',
                         css: {
                                height: main.outerHeight(),
                                top: main.offset().top,
                                left: main.offset().left
                               }
                        }).appendTo('body');
       
        $(document).mousemove(function(e){
          ghostbar.css("left",e.pageX+2);
       });
       
    });

   $(document).mouseup(function(e){
       if (dragging) 
       {
           var percentage = (e.pageX / window.innerWidth) * 100;
           var mainPercentage = 100-percentage;
           
           $('#leftListDiv').css("width",percentage + "%");
           $('#rightFormDiv').css("width",mainPercentage + "%");
           $('#ghostbar').remove();
           $(document).unbind('mousemove');
           dragging = false;
       }
    });