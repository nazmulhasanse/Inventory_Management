/**
 * Declare ERPLIST Namespace if not exist
 */
var ERPLIST = ERPLIST || {};

$.extend(ERPLIST, {
  mUrl: 'api/server_api.php',
  mType: 'get',
  mData: '',
  mAsync: false,
  mReqType: '',
  queryData: '',
  queryParam: '',
  _searchParams: '',
  _URL_API: 'receiving-transaction-creation_api.php',

  foo: 'here for no reason other than to be the last line, without a comma'
});




ERPLIST.displayQueryData = function(jsonData){

  var pagination = jsClient.makePagination(jsonData)

  var data = JSON.parse(jsonData);
  var listData = data['listData'];
  var hasData = (data.noResult) ? 'no' : 'yes';
  var listTable = ERPLIST.makeTable(listData, hasData, jsonData);

  $("#listDiv").html(pagination);
  $("#listDiv").append(listTable);

  ERPLIST.initSearchAction();

  /**
   * Css
   */
  $('#listTable').css({
    'width':'100%'
  });
  $('#listTable tr#searchForm input[type="text"]').css({
    'width':'95%',
    'min-width': '100px',
    'font-family':'Arial',
    'padding':'2px',
    'border':'1px solid #7F7F7F',
    'border-radius':'3px'
  });
  $('#listTable tr#searchForm button').css({
    'padding':'2px',
    'border':'1px solid #7F7F7F',
    'border-radius':'3px',
    'vertical-align': 'middle'
  });  
  $('#listTable .hasCustomSearch').css({
    'width':'70%'
  });
  jsClient.paginationCSS();
  ERPLIST.applyCustomCSS();
  ERPLIST.changeTempleteCSS();
  ERPLIST.applyCustomFunction();
  ERPLIST.initList();

  // --- Fix table header during on scroll
  $("#listTable").fixMe();

}



ERPLIST.exportToExecl = function(){
  var searchParams = {};
  $('table#listTable thead tr#searchForm').each(function() {
    $(this).find("td input:text,select").each(function() {
      var textVal   = this.value.trim();
      var inputName = $(this).attr("name");
      var tagName   = $(this).prop("tagName");

      // if inputName is undefined then assume its combobox 
      if(inputName == undefined) return;
      // try to retrive name by closest select tag
      if(!!ERPLIST.libraryColumns[inputName]){
          if(textVal == '______'){ // define for empty
            textVal = "";
          }
      }
      if(textVal != ""){
        searchParams[inputName] = textVal;
      }            
    });
  });
// return encodeURIComponent(key) + '=' + encodeURIComponent(params[key]);
  var qrystr = $.param( searchParams );
  var expURL = '/erp-nonpo/receiving-transaction-creation_api.php?reqType=exportListData&' + qrystr;
  window.open(expURL);
}

ERPLIST.makeTable = function(mydata,hasData, jsonData) {
  var $table = $('<table border=1 id="listTable" class="listTable" />');
  var $thead = $('<thead />');
  var $tbody = $('<tbody/>');

  //for composition column
  ERPLIST.compositeColumns = {
    
    
   linestatus:{
      linestatus: {
        fielddesc: 'Status',
        islibrary: true,
        datasource: {
          0: 'Entered',
          1: 'Complete',
          2: 'Released'
        },  
        customsearch: true,
        composite: false,
        end: true
      }
    },

    // docnumber : {
    //   docnumber : {
    //     fielddesc: 'Requisition No.',
    //     composite: false,
    //     customsearch: false,
    //     single: true,
    //     end: true
    //   },        
    // },


    // doclinenumber : {
    //   doclinenumber : {
    //     fielddesc: 'Requisition Line No.',
    //     composite: false,
    //     customsearch: false,
    //     single: true,
    //     end: true
    //   },        
    // },

    // docdate : {
    //   docdate : {
    //     fielddesc: 'PR Date',
    //     composite: false,
    //     customsearch: true,
    //     single: true,
    //     type: 'date',
    //     end: true
    //   },        
    // },

    // company : {
    //   company : {
    //     fielddesc: 'Division',
    //     composite: false,
    //     customsearch: false,
    //     single: true,
    //     end: true
    //   },        
    // },

    // orderqty : {
    //   orderqty : {
    //     fielddesc: 'Quantity',
    //     composite: false,
    //     customsearch: false,
    //     single: true,
    //     end: true
    //   },        
    // },

    // receivedqty : {
    //   receivedqty : {
    //     fielddesc: 'Received Qty',
    //     composite: false,
    //     customsearch: false,
    //     single: true,
    //     end: true
    //   },        
    // },

    // iduom : {
    //   iduom : {
    //     fielddesc: 'UoM',
    //     composite: false,
    //     customsearch: false,
    //     single: true,
    //     end: true
    //   },        
    // },
    // whlocation : {
    //   whlocation : {
    //     fielddesc: 'WH Location',
    //     composite: false,
    //     customsearch: false,
    //     single: true,
    //     end: true
    //   },        
    // },    
    // supplierlot : {
    //   supplierlot : {
    //     fielddesc: 'Supplier Lot',
    //     composite: false,
    //     customsearch: false,
    //     single: true,
    //     end: true
    //   },        
    // },
    // manufacturingdate : {
    //   manufacturingdate : {
    //     fielddesc: 'Manufacturing Date',
    //     composite: false,
    //     customsearch: false,
    //     single: true,
    //     end: true
    //   },        
    // },
    // expiredate : {
    //   expiredate : {
    //     fielddesc: 'Expire Date',
    //     composite: false,
    //     customsearch: false,
    //     single: true,
    //     end: true
    //   },        
    // },

    // ponumber : {
    //   ponumber : {
    //     fielddesc: 'PO No.',
    //     composite: false,
    //     customsearch: false,
    //     single: true,
    //     end: true
    //   },        
    // },

    // podocdate : {
    //   podocdate : {
    //     fielddesc: 'PO Date',
    //     composite: false,
    //     customsearch: true,
    //     single: true,
    //     type: 'date',
    //     end: true
    //   },        
    // },  

    // project : {
    //   project : {
    //     fielddesc: 'Project Code',
    //     composite: false,
    //     customsearch: false,
    //     single: true,
    //     end: true
    //   },        
    // },

    // itemcode : {
    //   itemcode : {
    //     fielddesc: 'Item Code',
    //     composite: false,
    //     customsearch: false,
    //     single: true,
    //     end: true
    //   },        
    // },

    // itemname : {
    //   itemname : {
    //     fielddesc: 'Item Name',
    //     composite: false,
    //     customsearch: false,
    //     single: true,
    //     end: true
    //   },        
    // },

    // itemnature : {
    //   itemnature : {
    //     fielddesc: 'Item Nature',
    //     composite: false,
    //     customsearch: false,
    //     single: true,
    //     end: true
    //   },        
    // },

    // itemdescription : {
    //   itemdescription : {
    //     fielddesc: 'Item Description',
    //     composite: false,
    //     customsearch: false,
    //     single: true,
    //     end: true
    //   },        
    // },

    // purchasemode : {
    //   purchasemode : {
    //     fielddesc: 'Procurer',
    //     composite: false,
    //     customsearch: false,
    //     single: true,
    //     end: true
    //   },        
    // },

    // suppliername : {
    //   suppliername : {
    //     fielddesc: 'Supplier Name',
    //     composite: false,
    //     customsearch: false,
    //     single: true,
    //     end: true
    //   },        
    // },

    // supplieraddress : {
    //   supplieraddress : {
    //     fielddesc: 'Supplier Address',
    //     composite: false,
    //     customsearch: false,
    //     single: true,
    //     end: true
    //   },        
    // },

    // unitprice : {
    //   unitprice : {
    //     fielddesc: 'Unit Price',
    //     composite: false,
    //     customsearch: false,
    //     single: true,
    //     end: true
    //   },        
    // },

    // deliverydate : {
    //   deliverydate : {
    //     fielddesc: 'Delivery Date',
    //     composite: false,
    //     customsearch: true,
    //     single: true,
    //     type: 'date',
    //     end: true
    //   },        
    // },
  }

  var translationsHardCode = {};
  var params = jsClient.paramsToObj(window.location.search);
  var itemtype = params.itemtype;
  
	if(itemtype == 'ELS'){
    	var hideColumns = [ 'idlines',  'doctype','sizeormeasurement','formtype','costcenter','costdept','itemname', 'purchasemode', 'brand', 'manufacturingdate', 'expiredate', 'extracost', 'amountwithoutdiscount', 'discountamount', 'capexno', 'requestername', 'requestercontactno', 'itemnature', 'deliverydate', 'extracostdescription', 'supplierlot', 'itemdescription', 'color', 'supplieraddress', 'linesremarks'];

		var fieldSequence = [ 'idlines', 'linestatus', 'itemtype', 'docnumber', 'doclinenumber', 'trackingNum', 'masterreference', 'project', 'docdate', 'company', 'orderqty', 'receivedqty', 'iduom', 'whlocation', 'ponumber', 'podocdate', 'polinenumber', 'itemcode', 'subcode01', 'suppliername', 'trimscatagory', 'subcode04', 'subcode05', 'subcode06', 'subcode07', 'subcode08', 'formtype'];

        translationsHardCode.subcode01 = 'Item Description';
        translationsHardCode.subcode02 = 'Construction';
        translationsHardCode.subcode03 = 'Composition';
        translationsHardCode.subcode04 = 'Item Color';
        translationsHardCode.subcode05 = 'Shade No.';
        translationsHardCode.subcode06 = 'Elastic Code';
        translationsHardCode.subcode07 = 'Width';
        translationsHardCode.subcode08 = 'Width UoM';  
        translationsHardCode.subcode09 = 'Size';  
        translationsHardCode.subcode10 = 'Supplier Reference/ Product Code'; 
        translationsHardCode.project           = 'WO No./Project'; 	
 
  } else if(itemtype == 'CTN'){
    	var hideColumns = [ 'idlines',  'doctype','sizeormeasurement','formtype','costcenter','costdept','itemname', 'purchasemode', 'brand', 'manufacturingdate', 'expiredate', 'extracost', 'amountwithoutdiscount', 'discountamount', 'capexno', 'requestername', 'requestercontactno', 'itemnature', 'deliverydate', 'extracostdescription', 'supplierlot', 'itemdescription', 'color', 'supplieraddress', 'linesremarks', 'subcode01'];
    	
		var fieldSequence = [ 'idlines', 'linestatus', 'itemtype', 'docnumber', 'doclinenumber', 'trackingNum', 'masterreference', 'project', 'docdate', 'company', 'orderqty', 'receivedqty', 'iduom', 'whlocation', 'ponumber', 'podocdate', 'polinenumber', 'itemcode', 'subcode01', 'suppliername', 'trimscatagory', 'subcode04', 'subcode05', 'subcode06', 'subcode07', 'subcode08', 'formtype'];

    	translationsHardCode.subcode01 = 'No. of Ply';
        translationsHardCode.subcode02 = 'GSM';
        translationsHardCode.subcode03 = 'Garment Size';
        translationsHardCode.subcode04 = 'Length';
        translationsHardCode.subcode05 = 'Width';
        translationsHardCode.subcode06 = 'Height';
        translationsHardCode.subcode07 = 'Measurement Unit';
        translationsHardCode.subcode08 = 'SQM';  
        translationsHardCode.subcode09 = 'Carton Color';  
        translationsHardCode.subcode10 = 'Shipping Mark';  
        translationsHardCode.subcode11 = 'Shipping Color';  
        translationsHardCode.project           = 'WO No./Project';
  } else{
    	var hideColumns = [ 'idlines', 'customer', 'doctype','workorderdocnumber','formtype', 'poformtype','cpdocnumber','isrrfreezed','recalculationbit', 'actualdeductionqty', 'requirednetqty', 'parentrrnumber', 'masterreference', 'subcode01', 'trimscatagory', 'subcode04', 'subcode05', 'subcode06', 'subcode07', 'subcode08'];

		var fieldSequence = [ 'idlines', 'linestatus', 'docnumber', 'doclinenumber', 'docdate', 'company', 'orderqty', 'receivedqty', 'iduom', 'whlocation', 'supplierlot', 'manufacturingdate', 'expiredate', 'ponumber', 'podocdate', 'project', 'itemcode', 'itemname', 'itemnature', 'itemdescription', 'purchasemode', 'suppliername', 'supplieraddress', 'unitprice', 'deliverydate', 'itemtype', 'brand', 'color', 'sizeormeasurement', 'costcenter', 'costdept', 'extracost', 'extracostdescription', 'amountwithoutdiscount', 'discountamount', 'amount', 'currency', 'capexno', 'requestername', 'requestercontactno', 'linesremarks', 'formtype', 'poformtype', 'polinenumber'];

    	translationsHardCode.project           = 'Project Code';
  }
    // some trickery for nice formatting
  
  translationsHardCode.iduom                 = 'UoM';
  translationsHardCode.docnumber             = 'Requisition No.';
  translationsHardCode.docdate               = 'PR Date';
  translationsHardCode.costcenter            = 'Cost Center';
  translationsHardCode.costdept              = 'Cost Dept.';
  translationsHardCode.itemname              = 'Item Name';
  translationsHardCode.brand                 = 'Brand';
  translationsHardCode.color                 = 'Color';
  translationsHardCode.sizeormeasurement     = 'Size or Measurement';
  translationsHardCode.orderqty              = 'Order Quantity';
  translationsHardCode.deliverydate          = 'Delivery Date';
  translationsHardCode.purchasemode          = 'Procurer';
  translationsHardCode.suppliername          = 'Supplier Name';
  translationsHardCode.unitprice             = 'Unit Price';
  translationsHardCode.currency              = 'Currency';
  translationsHardCode.extracost             = 'Extra cost';
  translationsHardCode.trimscatagory         = 'Trims Catagory';
  translationsHardCode.trackingNum           = 'Tracking No.';
  
  translationsHardCode.amountwithoutdiscount = 'Amount Without Discount';
  translationsHardCode.discountamount        = 'Discount Amount';
  translationsHardCode.amount                = 'Amount';
  
  translationsHardCode.capexno               = 'Capex No';
  translationsHardCode.linesremarks          = 'Remarks';
  translationsHardCode.linestatus            = 'Status';
  translationsHardCode.ponumber              = 'PO No.';
  translationsHardCode.podocdate             = 'PO Date';
  translationsHardCode.supplieraddress       = 'Supplier Address';
  translationsHardCode.extracostdescription  = 'Extra Cost Description';

  translationsHardCode.requestername         = 'Requestor Name';
  translationsHardCode.requestercontactno    = 'Requestor Contact No.';
  translationsHardCode.receivedqty    = 'Received Qty';
  
  translationsHardCode.supplierlot    = 'Supplier Lot';
  translationsHardCode.manufacturingdate    = 'Manufacturing Date';
  translationsHardCode.expiredate    = 'Expire Date';
  translationsHardCode.whlocation    = 'WH Location';
  translationsHardCode.masterreference    = 'Master Ref#';
  
  
  
  translationsHardCode.doclinenumber         = 'Requisition Line No.';
  translationsHardCode.company               = 'Division';
  translationsHardCode.itemcode              = 'Item Code';
  translationsHardCode.itemdescription       = 'Item Description';
  translationsHardCode.subcode01             = 'Item Description';
  translationsHardCode.itemnature            = 'Item Nature';
  translationsHardCode.itemtype              = 'Item Type';
  translationsHardCode.polinenumber          = 'PO Line No.';


  ERPLIST.translationsHardCode = translationsHardCode;


  // builds the table header
  var mydata1 = [];
  $.each(mydata, function (index, row) {
    item = {}
    $.each(fieldSequence, function(index, fieldname){
        item [fieldname] = row[fieldname];
    });
    mydata1.push(item);
  });
  mydata = mydata1;

  var orgBgOn = '';
  var mydata_json = JSON.stringify(mydata);
  var firstRow = mydata[0];

  var dataForDataId   = JSON.parse(jsonData);
  var pageNum      = parseInt(dataForDataId['pageNum']-1);
  var showLimit    = parseInt(dataForDataId['showLimit']);
  var trDataId = parseInt(pageNum * showLimit) + 1;

  var firstRowCopy = firstRow;
  var compositeColumnsLength = Object.keys(ERPLIST.compositeColumns).length;
  var countVisibleColumn = 1; // here start from 1 cz first td for option
  /**
   * first header row------------------------------------------------------------------------------------------------------------------------------------------------------------
   */
  var $tr = $("<tr/>");
  $td = $('<th/>');
  thisLineActionBtn = '<center>Check All</center>';
  $td.html(thisLineActionBtn);
  $td.appendTo($tr);

  // process composite column first if has
  if(compositeColumnsLength > 0){
    $.each(ERPLIST.compositeColumns, function(groupName, groupColumns){
      // hide first
      $.each(groupColumns, function(fieldname, fieldStyle){
        var fielddesc = fieldname;
        $td = $('<th/>');
        if (!!translationsHardCode[fieldname]) fielddesc = translationsHardCode[fieldname];
        $td.html('<center>'+ fielddesc +'</center>');
        $td.css('display','none');
        $td.appendTo($tr);

        delete firstRowCopy[fieldname]; // its already procceed
      });

      $td = $('<th/>');
      $td.attr('class', groupName);
      if ( hideColumns.indexOf(groupName) >= 0 ){ 
        $td.css('display','none'); countVisibleColumn--;
      }else{
        countVisibleColumn++;
      }
      if (!!translationsHardCode[groupName]) groupName = translationsHardCode[groupName];
      $td.html('<center>'+ groupName +'</center>');
      $td.appendTo($tr);
      // countVisibleColumn++;
    });
  }

  // precess rest of columns----------------------------------------------------------------------------------------------
  $.each(firstRowCopy, function (fieldname, fieldvalue) {
    countVisibleColumn++;
    var fielddesc = fieldname;
    $td = $('<th/>');
    if (!!translationsHardCode[fieldname]) fielddesc = translationsHardCode[fieldname];
    $td.html('<center>'+ fielddesc +'</center>');
    if ( hideColumns.indexOf(fieldname) >= 0 ){ $td.css('display','none'); countVisibleColumn--};
    $td.appendTo($tr);
  });
  $tr.appendTo($thead);
  $thead.appendTo($table);
  // end -----------------------------------------------------------------------------------------------------------------


  /**
   * second header row-----------------------------------------------------------------------------------------------------------------------------------------------------------
   */
  var $tr = $("<tr/>").attr("id","searchForm");
  var $td;
  $td = $('<td/>');
  thisLineActionBtn = '<center><input type="checkbox" class="chkallrrline" name="" onclick="ERPLIST.alllineChooser(this);"></center>';
  $td.html(thisLineActionBtn);
  $td.appendTo($tr);

  if(compositeColumnsLength > 0){
    $.each(ERPLIST.compositeColumns, function(groupName, groupColumns){

      var compositeClass = '';
      $td = $('<td/>');
      $td.attr('class', groupName);
      $.each(groupColumns, function(fieldname, fieldpropties){

        compositeClass +=  ( !!fieldpropties.end) ? fieldname : fieldname + '__';          
        var customsearch_option = ( !!fieldpropties.showsearchimg) ?'<button type="button" onclick="ERPLIST.handleCustomSearch(this);"><img src="img/search_icon.png" alt="" height="15" width="15"></button>': '';
        var customsearch_click  = ( !!fieldpropties.customsearch) ?'onclick="ERPLIST.handleCustomSearch(this);"': 'onclick="ERPLIST.handleThisSearchInputFieldClick(this);"';
        var customsearch_class  = ( !!fieldpropties.customsearch ) ? '  hasCustomSearch' : '';

        var html = '<center><input type="text" name="'+ compositeClass +'" value="" id="'+compositeClass+'" class="'+compositeClass + customsearch_class +'" onclick="ERPLIST.handleCustomSearch(this);" />'+ customsearch_option +'</center><div id="'+compositeClass+'_displaySearchParams" style="background-color:white;"></div>';
        $td.html(html);

        // delete firstRowCopy[fieldname]; // its already procceed
        if(fieldpropties.composite == false) return;
        $td_hide = $('<td/>');
        $td_hide.html('<center><input type="hidden" class="'+ fieldname +'" value="" id="'+fieldname+'" /></center>');
        $td_hide.css('display','none');
        $td_hide.appendTo($tr);

      });
      if ( hideColumns.indexOf(groupName) >= 0 ) $td.css('display','none');
      $td.appendTo($tr);

    });
  }
  // end -----------------------------------------------------------------------------------------------------------------

  // precess rest of columns----------------------------------------------------------------------------------------------
  $.each(firstRowCopy, function (fieldname, fieldvalue) {    
    var fielddesc = fieldname;
    $td = $('<td/>');
    $td.attr('class', fieldname);
    $td.html('<center><input type="text"  name="'+ fieldname +'" class="'+ fieldname +'" value="" id="'+fieldname+'" onclick="ERPLIST.handleThisSearchInputFieldClick(this);" /></center><div id="'+fieldname+'_displaySearchParams" style="background-color:white;"></div>');
    if ( hideColumns.indexOf(fieldname) >= 0 ) $td.css('display','none');
    $td.appendTo($tr);
  });
  $tr.appendTo($thead);
  $thead.appendTo($table);
  // end -----------------------------------------------------------------------------------------------------------------
  /**
   * second header row end -----------------------------------------------------------------------------------------------------------------------------------------------------------
   */

  if(hasData == 'no'){
    $thead.appendTo($table);
    //custom for no record found
    var $tr = $("<tr/>");
    // var numberOfColumn = $("#listTable > thead > tr:first > th:visible").length;
    var $td = $('<td/>').attr("colspan",countVisibleColumn);
    $td.html('No Data Found')
      .css({'text-align':'center','vertical-align':'middle'});
    $td.appendTo($tr);
    $tr.appendTo($table);
    return $table;
  }

  /**
   * populates with data--------------------------------------------------------------------------------------------------------------------------------------------------
   */
  var mydata = JSON.parse(mydata_json);
  $.each(mydata, function (index, value) {
    var $tr = $("<tr/>"); // it should be in here
    $tr.attr("data-id",trDataId);
    trDataId++;

    var thisRow = value;
    var thisRowCopy = thisRow;
    var thisRowCopy_Json =  JSON.stringify(thisRow);

    var formtype = thisRow['formtype'];
    var linestatus = thisRow['linestatus'];
    var isrrfreezed = thisRow['isrrfreezed'];
    var recalculationbit = thisRow['recalculationbit'];
    var poformtype = thisRow['poformtype'];

    var idlines = thisRow['idlines'];
    // generate button if needed
    var thisLineActionBtn = '';
    if(isrrfreezed != '0'){
      if(!!ERPLIST.selectedLineInfo){
        if( ERPLIST.selectedLineInfo.idlines.indexOf(idlines) > -1 ){
          thisLineActionBtn = '<center><input type="checkbox" class="chkrrline" name="" onclick="ERPLIST.lineChooser(this);" checked></center>';
        }else{
          thisLineActionBtn = '<center><input type="checkbox" class="chkrrline" name="" onclick="ERPLIST.lineChooser(this);"></center>';
        }  
      }else{
        thisLineActionBtn = '<center><input type="checkbox" class="chkrrline" name="" onclick="ERPLIST.lineChooser(this);"></center>';
      }
      
    } else{
      if(!!ERPLIST.selectedLineInfo){
        if( ERPLIST.selectedLineInfo.idlines.indexOf(idlines) > -1 ){
          thisLineActionBtn = '<center><input type="checkbox" class="chkrrline" name="" onclick="ERPLIST.lineChooser(this);" checked></center>';
        }else{
          thisLineActionBtn = '<center><input type="checkbox" class="chkrrline" name="" onclick="ERPLIST.lineChooser(this);"></center>';
        }
      }else{
        thisLineActionBtn = '<center><input type="checkbox" class="chkrrline" name="" onclick="ERPLIST.lineChooser(this);"></center>';
      }
    }


    $td = $('<td/>');
    $td.html(thisLineActionBtn);
    $td.appendTo($tr);

    // process composite column first if has----------------------------------------------------------------------------------
    if(compositeColumnsLength > 0){
      $.each(ERPLIST.compositeColumns, function(groupName, groupColumns){
        $td = $('<td/>');
        $td.attr('class', groupName);
        $td.attr('fieldname', groupName);
        var compositeColumnsHTML = '';
        var divRow = '';
        $.each(groupColumns, function(fieldname, fieldprop){

          var fieldvalue = thisRow[fieldname];
          var fielddesc = (!!fieldprop.fielddesc) ? fieldprop.fielddesc : fieldname;
          var style = ( !!fieldprop.style ) ? 'style="' + fieldprop.style + '"': '';

          // *** write custom code here

          var obj_thisRowCopy_Json =  JSON.parse(thisRowCopy_Json);
          fieldvalue = (fieldname == "powonumber") ? "<a href='erpdocument.php?docnumber="+fieldvalue+"&doctype=PO&formtype="+formtype+"' target='_blank''>"+fieldvalue+"</a>" : fieldvalue;
          
          fieldvalue = (fieldname == "docnumber") ? "<a href='erpdocument.php?docnumber="+fieldvalue+"&doctype=PR&formtype="+formtype+"' target='_blank''>"+fieldvalue+"</a>" : fieldvalue;
          fieldvalue = (fieldname == "ponumber") ? "<a href='erpdocument.php?docnumber="+fieldvalue+"&doctype=PO&formtype="+poformtype+"' target='_blank''>"+fieldvalue+"</a>" : fieldvalue;
          if(fieldname == "podocdate" && fieldvalue == null) fieldvalue="";
          if(fieldname == "fabricinhousedate"){
           fieldvalue = ERPLIST.generateHTMLinHouse(thisRowCopy,fieldname, fieldvalue);
          }
          if(fieldname == "whlocation") fieldvalue = params.whlocation.replace(/\+/g, ' ');
          // *** custom code end

          divRow += '<div class="crow" '+ '' +'>';
          if( !!fieldprop.composite ){
            divRow += '<div class="ccell1 '+ fieldname +'" '+ style +'>'+ fielddesc +'</div>';
            divRow += '<div class="ccell2 '+ fieldname +'">:</div>';
          }
          divRow += '<div class="ccell3 '+ fieldname +'_ccell3" '+ style +'>'+ fieldvalue +'</div>';
          divRow += "</div>";

          delete thisRowCopy[fieldname]; // its already procceed
          if(fieldprop.composite == false) return;
          $td_hide = $('<td/>');
          $td_hide.html(fieldvalue);
          $td_hide.attr("fieldname",fieldname);
          $td_hide.css('display','none');
          $td_hide.appendTo($tr);

        });

        var divTable = "<div id='ctable'>"; 
        divTable += divRow;  
        divTable += "</div>"; 

        compositeColumnsHTML = divTable;
        $td.html(compositeColumnsHTML)
          .css("cursor","pointer")
          .hover(
               function(){bgOn = $(this).closest("tr").css("background-color"); $(this).closest("tr").css("background-color", "lightblue");},
               function(){$(this).closest("tr").css("background-color", bgOn);}
             );
        if ( hideColumns.indexOf(groupName) >= 0 ) $td.css('display','none');
        $td.appendTo($tr);

      });
    }
    // end -----------------------------------------------------------------------------------------------------------------

    // precess rest of columns----------------------------------------------------------------------------------------------
    $.each(thisRowCopy, function (fieldname, fieldvalue) {

      // *** write custom code here
      fieldvalue = (fieldname == "docnumber") ? "<a href='erpdocument.php?docnumber="+fieldvalue+"&doctype=PR&formtype="+formtype+"' target='_blank''>"+fieldvalue+"</a>" : fieldvalue;
      fieldvalue = (fieldname == "ponumber") ? "<a href='erpdocument.php?docnumber="+fieldvalue+"&doctype=PO&formtype="+poformtype+"' target='_blank''>"+fieldvalue+"</a>" : fieldvalue;
      if(fieldname == "fabricinhousedate"){
        fieldvalue = ERPLIST.generateHTMLinHouse(thisRowCopy,fieldname, fieldvalue);
      }
      if(fieldname == "whlocation") fieldvalue = params.whlocation.replace(/\+/g, ' ');

      // *** custom code end

      $td = $('<td/>');
        $td.html(fieldvalue)
          .css("white-space","pre-wrap")
          .attr("fieldname",fieldname)
          .attr("class",fieldname)
          .css("cursor","pointer")
          .hover(
               function(){bgOn = $(this).closest("tr").css("background-color"); $(this).closest("tr").css("background-color", "lightblue");},
               function(){$(this).closest("tr").css("background-color", bgOn);}
             );
        if ( hideColumns.indexOf(fieldname) >= 0 ) $td.css('display','none');
        $td.appendTo($tr);
    });


    // *** custom code start-----------------------------------------------------------------------------------------
    // $tr.find('td.requiredinformation').append(thisLineActionBtn);
    // *** custom code end-------------------------------------------------------------------------------------------

    if(linestatus == 'Complete'){
      $tr.css("background-color", "#FFFFCC");
    }else if(linestatus == 'Released'){
      $tr.css("background-color", "#AEF5D4");
    }

    $tr.click( function(e) { 
          
          if(orgBgOn != '') $('#listTable tbody tr.clicked').css("background-color", orgBgOn);
          $('#listTable tbody tr').removeClass('clicked');
          orgBgOn = bgOn;
          $(this).closest("tr").css("background-color", "yellow");
          bgOn = $(this).closest("tr").css("background-color")
          $(this).closest("tr").addClass('clicked');

          // var cell = $(e.target).get(0); // This is the TD you clicked
          var typex = $(e.target).attr('type'); 
          if(typex == 'checkbox') return; // LineChooser

          // var thisfieldname = $(this).closest('td').attr('fieldname');
          var thisfieldname = $(e.target).closest('td').attr('fieldname');
          console.log(thisfieldname);
          if(thisfieldname == 'orderqty' || thisfieldname == 'supplierlot' || thisfieldname == 'whlocation'){
              // $(e.target).closest('td').find('div span').attr('contenteditable', true); 
              // var xval = $(e.target).closest('td').find('div span.dbvalue').text(); 
              var xval = $(e.target).closest('td').text(); 
              // $(e.target).closest('td').find('div').find('input').remove(); 
              if($(e.target).closest('td').find('input').length > 0) return;
              if(thisfieldname == 'whlocation'){
                $(e.target).closest('td').html('<input id = "x'+ thisfieldname +'" type = "text" name = "x'+ thisfieldname +'" value= "'+ xval +'" onclick="ERPLIST.handleLookup(this);">'); 
              } else{
                $(e.target).closest('td').html('<input id = "x'+ thisfieldname +'" type = "text" name = "x'+ thisfieldname +'" value= "'+ xval +'">'); 
              }
              // $(e.target).closest('td').find('div span').css({
              //   height: '40px',
              //   width: '80px',
              //   display: 'block'
              // }); 
          }

          if(thisfieldname == 'manufacturingdate' || thisfieldname == 'expiredate'){
              var xval = $(e.target).closest('td').text(); 
              if($(e.target).closest('td').find('input').length > 0) return;
              $(e.target).closest('td').html('<input id = "x'+ thisfieldname +'" type = "text" class="datepicker" name = "x'+ thisfieldname +'" value= "'+ xval +'">'); 
              $('.datepicker').datetimepicker({ timepicker:false, format:'Y-m-d'});

          }

          if(ERPLIST.isEnableExcelMode) return;
          if(ERPLIST.lineEditEntryMode) return;

          if(thisfieldname == 'x-options' || thisfieldname == 'x-lineformactionbuttons') return;       
          if(thisfieldname == 'docnumber' || thisfieldname == 'docnumber') return;       

          var thisPtr = this;
          // ERPLIST.sendBackSearchChoice($(this));
          // ERPLIST.handleReadEntity(thisPtr);

        })
      .appendTo($tbody);
  });

  $thead.appendTo($table)
  $tbody.appendTo($table)

  return $table;
};





/**
* Custom table generate code------------------------------------------------------------------------------------------------------
*/










/**
* Custom function code------------------------------------------------------------------------------------------------------
*/
ERPLIST.showPlannedDateForm = function (thisbtn){
  $(thisbtn).parents('td').find('#formDiv').css({'display':'block'});
  $(thisbtn).parents('td').find('#btnDiv1').css({'display':'none'});
  $(thisbtn).parents('td').find('#btnDiv2').css({'display':'none'});
  jsClient.initDateTimePicker();
}

ERPLIST.setFabricInhouseDate = function(thisbtn, idlines){
  var fabricinhousedate = $(thisbtn).parents('td').find('#formDiv #fabricinhousedate').val();
  var rrnumber = $(thisbtn).closest('tr').find('td[fieldname=rrnumber]').text();
  
  //click checkbox for uncheck when set fabric inhouse date
  if($(thisbtn).closest('tr').find('td input.chkrrline').prop('checked')){
    $(thisbtn).closest('tr').find('td input.chkrrline').trigger('click');
  }
  
  var postData = JSON.stringify({idlines:idlines, fabricinhousedate:fabricinhousedate});
  var mType    = 'post';
  var mUrl     = ERPLIST._URL_API;
  var mReqType = "setFabricInhouseDate";
  var returnData = jsClient.communicationToServer(mReqType, postData, mUrl, mType, false);

  returnData = JSON.parse(returnData);
  if(returnData.result == 'success'){
    $(thisbtn).parents('td').find('#formDiv').css({'display':'none'});
    $(thisbtn).parents('td').find('#btnDiv1').css({'display':'none'});
    $(thisbtn).parents('td').find('#btnDiv2').css({'display':'block'});

    $(thisbtn).parents('td').find('#showInhouseDate').css({'display':'block'});
    $(thisbtn).parents('td').find('#showInhouseDate').find('span').text(fabricinhousedate);

    jsClient.msgDisplayer('success:: Successfully updated inhouse date '+rrnumber); // green
  }

}

ERPLIST.generateHTMLinHouse = function(thisRowCopy,fieldname, fieldvalue){
  var fabricinhousedate = fieldvalue;

  if(fieldvalue == "" || fieldvalue == null || fieldvalue == "0000-00-00"){
    var content = '<div id="formDiv" style="display:none;">'
    content += '<input type="text" class="datepicker" name="fabricinhousedate" value="" id="fabricinhousedate">';
    content += '<input type="button" value="Done" onclick="ERPLIST.setFabricInhouseDate(this ' +","+ '  \'' + thisRowCopy['idlines'] + '\')"/>';
    content += '</div>';

    var content2 = '<div id="btnDiv1">';
    content2 += '<input type="button" value="Enter In-house Date" onclick="ERPLIST.showPlannedDateForm(this)"/>';
    content2 += '</div>';

    var content3 = '<div id="btnDiv2" style="float:left;display:none;">';
    content3 += '<a href="javascript:void(0)" onclick="ERPLIST.showPlannedDateForm(this)"><img src="img/edit.png"></a>';
    content3 += '</div>';

    var content4 = '<div id="showInhouseDate" style="float:left;display:none;">';
    content4 += '<span>' +fabricinhousedate+ '</span>';
    content4 += '</div>';

    fieldvalue = content4;
    fieldvalue += content;
    fieldvalue += content2;
    fieldvalue += content3;
  }else{
    var content = '<div id="formDiv" style="display:none;">'
    content += '<input type="text" class="datepicker" name="fabricinhousedate" value="'+fabricinhousedate+'" id="fabricinhousedate">';
    content += '<input type="button" value="Done" onclick="ERPLIST.setFabricInhouseDate(this ' +","+ '  \'' + thisRowCopy['idlines'] + '\')"/>';
    content += '</div>';

    var content2 = '<div id="btnDiv2" style="float:left;">';
    content2 += '<a href="javascript:void(0)" onclick="ERPLIST.showPlannedDateForm(this)"><img src="img/edit.png"></a>';
    content2 += '</div>';

    var content3 = '<div id="showInhouseDate" style="float:left;">';
    content3 += '<span>' +fabricinhousedate+ '</span>';
    content3 += '</div>';

    fieldvalue = content3;
    fieldvalue += content;
    fieldvalue += content2;          
  }  

  return fieldvalue;
}

ERPLIST.alllineChooser = function(thisflag){
  if($(thisflag).prop('checked')){
    $('.chkrrline').each(function(){
      $(this).prop('checked', true);
      ERPLIST.lineChooser(this);
    });
  }else{
    $('.chkrrline').each(function(){
      $(this).prop('checked', false);
      ERPLIST.lineChooser(this);
    });
  }

}


ERPLIST.lineChooser = function(thisf){
  var thisrow = $(thisf).parent().parent().parent().index();
  
  var idlines = $(thisf).closest('tr').find('td[fieldname=idlines]').text();
  var linestatus = $(thisf).closest('tr').find('td[fieldname=linestatus]').text();
  var supplier = $(thisf).closest('tr').find('td[fieldname=suppliername]').text();
  var purchasemode = $(thisf).closest('tr').find('td[fieldname=purchasemode]').text();
  var currency = $(thisf).closest('tr').find('td[fieldname=currency]').text();
  var company = $(thisf).closest('tr').find('td[fieldname=company]').text();
  var ponumber = $(thisf).closest('tr').find('td[fieldname=ponumber]').text();
  var polinenumber = $(thisf).closest('tr').find('td[fieldname=polinenumber]').text();
  var doclinenumber = $(thisf).closest('tr').find('td[fieldname=doclinenumber]').text();

  var orderqty;

  if($(thisf).closest('tr').find('td[fieldname=orderqty]').find('input').length > 0){
    orderqty = $(thisf).closest('tr').find('td[fieldname=orderqty]').find('input').val();
  }else{
    orderqty = $(thisf).closest('tr').find('td[fieldname=orderqty]').text();
  }

  console.log(linestatus);
    // define array
    if(!!!ERPLIST.selectedLineInfo){
      ERPLIST.selectedLineInfo  = {};
      ERPLIST.selectedLineInfo.uniquekey = [];
      ERPLIST.selectedLineInfo.idlines = [];
      ERPLIST.selectedLineInfo.linestatus = [];
      ERPLIST.selectedLineInfo.supplier = [];
      ERPLIST.selectedLineInfo.purchasemode = [];
      ERPLIST.selectedLineInfo.currency = [];
      ERPLIST.selectedLineInfo.company = [];
      ERPLIST.selectedLineInfo.ponumber = [];
      ERPLIST.selectedLineInfo.polinenumber = [];
      ERPLIST.selectedLineInfo.doclinenumber = [];
      ERPLIST.selectedLineInfo.orderqty = [];
    } 


    if($(thisf).prop('checked')){
      $(thisf).prop('checked', true);

      // push data in array
      ERPLIST.selectedLineInfo.uniquekey.push(thisrow);
      ERPLIST.selectedLineInfo.idlines.push(idlines);
      ERPLIST.selectedLineInfo.supplier.push(supplier);
      ERPLIST.selectedLineInfo.linestatus.push(linestatus);
      ERPLIST.selectedLineInfo.purchasemode.push(purchasemode);
      ERPLIST.selectedLineInfo.currency.push(currency);
      ERPLIST.selectedLineInfo.company.push(company);
      ERPLIST.selectedLineInfo.ponumber.push(ponumber);
      ERPLIST.selectedLineInfo.polinenumber.push(polinenumber);
      ERPLIST.selectedLineInfo.doclinenumber.push(doclinenumber);
      ERPLIST.selectedLineInfo.orderqty.push(orderqty);

     // Check end customer, division and SO type... which need to be same

      var arrayLengthSupplier = ERPLIST.selectedLineInfo.supplier.length;
      var chkSupplier  = ERPLIST.selectedLineInfo.supplier[0];      

      var arrayLengthLinestatus = ERPLIST.selectedLineInfo.linestatus.length;
      var chkLinestatus  = ERPLIST.selectedLineInfo.linestatus[0];     

      var arrayLengthPurchasemode = ERPLIST.selectedLineInfo.purchasemode.length;
      var chkPurchasemode  = ERPLIST.selectedLineInfo.purchasemode[0];

      var arrayLengthCurrency = ERPLIST.selectedLineInfo.currency.length;
      var chkCurrency  = ERPLIST.selectedLineInfo.currency[0];

      var arrayLengthCompany = ERPLIST.selectedLineInfo.company.length;
      var chkCompany  = ERPLIST.selectedLineInfo.company[0];

      if(arrayLengthSupplier > 0 || arrayLengthLinestatus > 0 || arrayLengthPurchasemode > 0 || arrayLengthCurrency > 0 || arrayLengthCompany > 0){
        if(supplier != chkSupplier){
          alert("Supplier need to be same.");
          $(thisf).prop('checked', false);
          ERPLIST.popUncheckedValue(thisrow);

          return;
        }
        if(company != chkCompany){
          alert("Division need to be same.");
          $(thisf).prop('checked', false);
          ERPLIST.popUncheckedValue(thisrow);

          return;
        }
        if(linestatus != chkLinestatus && linestatus == 'Complete'){
          alert("Status Should be Complete");
          $(thisf).prop('checked', false);
          ERPLIST.popUncheckedValue(thisrow);

          return;
        }
        if(purchasemode != chkPurchasemode){
          alert("Purchase mode need to be same.");
          $(thisf).prop('checked', false);
          ERPLIST.popUncheckedValue(thisrow);

          return;
        }
        if(currency != chkCurrency){
          alert("Currency need to be same.");
          $(thisf).prop('checked', false);
          ERPLIST.popUncheckedValue(thisrow);

          return;
        }

      }

    } else {
      $(thisf).prop('checked', false);


      var index = ERPLIST.selectedLineInfo.uniquekey.indexOf(thisrow);

      // pop data in array
      ERPLIST.popUncheckedValue(thisrow);
    }

}

ERPLIST.popUncheckedValue = function(thisrow){
    var index = ERPLIST.selectedLineInfo.uniquekey.indexOf(thisrow);
    ERPLIST.selectedLineInfo.uniquekey.splice(index, 1);
    ERPLIST.selectedLineInfo.idlines.splice(index, 1);
    ERPLIST.selectedLineInfo.supplier.splice(index, 1);
    ERPLIST.selectedLineInfo.linestatus.splice(index, 1);
    ERPLIST.selectedLineInfo.purchasemode.splice(index, 1);
    ERPLIST.selectedLineInfo.currency.splice(index, 1);
    ERPLIST.selectedLineInfo.company.splice(index, 1);
    ERPLIST.selectedLineInfo.ponumber.splice(index, 1);
    ERPLIST.selectedLineInfo.polinenumber.splice(index, 1);
    ERPLIST.selectedLineInfo.doclinenumber.splice(index, 1);
    ERPLIST.selectedLineInfo.orderqty.splice(index, 1);
    console.log(JSON.stringify(ERPLIST.selectedLineInfo.idlines) + '---' + index);

}



ERPLIST.cancel = function(){
   if(!!!ERPLIST.selectedLineInfo || ERPLIST.selectedLineInfo.idlines.length == 0){
    alert('You need to select atleast one RR line');
    return;
  }

  var idlines = ERPLIST.selectedLineInfo.idlines;

  var r = confirm(ERPLIST.selectedLineInfo.rrnumbers + ' will be gone to Allocated RR list');
  if(!r) return;


  var mType    = 'post';
  var mUrl     = ERPLIST._URL_API;
  var mReqType = "sendtoAllocatedRR";
  var postData = JSON.stringify({
    idlines  : ERPLIST.selectedLineInfo.idlines 
  });
  var returnData = jsClient.communicationToServer(mReqType, postData, mUrl, mType, false);

  returnData = JSON.parse(returnData);
  console.log(returnData.result);

  if(returnData.result == 'success'){
    ERPLIST.getListData(10,   1);
    var msgString  = 'success:: Successfully '+ ERPLIST.selectedLineInfo.rrnumber +' lines cancel for PO creation.';
    jsClient.msgDisplayer(msgString); // green
    delete(ERPLIST.selectedLineInfo);
  }  


}


ERPLIST.createPO = function(){
  if(!!!ERPLIST.selectedLineInfo || ERPLIST.selectedLineInfo.idlines.length == 0){
    alert('You need to select atleast one Requisition line');
    return;
  }

  length = ERPLIST.selectedLineInfo.idlines.length;
  requisitionStatus = ERPLIST.selectedLineInfo.linestatus;
  for(i=0 ; i < length ; i++){
    //check rr status is po created 
    if(requisitionStatus[i] == 'Released' || requisitionStatus[i] == 'Entered'){
      alert('Can not create PO with the status Entered or Released.');
      return;
    }
  }

  //Start confirm dialog PopUp
  $('<div id="jQueryUIDialogDiv"></div>').dialog({
     width: 500,
      modal: true,
      title: "Confirmation for Creating PO",
      open: function () {
          var markup = '<table><tr><th></th><th>Yes</th><th>Not Required</th></tr>';
          markup += '<tr><td>Capex Approved</td><td><input type="checkbox" class="approvalChk radioCapex" id="" name="" onclick=""></td><td><input type="checkbox" class="approvalChk radioCapex" id="" name="" onclick=""></td></tr>';
          markup += '<tr><td>Requisition Approved</td><td><input type="checkbox" class="approvalChk radioRequisition" id="" name="" onclick=""></td><td><input type="checkbox" class="approvalChk radioRequisition" id="" name="" onclick=""></td></tr>';
          markup += '<tr><td>Quotation Approved</td><td><input type="checkbox" class="approvalChk radioQuotation" id="" name="" onclick=""></td><td><input type="checkbox" class="approvalChk radioQuotation" id="" name="" onclick=""></td></tr>';
          markup += '<tr><td>CS Approved</td><td><input type="checkbox" class="approvalChk radioCS" id="" name="" onclick=""></td><td><input type="checkbox" class="approvalChk radioCS" id="" name="" onclick=""></td></tr></table>';
          
          // var markup = '<table><tr><td><input type="checkbox" class="approvalChk" id="" name="" onclick=""></td><td>Capex Approved</td></tr>';
          // markup += '<tr><td><input type="checkbox" class="approvalChk" id="" name="" onclick=""></td><td>Requisition Approved</td></tr>';
          // markup += '<tr><td><input type="checkbox" class="approvalChk" id="" name="" onclick=""></td><td>Quotation Approved</td></tr>';
          // markup += '<tr><td><input type="checkbox" class="approvalChk" id="" name="" onclick=""></td><td>CS Approved</td></tr></table>';
          $(this).html(markup);
          ERPLIST.checkboxAsRadio();
      },
      buttons: {
          "Yes": function () {
              var allChk = 1;
              var count = 0;
              $('.approvalChk').each(function(){
                if($(this).is(":checked")){
                  count++;
                }else{
                  allChk = 0;
                }
              });

              console.log(count);

              if(count != 4){
                alert("All Condition must be checked else can not create PO.");
              }else{
                var next_href = '/erp-nonpo/erpdocument.php?doctype=PO&formtype=PO&idlines=' + ERPLIST.selectedLineInfo.idlines;
                window.location = next_href;
              }
              
          },
          No: function () {
              $(this).dialog("close");
          }
      }
  }); //end confirm dialog PopUp

  
}

ERPLIST.createGRN = function(){
  var params     = jsClient.paramsToObj(window.location.search);
  var challanno  = params.challanno; 
  var remarks  = params.remarks; 
  // var whlocation = params.whlocation; 
  // whlocation = whlocation.replace("+", " ");
  challanno = challanno.replace("+", " ");

  if(!!!ERPLIST.selectedLineInfo || ERPLIST.selectedLineInfo.idlines.length == 0){
    alert('You need to select atleast one Requisition line');
    return;
  }

  length = ERPLIST.selectedLineInfo.idlines.length;
  requisitionStatus = ERPLIST.selectedLineInfo.linestatus;
  for(i=0 ; i < length ; i++){
    //check rr status is po created 
    if(requisitionStatus[i] != 'Released'){
      alert('Only Released Requisition is allowed for create GRN');
      return;
    }
  }

  // var params     = paramsToObj(window.location.search);
  // var polinenumber  = (ERPLIST.selectedLineInfo.polinenumber).join();
  

  console.log(polinenumber);

    var lineObj = {};
    lineObj.orderqty = [];
    lineObj.polinenumber = [];
    lineObj.doclinenumber = [];
    lineObj.supplierlot = [];
    lineObj.whlocation = [];
    lineObj.manufacturingdate = [];
    lineObj.expiredate = [];

    var mandetoryExMan = false;



    $('#listDiv #listTable tbody tr').each(function(indx, thisTr){

      if ($(thisTr).find("td:nth-child(1)").find('input[type=checkbox]').prop('checked') == true){

        if($(thisTr).closest('tr').find('td[fieldname=orderqty]').find('input').length > 0){
          orderqty = $(thisTr).closest('tr').find('td[fieldname=orderqty]').find('input').val();

        }else{
          orderqty = $(thisTr).closest('tr').find('td[fieldname=orderqty]').text();
        }        

        if($(thisTr).closest('tr').find('td[fieldname=whlocation]').find('input').length > 0){
          whlocation = $(thisTr).closest('tr').find('td[fieldname=whlocation]').find('input').val();

        }else{
          whlocation = $(thisTr).closest('tr').find('td[fieldname=whlocation]').text();
        }

        supplierlot = $(thisTr).closest('tr').find('td[fieldname=supplierlot]').find('input').val();
        manufacturingdate = $(thisTr).closest('tr').find('td[fieldname=manufacturingdate]').find('input').val();
        expiredate = $(thisTr).closest('tr').find('td[fieldname=expiredate]').find('input').val();

        // console.log(typeof manufacturingdate);

        polinenumber = $(thisTr).closest('tr').find('td[fieldname=polinenumber]').text();
        doclinenumber = $(thisTr).closest('tr').find('td[fieldname=doclinenumber]').text();

        if(params.itemtype == 'CHE'){
          if(manufacturingdate == '' || typeof manufacturingdate === 'undefined'){
            alert("Manufacturing Date is Mandetory");
            mandetoryExMan = true;
            return;
          }
          if(expiredate == '' || typeof expiredate === 'undefined'){
            alert("Expire Date is Mandetory");
            mandetoryExMan = true;
            return;
          }

        }

        lineObj.orderqty.push(orderqty);    
        lineObj.polinenumber.push(polinenumber);    
        lineObj.doclinenumber.push(doclinenumber);    
        lineObj.supplierlot.push(supplierlot);    
        lineObj.whlocation.push(whlocation);    
        lineObj.manufacturingdate.push(manufacturingdate);    
        lineObj.expiredate.push(expiredate);    

      } 

    });

    if(mandetoryExMan == true){
      return;
    }

    var orderqty  = (lineObj.orderqty).join();
    var polinenumber  = (lineObj.polinenumber).join();
    var doclinenumber  = (lineObj.doclinenumber).join();

    var supplierlot  = (lineObj.supplierlot).join();
    var whlocation  = (lineObj.whlocation).join();
    var manufacturingdate  = (lineObj.manufacturingdate).join();
    var expiredate  = (lineObj.expiredate).join();


    if(params.itemtype == 'CHE'){
      var searchParams = {
        'reqType': 'rcvChemicalItem',
        'polinenumber': polinenumber,
        'tnxquantity': orderqty,
        'supplierlot': supplierlot,
        'manufacturingdate': manufacturingdate,
        'expiredate': expiredate,
        'challanno': challanno,
        'whlocation': whlocation,
        'TransactionDate': params.TransactionDate,
        'TransactionTime': params.TransactionTime
      };
    } else if(params.itemtype == 'NPO'){
      var searchParams = {
        'reqType': 'getPOLineInfo',
        'polinenumber': polinenumber,
        'tnxquantity': orderqty,
        'challanno': challanno,
        'whlocation': whlocation,
        'TransactionDate': params.TransactionDate,
        'TransactionTime': params.TransactionTime
      };
    } else if(params.itemtype == 'ELS' || params.itemtype == 'CTN'){
      var searchParams = {
        'reqType': 'rcvAccessoriesItem',
        'polinenumber': polinenumber,
        'doclinenumber': doclinenumber,
        'tnxquantity': orderqty,
        'challanno': challanno,
        'supplierlot': supplierlot,
        'whlocation': whlocation,
        'remarks': remarks,
        'TransactionDate': params.TransactionDate,
        'TransactionTime': params.TransactionTime
      };
    }
// console.log(searchParams);
// return;

  $.ajax({
  type: 'post',
  url: 'docnonpogrn_api.php',
  data: searchParams,
  success: function(returnData) {
    // if result is JSON, we're using the new API return format
    // console.log(data);
    // data = JSON.parse(data);
    // if (!!data.errormsgs && data.errormsgs.length > 0) {
    //   console.log(data.errormsgs.join('\n'));
    // } else {
    //   console.log(data);
    // } 

    console.log(returnData);



    var next_href = '/zerp04/pkg/whs/main.php?rAPIFile=zerp04/pkg/whs/NonPOStockTransaction&docnumber='+returnData;
    window.location = next_href; 
  }

  }).fail(function(e) {
    alert('Saving failed, please try again.');
  });

  // if(returnData.length>0){
  //  var next_href = '/zerp04/pkg/whs/main.php?rAPIFile=zerp04/pkg/whs/NonPOStockTransaction&docnumber='+returnData;
  //  window.location = next_href;
  // }
  
}


ERPLIST.checkboxAsRadio = function(){

  $(".radioCapex").change(function() {
    var checked = $(this).is(':checked');
    $(".radioCapex").prop('checked',false);
    if(checked) {
      $(this).prop('checked',true);
    }
  });

  $(".radioRequisition").change(function() {
    var checked = $(this).is(':checked');
    $(".radioRequisition").prop('checked',false);
    if(checked) {
        $(this).prop('checked',true);
    }
  });

  $(".radioQuotation").change(function() {
    var checked = $(this).is(':checked');
    $(".radioQuotation").prop('checked',false);
    if(checked) {
        $(this).prop('checked',true);
    }
  });

  $(".radioCS").change(function() {
    var checked = $(this).is(':checked');
    $(".radioCS").prop('checked',false);
    if(checked) {
        $(this).prop('checked',true);
    }
  });

}

ERPLIST.getAutoCompleteInfo = function(){
  var searchParams = {
    'reqType': 'getProcurer'
  };

  var mType = 'get';
  var mUrl     = "receiving-transaction-creation_api.php";
  var mReqType = "";

  var returnData = jsClient.communicationToServer(mReqType, searchParams, mUrl, mType, false);

  console.log(returnData);
   if (returnData.length > 0) {

    data = JSON.parse(returnData);
   

    var purchasemodeTags = JSON.parse(data['purchasemode']);


    $( ".modal_procurer" ).autocomplete({
      source: purchasemodeTags
    });

   }

}


ERPLIST.setProcurer = function(){
  if(!!!ERPLIST.selectedLineInfo || ERPLIST.selectedLineInfo.idlines.length == 0){
    alert('You need to select atleast one Requisition line');
    return;
  }

  length = ERPLIST.selectedLineInfo.idlines.length;
  requisitionStatus = ERPLIST.selectedLineInfo.linestatus;
  for(i=0 ; i < length ; i++){
    //check rr status is po created 
    if(requisitionStatus[i] == 'Released'){
      alert('PO has already been created.');
      return;
    }
  }

  //Start confirm dialog PopUp
  $('<div id="jQueryUIDialogDiv"></div>').dialog({
     width: 500,
      modal: true,
      title: "Set Procurer",
      open: function () {
          var markup = '<table class="no_border"><tr><td>Procurer :</td><td><input type="text" id="modal_procurer" name="" class="modal_procurer" onclick="ERPLIST.getAutoCompleteInfo();"></td></tr></table>';
          $(this).html(markup);

          // ERPLIST.getAutoCompleteInfo();
      },
      buttons: {
          "Yes": function () {
              ERPLIST.assignProcurerName(this);
              $(this).dialog("close");
              
          },
          No: function () {
              $(this).dialog("close");
          }
      }
  }); //end confirm dialog PopUp



  
}



ERPLIST.assignProcurerName = function(thismodal) {
  var selectedRRLines = ERPLIST.selectedLineInfo;
  var idlines = selectedRRLines.idlines;
  var procurer = $(thismodal).find('table input#modal_procurer').val();


  var postData = {
    reqType: 'setProcurer',
    idlines: JSON.stringify(idlines),
    procurer: procurer
  };

  console.log(postData);


  $.ajax({
    type: 'post',
    url: 'receiving-transaction-creation_api.php',
    data: postData,
    success: function(data) {
        // data = JSON.parse(data);
        // if (!!data.errormsgs && data.errormsgs.length > 0) {
          
        // } else {
        //   ERPLIST.getListData(100,    1);
        // }
        delete(ERPLIST.selectedLineInfo);
        ERPLIST.getListData(100,    1);
    }
  }).fail(function(e) {
    alert('Assign failed, please try again.');
  });

}


ERPLIST.handleLookup = function(thisPtr){
  var fieldname = $(thisPtr).closest('.listTable tr td').find('input, select').prop('name');
  var thisrow = $(thisPtr).closest('tr').attr('data-id');
  ERPLIST.dataid = thisrow;
  var fieldname = fieldname.replace('x','');
  ERPLIST.showLoupeList(fieldname);
}

ERPLIST.showLoupeList =function(targetfieldname){
  // var params = paramsToObj(window.location.search);
  console.log(targetfieldname);

   var prepopulate = {};
   ERPLIST.targetfieldname = targetfieldname;
  
  if($('#docHeaderContainer #tbl_2 tbody tr').find('[fieldname=endcustomer]').text().length > 0){
    // prepopulate.endcustomer = $('#docHeaderContainer #tbl_2 tbody tr').find('[fieldname=endcustomer]').text(); 
  }  

  prepopulate.fieldname = targetfieldname;

  var prepopJS = (Object.keys(prepopulate).length > 0) ? 'var prepopulate = ' + JSON.stringify(prepopulate) + ';' : '';
  prepopJS = prepopJS + "var ERPLIST = ERPLIST || {};";
  prepopJS = prepopJS + "$(document).ajaxStop(function() {";

  prepopJS = prepopJS + "ERPLIST.sendBackSearchChoice = function( thisRow ) {";
  prepopJS = prepopJS + "  CODE = $(thisRow).find('td[fieldname=CODE]').text();";
  prepopJS = prepopJS + "  $.fancybox.close();";
  prepopJS = prepopJS + "  $('.listTable').find('tr[data-id='+ERPLIST.dataid+']').find('td input#xwhlocation').val(CODE);";
  // prepopJS = prepopJS + "  $('.receivingtransactioncreator tr #' + ERPLIST.targetfieldname).focus();";
  prepopJS = prepopJS + "};";  
  prepopJS = prepopJS + "});";

  var content = '<div id="popupListContent">\
    <div id="loadingDiv">\
      <center><img src="/images/loading_spinner.gif"></center>\
    </div>\
  </div>';
  content+= '<script> ' + prepopJS + '</script>'; // add some js

  $.fancybox({
    type: 'html',
    content: content,
    minWidth: 500,
    minHeight: 300,
    afterLoad: function(){
      this.title = "<b>Choose " + prepopulate.fieldname + "</b>";
    },    
    afterShow: function() {
      loadSessionContent();
      $.fancybox.update();
    },
    helpers: {
     title : {
      type : 'inside',
      position : 'top'
     },
     overlay : {
      css  : { /* 'background-color' : '#fff' */}
     }     
    }  
  });
  jQuery('.fancybox-title').css({'text-align':'center', 'margin-bottom':'10px'});

  function loadSessionContent(){
    $.ajax({
      async: false,
      type: 'get',
      url: 'nonposhowloupelist.php',
      success: function(htmlContent) {
        $('#popupListContent').empty().append(htmlContent);
        var searchParams = (Object.keys(prepopulate).length > 0) ? prepopulate : {};
        //                  show,   page,   api_url
        ERPLIST.getListData(20,   1,    ERPLIST._URL_API, searchParams);
        ERPLIST.updateFancyBox();
      }
    }).fail(function(e) {
      alert('Loading failed, please try again.');
    });
  }
}

ERPLIST.updateFancyBox = function(){
  $(document).ajaxStop(function() {
    // place code to be executed on completion of 
    // last outstanding ajax call here
    // this is needed// because ajax call is asyncronus
    $.fancybox.update(); 
  });
}














ERPLIST.actionButton = function(){
  var cloneDiv = $('#listSuccessDiv').clone();
  cloneDiv.css({'display':'block'})
      .insertBefore('#listSuccessDiv')
      .find('#listSuccessMsg').text('this is success');

  var cloneDiv = $('#listWarningDiv').clone();
  cloneDiv.css({'display':'block'})
      .insertBefore('#listWarningDiv')
      .find('#listWarningMsg').text('this is warning');

  var cloneDiv = $('#listErrorDiv').clone();
  cloneDiv.css({'display':'block'})
      .insertBefore('#listErrorDiv')
      .find('#listErrorMsg').text('this is error');
}

ERPLIST.initLibFieldsForSearch = function(){
  ERPLIST.libraryColumns = {
    //   linestatus:{
    //     style: 'font-weight:bold; color:green',
    //     customsearch: true,
    //     islibrary: true,
    //     datasource: {
    //         0: 'Entered',
    //         1: 'Running',
    //         2: 'Closed'
    //      },        
    //     fielddesc: 'Line Status',
    //     showsearchimg: true,
    // },
    company: {
      fielddesc: 'Company',
      sql: "SELECT Code AS code, Description AS description FROM mrd_library WHERE LibraryName='company'",
    },
    customer: {
      fielddesc: 'Customer',
      islibrary: true,
      sql: "SELECT Code AS code, Description AS description FROM mrd_library WHERE LibraryName='Buyer'", 
    },
    endcustomer: {
      fielddesc: 'End Customer',
      islibrary: true,
      sql: "SELECT Code AS code, Description AS description FROM mrd_library WHERE LibraryName='Buyer'", 
    },    
  };  
  return ERPLIST.libraryColumns;
}