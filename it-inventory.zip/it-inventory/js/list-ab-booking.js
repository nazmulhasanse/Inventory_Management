/**
 * Declare ERPLIST Namespace if not exist
 */
var ERPLIST = ERPLIST || {};

$.extend(ERPLIST, {
  mUrl: 'api/server_api.php',
  mType: 'get',
  mData: '',
  mAsync: false,
  mReqType: '',
  queryData: '',
  queryParam: '',
  _searchParams: '',
  _URL_API: 'list-ab-booking_api.php',

  foo: 'here for no reason other than to be the last line, without a comma'
});



ERPLIST.displayQueryData = function(jsonData){

  var pagination = jsClient.makePagination(jsonData)

  var data = JSON.parse(jsonData);
  var hasData = (data.noResult) ? 'no' : 'yes';
  var listTable = ERPLIST.makeTable(jsonData, hasData);

  $("#listDiv").html(pagination);
  $("#listDiv").append(listTable);

  ERPLIST.initSearchAction();


  /**
   * Css
   */
  $('#listTable').css({
    'width':'100%'
  });
  $('#listTable tr#searchForm button').css({
    'padding':'2px',
    'border':'1px solid #7F7F7F',
    'border-radius':'3px',
    'vertical-align': 'middle'
  });  
  $('#listTable .hasCustomSearch').css({
    'width':'70%'
  });
  jsClient.paginationCSS();
  ERPLIST.applyCustomListCSS();
  ERPLIST.changeTempleteCSS();
  ERPLIST.getHeaderData();

}






















ERPLIST.applyCustomListCSS = function(){
  $('#listTable tr#searchForm input').css({
    'width':'95%',
    'min-width': '100px',
    'font-family':'Arial',
    'padding':'2px',
    'border':'1px solid #7F7F7F',
    'border-radius':'3px'
  });
  // Custom CSS if required
  $('#listTable td.lineentrytime').css({
    'white-space':'nowrap'
  }); 
}

ERPLIST.makeTable = function(jsonData,hasData) {

  var data      = JSON.parse(jsonData);
  var mydata    = data['listData'];
  var pageNum   = parseInt(data['pageNum']-1);
  var showLimit = parseInt(data['showLimit']);
  var trDataId  = parseInt(pageNum * showLimit) + 1;


  //for composition column
  ERPLIST.compositeColumns = {
    shipmentdate: {
      shipmentdate:{
        fielddesc: 'Goods Ready date',
        customsearch: true,
        type: 'date',
        single: true,
        end: true        
      }    
    },
    exfactorydate: {
      exfactorydate:{
        fielddesc: 'Ex-factory Date',
        customsearch: true,
        type: 'date',
        single: true,
        end: true        
      }    
    }
  }

  // some trickery for nice formatting
  var hideColumns = ['idlines', 'docnumber', 'entitynumber', 'endcustomer', 'bookingformid', 'doctype', 'idsodeliverylines'];

  var translationsHardCode = {};
  translationsHardCode.iduom                     = 'UoM';
  translationsHardCode.season                    = 'Season';
  translationsHardCode.followupnumber            = 'Follow Up Serial';
  translationsHardCode.entitynumber              = 'BOM No.';
  translationsHardCode.doclinenumber             = 'BOM Line No.';
  translationsHardCode.avgunitpriceperpack       = 'Avg Unit Price Per Pack';
  translationsHardCode.destination               = 'Destination';
  translationsHardCode.currency                  = 'Currency';
  translationsHardCode.setorder                  = 'Setorder';
  translationsHardCode.referencetype             = 'Reference Type';
  translationsHardCode.referenceno               = 'Reference No';
  translationsHardCode.productcategory           = 'Product Category';
  translationsHardCode.elementuom                = 'Elem. UoM';
  translationsHardCode.docstatus                 = 'Document Status';
  translationsHardCode.documentinformation       = 'Document Information';
  translationsHardCode.itemspecification         = 'Item Specification';
  translationsHardCode.docnumber                 = 'Sales Order No.';
  translationsHardCode.idsodeliverylines         = 'Sales Order Delivery Line ID';
  translationsHardCode.subdoclinenumber          = 'Delivery Line No.';
  translationsHardCode.buyerpo                   = 'End Customer PO No.';
  translationsHardCode.shipmentdate              = 'Goods Ready Date';
  translationsHardCode.exfactorydate             = 'Ex-factory Date';
  translationsHardCode.pieceqty                  = 'Piece Qty';
  translationsHardCode.packqty                   = 'Pack Qty';
  translationsHardCode.pieceperpack              = 'Piece Per Pack';
  translationsHardCode.balanceqty                = 'Balance Qty';
  translationsHardCode.shipmentqty               = 'Shipment Qty';
  translationsHardCode.customer                  = 'Customer';
  translationsHardCode.endcustomer               = 'End Customer';
  translationsHardCode.style                     = 'Style No.';
  translationsHardCode.styledescription          = 'Style Description';
  translationsHardCode.company                   = 'Division';
  translationsHardCode.formtype                  = 'Sales Order Type';
  translationsHardCode.ldcslnumber               = 'Sales Order Item Line No.';
  
  translationsHardCode.NominatedSupplier         = 'Nominated Supplier';
  translationsHardCode.Consumption               = 'Consumption Per Dozen';
  translationsHardCode.UOM                       = 'UOM';
  translationsHardCode.note                      = 'Note';
  translationsHardCode.ProcessLoss               = 'Process Loss (%)';
  translationsHardCode.Size                      = 'Garment Size';
  translationsHardCode.Color                     = 'Item Color';
  translationsHardCode.itemdescription           = 'Item Description';
  translationsHardCode.ConsumptionEntryTime      = 'Consumption Entry Time';
  translationsHardCode.GarmentQty_Dzn            = 'Garment Qty (Dzn)';
  translationsHardCode.GarmentQtyEntryTime       = 'Garment Qty Entry Time';
  translationsHardCode.GarmentQtyChangeRate      = 'Garment Qty Change Rate';
  translationsHardCode.ReqQty                    = 'Garment Quantity in Pcs';
  translationsHardCode.ReadyForBooking           = 'Ready For Booking';
  translationsHardCode.RFB_Time                  = 'RFB_Time';
  translationsHardCode.BookingApproval           = 'Booking Approval';
  translationsHardCode.BATime                    = 'BA Time';
  translationsHardCode.MaterialRemarks           = 'Material Remarks';
  translationsHardCode.RowTester                 = 'Row Tester';
  translationsHardCode.ExpectedInHouseDate       = 'Expected InHouse Date';
  translationsHardCode.ExpectedInHouseChangeRate = 'Expected InHouse Change Rate';
  translationsHardCode.FinalConsumption          = 'Final Consumption';
  translationsHardCode.FinalProcessLoss          = 'Final Process Loss';
  translationsHardCode.FinalGarmentQty_Dzn       = 'Final Garment Qty (Dzn)';
  translationsHardCode.FinalExpectedInHouseDate  = 'Final Expected InHouse Date';
  translationsHardCode.FinalReqQty               = 'Total Required Gross  Qty';
  
  translationsHardCode.countername               = 'Counter Name';
  translationsHardCode.idcounter                 = 'ID Counter';
  translationsHardCode.buyername                 = 'End Customer';
  translationsHardCode.company                   = 'Division';
  translationsHardCode.outputperlineperday       = 'Output per line per day';
  translationsHardCode.ExpectedInHouseDate       = 'Expected Inhouse Date';
  translationsHardCode.actualinhousedate         = 'Actual Inhouse Date';
  translationsHardCode.actualinhouseqty          = 'Actual Inhouse Qty';
  translationsHardCode.followupcomments          = 'Comments';
  translationsHardCode.accessqty                 = 'Short or Excess Qty';
  translationsHardCode.bookingnumber             = 'Booking Serial No.';
  translationsHardCode.isbookingsent             = 'Booking Sent';
  translationsHardCode.bookingdate               = 'Booking Date';
  translationsHardCode.bookingqty                = 'Booking Qty';
  translationsHardCode.allocationplan            = 'Allocation Plan by Merchandiser';
  translationsHardCode.procurementeta            = 'ETA by Procurement';
  translationsHardCode.masterreference           = 'Master Ref#';
  translationsHardCode.bookingcomment            = 'Booking Comments';
  translationsHardCode.bookingformid             = 'Booking ID';
  translationsHardCode.TraceID                   = 'Trace ID';
  translationsHardCode.ItemName                  = 'Item Name';
  translationsHardCode.GarmentDesignOrColor      = 'Garment Design Or Color';
  translationsHardCode.ProcessLevel              = 'Process Level';
  translationsHardCode.subdoclinenumber          = 'Sales Order Delivery Line No.';
  translationsHardCode.docdate                   = 'Doc Date';
  translationsHardCode.elementuom                = 'Elem. UoM';
  translationsHardCode.documentinformation       = 'Document Information';
  translationsHardCode.itemspecification         = 'Item Specification';
  
  translationsHardCode.linestatus__company__docdate  = 'Document Information';

  ERPLIST.translationsHardCode = translationsHardCode;


  /**
   * builds the table header
   */
  var mydata_json = JSON.stringify(mydata);
  var firstRow = mydata[0];

  var firstRowCopy = firstRow;
  var compositeColumnsLength = Object.keys(ERPLIST.compositeColumns).length;
  var countVisibleColumn = 1; // here start from 1 cz first td for option


  var $table = $('<table border=1 id="listTable" class="listTable" />');
  var $thead = $('<thead />');
  var $tbody = $('<tbody/>');
  /**
  * first header row------------------------------------------------------------------------------------------------------------------------------------------------------------
  */


/*--------hard code for extra table head-------------- start -------------------*/
  var $tr = $("<tr/>");
  $td = $('<th/>');
  $td.appendTo($tr);
  $td = $('<th colspan="19"/>');
  $td.html('<center style="background-color:powderblue;"><b>Accessories BOM Information</b></center>');
  $td.appendTo($tr);

  $td = $('<th colspan="8"/>');
  $td.html('<center style="background-color:pink;"><b>Booking Information</b></center>');
  $td.appendTo($tr);

  $td = $('<th colspan="6"/>');
  $td.html('<center style="background-color:yellow;"><b>Booking Follow Up</b></center>');
  $td.appendTo($tr);

  $tr.appendTo($thead);
  $thead.appendTo($table);
  /*-------------- end -------------------*/




  // var $tr = ERPLIST.generateFirstHeaderTr(firstRowCopy, translationsHardCode);
  var $tr = $("<tr/>");
  $td = $('<th/>');
  $td.html('');
  $td.appendTo($tr);

    $.each(firstRowCopy, function (fieldname, fieldvalue) {
    // for (var fieldname in firstRowCopy) {
      // var fieldvalue = firstRowCopy[fieldname];
      
      // search this field is in composite column
      // and assume that its not under in composite colums
      var groupName = '';
      var groupFields = {};
      var hasInCompositeColumn = false;
      if(compositeColumnsLength > 0){
        for (var groupName in ERPLIST.compositeColumns) {
          groupFields = ERPLIST.compositeColumns[groupName];
          for (var thisfieldname in groupFields) {
            if(thisfieldname == fieldname){
              hasInCompositeColumn = true;
              break;
            }
          }
          if(hasInCompositeColumn) break;
        }
      }

      // if have then procceed composite column
      if (hasInCompositeColumn) {
      // hide first
      $.each(groupFields, function(fieldname, fieldStyle){
        var fielddesc = fieldname;
        $td = $('<th/>');
        if (!!translationsHardCode[fieldname]) fielddesc = translationsHardCode[fieldname];
        $td.html('<center>'+ fielddesc +'</center>');
        $td.css('display','none');
        $td.appendTo($tr);

        delete firstRowCopy[fieldname]; // its already procceed
      });

      $td = $('<th/>');
      $td.attr('class', groupName);
      if (!!translationsHardCode[groupName]) groupName = translationsHardCode[groupName];
      $td.html('<center>'+ groupName +'</center>');
      $td.appendTo($tr);
      countVisibleColumn++;

      } else {

      countVisibleColumn++;
      var fielddesc = fieldname;
      $td = $('<th/>');
      if (!!translationsHardCode[fieldname]) fielddesc = translationsHardCode[fieldname];
      $td.html('<center>'+ fielddesc +'</center>');
      if ( hideColumns.indexOf(fieldname) >= 0 ){ $td.css('display','none'); countVisibleColumn--};
      $td.appendTo($tr);

      }

    // }  
    });
  $tr.appendTo($thead);
  $thead.appendTo($table);
  // end -----------------------------------------------------------------------------------------------------------------


  /**
  * second header row-----------------------------------------------------------------------------------------------------------------------------------------------------------
  */
  var $tr = $("<tr/>").attr("id","searchForm");
  var $td;
  $td = $('<td/>');
  $td.html('<center>Option</center>');
  $td.appendTo($tr);

  var firstRowCopy = JSON.parse(mydata_json)[0];
    $.each(firstRowCopy, function (fieldname, fieldvalue) {
    // for (var fieldname in firstRowCopy) {
      // var fieldvalue = firstRowCopy[fieldname];
      
      // search this field is in composite column
      // and assume that its not under in composite colums
      var groupName = '';
      var groupFields = {};
      var hasInCompositeColumn = false;
      if(compositeColumnsLength > 0){
        for (var groupName in ERPLIST.compositeColumns) {
          groupFields = ERPLIST.compositeColumns[groupName];
          for (var thisfieldname in groupFields) {
            if(thisfieldname == fieldname){
              hasInCompositeColumn = true;
              break;
            }
          }
          if(hasInCompositeColumn) break;
        }
      }

      // if have then procceed composite column
      if (hasInCompositeColumn) {   
      var compositeClass = '';
      $td = $('<td/>');
      $td.attr('class', groupName);
      $.each(groupFields, function(fieldname, fieldpropties){

        compositeClass +=  ( !!fieldpropties.end) ? fieldname : fieldname + '__';          
        var customsearch_option = ( !!fieldpropties.showsearchimg) ?'<button type="button" onclick="ERPLIST.handleCustomSearch(this);"><img src="img/search_icon.png" alt="" height="15" width="15"></button>': '';
        var customsearch_click  = ( !!fieldpropties.customsearch) ?'onclick="ERPLIST.handleCustomSearch(this);"': 'onclick="ERPLIST.handleThisSearchInputFieldClick(this);"';
        var customsearch_class  = ( !!fieldpropties.customsearch ) ? '  hasCustomSearch' : '';

        var html = '<center><input type="text" name="'+ compositeClass +'" value="" id="'+compositeClass+'" class="'+compositeClass + customsearch_class +'" '+ customsearch_click +' />'+ customsearch_option +'</center><div id="'+compositeClass+'_displaySearchParams" style="background-color:white;"></div>';
        $td.html(html);

        delete firstRowCopy[fieldname]; // its already procceed
        if(!!fieldpropties.single && fieldpropties.single == true) return; // need to make one td in list
        $td_hide = $('<td/>');
        $td_hide.html('<center><input type="hidden" class="'+ fieldname +'" value="" id="'+fieldname+'" /></center>');
        $td_hide.css('display','none');
        $td_hide.appendTo($tr);

      });
      $td.appendTo($tr);    

      } else {

      var fielddesc = fieldname;
      $td = $('<td/>');
      $td.attr('class', fieldname);
      $td.html('<center><input type="text"  name="'+ fieldname +'" class="'+ fieldname +'" value="" id="'+fieldname+'" onclick="ERPLIST.handleThisSearchInputFieldClick(this);" /></center><div id="'+fieldname+'_displaySearchParams" style="background-color:white;"></div>');
      if ( hideColumns.indexOf(fieldname) >= 0 ) $td.css('display','none');
      $td.appendTo($tr);

      }

    // }  
    });

  $tr.appendTo($thead);
  $thead.appendTo($table);
  /**
  * second header row end -----------------------------------------------------------------------------------------------------------------------------------------------------------
  */


  if(hasData == 'no'){
    $thead.appendTo($table);
    //custom for no record found
    var $tr = $("<tr/>");
    var $td = $('<td/>').attr("colspan",countVisibleColumn);
    $td.html('No Data Found')
    .css({'text-align':'center','vertical-align':'middle'});
    $td.appendTo($tr);
    $tr.appendTo($table);
    return $table;
  }


  /**
  * populates with data--------------------------------------------------------------------------------------------------------------------------------------------------
  */
  var mydata = JSON.parse(mydata_json);
  $.each(mydata, function (index, value) {

    var $tr = $("<tr/>"); // it should be in here
    $tr.attr("data-id",trDataId);
    trDataId++;

    var thisRow = value;
    var thisRowCopy = thisRow;
    var thisRowCopy_Json =  JSON.stringify(thisRow);

    // retrive variable here which is needed
    var formtype = thisRow['formtype'];
    var linestatus = thisRow['linestatus'];

    // generate button if needed
    var btnLineChooser = '<center><input type="checkbox" class="multipleLineChooser" onclick="ERPLIST.handleLineChooserCheckboxClick(this);" ></center>';
    var btnThisLineAction = '';
    if(linestatus == 'Requisition Sent'){
      btnThisLineAction = '<button type="button" class="mbutton delete" onclick="ERPLIST.handleLineEvolutionBtnAction(this)">Cancel this line</button>';
    } else if(linestatus == 'Requisition Planned'){
      btnThisLineAction = '';
    }
    $td = $('<td/>');
    $td.html(btnLineChooser);
    $td.appendTo($tr);


      // looping over this row
      $.each(thisRow, function (fieldname, fieldvalue) {
      // for (var fieldname in firstRowCopy) {
        // var fieldvalue = firstRowCopy[fieldname];
        
        // search this field is in composite column
        // and assume that its not under in composite colums
        var groupName = '';
        var groupFields = {};
        var hasInCompositeColumn = false;
        if(compositeColumnsLength > 0){
          for (var groupName in ERPLIST.compositeColumns) {
            groupFields = ERPLIST.compositeColumns[groupName];
            for (var thisfieldname in groupFields) {
              if(thisfieldname == fieldname){
                hasInCompositeColumn = true;
                break;
              }
            }
            if(hasInCompositeColumn) break;
          }
        }

        // if have then procceed composite column
        if (hasInCompositeColumn) {

        $td = $('<td/>');
        $td.attr('class', groupName);
        $td.attr('fieldname', groupName);
        var compositeColumnsHTML = '';
        var divRow = '';
        $.each(groupFields, function(fieldname, fieldpropties){

          var fieldvalue = thisRow[fieldname];
          var fielddesc = (!!fieldpropties.fielddesc) ? fieldpropties.fielddesc : fieldname;
          var style = ( !!fieldpropties.style ) ? 'style="' + fieldpropties.style + '"': '';

          // *** write custom code here ---

          var obj_thisRowCopy_Json =  JSON.parse(thisRowCopy_Json);
          fieldvalue = (fieldname == "docnumber") ? "<a href='erpdocument.php?docnumber="+fieldvalue+"&doctype=SO&formtype="+formtype+"' target='_blank'>"+fieldvalue+"</a>" : fieldvalue;

          // *** custom code end ----------

          divRow += '<div class="crow" '+ '' +'>';
          if( (!!!fieldpropties.single) || (!!fieldpropties.single && fieldpropties.single == false) ){
            divRow += '<div class="ccell1 '+ fieldname +'" '+ style +'>'+ fielddesc +'</div>';
            divRow += '<div class="ccell2 '+ fieldname +'">:</div>';
          }
          divRow += '<div class="ccell3 '+ fieldname +'_ccell3" '+ style +'>'+ fieldvalue +'</div>';
          divRow += "</div>";

          delete thisRowCopy[fieldname]; // its already procceed
          if(!!fieldpropties.single && fieldpropties.single == true) return; // need to make one td in list
          $td_hide = $('<td/>');
          $td_hide.html(fieldvalue);
          $td_hide.attr("fieldname",fieldname);
          $td_hide.css('display','none');
          $td_hide.appendTo($tr);

        });

        var divTable = "<div id='ctable'>"; 
        divTable += divRow;  
        divTable += "</div>"; 

        compositeColumnsHTML = divTable;
        $td.html(compositeColumnsHTML)
        .css("cursor","pointer")
        .hover(
          function(){bgOn = $(this).closest("tr").css("background-color"); $(this).closest("tr").css("background-color", "lightblue");},
          function(){$(this).closest("tr").css("background-color", bgOn);}
        );
        $td.appendTo($tr);


        } else {

        // *** write custom code here ---
        fieldvalue = (fieldname == "docnumber") ? "<a href='erpdocument.php?docnumber="+fieldvalue+"&doctype=SO&formtype="+formtype+"&docviewflag=apparel' target='_blank'>"+fieldvalue+"</a>" : fieldvalue;
        // *** custom code end ----------

        $td = $('<td/>');
        $td.html(fieldvalue)
        .css("white-space","pre-wrap")
        .attr("fieldname",fieldname)
        .css("cursor","pointer")
        .hover(
          function(){bgOn = $(this).closest("tr").css("background-color"); $(this).closest("tr").css("background-color", "lightblue");},
          function(){$(this).closest("tr").css("background-color", bgOn);}
        );
        if ( hideColumns.indexOf(fieldname) >= 0 ) $td.css('display','none');
        $td.appendTo($tr);

        }

      // }  
      });

    // *** custom code start-----------------------------------------------------------------------------------------
    // $tr.find('td.requiredinformation').append(btnThisLineAction);
    // *** custom code end-------------------------------------------------------------------------------------------

      $tr.click( function() { 
          ERPLIST.sendBackSearchChoice($(this));
        })
        .appendTo($tbody);
    });

    $thead.appendTo($table)
    $tbody.appendTo($table)

    return $table;
};



/**
* Custom function code------------------------------------------------------------------------------------------------------
*/
ERPLIST.customFunction = function(argument) {
}




ERPLIST.redrawList = function(){
  var pagenum = $('#pagination').find('span.current').text();
      var lineperpage = $('#divRowLimit').find('select[name=show]').val();
      if(!!!pagenum) pagenum=1;
      if(!!!lineperpage) lineperpage=50;
  ERPLIST.getListData( lineperpage, pagenum );

  delete ERPLIST.selectedLineInfo;

}



ERPLIST.sendBackSearchChoice = function(thisRow){
  // var entitynumber = $(thisRow).find('td[fieldname=entitynumber]').text();
  // alert(entitynumber);
}




ERPLIST.handleLineChooserCheckboxClick = function(thisf){
  var thisrow = $(thisf).closest('tr').attr('data-id');
  console.log(thisrow);
  var doclinenumber = $(thisf).closest('tr').find('td[fieldname=doclinenumber]').text();

  var bookingnumber = $(thisf).closest('tr').find('td[fieldname=bookingnumber]').text();
  var followupnumber = $(thisf).closest('tr').find('td[fieldname=followupnumber]').text();
  ERPLIST.thisLinePtr = thisf;

  var chooserType = $(thisf).prop('class');
  if(chooserType == 'multipleLineChooser'){
    // define array
    if(!!!ERPLIST.selectedLineInfo){
      ERPLIST.selectedLineInfo  = {};
      ERPLIST.selectedLineInfo.uniquekey = [];
      ERPLIST.selectedLineInfo.doclinenumbers = [];
      ERPLIST.selectedLineInfo.bookingnumbers = [];
      ERPLIST.selectedLineInfo.followupnumbers = [];

      } 
    if($(thisf).prop('checked')){
      $(thisf).prop('checked', true);
      // push data in array
      ERPLIST.selectedLineInfo.uniquekey.push(thisrow);
      ERPLIST.selectedLineInfo.doclinenumbers.push(doclinenumber);
      ERPLIST.selectedLineInfo.bookingnumbers.push(bookingnumber);
      ERPLIST.selectedLineInfo.followupnumbers.push(followupnumber);
        
      var arrayLengthbookingnumber = ERPLIST.selectedLineInfo.bookingnumbers.length;
      var chkbookingnumber  = ERPLIST.selectedLineInfo.bookingnumbers[0];      

      var arrayLengthfollowupnumber = ERPLIST.selectedLineInfo.followupnumbers.length;
      var chkfollowupnumber  = ERPLIST.selectedLineInfo.followupnumbers[0];

      if(arrayLengthbookingnumber > 0 || arrayLengthfollowupnumber > 0){
        if(bookingnumber != chkbookingnumber){
          alert("You need to choose a line for which Booking serial is not assigned.");
          $(thisf).prop('checked', false);
          ERPLIST.popUncheckedValue(thisrow);

          return;
        }
        if(followupnumber != chkfollowupnumber){
          alert("Follow up Serial need to be same.");
          $(thisf).prop('checked', false);
          ERPLIST.popUncheckedValue(thisrow);

          return;
        }
      }  

    } else {
      $(thisf).prop('checked', false);
      var index = ERPLIST.selectedLineInfo.uniquekey.indexOf(thisrow);
      // pop data in array
      ERPLIST.popUncheckedValue(thisrow);
      
    }


  } else if (chooserType == 'singleLineChooser'){

    if($(thisf).prop('checked')){
      $('.singleLineChooser').prop('checked', false);
      $(thisf).prop('checked', true);
      // define variable
      // if(!!!ERPLIST.docnumber) ERPLIST.docnumber = docnumber;
      if(!!!ERPLIST.subdoclinenumber) ERPLIST.subdoclinenumber = subdoclinenumber;
      // if(!!!ERPLIST.bomlinestatus) ERPLIST.bomlinestatus = 'xxxx';

    } else {
      $(thisf).prop('checked', false);
      delete ERPLIST.subdoclinenumber;
      // delete ERPLIST.bomlinestatus;
    }
  }


}


ERPLIST.popUncheckedValue = function(thisrow){
    var index = ERPLIST.selectedLineInfo.uniquekey.indexOf(thisrow);
          ERPLIST.selectedLineInfo.uniquekey.splice(index, 1);
          ERPLIST.selectedLineInfo.uniquekey.splice(index, 1);
          ERPLIST.selectedLineInfo.doclinenumbers.splice(index, 1);
          ERPLIST.selectedLineInfo.bookingnumbers.splice(index, 1);
          ERPLIST.selectedLineInfo.followupnumbers.splice(index, 1);
    console.log(JSON.stringify(ERPLIST.selectedLineInfo.doclinenumbers) + '---' + index);
    console.log(JSON.stringify(ERPLIST.selectedLineInfo.idlines) + '---' + index);

}









ERPLIST.setBookingInfo = function(num){

  if(!!!ERPLIST.selectedLineInfo){
    alert('Please select one line!');
    return;
  }

    var bookingnumber   = $(ERPLIST.thisLinePtr).closest('tr').find('td[fieldname=bookingnumber]').text();
    var isbookingsent   = $(ERPLIST.thisLinePtr).closest('tr').find('td[fieldname=isbookingsent]').text();
    var bookingdate     = $(ERPLIST.thisLinePtr).closest('tr').find('td[fieldname=bookingdate]').text();
    var bookingqty      = $(ERPLIST.thisLinePtr).closest('tr').find('td[fieldname=bookingqty]').text();
    var allocationplan  = $(ERPLIST.thisLinePtr).closest('tr').find('td[fieldname=allocationplan]').text();
    var procurementeta  = $(ERPLIST.thisLinePtr).closest('tr').find('td[fieldname=procurementeta]').text();
    var masterreference = $(ERPLIST.thisLinePtr).closest('tr').find('td[fieldname=masterreference]').text();
    var bookingcomment  = $(ERPLIST.thisLinePtr).closest('tr').find('td[fieldname=bookingcomment]').text();



  if(num == "1"){
    r = confirm("Are you sure to remove Booking information of this line?");
    if(r==false) return;
    var bookingnumber   = "";
    var isbookingsent   = "";
    var bookingdate     = "";
    var bookingqty      = "";
    var allocationplan  = "";
    var procurementeta  = "";
    var masterreference = "";
    var bookingcomment  = "";
  }

    var selectedYes = (isbookingsent == 'Yes') ? "selected" :  "";
    var selectedNo = (isbookingsent == 'No') ? "selected" :  "";

  var content = '<fieldset id="fieldSetBooking">';
  content += '<form  id="formBooking">';
  // content += '<center>';
  // static header table
  content += '<table id="table-1" style="width:100%" class="no_border" text-align="left">';  

  content += '<tr>';
  content += '<th>Booking Serial No.</th>';
  content += '<th>:</th>';
  content += '<th><input type="text" id="bookingnumber" value="'+bookingnumber+'" readonly></th>';
  content += '</tr>';
  
  content += '<tr>';
  content += '<th>Booking Sent</th>';
  content += '<th>:</th>';
  content += '<th><select type="text" id="isbookingsent" value="'+isbookingsent+'"><option value="">Select</option><option value="Yes"' + selectedYes +'>Yes</option><option value="No"'+ selectedNo +'>No</option></select></th>';
  // content += '<th><select type="text" id="isbookingsent" value="'+isbookingsent+'"><option value="Yes"' + selectedYes +'>Yes</option><option value="No"'+ selectedNo +'>No</option></select></th>';
  content += '</tr>';  
  
  content += '<tr>'; 
  content += '<th>Booking Date</th>';
  content += '<th>:</th>';
  content += '<th><input type="text" class="datepicker" id="bookingdate" value="'+bookingdate+'"></th>';
  content += '</tr>'; 
  
  content += '<tr>';
  content += '<th>Booking Qty</th>';
  content += '<th>:</th>';
  content += '<th><input type="text" id="bookingqty" value="'+bookingqty+'"></th>';
  content += '</tr>'; 
  
  content += '<tr>';
  content += '<th>Allocation Plan by Merchandiser</th>';
  content += '<th>:</th>';
  content += '<th><textarea type="text" id="allocationplan" value="">'+allocationplan+'</textarea></th>';
  content += '</tr>'; 

  content += '<tr>';
  content += '<th>ETA by Procurement</th>';
  content += '<th>:</th>';
  content += '<th><input type="text" class="datepicker" id="procurementeta" value="'+procurementeta+'"></th>';
  content += '</tr>';

  content += '<tr>';
  content += '<th>Master Ref#</th>';
  content += '<th>:</th>';
  content += '<th><input type="text" id="masterreference" value="'+masterreference+'"></th>';
  content += '</tr>';

  content += '<tr>';
  content += '<th>Booking Comments</th>';
  content += '<th>:</th>';
  content += '<th><textarea type="text" id="bookingcomment" value="">'+bookingcomment+'</textarea></th>';
  content += '</tr>';

  content += '</table>';
  

  // content += '</center>';
  content += '<center id="div_submitbtn"><input name="submit" class="button" type="button" id="btnSubmit" value="Submit"></center>';
  content += '</form>';
  content += '</fieldset>';


  $.fancybox({
    type: 'html',
    content: content,
    minWidth: 500,
    minHeight: 300,
    afterLoad: function(){
      this.title = "<b>Booking Information</b>";
    },    
    afterShow: function() {
      $.fancybox.update();
      jsClient.initDateTimePicker();
    },
    helpers: {
     title : {
      type : 'inside',
      position : 'top'
     },
     overlay : {
      css  : {  
        // 'background-color' : 'powderblue' 
      }
     }     
    }  
  });
  jQuery('.fancybox-title').css({'text-align':'center', 'font-size': '20px',  'margin-bottom':'10px'});

  


  $('#btnSubmit').click(function(){
    var data = {};

    var params = jsClient.paramsToObj(window.location.search);
    var bookingformid     = params.bookingformid;


    var  bookingnumber      = $('#formBooking input#bookingnumber').val();
    var  isbookingsent      = $('#formBooking select#isbookingsent').val();
    var  bookingdate        = $('#formBooking input#bookingdate').val();
    var  bookingqty         = $('#formBooking input#bookingqty').val();
    var  allocationplan     = $('#formBooking textarea#allocationplan').val();
    var  procurementeta     = $('#formBooking input#procurementeta').val();
    var  masterreference    = $('#formBooking input#masterreference').val();
    var  bookingcomment     = $('#formBooking textarea#bookingcomment').val();
    

    // alert(bookingnumber);
    data['bookingformid']   = bookingformid;
    data['bookingnumber']   = bookingnumber;
    data['isbookingsent']   = isbookingsent;
    data['bookingdate']     = bookingdate;
    data['bookingqty']      = bookingqty;
    data['allocationplan']  = allocationplan;
    data['procurementeta']  = procurementeta;
    data['masterreference'] = masterreference;
    data['bookingcomment']  = bookingcomment;
    
    var postData = {
      reqType: 'setBookingInfo',
      docobj: JSON.stringify(data),
      doclinenumbers: JSON.stringify(ERPLIST.selectedLineInfo.doclinenumbers)
    };

    if(num == '1'){
      var postData = {
        reqType: 'deleteBookingInfo',
        docobj: JSON.stringify(data),
        doclinenumbers: JSON.stringify(ERPLIST.selectedLineInfo.doclinenumbers)
      };
    }


      $.ajax({
        type: 'post',
        url: 'list-ab-booking_api.php',
        data: postData,
        success: function(data) {
          // if result is JSON, we're using the new API return format
          // console.log(data);
          data = JSON.parse(data);
          if (!!data.errormsgs && data.errormsgs.length > 0) {
            console.log(data.errormsgs.join('\n'));
          } else {
              // location.reload();
              alert("Information have been updated.");
              ERPLIST.redrawList();
              $.fancybox.close();
            }

          
        }

      }).fail(function(e) {
        alert('Saving failed, please try again.');
      });




  });


}










ERPLIST.setFollowUpInfo = function(num){
  if(!!!ERPLIST.selectedLineInfo){
    alert('Please select one line!');
    return;
  }

  var followupnumber      = $(ERPLIST.thisLinePtr).closest('tr').find('td[fieldname=followupnumber]').text();
  var ExpectedInHouseDate = $(ERPLIST.thisLinePtr).closest('tr').find('td[fieldname=ExpectedInHouseDate]').text();
  var actualinhousedate   = $(ERPLIST.thisLinePtr).closest('tr').find('td[fieldname=actualinhousedate]').text();
  var actualinhouseqty    = $(ERPLIST.thisLinePtr).closest('tr').find('td[fieldname=actualinhouseqty]').text();
  var followupcomments    = $(ERPLIST.thisLinePtr).closest('tr').find('td[fieldname=followupcomments]').text();
  var accessqty           = $(ERPLIST.thisLinePtr).closest('tr').find('td[fieldname=accessqty]').text();
  var bookingnumber       = $(ERPLIST.thisLinePtr).closest('tr').find('td[fieldname=bookingnumber]').text();
  
  if(num == "1"){
    r = confirm("Are you sure to remove Follow Up information of this line?");
    if(r==false) return;
       // alert('go');
    var followupnumber      = "";
    var ExpectedInHouseDate = "";
    var actualinhousedate   = "";
    var actualinhouseqty    = "";
    var followupcomments    = "";
    var accessqty           = "";
  }



  // alert(bookingnumber);
  if(bookingnumber == ""){
    alert('Supply Chain Merchandiser has not yet update the Booking information.');
    return;
  }



  // var docnumber     = $(input).closest('tr').find('td.docnumber input').val();
  var content = '<fieldset id="fieldSetFollowUp">';
  content += '<form  id="formFollowUp">';
  // content += '<center>';
  // static header table
  content += '<table id="table-1" style="width:100%" class="no_border" text-align="left">';  

  content += '<tr>';
  content += '<th>Follow up serial</th>';
  content += '<th>:</th>';
  content += '<th><input type="text" id="followupnumber" value="'+followupnumber+'" readonly></th>';
  content += '</tr>';

  content += '<tr>';
  content += '<th>Expected Inhouse Date</th>';
  content += '<th>:</th>';
  content += '<th><input type="text" class="datepicker" id="ExpectedInHouseDate" value="'+ExpectedInHouseDate+'"></th>';
  content += '</tr>';
  
  content += '<tr>';
  content += '<th>Actual Inhouse Date</th>';
  content += '<th>:</th>';
  content += '<th><input type="text" class="datepicker" id="actualinhousedate" value="'+actualinhousedate+'"></th>';
  content += '</tr>';  
  
  content += '<tr>'; 
  content += '<th>Actual Inhouse Qty</th>';
  content += '<th>:</th>';
  content += '<th><input type="text" id="actualinhouseqty" value="'+actualinhouseqty+'"></th>';
  content += '</tr>'; 
  
  content += '<tr>';
  content += '<th>Comments</th>';
  content += '<th>:</th>';
  content += '<th><textarea type="text" id="followupcomments" value="">'+followupcomments+'</textarea></th>';
  content += '</tr>'; 
  
  content += '<tr>';
  content += '<th>Short or Excess Qty</th>';
  content += '<th>:</th>';
  content += '<th><input type="text" id="accessqty" value="'+accessqty+'" readonly></th>';
  content += '</tr>';
  content += '</table>';
  

  // content += '</center>';
  content += '<center id="div_submitbtn"><input name="submit" class="button" type="button" id="btnSubmit" value="Submit"></center>';
  content += '</form>';
  content += '</fieldset>';


  $.fancybox({
    type: 'html',
    content: content,
    minWidth: 500,
    minHeight: 300,
    afterLoad: function(){
      this.title = "<b>Booking Follow Up Information</b>";
    },    
    afterShow: function() {
      $.fancybox.update();
      jsClient.initDateTimePicker();
    },
    helpers: {
     title : {
      type : 'inside',
      position : 'top'
     },
     overlay : {
      css  : {  
        // 'background-color' : 'powderblue' 
      }
     }     
    }  
  });
  jQuery('.fancybox-title').css({'text-align':'center', 'font-size': '20px', 'margin-bottom':'10px'});

  


  $('#btnSubmit').click(function(){
    
    var data = {};
    var params               = jsClient.paramsToObj(window.location.search);
    var bookingformid        = params.bookingformid;

    var  followupnumber      = $('#formFollowUp input#followupnumber').val();
    var  ExpectedInHouseDate = $('#formFollowUp input#ExpectedInHouseDate').val();
    var  actualinhousedate   = $('#formFollowUp input#actualinhousedate').val();
    var  actualinhouseqty    = $('#formFollowUp input#actualinhouseqty').val();
    var  followupcomments    = $('#formFollowUp textarea#followupcomments').val();
    var  accessqty           = $('#formFollowUp input#accessqty').val();
    
    data['bookingformid']       = bookingformid;    
    data['followupnumber']      = followupnumber;    
    data['ExpectedInHouseDate'] = ExpectedInHouseDate;
    data['actualinhousedate']   = actualinhousedate;
    data['actualinhouseqty']    = actualinhouseqty;
    data['followupcomments']    = followupcomments;
    data['accessqty']           = accessqty;
    
    var postData = {
      reqType: 'setFollowUpInfo',
      docobj: JSON.stringify(data),
      doclinenumbers: JSON.stringify(ERPLIST.selectedLineInfo.doclinenumbers)
    };

    if(num == '1'){ 
      var postData = {
        reqType: 'deleteFollowUpInfo',
        docobj: JSON.stringify(data),
        doclinenumbers: JSON.stringify(ERPLIST.selectedLineInfo.doclinenumbers)
      };
    }


      $.ajax({
        type: 'post',
        url: 'list-ab-booking_api.php',
        data: postData,
        success: function(data) {
          // if result is JSON, we're using the new API return format
          // console.log(data);
          data = JSON.parse(data);
          if (!!data.errormsgs && data.errormsgs.length > 0) {
            console.log(data.errormsgs.join('\n'));
          } else {
              // location.reload();
              alert("Information have been updated.");
              ERPLIST.redrawList();
              $.fancybox.close();
            }

          
        }

      }).fail(function(e) {
        alert('Saving failed, please try again.');
      });

  });


}






ERPLIST.getHeaderData = function() {
  var params = jsClient.paramsToObj(window.location.search);
  if( !!!params.bookingformid ) return;

  var searchParams = {
    'reqType': 'readDoc'
  };
  searchParams['bookingformid'] = params.bookingformid;

  $.get('/erp-apparel/list-ab-booking_api.php', searchParams, getHeaderData_results(searchParams), 'json')

  function getHeaderData_results(extraParams) {
    return function(data, textStatus, jqXHR) {
      mydata = data;

      var hideColumns = ['iddocument', 'destination'];
      var translationsHardCode = {};
      translationsHardCode.endcustomer      = 'End Customer';
      translationsHardCode.bookingformid    = 'Accessores Booking form No.';
      translationsHardCode.entitynumber     = 'BOM No.';
      translationsHardCode.ldcslnumber      = 'Sales Order Item Line No';
      translationsHardCode.formtype         = 'Sales Order Type';

      var $table = $('<table border=1 class="no_border" />');
      $.each(mydata, function(key, val){
        // take new tr
        var $tr = $("<tr/>");

        // process th
        $th = $('<th style="border-color:grey;"/>');
        $th.html(key)
          .css("white-space", "pre")
          .attr("fieldname", key)
          .css("cursor", "pointer")
          .hover(function() {
              $(this).closest("tr").css("background-color", "lightblue");
            },
            function() {
              $(this).closest("tr").css("background-color", "transparent");
            }
          );
        if (!!translationsHardCode[key]) $th.html(translationsHardCode[key]); // substitutes the header with hard-coded descriptions          
        if (hideColumns.indexOf(key) >= 0) $th.css('display', 'none');
        $th.appendTo($tr);

        // process td
        $td = $('<td style="border-color:grey;"/>');
        $td.html(':')
          .css("white-space", "pre")
          .css("cursor", "pointer")
          .hover(function() {
              $(this).closest("tr").css("background-color", "lightblue");
            },
            function() {
              $(this).closest("tr").css("background-color", "transparent");
            }
          );
        if (hideColumns.indexOf(key) >= 0) $td.css('display', 'none');
        $td.appendTo($tr);

        // process td
        $td = $('<td style="border-color:grey;"/>');
        $td.html(val)
          .css("white-space", "pre")
          .attr("fieldname", key)
          .css("cursor", "pointer")
          .hover(function() {
              $(this).closest("tr").css("background-color", "lightblue");
            },
            function() {
              $(this).closest("tr").css("background-color", "transparent");
            }
          );
        if (hideColumns.indexOf(key) >= 0) $td.css('display', 'none');
        $td.appendTo($tr);


        $tr.click(function() {
          var docnumber = $(this).find('[fieldname=docnumber]').text();
        }).appendTo($table);

      });

      $table.css('margin-bottom', '10pt')

      var fieldset = '<fieldset style="border: 1px solid #B7B7B7; border-radius:5px; margin-bottom:10px; padding-left: 5px;"><legend style="border: 1px solid #B7B7B7; padding: 5px; border-radius:5px; font-weight: bold; padding: 5px; margin: 15px; color:black;">Header Information</legend></fieldset>';
      $('#docHeaderContainer').empty().append(fieldset);
      $('#docHeaderContainer fieldset').append($table);

    }

  }

}