/**
 * Check if jQuery is loaded
 */
if (!window.jQuery) {
  var jq = document.createElement('script');
  jq.type = 'text/javascript';
  jq.src = '/js/jquery-2.1.3.min.js';
  document.getElementsByTagName('head')[0].appendChild(jq);
}

/**
 * Declare the namespace LIZERP if not existent
 */
var LIZERP = LIZERP || {};

$.extend(LIZERP, {
  formId: '',
  formMode: '',
  dbAuxData: [], // extra data submitted by the API that are not fields of the DB

  companyHTML: '<option value="">Select</option>',
  docstatusHTML: '<option value="">Select</option>',
  iduomHTML: '<option value="">Select</option>',
  itemSearchFormHTML: '',
  inventorySearchFormHTML: '',
  inventorySearchFormJS: '',
  lineHTML_template: '',

  formFieldSettings: '',

  // line gets dirty if user changes any field after the line is added or made editable
  lineIsDirty: false,
  valAtFocus: '',

  populateCache: [],

  _URL_DOCUMENTAPI: {
    DOCTYPE1:  '',
    DOCTYPE2:  '/code-framework/form-framework1/doctype2_api.php',
    foo: ''
  },
  _URL_DOCDEFINEAPI: {
    DOCTYPE1: '',
    DOCTYPE2: '/code-framework/form-framework1/erpdocument_define.php?doctype=DOCTYPE2',
    foo: ''
  },
  _URL_LOGIN: '/user/index.php',
  _URL_LIBRARYAPI: '/pdm/mrd_library_api.php',

  _FIELDS_CREATEONLY: []
});

//******************************************* FIELD HANDLING

/**
 * Populate dropdowns
 * This adds to whatever options are already available, allowing for a blank initial option
 * To clear the options prior, use $('select').empty();
 * TO-DO: add extra options: run select2, auto-adjust width of SELECT
 */
LIZERP.populateDropdown = function(field, library, defaultval, options) {
  var populateParams = {
    'library': library,
    'field': field
  };
  if (!!defaultval && defaultval != null) {
    populateParams.defaultval = defaultval;
  }
  if (!!options && options.indexOf('showkeys') != -1) {
    populateParams.showkeys = true;
  }

  if (field == 'productionfloor') {
    var searchParams = {
      'library': library,
      'field': field
    };
    if ($('#company').val().trim().length > 0) {
      searchParams.company = $('#company').val();
    }
    $('#productionfloor').empty().append('<option value="">Select</option>');
    return $.get(LIZERP._URL_LIBRARYAPI, searchParams, populateDropdown_populate(populateParams), 'json');
  }

  if (!!LIZERP.populateCache[library]) {
    populateDropdown_populate(populateParams)(LIZERP.populateCache[library]);
    // returns a resolved promise to signify that there's no pending ajax.
    return $.Deferred().resolve().promise();
  } else {
    var searchParams = {
      'library': library,
      'field': field
    };
    return $.get(LIZERP._URL_LIBRARYAPI, searchParams, populateDropdown_populate(populateParams), 'json');
  }

  function populateDropdown_populate(extraParams) {
    var showkeys = extraParams.showkeys;
    return function(data, textStatus, jqXHR) {
      LIZERP.populateCache[extraParams.library] = data;
      var setasdefault = false;
      $.each(data, function(index, value) {
        setasdefault = (!!extraParams.defaultval && (value == extraParams.defaultval || index == extraParams.defaultval));
        if (!!showkeys && showkeys === true && index != value) {
          $('#' + extraParams.field)
            .append($("<option></option>")
              .attr("value", index)
              .text(index + ' - ' + value)
              .prop('selected', setasdefault)
            );
        } else {
          $('#' + extraParams.field)
            .append($("<option></option>")
              .attr("value", index)
              .text(value)
              .prop('selected', setasdefault)
            );
        }
      });
      return;
    }
  }
}

LIZERP.searchLoupe_show = function(inputfield) {
  var imgheight = 16;
  var imgwidth = 16;
  var fieldName = $(inputfield).closest('td').attr('class');
  aleft = $(inputfield).offset().left + $(inputfield).width() - imgwidth + 2;
  atop = $(inputfield).offset().top + 3;
  $('<div/>')
    .offset({
      top: atop,
      left: aleft
    })
    .css('display', 'block')
    .css('position', 'absolute')
    .css('background-repeat', 'no-repeat')
    .css('background-image', 'url(./img/search.png)')
    .attr('fieldname', fieldName)
    .addClass('itemsearchLoupe')
    .height($(inputfield).outerHeight() - 2)
    .width($(inputfield).outerHeight() - 2)
    .appendTo($('body'))
    .hover(function(e) {}, function(e) {
      $('.itemsearchLoupe').remove();
    })
    .on('click', function() {
      LIZERP.handleSearchForm($(this).attr('fieldname'));
    });
}

LIZERP.searchLoupe_hide = function() {
  $('.itemsearchLoupe').remove();
}

/**
 * Bind datepicker with an input field
 * @param selector
 */
LIZERP.bindDatepicker = function(selector) {
  $(selector).datepicker({
    dateFormat: 'yy-mm-dd',
    changeMonth: true,
    changeYear: true,
    constrainInput: true,
    onClose: function(dateText, inst) {
      /* Validate date input; erase data if invalid */
      if (isDate(dateText, false) == false) {
        $(this).val('');
      }
    }
  });
}

/**
 * Bind datetimepicker with an input field
 * @param selector
 */
LIZERP.bindDatetimepicker = function(selector) {
  $(selector).datetimepicker({
    dateFormat: 'yy-mm-dd',
    changeMonth: true,
    changeYear: true,
    constrainInput: true,
    onClose: function(dateText, inst) {
      /* Validate date input; erase data if invalid */
      if (isDate(dateText, true) == false) {
        $(this).val('');
      }
    }
  });
}

/**
 * Handle docdate field. Current browser date is auto populated.
 */
LIZERP.handle_docdate_field = function() {
  /* Show current date in docdate field */
  var today = new Date();
  var dd = today.getDate();
  var mm = today.getMonth() + 1;
  /* January is 0! */
  var yyyy = today.getFullYear();

  dd = dd < 10 ? ('0' + dd) : dd;
  mm = mm < 10 ? ('0' + mm) : mm;

  $(LIZERP.formId + ' #docdate').val(yyyy + '-' + mm + '-' + dd);

}

/**
 * Validate form fields
 * @param container
 * @returns {boolean}
 */
LIZERP.validateFormContainerFields = function(container) {
  var error = false;
  $(container).find('input, select, textarea').each(function() {
    if (!!$(this).prop('required')) {
      if ($(this).val() == '') {
        error = true;
        LIZERP.hightlightErrorField($(this));
      }
    }
  });
  return error;
}

/**
 * Highlight error field for a certain period
 * @param field
 */
LIZERP.hightlightErrorField = function(field) {
  field.addClass('error');
  setTimeout(function() {
    field.removeClass('error');
  }, 3000);
}

/**
 * Show form error
 * @param msg
 */
LIZERP.showFormError = function(msg) {
  $(LIZERP.formId + ' #formError').html(msg).show();
  setTimeout(function() {
    $(LIZERP.formId + ' #formError').hide('slow').html('');
  }, 3000);
}

LIZERP.changeDocStatus = function(){
  var params = paramsToObj(window.location.search);
  if (!params.docnumber) {
    alert('Error: iddocument not available. Please tell ERP department.');
    return;
  }
  var searchParams = {};
  searchParams.docnumber = params.docnumber;
  searchParams.reqType = 'changeDocStatus';
  return $.post(LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM], searchParams, changeDocStatus_return(), 'json');

  function changeDocStatus_return(extraParams) {
    return function(data, textStatus, jqXHR) {
      if (data.result == 'success') {
        location.reload();
      } else {
        alert(data.errormsgs.join('\n'));
      }
    }
  }

}

//******************************************* LINE HANDLING

LIZERP.getLineBeingEdited = function() {
  return $('#formLines input[type=text]:visible').first().closest('tr');
}

/**
 * Save a line
 */
LIZERP.saveLine = function(edit) {
  // edit = 1 if we're trying to save because we clicked on an edit button of another line
  var $tr2 = LIZERP.getLineBeingEdited();

  // if line is completely blank, ignore request
  var fieldsWithData = 0;
  $tr2.find('input,textarea,select').filter(':visible')
    .each(function(index, element) {
      if ($(element).attr('type') == "button") return;
      if ($(element).val().trim().length > 0) fieldsWithData++;
    });
  if (fieldsWithData == 0) return;


  var error = false;
  // before reading any values, make the values of the inputs actually uppercase and not only CSS transformed
  $tr2.find('input,textarea').each(function(i) {
    if ($(this).css('text-transform') == 'uppercase') $(this).val($(this).val().toUpperCase());
  });

  var fieldList = [];
  var requiredCols = [];
  $('#formLines #fieldset_lineinformation table tr th')
    .each(function(e) {
      if (!!$(this).attr('class')) fieldList.push($(this).attr('class'));
      if (!!$(this).attr('required')) requiredCols.push($(this).attr('class'));
    });
  // remove from array, this field is not user-entered
  fieldList.splice(fieldList.indexOf('idlines'), 1)
  fieldList.splice(fieldList.indexOf('linenumber'), 1)

  var $lineFields = {};
  for (key in fieldList) {
    $lineFields[fieldList[key]] = $tr2.find('.' + fieldList[key]).find('input,select,textarea');
  }

  // Check if any required fields are empty
  for (key in requiredCols) {
    $validatingField = $lineFields[requiredCols[key]];
    if ($validatingField.val() == '') {
      LIZERP.hightlightErrorField($validatingField);
      error = true;
    }
  }

  // if any blinking errors, stop
  if ($('.error').length > 0) error = true;

  if (!error) {
    for (key in fieldList) {
      if ($lineFields[fieldList[key]].prop('tagName') == 'SELECT') {
        var selectedvalue = $lineFields[fieldList[key]].find('option:selected').text();
        if (selectedvalue != 'Select') {
          $tr2.find('.' + fieldList[key]).find('span').text(selectedvalue);
        }
      } else {
        $tr2.find('.' + fieldList[key]).find('span').text($lineFields[fieldList[key]].val());
      }
    }
    $tr2.find('textarea').parent().find('span').css('white-space', 'pre-wrap');

    $tr2.removeClass('editable new').addClass('valid');

    if (edit != 1) {
      LIZERP.addLine();
    }
  }
  if (edit == 1) {
    return error;
  }
}

/**
 * Edit a line
 * @param line
 */
LIZERP.editLine = function(line) {
  // try to save if currently on a dirty line
  if (LIZERP.lineIsDirty == true) $('#formLines input[type=text]:visible').closest('tr').find('.saveLine').first().click();
  // don't let user get out of a line if it has errors
  if ($('.error').length > 0) return;

  var error = false;

  if ($(LIZERP.formId + ' #formLines tr.editable.new').length > 0) {
    /* User wishes to edit a saved line and a new line exists and is editable. So remove the new line */
    $(LIZERP.formId + ' #formLines tr.new').remove();
  } else if ($(LIZERP.formId + ' #formLines tr.editable').length > 0) {
    // getting here means there's a line being edited and it's clean
    // User wishes to edit a saved line and new line doesn't exist; a saved line is now editable. So save the currently editable line first. 
    error = LIZERP.saveLine(1);
  }

  if (!error) {
    $(LIZERP.formId + ' #formLines tr[data-id="' + line + '"]').addClass('editable').removeClass('valid');
    $('#div_floatingButton').remove();
    LIZERP.initLine();
  }
}

/**
 * Remove a line
 * @param line
 */
LIZERP.removeLine = function(line) {
  if (confirm('Are you sure to delete line ' + line + '?')) {
    $(LIZERP.formId + ' #formLines tr[data-id="' + line + '"]').remove();
    LIZERP.addLine();
  }
}

/**
 * Add a line
 */
LIZERP.addLine = function() {
  var line = $(LIZERP.formId + ' #formLines tbody tr').length > 0 ? (parseInt($(LIZERP.formId + ' #formLines tbody tr:last-child').attr('data-id'))) : 0;
  if (!!LIZERP.dbAuxData['lastlinenumber']) {
    line = Math.max(line, LIZERP.dbAuxData['lastlinenumber']);
  }
  line = line + 1;

  var lineHTML = LIZERP.lineHTML_template
    .replace('<select name="lines[1][iduom]" required="required">\n                            <option value="">Select</option>', '<select name="lines[' + line + '][iduom]" required="required">\n' + LIZERP.iduomHTML)
    .replace('class="editable"', 'class="editable new"')
    .replace('<span>1</span>', '<span>' + line + '</span>')
    .replace('value="1"', 'value="' + line + '"')
    .replace('data-id="1"', 'data-id="' + line + '"')
    .replace(/lines\[1\]/g, 'lines[' + line + ']');

  $(LIZERP.formId + ' #formLines #fieldset_lineinformation table tbody').append(lineHTML);
  LIZERP.initLine();
  $(LIZERP.formId + ' #formLines .trackingno input').focus();
}

LIZERP.initLine = function() {
  $tr = LIZERP.getLineBeingEdited();
  var line = $('#formLines input[type=text]:visible').closest('tr').attr('data-id');

  // Bind auto-fills: if the value of the field has changed, send to the search function

  // Bind CTRL-Enter to save lines
  $tr.find('input,textarea,select')
    .keydown(function(e) {
      if (e.ctrlKey && e.keyCode == 13) {
        e.preventDefault();
        e.stopImmediatePropagation();
        LIZERP.saveLine();
      }
    });
    
  // Bind ENTER to move to next field
  $tr.find('input,textarea,select').keydown(bindEvent_EnterMovesFocus);

  // Move wh_description to a block under itemcode if there's no item description field
  if (!$tr.find('td.itemdescription').length) {
    var div_floatingWhDesc0 = $('<div class="div_floatingWhDesc0" style="float:left;position:absolute;">');
    var div_floatingWhDesc1 = $('<div class="div_floatingWhDesc1" style="float:left;position:absolute;top:2px;">');
    div_floatingWhDesc1.append('<pre style="font-family:monospace;"></pre>');
    div_floatingWhDesc1.appendTo(div_floatingWhDesc0);
    $tr.find('.div_floatingWhDesc0').remove();
    $tr.find('td.itemcode').append(div_floatingWhDesc0);
  }

  // Create and bind line buttons
  var div_floatingButton0 = $('<div id="div_floatingButton" style="float:left;position:absolute;">');
  var div_floatingButton1 = $('<div id="div_floatingButton1" style="float:left;position:absolute;top:24px;width:200px;">');
  div_floatingButton1.append('<input type="button" class="saveLine btn-blue material-icons" style="font-size:24px;" value="_done_">');
  div_floatingButton1.append('&nbsp;&nbsp;');
  div_floatingButton1.append('<input type="button" class="removeLine btn-grey material-icons" style="font-size:24px;" value="delete">');
  div_floatingButton1.appendTo(div_floatingButton0);
  $tr.find('#div_floatingButton').remove();
  $tr.find('td:first-child').append(div_floatingButton0);

  $tr.find('.saveLine')
    .on('click', function() {
      LIZERP.saveLine();
    });
  $tr.find('.editLine')
    .on('click', function() {
      LIZERP.editLine($(this).closest('tr').attr('data-id'));
    });
  $tr.find('.removeLine')
    .on('click', function() {
      LIZERP.removeLine($(this).closest('tr').attr('data-id'));
    });
  $tr.find('.printLine')
    .on('click', function() {
      LIZERP.printLine($(this).closest('tr').attr('data-id'));
    });

  // Loupe (magnifying glass) displays only on hover
  $tr.find('td.itemcode input')
    .hover(function(e) {
      LIZERP.searchLoupe_show(this);
    }, function(e) {
      atop = $(this).offset().top;
      aleft = $(this).offset().left;
      abottom = atop + parseFloat($(this).css('height').replace('px', ''));
      aright = aleft + parseFloat($(this).css('width').replace('px', ''));
      // if mouse left the input box
      if (atop > e.pageY || abottom < e.pageY || aleft > e.pageX || aright < e.pageX) LIZERP.searchLoupe_hide();
    });

  // Loupe (magnifying glass) displays only on hover
  $tr.find('td.idlocation input')
    .hover(function(e) {
      LIZERP.searchLoupe_show(this);
    }, function(e) {
      atop = $(this).offset().top;
      aleft = $(this).offset().left;
      abottom = atop + parseFloat($(this).css('height').replace('px', ''));
      aright = aleft + parseFloat($(this).css('width').replace('px', ''));
      // if mouse left the input box
      if (atop > e.pageY || abottom < e.pageY || aleft > e.pageX || aright < e.pageX) LIZERP.searchLoupe_hide();
    });

  // Loupe (magnifying glass) displays only on hover
  $tr.find('td.itemlot input')
    .hover(function(e) {
      LIZERP.searchLoupe_show(this);
    }, function(e) {
      atop = $(this).offset().top;
      aleft = $(this).offset().left;
      abottom = atop + parseFloat($(this).css('height').replace('px', ''));
      aright = aleft + parseFloat($(this).css('width').replace('px', ''));
      // if mouse left the input box
      if (atop > e.pageY || abottom < e.pageY || aleft > e.pageX || aright < e.pageX) LIZERP.searchLoupe_hide();
    });

  // Edit button displays only on hover
  $tr
    .hover(function(e) {
      $(this).find('.div_editButton').css('display', 'block');
    }, function(e) {
      $(this).find('.div_editButton').css('display', 'none');
    });

  // Enable dirty line detection
  LIZERP.lineIsDirty = false;
  $tr.find('input,textarea,select')
    .change(function() {
      LIZERP.lineIsDirty = true;
    });
}

//******************************************* FORM HANDLING

/**
 * Receives data from the API and populates the respective fields of the form
 * @param  {docobj} headerObj is the docobj from the API, minus the lines element
 * @param  {docboj.lines} linesObj is the lines element of docobj
 * @return {boolean}           true for success, false for failure
 */
LIZERP.fillForm = function(headerObj, linesObj) {
  // First, check if data is complete
  if (linesObj.length == 0) {
    return false;
  }

  // Complete the header fields
  // if ( !!headerObj.docnumber ) headerObj.docnumber =  formatDocnum( LIZERP._ERP_DOCACRONYM , headerObj.docnumber );
  for (var key in headerObj) {
    if (key.substr(0, 1) == "_") {
      LIZERP.dbAuxData[key.substr(1)] = headerObj[key]
      continue;
    }
    $('#' + key).filter('input,select,textarea').val(headerObj[key]);
    if(key == "docnumber"){$('span#span' + key).text(headerObj[key]);}
    else if(key == "docstatus"){$('span#span' + key).text(headerObj[key]);} 
    else {$('span#' + key).text(headerObj[key]);}

  }


  // Get a list of the TH columns marked as required
  var requiredCols = [];
  $('#formLines #fieldset_lineinformation table tr th[required=required]')
    .each(function(key, element) {
      requiredCols.push($(element).attr('class'));
    });
  // Complete the line fields
  for (var i = 0; i < linesObj.length; i++) {
    // Check if all required columns are present in the data from the DB, skip malformed lines
    for (var j = 0; j < requiredCols.length; j++) {
      if (!linesObj[i][requiredCols[j]] || linesObj[i][requiredCols[j]].trim().length == 0) {
        console.log('Skipping line ' + i + ' because ' + requiredCols[j] + ' is missing.');
        alert('A line has been lost because the data coming from the system is incomplete.');
        continue;
      }
    };

    // Build field list from the visible or hidden form
    var fieldList = [];
    $('#formLines #fieldset_lineinformation tr th').each(function(e) {
      if (!!$(this).attr('class')) fieldList.push($(this).attr('class'));
    });
    // Start copying data to the fields
    var $tr2 = LIZERP.getLineBeingEdited();
    for (var j = 0; j < fieldList.length; j++) {
      if (!!linesObj[i][fieldList[j]] && linesObj[i][fieldList[j]].length > 0) {
        $tr2.find('td.' + fieldList[j]).find('input,textarea,select').first().val(linesObj[i][fieldList[j]]);
      }
    }
    // var wh_description = linesObj[i]['wh_description1'] + '\n' + linesObj[i]['wh_description2'];
    // if ($tr2.find('.div_floatingWhDesc0').size() == 1) $tr2.find('.div_floatingWhDesc0 pre').text(wh_description);

    // Set the line number to match the DB
    var linenumber = linesObj[i]['linenumber'];
    $tr2.attr('data-id', linenumber);
    $tr2.find('td.linenumber span').text(linenumber);
    $tr2.find('input,select,textarea').each(function(e) {
      var currName = $(this).attr('name');
      if (!!currName) $(this).attr('name', currName.replace(/\[\d+\]/, "[" + linenumber + "]"));
    });
    $tr2.find('input.saveLine:visible').first().click();
  }
  return true;
}

/**
 * Handle form fields to show-hide/enable-disable/required/readonly etc.
 */
LIZERP.handleFormFields = function(crudmode) {
  var params = paramsToObj(window.location.search);
  var searchParams = params;
  if (searchParams.formtype === undefined) {
    searchParams.formtype = 'default';
  }
  delete searchParams.doctype;

  return $.get(LIZERP._URL_DOCDEFINEAPI[LIZERP._ERP_DOCACRONYM], searchParams, handleFormFields_results(), 'json');

  function handleFormFields_results(extraParams) {
    return function(data, textStatus, jqXHR) {
      /* Save to formFieldSettings for later use such as form lines */
      LIZERP.formFieldSettings = data;
      // alert(JSON.stringify(data));

      /* Handle header fields */
      $.each(data['header'], function(fieldName, attributes) {

        console.log(fieldName+ "---" + JSON.stringify(attributes));
        /* Handle required restriction */
        if (attributes['restriction'] == 'required') {
          $(LIZERP.formId + ' #' + fieldName).attr('required', 'required');
          $(LIZERP.formId + ' #' + fieldName).closest('div.formGroup').find('label').append('<span class="required">*</span>');
        } else {
          $(LIZERP.formId + ' #' + fieldName).removeAttr('required');
          $(LIZERP.formId + ' #' + fieldName).closest('div.formGroup').find('label span.required').remove();
        }

        /* Handle viewonly restriction */
        if (attributes['restriction'] == 'viewonly') {
          $(LIZERP.formId + ' #' + fieldName).attr('readonly', 'readonly');
          $(LIZERP.formId + ' #' + fieldName).attr('disabled', 'disabled');
        } else {
          $(LIZERP.formId + ' #' + fieldName).removeAttr('readonly');
          $(LIZERP.formId + ' #' + fieldName).removeAttr('disabled');
        }

        /* Handle hidden restriction */
        if (attributes['restriction'] == 'hidden') {
          $(LIZERP.formId + ' #' + fieldName).closest('div.formGroup').hide();
        }

        /* Handle defaults */
        if (!!attributes['default']) {
          if (attributes['default'].indexOf(':') == -1) {
            $(LIZERP.formId + ' #' + fieldName).val(attributes['default']);
          }
        }
        // After changing fields, must refresh

      });
      /* Handle table header */
      $.each(data['lines'], function(fieldName, attributes) {
        if (attributes['restriction'] == 'required') {
          $(LIZERP.formId + ' th.' + fieldName).attr('required', 'required');
          $(LIZERP.formId + ' th.' + fieldName).append('<span class="required">*</span>');
        }
      });
    }
  }
}

/**
 * Update the form title
 */
LIZERP.updateFormTitle = function(crudmode) {
  var params = paramsToObj(window.location.search);
  if (params.formtype != $('input#formtype').val()) {
    params.formtype = $('input#formtype').val();
    window.location = window.location.origin + window.location.pathname + '?' + $.param(params);
  }
}

/**
 * Save form via ajax after validation
 */
LIZERP.saveForm = function() {
  // tries to save the line if it's dirty
  if ((LIZERP.lineIsDirty == true) || ($(LIZERP.formId + ' #formLines tr.editable:not(.new)').length > 0)) {
    $('#formLines input[type=text]:visible').closest('tr').find('.saveLine').first().click();
  }

  // change data to actual uppercase from just css transform
  $(LIZERP.formId).find('input,textarea').each(function(i) {
    if ($(this).css('text-transform') == 'uppercase') $(this).val($(this).val().toUpperCase());
  });


  var error;
  // if no lines have been added, don't continue
  var validLines = $(LIZERP.formId + ' #formLines #fieldset_lineinformation tbody tr.valid').length;
  if (validLines == 0) {
    error = true;
    LIZERP.showFormError('Please provide at least one valid line information.');
  }

  // If all data is validated, then submit
  if (!error && LIZERP.formMode == 'edit') {
    // just to avoid re-entry, the server should also check for double submission
    LIZERP.readMode();

    /* Prepare JSON */
    var jsonData = {
      'lines': []
    };
    $.each(LIZERP.formFieldSettings['header'], function(fieldName, attributes) {
      jsonData[fieldName] = $(LIZERP.formId + ' #' + fieldName).val();
    });

    $(LIZERP.formId + ' #formLines #fieldset_lineinformation tbody tr.valid').each(function() {
      var fieldList = [];
      // Build field list from the visible form
      $('#formLines #fieldset_lineinformation tr th').each(function(e) {
        if (!!$(this).attr('class')) fieldList.push($(this).attr('class'));
      });
      // Build field list from the formFieldSettings variable
      // $.each( LIZERP.formFieldSettings['lines'], function( fieldName, attributes ) {
      //     fieldList.push( fieldName );
      // } );

      var formLine = {};
      
      for (index in fieldList) {
        formField = fieldList[index];
        formLine[formField] = $(this).find('td.' + formField).find('input,textarea,select').first().val();
      
      }
      jsonData['lines'].push(formLine);
    });
    /* Submit via ajax */
    var postData = {
      reqType: 'saveDoc',
      docobj: JSON.stringify(jsonData)
    };
    // add iddocument in case this is an Edit
    if ($(LIZERP.formId + ' #docnumber').val().length > 0) postData.docnumber = $(LIZERP.formId + ' #docnumber').val();
    console.log(postData);
    $.ajax({
      type: 'post',
      url: LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM],
      //dataType: 'json',/* if the return data is json */
      data: postData,
      success: function(data) {
          // if result is JSON, we're using the new API return format
          console.log(data);
          data = JSON.parse(data);
          if (!!data.errormsgs && data.errormsgs.length > 0) {
            console.log(data.errormsgs.join('\n'));
            alert("===>"+data.errormsgs.join('\n'));
            LIZERP.editMode();
          } else {
            var params = paramsToObj(window.location.search);
            var next_href = window.location.origin + window.location.pathname + '?doctype=' + LIZERP._ERP_DOCACRONYM + '&docnumber=' + data.docnumber;
            window.location.href = next_href;
          }
      }
    }).fail(function(e) {
      alert('Saving failed, please try again.');
      LIZERP.editMode();
    });
  }
  return;
}


/**
 * Show popup item code search form
 */
LIZERP.handleSearchForm = function(callingField, prepopulate) {
  LIZERP.searchLoupe_hide();
  if (callingField == 'itemcode') {
    var prepopJS = (!!prepopulate) ? 'var prepopulate = ' + JSON.stringify(prepopulate) + ';' : '';
    var content = LIZERP.itemSearchFormHTML + '<script> ' + prepopJS + '</script>';
  } else if (callingField == 'idlocation') {
    if (LIZERP._ERP_DOCACRONYM == 'GD' || LIZERP._ERP_DOCACRONYM == 'TO') {
      var $whlocation = $('select#sendlocation');
    } else if (LIZERP._ERP_DOCACRONYM == 'GR') {
      var $whlocation = $('select#recvlocation');
    } else {
      throw "FATAL ERROR: unrecognized doctype in handleSearchForm";
    }
    if ($whlocation.val() == '') {
      LIZERP.hightlightErrorField($whlocation);
      return;
    } else {
      var $tr2 = LIZERP.getLineBeingEdited();

      prepopulate = !!prepopulate ? prepopulate : {};
      prepopulate.whlocation = $whlocation.val();
      prepopulate.fulladdresscode = $tr2.find('.idlocation input').val();
      var prepopJS = 'var prepopulate = ' + JSON.stringify(prepopulate) + ';';
      var content = LIZERP.locationSearchFormHTML + '<script> ' + prepopJS + '</script>';
    }
  }
  $.fancybox({
    parent: LIZERP.formId,
    type: 'html',
    content: content,
    minWidth: 500,
    minHeight: 300,
    afterShow: function() {
      $('#searchForm .focusonme').first().focus();
      if (!!prepopulate) {
        for (field in prepopulate) {
          $('#searchForm').find('input,select').filter('[name=' + field + ']').val(prepopulate[field]);
        }
        $('#searchForm').find('input,select').filter('[name=whlocation]').attr('disabled', 'disabled');
        $('#searchForm button#search').first().click();
      }
    }
  });
  return;
}



//******************************************* MODE HANDLING

LIZERP.readMode = function() {
  $(LIZERP.formId).find(' #formLines tr.new').remove();
  $(LIZERP.formId).find(' #formLines tr').unbind('mouseenter mouseleave');
  $(LIZERP.formId).find('input,select,textarea').attr('disabled', 'disabled');
  $(LIZERP.formId).find(' input[type=button]').removeAttr('disabled');
  $('#fieldset_systeminformation').css('display', 'block');
  $(' .btnEditMode ').css('display', 'none');
  $(' .btnReadMode ').css('display', 'inline-block');
  $('.datepicker').unmousewheel();
  LIZERP.formMode = 'read';
}


LIZERP.editMode = function() {
  if ($(LIZERP.formId + ' .btnPrintLabels').hasClass('btn-orange')) LIZERP.labelPrintMode();
  if ($(' #formLines tr.editable').length == 0) LIZERP.addLine();
  $(LIZERP.formId + ' #formLines tr').hover(function(e) {
    $(this).find('.div_editButton').css('display', 'block');
  }, function(e) {
    $(this).find('.div_editButton').css('display', 'none');
  });
  $(LIZERP.formId).find('input,select,textarea').removeAttr('disabled');
  LIZERP.lockCreateOnlyFields();
  $('#fieldset_systeminformation').css('display', 'none');
  $(' .btnEditMode ').css('display', 'inline-block');
  $(' .btnReadMode ').css('display', 'none');
  LIZERP.formMode = 'edit';
}

/**
 * Locks all fields that can not be changed after document is saved.
 * This is done to keep consistency on the DB.
 * E.g. status of the related document has already been changed.
 */
LIZERP.lockCreateOnlyFields = function() {
  var fieldList = LIZERP._FIELDS_CREATEONLY;
  for (field in fieldList) {
    $(LIZERP.formId).find('input,textarea,select').filter('#' + fieldList[field]).attr('disabled', 'disabled');
  }
}

//******************************************* OTHER

LIZERP.wait = function(ms) {
  var deferred = $.Deferred();
  setTimeout(function() {
    deferred.resolve()
  }, ms);
  return deferred.promise();
}