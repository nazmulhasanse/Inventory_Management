/**
 * Declare ERPLIST Namespace if not exist
 */
var ERPLIST = ERPLIST || {};

$.extend(ERPLIST, {
  mUrl: 'api/server_api.php',
  mType: 'get',
  mData: '',
  mAsync: false,
  mReqType: '',
  queryData: '',
  queryParam: '',
  _searchParams: '',
  _URL_API: 'list-quantity-request_api.php',

  foo: 'here for no reason other than to be the last line, without a comma'
});



ERPLIST.applyCustomCSS = function(){
   // Custom CSS if required
   $('#listTable tr#searchForm input').css({
    'width':'90%',
    'min-width': '40px',
    'font-family':'Arial',
    'padding':'2px',
    'border':'1px solid #7F7F7F',
    'border-radius':'3px'
  });  

  $('#listTable td.company').css({
    'min-width':'20px'
  });   
  $('#listTable td.construction').css({
    'min-width':'100px'
  });   
  $('#listTable td.composition').css({
    'min-width':'100px'
  });    
  $('#listTable td.printingtype').css({
    'min-width':'100px'
  }); 

}


ERPLIST.makeTable = function(mydata,hasData) {
  var $table = $('<table border=1 id="listTable" class="listTable" />');
  var $thead = $('<thead />');
  var $tbody = $('<tbody/>');

  //for composition column
  ERPLIST.compositeColumns = {
    // docnumber:{
    //   docnumber: {
    //     style: 'font-weight:bold; color:blue',
    //     customsearch: true,
    //     composite: false,
    //     end: true
    //   }
    // },
    // linenumber:{
    //   linenumber:{
    //     style: 'font-weight:bold; color:green',
    //     composite: false,
    //     end: true        
    //   }
    // },

    // documentinformation : {
    //   linestatus:{
    //     style: 'font-weight:bold; color:green',
    //     customsearch: true,
    //     islibrary: true,
    //     datasource: {
    //       0: 'Entered',
    //       1: 'Running',
    //       2: 'Closed'
    //     },        
    //     fielddesc: 'Line Status',
    //     composite: true
    //   },
    //   company:{
    //     style: 'font-weight:bold; color:green',
    //     islibrary: true,
    //     sql: "SELECT Code AS code, Description AS description FROM mrd_library WHERE LibraryName='company'", 
    //     customsearch: true,
    //     fielddesc: 'Company',
    //     composite: true
    //   },
    //   docdate:{
    //     fielddesc: 'Doc Date',
    //     customsearch: true,
    //     composite: true,
    //     fielddesc: 'Document date',
    //     type: 'date',
    //     end: true        
    //   }
    // },
    // formtype: {
    //   formtype:{
    //     composite: false,
    //     end: true        
    //   }
    // },
    // itemspecification: {
    //   itemtype:{
    //     fielddesc: 'Item Type',
    //     style: 'font-weight:bold; color:green',
    //     islibrary: true,
    //     sql: "SELECT Code AS code, Description AS description FROM mrd_library WHERE LibraryName='itemtype_textile'",        
    //     customsearch: true,
    //     composite: true
    //   },
    //   docstatus:{
    //     fielddesc: 'Doc Status',
    //     customsearch: true,
    //     composite: true,
    //     end: true        
    //   }
    // },    

  }

  // some trickery for nice formatting
  var hideColumns = ['idlines', 'doctype','workorderdocnumber','formtype','linenumber','doccreationtime','docstatus','entrypersonbadge','linestatus','lineentrytime'];

  var translationsHardCode = {};
  translationsHardCode.iduom = 'UoM';
  translationsHardCode.elementuom = 'Elem. UoM';
  translationsHardCode.docdate = 'Doc Date';
  translationsHardCode.docstatus = 'Document Status';
  translationsHardCode.documentinformation = 'Document Information';
  translationsHardCode.itemspecification = 'Item Specification';
  translationsHardCode.docnumber = 'Doc No.';
  translationsHardCode.salesorder = 'SO No.';
  translationsHardCode.linesremarks = 'Lines Remarks';
  translationsHardCode.trackingno = 'Tracking No.';
  translationsHardCode.itemtype = 'Item Type';
  translationsHardCode.itemcode = 'Item Code';
  translationsHardCode.itemlot = 'Item Lot';
  translationsHardCode.itemdescription = 'Item Description';
  translationsHardCode.itemserial = 'Item Serial';
  translationsHardCode.tnxqty = 'Quantity';
  translationsHardCode.company = 'Division';


  // builds the table header
  var mydata_json = JSON.stringify(mydata);
  var firstRow = mydata[0];

  var firstRowCopy = firstRow;
  var compositeColumnsLength = Object.keys(ERPLIST.compositeColumns).length;
  var countVisibleColumn = 1; // here start from 1 cz first td for option
  /**
   * first header row------------------------------------------------------------------------------------------------------------------------------------------------------------
   */
  var $tr = $("<tr/>");
  // $td = $('<th/>');
  // $td.html('');
  // $td.appendTo($tr);

  // process composite column first if has
  if(compositeColumnsLength > 0){
    $.each(ERPLIST.compositeColumns, function(groupName, groupColumns){
      // hide first
      $.each(groupColumns, function(fieldname, fieldStyle){
        var fielddesc = fieldname;
        $td = $('<th/>');
        if (!!translationsHardCode[fieldname]) fielddesc = translationsHardCode[fieldname];
        $td.html('<center>'+ fielddesc +'</center>');
        $td.css('display','none');
        $td.appendTo($tr);

        delete firstRowCopy[fieldname]; // its already procceed
      });

      $td = $('<th/>');
      $td.attr('class', groupName);
      if (!!translationsHardCode[groupName]) groupName = translationsHardCode[groupName];
      $td.html('<center>'+ groupName +'</center>');
      $td.appendTo($tr);
      countVisibleColumn++;
    });
  }

  // precess rest of columns----------------------------------------------------------------------------------------------
  $.each(firstRowCopy, function (fieldname, fieldvalue) {
    countVisibleColumn++;
    var fielddesc = fieldname;
    $td = $('<th/>');
    if (!!translationsHardCode[fieldname]) fielddesc = translationsHardCode[fieldname];
    $td.html('<center>'+ fielddesc +'</center>');
    if ( hideColumns.indexOf(fieldname) >= 0 ){ $td.css('display','none'); countVisibleColumn--};
    $td.appendTo($tr);
  });
  $tr.appendTo($thead);
  $thead.appendTo($table);
  // end -----------------------------------------------------------------------------------------------------------------


  /**
   * second header row-----------------------------------------------------------------------------------------------------------------------------------------------------------
   */
  var $tr = $("<tr/>").attr("id","searchForm");
  var $td;
  // $td = $('<td/>');
  // $td.html('<center>Option</center>');
  // $td.appendTo($tr);

  if(compositeColumnsLength > 0){
    $.each(ERPLIST.compositeColumns, function(groupName, groupColumns){

      var compositeClass = '';
      $td = $('<td/>');
      $td.attr('class', groupName);
      $.each(groupColumns, function(fieldname, fieldpropties){

        compositeClass +=  ( !!fieldpropties.end) ? fieldname : fieldname + '__';          
        var customsearch_option = ( !!fieldpropties.customsearch) ?'<button type="button" onclick="ERPLIST.handleCustomSearch(this);"><img src="img/search_icon.png" alt="" height="15" width="15"></button>': '';
        var customsearch_click  = ( !!fieldpropties.customsearch) ?'onclick="ERPLIST.handleCustomSearch(this);"': 'onclick="ERPLIST.handleThisSearchInputFieldClick(this);"';
        var customsearch_class  = ( !!fieldpropties.customsearch ) ? '  hasCustomSearch' : '';

        var html = '<center><input type="text" name="'+ compositeClass +'" value="" id="'+compositeClass+'" class="'+compositeClass + customsearch_class +'" '+ customsearch_click +' />'+ customsearch_option +'</center><div id="'+compositeClass+'_displaySearchParams" style="background-color:#43C6DB;"></div>';
        $td.html(html);

        // delete firstRowCopy[fieldname]; // its already procceed
        $td_hide = $('<td/>');
        $td_hide.html('<center><input type="hidden" class="'+ fieldname +'" value="" id="'+fieldname+'" /></center>');
        $td_hide.css('display','none');
        $td_hide.appendTo($tr);

      });
      $td.appendTo($tr);

    });
  }
  // end -----------------------------------------------------------------------------------------------------------------

  // precess rest of columns----------------------------------------------------------------------------------------------
  $.each(firstRowCopy, function (fieldname, fieldvalue) {    
    var fielddesc = fieldname;
    $td = $('<td/>');
    $td.attr('class', fieldname);
    $td.html('<center><input type="text"  name="'+ fieldname +'" class="'+ fieldname +'" value="" id="'+fieldname+'" onclick="ERPLIST.handleThisSearchInputFieldClick(this);" /></center><div id="'+fieldname+'_displaySearchParams" style="background-color:yellow;"></div>');
    if ( hideColumns.indexOf(fieldname) >= 0 ) $td.css('display','none');
    $td.appendTo($tr);
  });
  $tr.appendTo($thead);
  $thead.appendTo($table);
  // end -----------------------------------------------------------------------------------------------------------------
  /**
   * second header row end -----------------------------------------------------------------------------------------------------------------------------------------------------------
   */

  if(hasData == 'no'){
    $thead.appendTo($table);
    //custom for no record found
    var $tr = $("<tr/>");
    // var numberOfColumn = $("#listTable > thead > tr:first > th:visible").length;
    var $td = $('<td/>').attr("colspan",countVisibleColumn);
    $td.html('No Data Found')
      .css({'text-align':'center','vertical-align':'middle'});
    $td.appendTo($tr);
    $tr.appendTo($table);
    return $table;
  }

  /**
   * populates with data--------------------------------------------------------------------------------------------------------------------------------------------------
   */
  var mydata = JSON.parse(mydata_json);
  $.each(mydata, function (index, value) {
    var $tr = $("<tr/>"); // it should be in here

    var thisRow = value;
    var thisRowCopy = thisRow;
    var thisRowCopy_Json =  JSON.stringify(thisRow);

    var formtype = thisRow['formtype'];
    var linestatus = thisRow['linestatus'];
    // generate button if needed
    var thisLineActionBtn = '';
    if(linestatus == 'Requisition Sent'){
      thisLineActionBtn = '<button type="button" class="mbutton delete" onclick="ERPLIST.handleLineEvolutionBtnAction(this)">Cancel this line</button>';
    } else if(linestatus == 'Requisition Planned'){
    }

    $td = $('<td/>');
    // $td.html(thisLineActionBtn);
    // $td.appendTo($tr);

    // process composite column first if has----------------------------------------------------------------------------------
    if(compositeColumnsLength > 0){
      $.each(ERPLIST.compositeColumns, function(groupName, groupColumns){
        $td = $('<td/>');
        $td.attr('class', groupName);
        $td.attr('fieldname', groupName);
        var compositeColumnsHTML = '';
        var divRow = '';
        $.each(groupColumns, function(fieldname, fieldprop){

          var fieldvalue = thisRow[fieldname];
          var fielddesc = (!!fieldprop.fielddesc) ? fieldprop.fielddesc : fieldname;
          var style = ( !!fieldprop.style ) ? 'style="' + fieldprop.style + '"': '';

          // *** write custom code here

          var obj_thisRowCopy_Json =  JSON.parse(thisRowCopy_Json);
          fieldvalue = (fieldname == "docnumber") ? "<a href='erpdocument.php?docnumber="+fieldvalue+"&doctype=T7&formtype="+formtype+"' target='_blank''>"+fieldvalue+"</a>" : fieldvalue;
          
          // *** custom code end

          divRow += '<div class="crow" '+ '' +'>';
          if( !!fieldprop.composite ){
            divRow += '<div class="ccell1 '+ fieldname +'" '+ style +'>'+ fielddesc +'</div>';
            divRow += '<div class="ccell2 '+ fieldname +'">:</div>';
          }
          divRow += '<div class="ccell3 '+ fieldname +'_ccell3" '+ style +'>'+ fieldvalue +'</div>';
          divRow += "</div>";

          delete thisRowCopy[fieldname]; // its already procceed
          $td_hide = $('<td/>');
          $td_hide.html(fieldvalue);
          $td_hide.attr("fieldname",fieldname);
          $td_hide.css('display','none');
          $td_hide.appendTo($tr);

        });

        var divTable = "<div id='ctable'>"; 
        divTable += divRow;  
        divTable += "</div>"; 

        compositeColumnsHTML = divTable;
        $td.html(compositeColumnsHTML)
          .css("cursor","pointer")
          .hover(
               function(){bgOn = $(this).closest("tr").css("background-color"); $(this).closest("tr").css("background-color", "lightblue");},
               function(){$(this).closest("tr").css("background-color", bgOn);}
             );
        $td.appendTo($tr);

      });
    }
    // end -----------------------------------------------------------------------------------------------------------------

    // precess rest of columns----------------------------------------------------------------------------------------------
    $.each(thisRowCopy, function (fieldname, fieldvalue) {

      // *** write custom code here
      fieldvalue = (fieldname == "docnumber") ? "<a href='erpdocument.php?docnumber="+fieldvalue+"&doctype=DR&formtype="+formtype+"&docviewflag=apparel' target='_blank''>"+fieldvalue+"</a>" : fieldvalue;
      // *** custom code end

      $td = $('<td/>');
        $td.html(fieldvalue)
          .css("white-space","pre-wrap")
          .attr("fieldname",fieldname)
          .css("cursor","pointer")
          .hover(
               function(){bgOn = $(this).closest("tr").css("background-color"); $(this).closest("tr").css("background-color", "lightblue");},
               function(){$(this).closest("tr").css("background-color", bgOn);}
             );
        if ( hideColumns.indexOf(fieldname) >= 0 ) $td.css('display','none');
        $td.appendTo($tr);
    });


    // *** custom code start-----------------------------------------------------------------------------------------
    // $tr.find('td.requiredinformation').append(thisLineActionBtn);
    // *** custom code end-------------------------------------------------------------------------------------------


    $tr.click( function() { 
        // sendBackSearchChoice($(this));
      })
      .appendTo($tbody);
  });

  $thead.appendTo($table)
  $tbody.appendTo($table)

  return $table;
};





/**
* Custom table generate code------------------------------------------------------------------------------------------------------
*/










/**
* Custom function code------------------------------------------------------------------------------------------------------
*/
ERPLIST.fuckingFunction = function(argument) {
}