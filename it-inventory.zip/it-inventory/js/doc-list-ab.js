/**
 * Declare the namespace LIZERP if not existent
 */
var LIZERP = LIZERP || {};

$.extend(LIZERP, {
  _ERP_DOCACRONYM: '',
  _FIELDSETS_HEADER: ['fieldset_documentinformation', 'fieldset_logisticsinformation', 'fieldset_projectinformation'],

  foo: 'here for no reason other than to be the last line, without a comma'
});





LIZERP.actionButton = function(){

  if ( $('#listSuccessDiv').css('display') == 'none' ){

    var cloneDiv = $('#listSuccessDiv').clone();
    cloneDiv.css({'display':'block'})
        .insertBefore('#listSuccessDiv')
        .find('#listSuccessMsg').text('sdfsferwerewrewr');
    
  } else if($('#listSuccessDiv').css('display') == 'block'){
    // element is block
    var cloneDiv = $('#listSuccessDiv').clone();
    cloneDiv.css({'display':'block'})
        .insertBefore('#listSuccessDiv')
        .find('#listSuccessMsg').text('this is success');

    var cloneDiv = $('#listWarningDiv').clone();
    cloneDiv.css({'display':'block'})
        .insertBefore('#listWarningDiv')
        .find('#listWarningMsg').text('this is warning');

    var cloneDiv = $('#listErrorDiv').clone();
    cloneDiv.css({'display':'block'})
        .insertBefore('#listErrorDiv')
        .find('#listErrorMsg').text('this is error');

  }

}






/**
 * Save form via ajax after validation
 */
LIZERP.saveForm = function() {
  // change data to actual uppercase from just css transform
  $(LIZERP.formId).find('input,textarea').each(function(i) {
    if ($(this).css('text-transform') == 'uppercase') $(this).val($(this).val().toUpperCase());
  });

  // run validation on all header fields
  var error = false;
  for (i in LIZERP._FIELDSETS_HEADER) {
    error = error || LIZERP.validateFormContainerFields(LIZERP.formId + ' #' + LIZERP._FIELDSETS_HEADER[i]);
  }


  // If all data is validated, then submit
  // var error;
  if (!error && LIZERP.formMode == 'edit') {
    // just to avoid re-entry, the server should also check for double submission
    LIZERP.readMode();

    /* Prepare JSON */
    var jsonData = {
      'lines': []
    };
    $.each(LIZERP.formFieldSettings['header'], function(fieldName, attributes) {
      jsonData[fieldName] = $(LIZERP.formId + ' #' + fieldName).val();
    });
    


    /* Submit via ajax */
    var postData = {
      reqType: 'saveDoc',
      docobj: JSON.stringify(jsonData)
    };
    // add iddocument in case this is an Edit
    if ($(LIZERP.formId + ' #docnumber').val().length > 0) postData.docnumber = $(LIZERP.formId + ' #docnumber').val();
    console.log(postData);
    $.ajax({
      type: 'post',
      url: LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM],
      //dataType: 'json',/* if the return data is json */
      data: postData,
      success: function(data) {
          // if result is JSON, we're using the new API return format
          console.log(data);
          data = JSON.parse(data);
          if (!!data.errormsgs && data.errormsgs.length > 0) {
            console.log(data.errormsgs.join('\n'));
            alert(data.errormsgs.join('\n'));
            LIZERP.editMode();
          } else {
            // LISTDOC.getListData(30,   1,    '');  
            LIZERP.hideFormInterface();
            // var next_href = window.location.origin + window.location.pathname + '?doctype=' + LIZERP._ERP_DOCACRONYM + '&ldcslnumber=' +;
            // window.location.href = next_href;
            location.reload();
          }
      }
    }).fail(function(e) {
      alert('Saving failed, please try again.');
      LIZERP.editMode();
    });
  }
  return;
}





















//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
LIZERP.displayFormInterface = function(){
  $('#formDiv').css({
    'display':'block',
    'floal': 'left',
  });
  LIZERP.adjustInterface();
}

LIZERP.hideFormInterface = function(){
  // alert($('#formDiv').length);
  if($('#formDiv').length > 0){
    $('#formDiv').css({
      'display':'none'
    });    
    // LIZERP.adjustInterface();
    LISTDOC.getListData(30,   1,    '');
  }
}


LIZERP.readThisDoc_N_FillInForm = function(docnumber){
  LIZERP.displayFormInterface();
  var searchParams = {
  'reqType': 'readDoc',
  'docnumber': docnumber
  };
  $.get(LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM], searchParams, populateFromDb);
  function populateFromDb(data, textStatus, jqXHR) {
    data = JSON.parse(data);
    if (Object.keys(data).length > 0) {
        LIZERP.fillForm(data);
        LIZERP.readMode();
        window.scrollTo(0, 0);
    } else {
      LIZERP.editMode();
      alert('Document not found.');
    }
  }

}


LIZERP.blankForm = function(){
  LIZERP.displayFormInterface();
  LIZERP.editMode();

  // var formId =  $("#formERP");
  // jsClient.resetForm(formId);
  // jsClient.clearForm(formId);
  LIZERP.handle_docdate_field();
}


LIZERP.initForm = function(){
var params = paramsToObj(window.location.search);
  if(!!params.ldcslnumber){
    $(LIZERP.formId).find('input#ldcslnumber').val(params.ldcslnumber);
    // alert(params.subdoclinenumber);
  }
}






$.extend(LIZERP, {
  /**
   * Start up function
   * @description Any JS code to be run on start up
   * @returns {undefined}
   */
  init: function() {
    /* executable JS */
    return;
  },
  enableRead: function() {
    LIZERP.readMode();
    return;
  },
  enableEdit: function() {
    LIZERP.editMode();
    return;
  },
  enableReceive: function() {
    LIZERP.receiveMode();
    return;
  },

  /**
   * Process Purchase Request Form
   * @param selector formId
   * @returns {undefined}
   */
  processForm: function(purchaseFormId, _ERP_DOCACRONYM, _URL_DOCUMENTAPI, _URL_DOCDEFINEAPI, isBlankForm) {
    LIZERP.formId = purchaseFormId + ' ';
    LIZERP.formMode = 'edit';
    LIZERP._ERP_DOCACRONYM = _ERP_DOCACRONYM;
    LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM] = _URL_DOCUMENTAPI;
    LIZERP._URL_DOCDEFINEAPI[LIZERP._ERP_DOCACRONYM] = _URL_DOCDEFINEAPI;

    var populatePromises = [];
    populatePromises.push(LIZERP.populateDropdown('company', 'company', 'LFI'));
    populatePromises.push(LIZERP.populateDropdown('buyername', 'Buyer','','codevalequal'));
    populatePromises.push(LIZERP.populateDropdown('orderstatus', 'OrderStatus', '', 'codevalequal'));        
    populatePromises.push(LIZERP.populateDropdown('iduom', 'UOM'));
    $.when.apply($, populatePromises).then(function() {
      // Caches the HTML of a new line
      // LIZERP.lineHTML_template = $('#fieldset_lineinformation table tr[data-id=1]')[0].outerHTML;
    });

    LIZERP.handle_docdate_field();
    /* Show/Hide/Enable/Disable fields on document load */
    LIZERP.handleFormFields('create');

    LIZERP.initForm(); 
    LIZERP.editMode();
    // LIZERP.readMode();


    $(window).keydown(function(e) {
      if (e.ctrlKey || e.metaKey) {
        switch (String.fromCharCode(e.which).toLowerCase()) {
          case 's':
            e.preventDefault();
            $('#upperButtonBar .btnSaveForm').click();
            break;
        }
      }
    });

    $('.btnSaveForm').on('click', function(e) {
      e.preventDefault();
      LIZERP.saveForm();
    });     

    $('#upperButtonBar .btnNew').on('click', function(e) {
      e.preventDefault();
      LIZERP.blankForm();
    });    

    $(LIZERP.formId + ' .btnNext').on('click', function(e) {
      e.preventDefault();
      var docnumber = $(LIZERP.formId + ' #docnumber').val();
      var next_href = window.location.origin + window.location.pathname + '?doctype=FL&formtype=default&dprnumber=' + docnumber + '&tabcontent=1';
      window.location.href = next_href;
      // LIZERP.blankForm();
    });     

    $(LIZERP.formId + ' .btnNext2').on('click', function(e) {
      e.preventDefault();
      var docnumber = $(LIZERP.formId + ' #docnumber').val();
      var next_href = window.location.origin + window.location.pathname + '?doctype=FL&formtype=default&dprnumber=' + docnumber + '&tabcontent=2';
      window.location.href = next_href;
      // LIZERP.blankForm();
    });

    $('#upperButtonBar .btnCancelForm').on('click', function(e) {
      e.preventDefault();
      // location.reload();
    });
    $('#rightFormButtons .btnCancelForm').on('click', function(e) {
      e.preventDefault();
      // location.reload();
    });


    $(' .btnEnterEditMode').on('click', function(e) {
      e.preventDefault();
      LIZERP.editMode();
    });

    $(LIZERP.formId + ' .btnPrintSheet').on('click', function(e) {
      e.preventDefault();
      var params = paramsToObj(window.location.search);
      window.open('printdoc-v3.php?doctype=' + params.doctype + '&docnumber=' + params.docnumber);
    });

    $(LIZERP.formId + ' .btnChangeDocStatus').on('click', function(e) {
      e.preventDefault();
      if (confirm('Click OK to send to WMS')) LIZERP.changeDocStatus();
    });


    // If the page was called with a document ID, try to read the record
    var params = paramsToObj(window.location.search);
    if (!!params.docnumber) {
      var searchParams = {
        'reqType': 'readDoc',
        'docnumber': params.docnumber
      };
      $.when.apply($, populatePromises).then(function() {
        $.get(LIZERP._URL_DOCUMENTAPI[LIZERP._ERP_DOCACRONYM], searchParams, populateFromDb);
      });
    } else {
        // not call from blank form
        // and has not doc number
        // if(!isBlankForm) LIZERP.addRelatedDocsTable();
    }

    function populateFromDb(data, textStatus, jqXHR) {
      // alert(data);
      data = JSON.parse(data);
      var lines = data.lines;
      delete data.lines;
      if (Object.keys(data).length > 0) {
        $.when.apply($, populatePromises).then(function() {
          LIZERP.fillForm(data, lines);
          LIZERP.readMode();
          window.scrollTo(0, 0);
        });
      } else {
        LIZERP.editMode();
        alert('Document not found.');
      }
    }

    return;
  }
});


var erpdocument = {};
erpdocument.processForm = function(formId, _ERP_DOCACRONYM, _URL_DOCUMENTAPI, _URL_DOCDEFINEAPI) {
  LIZERP.processForm(formId, _ERP_DOCACRONYM, _URL_DOCUMENTAPI, _URL_DOCDEFINEAPI);
}




























var dragging = false;
   $('#dragbar').mousedown(function(e){
       e.preventDefault();
       
       dragging = true;
       var main = $('#rightFormDiv');
       var ghostbar = $('<div>',
                        {id:'ghostbar',
                         css: {
                                height: main.outerHeight(),
                                top: main.offset().top,
                                left: main.offset().left
                               }
                        }).appendTo('body');
       
        $(document).mousemove(function(e){
          ghostbar.css("left",e.pageX+2);
       });
       
    });

   $(document).mouseup(function(e){
       if (dragging) 
       {
           var percentage = (e.pageX / window.innerWidth) * 100;
           var mainPercentage = 100-percentage;
           
           $('#leftListDiv').css("width",percentage + "%");
           $('#rightFormDiv').css("width",mainPercentage + "%");
           $('#ghostbar').remove();
           $(document).unbind('mousemove');
           dragging = false;
       }
    });