<?php
require_once $_SERVER["DOCUMENT_ROOT"] . '/includes/user.cookies.php';    // check user login
require_once $_SERVER["DOCUMENT_ROOT"] . '/includes/config.php';          // mysql connections
require_once $_SERVER["DOCUMENT_ROOT"] . '/includes/user-privilege.php';  // privilege function
// check privilege (keep module and section empty to skip privilege check)
$module = "";
$section = "";
$privilege = userPrivileges($module, $section);
if (!$privilege['R']) { header("Location: ../user/no-permission.php"); exit();}

$status = $_GET['linestatus'];
// $unitprice = $_GET['unitprice'];
// $procurer = $_GET['purchasemode'];

$formTitle = "Realeased Requisition List";
$pageTittle= "Realeased Requisition List"; 

// if($unitprice == '0'){
//     $formTitle = "Zero Price Requisition List";
//     $pageTittle= "Zero Price Requisition List"; 

// }else if($procurer == 'blank'){
//     $formTitle = "Un-Assigned Requisition List";
//     $pageTittle= "Un-Assigned Requisition List"; 

// }else{
//     $formTitle = "PO Creation Requisition List";
//     $pageTittle= "PO Creation Requisition List";  
// }

$mainHTML  = 'html/listerp.html';
// $customHTML= 'html/list-new-rr-lines.html';
$mainJS    = 'js/list-erp.js?t=2018-05-24';
$customJS  = 'js/list-rr-released.js?t=2018-05-24';
$apiURL    = 'list-rr-released_api.php';
$formId    = 'searchForm';

$module = "";
$section = "";
$privilege_sm = json_encode(userPrivileges($module,$section));

$environment = ''; 
if( isset($_GET['rrtype']) && $_GET['rrtype'] == 'Direct'){
    $environment = ' (Direct Environment)';
}
?>

<!DOCTYPE HTML>
<html>
<head>
	<?php require_once($_SERVER["DOCUMENT_ROOT"] . "/includes/head.php") ;?>
	<title><?php echo $formTitle;?></title>

	<link rel="stylesheet" type="text/css" href="css/listerp.css">
	<link rel="stylesheet" type="text/css" href="css/list-yourname.css">
    <link rel="stylesheet" type="text/css" href="css/material-button.css">
	<link rel="stylesheet" type="text/css" href="plugin/msgPop.css">
</head>
<body class="right-sidebar">

<!-- Header Wrapper -->
<div id="header-wrapper">
<div class="container">
<div class="row">
<div class="12u">
<!-- Header -->
	<header id="header">
		<?php 
		include_once($_SERVER["DOCUMENT_ROOT"] . "/includes/mainmenu.php");
		?>
	</header>
</div>
</div>
</div>
</div>

<!-- Main Wrapper -->
<div id="main-wrapper">
<div class="container">
<div class="row">
	<div class="12u skel-cell-important">
        <!-- Content -->
        <div id="content">
        <article class="last">
    <!-- HEADLINES -->
        <div class="headline1"><a href="/erp-nonpo/documents-home.php">Home</a> - </div>   
        <div class="headline2"><?php echo $formTitle;?></a></div> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<!-- LINKS -->
        <?php
        

        ?>
        <br><br><br>
        <div id='tabsalesorder'></div>   
        <!-- <br><br><br> -->
        <div id="upperButtonBar" style="height:50px;">
    <input type="button" class="btn-grey" value="Export to Execl" title="Export to Execl" onclick="ERPLIST.exportToExecl();" style="display: inline-block;">
        </div>
<!-- PAGE CONTENTS -->
<?php
include $mainHTML;
?>
		</article>
		</div>
	</div>

</div>
</div>
</div>


<!-- Footer Wrapper -->
<div id="footer-wrapper">
	<?php include_once($_SERVER["DOCUMENT_ROOT"] . "/includes/footer.php") ;?>
</div>
<script type="text/javascript" src="plugin/fancybox/source/jquery.fancybox.js"></script>
<script type="text/javascript" src="plugin/msgPop.js"></script>
<script type="text/javascript" src="api/client_api.js"></script>
<script type="text/javascript" src="<?php echo $mainJS. '?v=2018-05-24'; ?>"></script>	
<script type="text/javascript" src="<?php echo $customJS. '?v=2018-05-24'; ?>"></script>	
<script type="text/javascript">
$(document).ready(function() {
	var apiURL = '<?php echo $apiURL;?>';
	//                  show, 	page, 	api_url
    ERPLIST.getListData(100,		1, 		apiURL);

    //success msg show 
    params = jsClient.paramsToObj(window.location.search);
    if(!!params.sMsg && params.sMsg != ''){
        var cloneDiv = $('#listSuccessDiv').clone();
        cloneDiv.css({'display':'block'})
          .insertBefore('#listSuccessDiv')
          .find('#listSuccessMsg').text(params.sMsg);
    }
});	
</script>
</body>
</html>