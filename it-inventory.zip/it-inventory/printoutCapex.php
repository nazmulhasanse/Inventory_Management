<?php
//--->Author_Nazmul
session_start();
require_once __DIR__ . "/classes/config.php";
require_once __DIR__ . "/classes/myclassautoloader.php";

class GatePassPrintFormat
{
  public $conn;

  public function __construct() {
    $this->conn = new ErpDbConn;

    // Load Entity Attribute through constructor
    // parent::__construct();
  }

  ////////////////////////////////////////----------------Take Parts & Send Mail---------------------/////////////////////////////////////////
  function printGatePassDetail(){

    $docnumber = $_GET['docnumber'];
    $flag = $_GET['flag'];

    date_default_timezone_set("Asia/Dhaka");
    $today_date = date('Y-m-d');

    $sql = "SELECT * FROM erp_requisition g LEFT JOIN erp_requisition_library l ON g.username = l.username WHERE g.docnumber = '$docnumber' LIMIT 1";
    $queryResult = $this->conn->query($sql);
    $rows = $queryResult->fetch_assoc();

    $DocDate       = $rows['docdate'];
    $docstatus     = $rows['docstatus'];
    $TKNumber      = $rows['trackingnumber'];
    $Division      = $rows['companydescription'];
    $Department    = $rows['departmentdescription'];
    $Section       = $rows['sectiondescription'];
    $EmployeeID    = $rows['entrypersonbadge'];
    $Requester     = $rows['username'];
    $Budget        = $rows['budget'];
    $Balance       = $rows['balance'];
    $Utilized      = $rows['utilized'];
    $isreplacement = $rows['isreplacement'];
    $innew         = $rows['innew'];
    $isbudgeted    = $rows['isbudgeted'];
    
    $sql = "SELECT l.Zone AS Zone FROM erp_requisition g LEFT JOIN mrd_library l ON g.company = l.Code WHERE g.docnumber = '$docnumber' LIMIT 1";
    $queryResult = $this->conn->query($sql);
    $rows = $queryResult->fetch_assoc();

    $CompanyAddress  = $rows['Zone'];

    $sql = "SELECT SUM(amount) AS totalAmount FROM erp_requisition WHERE docnumber = '$docnumber'";
    $queryResult = $this->conn->query($sql);
    $totalAmount = $queryResult->fetch_assoc()['totalAmount'];

    $sql = "SELECT SUM(quantity) AS totalQuantity FROM erp_requisition WHERE docnumber = '$docnumber'";
    $queryResult = $this->conn->query($sql);
    $totalQuantity = $queryResult->fetch_assoc()['totalQuantity'];

    
    if($docnumber != ''){

        echo "<html>";

        echo "<header><title>ICT Capex Requisition</title></header>";
        echo "<button id = 'printPageButton' onclick = 'window.print()'>Print</button>";
        echo "<body style = 'padding: 1% 1% 1% 1%'>";

        echo "<table>
                <tr>
                    <td text-align='left'><b>LDC Group - BANGLADESH</b></td>
                    <td text-align='center'>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</td>
                    <td text-align='center'>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</td>
                    <td text-align='center'>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</td>
                    <td text-align='right'><b>Date : $DocDate</b></td>
                </tr>
                </table>";

        echo "<table>
                <tr>
                    <td text-align='left'><b>APPROVAL REQUEST for CAPEX</b></td>
                    <td text-align='center'>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</td>
                    <td text-align='center'>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</td>
                    <td text-align='center'>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</td>
                    <td text-align='right'><b>Tracking No. : &emsp;&nbsp; $docnumber</b></td>
                </tr>
                </table>";

        echo "<div id='example2' style='font-size:16pt; font-family:Calibri; text-align:center;'> 
        		<tr><b>$Division</b></tr>
    		  </div>";
        // echo "<div style='font-size:10pt; font-family:Calibri; text-align:center;'><b>$CompanyAddress</b></div>";

        echo "<br>
            <table>

                <tr style='text-align:left;'>
                <td><b>Request From</b>
                <td><b>Section</b><td> : </td><td>$Section</td>
                <td><b>Department</b><td> : </td><td>$Department</td>
                </tr>

                <tr style='text-align:left;'>
                <td><b>Budgeted</b><td> : </td><td>$isbudgeted</td>
                <td><b>If YES, Amount in BDT</b></td>
                <td><b>Budget</b></td><td> : </td>
                </tr>

                <tr style='text-align:left;'>
                <td><b></b><td></td><td></td>
                <td></td><td><b>Utilized</b><td> : </td><td>$Utilized</td>
                </tr>

                <tr style='text-align:left;'>
                <td><b>Replacement</b><td> : </td><td>$isreplacement</td>
                <td></td><td><b>Balance</b><td> : </td><td>$Balance</td>
                </tr>

            </table>
            <br>";

        echo "<div id='example2'> 
                <tr><b>CAPEX</b> means vis-a-vis Fixed Assets covering all kind of Properties, Plant & Equipment (PPE) as per accounting term. In principle the expenditures are incurred or the amount is spent for aquiring or upgrading assets as are using directly or indirectly for generating revenue and the benefits of the expenditures continue over a long period at least three years with a minimum value of BDT 10,000/-</tr>
            </div>";

        echo "<div> 
                <tr><b>CAPEX Description with UOM & Quantity, Rate & Value</b></tr>
              </div>";

        $sql = "SELECT * FROM erp_requisition WHERE docnumber = '$docnumber'";
        $queryResult = $this->conn->query($sql);
        
        $gatepasslines = "";

        while ($rows = $queryResult->fetch_assoc()) {
                    
            $LineNo        =  $rows['linenumber'];
            $ItemDes       =  $rows['itemdescription'];
            $UOMone        =  $rows['iduom'];
            $Quantity      =  $rows['quantity'];
            $Price         =  $rows['amount'];
            $usefullife    =  $rows['usefullife'];
            $inhouseperiod =  $rows['inhouseperiod'];

        $gatepasslines .= "<tr>
                                    <td>$LineNo</td> 
                                    <td>$ItemDes</td> 
                                    <td>$UOMone</td>  
                                    <td>$Quantity</td>  
                                    <td>$Price</td>    
                                    <td>$usefullife</td>  
                                    <td>$inhouseperiod</td>  
                            </tr>";
                                    
        }

        $totalLineQuantity = "<tr >
                                    <td colspan='3' align='right'><b>Total &nbsp;&nbsp;<b></td>
                                    <td colspan='1'>$totalQuantity</td>
                                    <td>$totalAmount</td>
                               </tr>";

        $gatepasslines = $gatepasslines . $totalLineQuantity;
        
        echo "
            <div>
                <table border='1' cellpadding='0' cellspacing='0' depth ='0'>
                    <tr>
                        <th>Line No.</th>  
                        <th>Item Description</th>  
                        <th>UOM</th>  
                        <th>Quantity</th>  
                        <th>Amount in BDT</th>  
                        <th>Useful Life</th>  
                        <th>Inhouse Period</th>  
                    </tr>
                    $gatepasslines
                </table>
            </div><br>";

            echo "<div> 
                    <tr><b>Justification</b></tr>
                </div>";

            echo "<div id='example2'> 
                    <tr><b>Usage & Compliance Benefits</b></tr>
                </div>";

            echo "<table>
                    <tr>
                        <td id='example5'></td>
                    </tr>
                </table>";

            echo "<div id='example4'> 
                    <tr><b>Economic Benefits</b></tr>
                </div>";


            echo "<table>
                    <tr>
                        <td id='example5'></td>
                    </tr>
                </table>";

            echo "<div id='example4'> 
                    <tr><b>Est. Maintenance & Service Costs (per year in % of Total CAPEX)</b></tr>
                </div>";


            echo "<table>
                    <tr>
                        <td id='example6'></td>
                    </tr>
                </table>";

            echo "<br>";

            echo "<div style='font-size:10pt;'>
                <tr>
                    <td><b>(1) Requested by: User Section (Centre) Head</b></td>
                    <td>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp;</td>
                    <td><b>(3) Approved by: COO</b></td>
                </tr>
                </div>
                
                <table>
                <tr>
                    <td id='example1'></td>
                    <td></td>
                    <td id='example1'></td>
                </tr>
                </table>

                <table>
                <tr>
                    <td><i>Signature & Date</i></td>
                    <td></td>
                    <td><i>Signature & Date</i></td>
                </tr>
                </table>
            ";
                
            echo "<br>";

            echo "<div style='font-size:10pt;'>
                <tr>
                    <td><b>(2) Approved by: User Department Head</b></td>
                    <td>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp;</td>
                    <td><b>(4) Approved by: CEO / on behalf of</b></td>
                </tr>
                </div>
                
                <table>
                <tr>
                    <td id='example1'></td>
                    <td></td>
                    <td id='example1'></td>
                </tr>
                </table>

                <table>
                <tr>
                    <td><i>Signature & Date</i></td>
                    <td></td>
                    <td><i>Signature & Date</i></td>
                </tr>
                </table>

            </body>
        </html>";

    } 



  }

}


$obj = new GatePassPrintFormat();
$obj->printGatePassDetail();

?>
    


<style type="text/css">

table {
  border-collapse: collapse;
  text-align: center;
  min-width: 100%;
  font-size: 10pt;
}


#example1 {
  border: 1px solid;
  padding: 25px;
}

#example2 {
  border: 1px solid;
  padding: 1px;
  font-size:10pt;
  
}
#example3 {
  border: 1px solid;
  padding: 1px;
  border-top: none;
}

#example4 {
  border: 1px solid;
  padding: 1px;
  font-size:10pt;
  border-top: none;
}

#example5 {
  border: 1px solid;
  padding: 25px;
  border-top: none;
}

#example6 {
  border: 1px solid;
  padding: 15px;
  border-top: none;
}




@media print {
  #printPageButton {
    display: none;
  }

  #newPage {
    page-break-after: always;
  }
}
</style>



