<?php
session_start();
require_once $_SERVER["DOCUMENT_ROOT"] . '/includes/configli.php'; // mysql connections
require_once __DIR__ . "/classes/myclassautoloader.php";
/**
* ThisDocAPI class
*/
// class ThisDocAPI extends BaseDocAPI
class ThisDocAPI extends ErpDocListAB
{

	function __construct(){

		$this->docStatusTranslatorF  = array('0' => 'Entered', '1' => 'Requisition Sent', '2' => 'Closed');
		$this->docStatusTranslatorB  = array('Entered' => '0', 'Requisition Sent' => '1', '2' => 'Closed');
		$this->lineStatusTranslatorF = array('0' => 'Entered', '1' => 'Requisition Sent', '2' => 'Requisition Planned');
		$this->lineStatusTranslatorB = array('Entered' => '0', 'Requisition Sent' => '1', 'Requisition Planned' => '2');

	}

	function saveDoc($docdata){

		$genericDocument = new ErpDocListAB();
		$formStructure = json_encode($genericDocument->formStructure('AB', 'default', 'crudmode'), JSON_PRETTY_PRINT);		

		$docobj = json_decode($docdata, true);
		if(isset($docobj['docnumber']) && $docobj['docnumber'] != ""){ // update Doc
			$returnJSON = $this->updateDoc($docdata, $formStructure);
			return json_encode($returnJSON);	
		} else {													   // create Doc
			$returnJSON = $this->createDoc($docdata, $formStructure);
			return json_encode($returnJSON);
		}
	}

	function createDoc($docdata, $formStructure){
		$conn = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$formStructure = json_decode($formStructure, true);
		$tablename = $formStructure['schema']['tablename'];
		$doctype   = $formStructure['header']['doctype'];
		$formtype  = $formStructure['header']['formtype'];

		$docobj = json_decode($docdata, true);
		// doc input value validation
		$vldObj = new Validation();
		$returnJSON->errormsgs = $vldObj->validDocobj($formStructure, $docobj);
		if (count($returnJSON->errormsgs) > 0) {
			array_push($returnJSON->errormsgs, "Document was not saved.");
			return $returnJSON;
		}

		// generate Entity number and line number
		$returnData = $this->checkEntityNumberCreatedAndGetNextLineNumber($docobj['ldcslnumber']);
		if($returnData['entitynumber'] == ''){
			$entitynumber = $this->getNextDocNumber('counter_BOM');
			$docobj['entitynumber'] = $entitynumber;
			$docobj['linenumber'] = '1';
			$docobj['doclinenumber'] = $entitynumber . "-1";
		} else {
			$docobj['entitynumber'] = $returnData['entitynumber'];
			$docobj['linenumber'] =  (int)$returnData['numberofline'] + 1;	
			$docobj['doclinenumber'] = $returnData['entitynumber'] . "-" . ( (int)$returnData['numberofline'] + 1 );	
		}

		$returnJSON = $this->_createDoc(json_encode($docobj), json_encode($formStructure));
		return $returnJSON;

	}



	function checkEntityNumberCreatedAndGetNextLineNumber($ldcslnumber){
		$conn = new ErpDbConn;
		$returnData = array(
			'entitynumber' => '',
			'numberofline' => 0,
		);

		$sql = "SELECT entitynumber FROM tnx_bom_accessory WHERE ldcslnumber = '$ldcslnumber'";
		$queryResult = $conn->query($sql);
		$numberofline = $queryResult->num_rows;
		if( $numberofline> 0){
			$row = $queryResult->fetch_assoc();
			$returnData['entitynumber'] = $row['entitynumber'];
			$returnData['numberofline'] = $numberofline;
		}
		$conn->close();
		return $returnData;
	}


	function updateDoc($docdata, $formStructure){
		$conn = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$formStructure = json_decode($formStructure, true);
		$tablename = $formStructure['schema']['tablename'];   

		$newdocobj = json_decode($docdata, true);
		$docnumber = $newdocobj['docnumber'];
		// doc input value validation
		$vldObj = new Validation();
		$returnJSON->errormsgs = $vldObj->validDocobj($formStructure, $newdocobj);
		if (count($returnJSON->errormsgs) > 0) {
			array_push($returnJSON->errormsgs, "Document was not saved.");
			return $returnJSON;
		}

		$docLinesArray = $newdocobj['lines']; // format: lines = array(0 => array, 1 => array, ....)
		unset($newdocobj['lines']);
		$docHeaderArray = $newdocobj;

		$newdocobj['lines'] = $docLinesArray;

		$returnJSON = $this->_updateDoc(json_encode($newdocobj), json_encode($formStructure));

		return $returnJSON;

	}



	function readDoc($docnumber){

		$genericDocument = new ErpDocListAB();
		$formStructure = json_encode($genericDocument->formStructure('AB', 'default', ''), JSON_PRETTY_PRINT);

		$docnumber = $_GET['docnumber'];
		$docData = $this->_readDoc($docnumber, $formStructure);
		$docObj = json_decode($docData, true);
		// $docObj['docstatus'] = $this->docStatusTranslatorF[$docObj['docstatus']];

		return json_encode($docObj);

	}

	function removeLine($doclinenumber){

		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();
		$conn = new ErpDbConn;
		$sql = "DELETE FROM tnx_bom_accessory WHERE doclinenumber = '$doclinenumber'";
		$queryResult = $conn->query($sql);

		return json_encode($returnJSON);

	}


	function importAccesoryBOM($ldcslnumber, $toldcslnumber){

		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$conn = new ErpDbConn;
		$sql = "SELECT * FROM tnx_bom_accessory WHERE ldcslnumber = '$ldcslnumber'";
		$data = json_decode( $conn->sqlToJson($sql), true);

		// check and retrive
		$entitynumber = '';
		$numberofline = 1;
		$returnData = $this->checkEntityNumberCreatedAndGetNextLineNumber($toldcslnumber);
		if($returnData['entitynumber'] == ''){
			$entitynumber = $this->getNextDocNumber('counter_BOM');
		} else {
			$entitynumber = $returnData['entitynumber'];
			$numberofline =  (int)$returnData['numberofline'] + 1;	
		}

		// insert query prepare
		foreach ($data as $indx => $line) {
			$docnumber = $this->getNextDocNumber('counter_ABL');

			$line['entitynumber'] = $entitynumber;
			$line['docnumber'] = $docnumber;
			$line['doclinenumber'] = $entitynumber . "-" . $numberofline;
			$line['linenumber'] = $numberofline;

			$line['ldcslnumber'] = $toldcslnumber;
			$numberofline++;

			unset($line['idlines']);
			unset($line['ID']);
			unset($line['bookingformid']);

			$columnFields = array_keys($line);
			$fieldValues = array_values($line);

			$columnFields = implode(',', $columnFields);
			$fieldValues = "'" . implode("', '", $fieldValues) . "'";

			$sql = "INSERT INTO tnx_bom_accessory ($columnFields) VALUES($fieldValues);";
			// return $sql;
			$conn->query($sql);
		}

		return json_encode($returnJSON);
	}



}


/**
 * Routing ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 */
if ( basename(__FILE__) == basename($_SERVER["SCRIPT_FILENAME"]) ) {
    // called directly
	if ( $_SERVER['REQUEST_METHOD'] == 'GET' ) {

		if(isset($_GET['reqType'])){

			$reqType = $_GET['reqType'];
			$obTest  = new ThisDocAPI();

			if($reqType == 'readDoc') {

				$docnumber = $_GET['docnumber'];
				$returnData = $obTest->readDoc($docnumber);
				echo $returnData;
			}

			if($reqType == '_searchDoc') {
				$genericDocument = new ErpDocListAB();
				$formStructure = json_encode($genericDocument->formStructure($formtype, $crudmode), JSON_PRETTY_PRINT);

				$where = $_GET['where'];
				$columns = $_GET['columns'];
				$returnData = $obTest->_searchDoc($formStructure, $where, $columns);
				echo $returnData;
			}


		}


	} else if( $_SERVER['REQUEST_METHOD'] == 'POST' ){
	
		if(isset($_POST['reqType'])){

			$reqType = $_POST['reqType'];
			$obTest  = new ThisDocAPI();

			if($reqType == "saveDoc"){
		
				$docobj = $_POST['docobj'];
				$returnData = $obTest->saveDoc($docobj);
				echo $returnData;
			}

			if($reqType == "removeLine"){
		
				$doclinenumber = $_POST['doclinenumber'];
				$returnData = $obTest->removeLine($doclinenumber);
				echo $returnData;
			}

			if($reqType == "importAccesoryBOM"){
		
				$ldcslnumber = $_POST['ldcslnumber'];
				$toldcslnumber = $_POST['toldcslnumber'];
				$returnData = $obTest->importAccesoryBOM($ldcslnumber, $toldcslnumber);
				echo $returnData;
			}

		}



	}

} else {
    // included/required

}
?>