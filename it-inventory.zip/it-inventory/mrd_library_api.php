<?php
// require_once "../includes/db_credentials.php";
require_once "../includes/database_lib.php";

if (basename(__FILE__) == basename($_SERVER["SCRIPT_FILENAME"])) {
  // called directly
  if ($_SERVER['REQUEST_METHOD'] == 'GET') {

    if (isset($_GET['library'])) {
      // echo "<pre>" . getLibrary($_GET['library']) . "</pre>";
      echo getLibrary($_GET);

    } else {
      die("Library not specified!");
    }

  } else {
    die("Only GET method is acceptable!");
  }

} else {
  // included/required
}

function getLibrary($params) {
  // for compatiblity with old code, accept strings
  if (is_string($params)) {
    $library = $params;
  } else {
    $library = $params['library'];
  }

  $conn    = connectOrDie();
  $library = $conn->real_escape_string($library);

  if ($library == 'itemtype') {

    $sql = "SELECT ItemType AS Code, ItemDescription AS Description FROM mrd_itemtype_description ORDER BY ItemType";

  } elseif ($library == 'pdlocation') {

    if (isset($params['company'])) {
      $company = $params['company'];
      $sql     = "SELECT child.idmrd_location AS Code, child.locationname AS Description
              FROM erpprod.mrd_location child
              JOIN erpprod.mrd_location parent ON child.idparentlocation = parent.idmrd_location
              WHERE child.locationtype = 'PD'
                    AND parent.locationname IN (SELECT Description FROM erpprod.mrd_library WHERE LibraryName = 'company' AND Code = '$company')
              ";
    } else {
      $sql = "SELECT idmrd_location as Code, locationname as Description FROM erpprod.mrd_location WHERE locationtype = 'PD'";
    }

  } elseif ($library == 'docstatus') {

    if (isset($params['doctype'])) {
      $doctype = $params['doctype'];
    } else {
      die('doctype is not specified!');
    }

    $sql = "SELECT statuscode AS Code, statusdesc AS Description FROM mrd_docstatus WHERE doctype = '$doctype' ORDER BY statuscode";

  } elseif ($library == 'companycode') {
    
    $sql = "SELECT companycode, companydescription FROM erp_requisition_library GROUP BY $library";
    $result = $conn->query($sql);
    $conn->close();
    
    $libraryArray = array();
    while ($row = $result->fetch_assoc()) {
      $Code                = $row['companycode'];
      $libraryArray[$Code] = $row['companydescription'];
    }

    return json_encode($libraryArray, JSON_PRETTY_PRINT);

  } elseif ($library == 'departmentcode') {
    
    $sql = "SELECT departmentcode, departmentdescription FROM erp_requisition_library GROUP BY $library";
    $result = $conn->query($sql);
    $conn->close();
    
    $libraryArray = array();
    while ($row = $result->fetch_assoc()) {
      $Code                = $row['departmentcode'];
      $libraryArray[$Code] = $row['departmentdescription'];
    }

    return json_encode($libraryArray, JSON_PRETTY_PRINT);

  } elseif ($library == 'sectioncode') {
    
    $sql = "SELECT sectioncode, sectiondescription FROM erp_requisition_library GROUP BY $library";
    $result = $conn->query($sql);
    $conn->close();
    
    $libraryArray = array();
    while ($row = $result->fetch_assoc()) {
      $Code                = $row['sectioncode'];
      $libraryArray[$Code] = $row['sectiondescription'];
    }

    return json_encode($libraryArray, JSON_PRETTY_PRINT);

  } elseif ($library == 'username') {
    
    $sql = "SELECT username FROM erp_requisition_library GROUP BY $library";
    $result = $conn->query($sql);
    $conn->close();
    
    $libraryArray = array();
    while ($row = $result->fetch_assoc()) {
      $Code                = $row['username'];
      $libraryArray[$Code] = $row['username'];
    }

    return json_encode($libraryArray, JSON_PRETTY_PRINT);

  } else {
    $sql = "SELECT Code, Description FROM mrd_library WHERE LibraryName = '$library' ORDER BY Description";
  }

  $result = $conn->query($sql);
  $conn->close();

  $libraryArray = array();
  while ($row = $result->fetch_assoc()) {
    $Code                = $row['Code'];
    $libraryArray[$Code] = $row['Description'];
  }

  return json_encode($libraryArray, JSON_PRETTY_PRINT);
}

?>