<?php
/********************************
 **Author: Al-Mamun    **
 **Module Name: document   **
 **Crated date: 2017-01-14 **
 ********************************/
/*
 * Check if we have iddocument
 * Get json data for this document and decode
 * Get the definition from erpdocument_define.php
 * include printdocdefine file
 * Decode data using library (if necessary) and overwrite value
 * Process Barcode
 * Quantity processing for item-lot-element
 * Unset unnecessary line element
 * Getting unique value and re-index array
 * Push calculated total value in line array
 * Draw Head Table
 * Draw Line Table
 * Draw Net Total Table
 * Draw GatePass Table
 * Draw Signature Table
 * Draw Notes Table
 */
session_start();
$directory = __DIR__ ;
require_once __DIR__ . "/classes/config.php";
require_once __DIR__ . "/classes/myclassautoloader.php";

/**
* Print Document Class
*/
class PrintDoc extends GeneralPrintDoc
{
	private $printFormat;
	public $docdefine;
	public $printdocdefine;
	private $printParams = array();

	function __construct($doctype, $formtype){
		/*
		 * Get the definition from erpdocument_define.php
		 */
		$serverUrl = "http://";
		$serverUrl .= $_SERVER["SERVER_NAME"];
		$serverUrl .= ($_SERVER["SERVER_PORT"] != "80") ? ":" . $_SERVER["SERVER_PORT"] : "";

		$rootPath = $_SERVER['DOCUMENT_ROOT'];
		$thisPath = dirname($_SERVER['PHP_SELF']);
		$onlyPath = str_replace($rootPath, '', $thisPath);
		$docdefine = file_get_contents("$serverUrl/$onlyPath/erpdocument_define.php?doctype=$doctype&formtype=$formtype&crudmode=read");
		$this->docdefine = $docdefine;
		// echo $docdefine;
	}

	public function printPage($printParams){

		$pageTittle = $printParams['pageTittle'];
		$company = $printParams['company'];
		$companyAddress = $printParams['companyAddress'];
		$docTittle = $printParams['docTittle'];
		$docSubTittle = $printParams['docSubTittle'];
		$headTable  = $printParams['headTable'];
		$lineTable  = $printParams['lineTable'];
		$notesTable  = $printParams['notesTable'];
		$gatePassPage  = $printParams['gatePassPage'];

echo <<<EOF
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
	<title>$pageTittle</title>
	<link rel="stylesheet" type="text/css" href="css/printdoc.css?t=3">
</head>
<body onload="printDiv('printed_content')">

<div id="printed_content">
	<div id="wrapper">
	<!-- //========== Generic Model =========-->
	<div id="div_companyinfo">
	  <p id="div_companyinfo_name">$company</p>
	  <p id="div_companyinfo_address">$companyAddress</p>
	</div>
	<div id="div_doctittle">$docTittle</div>
	<div id="div_docsubtittle">$docSubTittle</div>
	<!-- //========== Generic Model =========-->
	$headTable
	$lineTable
	$notesTable
	$varSignTable

	<div class="newpage">
	$gatePassPage
	</div>


	</div> <!-- wrapper div end -->
</div>  <!-- print content div end -->

<script type="text/javascript">
function printDiv(divName) {
   var printContents = document.getElementById(divName).innerHTML;
   var originalContents = document.body.innerHTML;

   document.body.innerHTML = printContents;
   window.print();
   document.body.innerHTML = originalContents;
}
</script>
</body>
</html>
EOF;

	} 

	function getNotes_printFormat($docdefine, $printdocdefine){
		$doctype    = $_GET['doctype'];
		if ($doctype == 'PO' || $doctype == 'BOM' || $doctype == 'CP' || $doctype == 'TI'){

			if ($printdocdefine['hasNotesTable']) {
			  	$varNotesTable = 
			  	'<div id="div_notes">
			      	<p>' . $printdocdefine['note'] . '</p>
			      	<table id="notestable">
			        	<tr>
			          		<td id="notestable_td2"><dt id="notes_dt2"><span></span></dt></td>
			          		<td id="notestable_td2"><dt id="notes_dt2"><span></span></dt></td>
			          		<td id="notestable_td2"><dt id="notes_dt2"><span></span></dt></td>
			          		<td id="notestable_td2"><dt id="notes_dt2"><span></span></dt></td>
			        	</tr>
			        	<tr>
			          		<td id="notestable_td2">Receiver Signature</td>
			          		<td id="notestable_td2">Security Incharge</td>
			          		<td id="notestable_td2">Store Officer</td>
			          		<td id="notestable_td2">Authorized Signature</td>
			        	</tr>
			     	</table>
			    </div>';
			} else {
			  $varNotesTable = "";
			}

			return $varNotesTable;
		}

	}

	function getLineTable_printFormat($docdata, $doclines, $docdefine, $printdocdefine){
		$varLineTable = "";

		if($printdocdefine['hasLineTable'] == false){

			$varLineTable .= "</br>";

		  	$lineTableStructure = $printdocdefine['linetable'];

		  	$varLineTable .= "<table class='print' id='linetable'>";
		  	$varLineTable .= "<thead>";
		  	$varLineTable .= "<tr>";
		  	foreach ($lineTableStructure as $columnKey => $columnFields) {
		    	$varLineTable .= "<th>" . $columnKey . "</th>";
		  	}
		  	$varLineTable .= "</thead>";
		  	$varLineTable .= "<tbody>";

		    //========= from data loop =========
		  	foreach ($doclines as $index => $linedata) {
		    	$i = 0;
		    	$varLineTable .= "<tr>";
		    	foreach ($lineTableStructure as $columnKey => $columnFields) {
			      	$i++;
			      	// if columnFields is array then break down			      	
			      	if(is_array($columnFields)){
			      		$varLineTable .=  "<td class='linetable_td' id='linetable_td" . $i . "'>";
				      	// break down td
				      	foreach ($columnFields as $key => $value) {

				        	if (isset($docdefine['lines'][$value]['fielddesc']) && $docdefine['lines'][$value]['fielddesc'] != "") {
				          		$colon = ":"; $pre1  = "<pre>"; $pre2  = "</pre>";
				          		$varLineTable .=   $pre1 . '<b>' . $docdefine['lines'][$value]['fielddesc'] . '</b>' . $colon  . $doclines[$index][$value] . $pre2;
				        	} else {
				          		$colon = ""; $pre1  = ""; $pre2  = "";
				          		$varLineTable .=   $pre1 . $value . $colon  . $doclines[$index][$value] . $pre2;
				        	}
				      	}
			      		$varLineTable .=  "</td>";

			      	} else {
			      		if($columnKey == "#"){
			      			$varLineTable .= ($columnKey == '#') ? "<td class='linetable_td' id='linetable_td" . $i . "'><div class='avoid'>" . sprintf("%03d", ($index + 1)) . "</td>" : "";
			      		} else {
      						$varLineTable .=  "<td class='linetable_td' id='linetable_td" . $i . "'>"  . $linedata[$columnFields] . "</td>";
			      		}
			      	}

			      	$varLineTable .= "";
		    	}
		    	$varLineTable .= "</tr>";
		  	}
		    //========= from data loop =========

			if ($printdocdefine['hasNetTotalTable']) {
				$netTotalTableStructure = $printdocdefine['nettolaltable'];
				$varLineTable .= 
				"<tr>
					<td colspan='6' class='total'>Sub Total</td>
					<td id='nettotaltable_td2'>" . $docdata[$netTotalTableStructure['totalgarmentqty']] .  "</td>
					<td id='nettotaltable_td3'>" . "" .  "</td>
					<td id='nettotaltable_td3'>" . "" .  "</td>
					<td id='nettotaltable_td3'>" . "" .  "</td>
					<td class='total'>" . $docdata['totalamount'] . "</td>
				</tr>"
				;
			}

			$varLineTable .= "</tbody>";
		  	$varLineTable .= "</table>";

		  	$varLineTable .= "</br><div id='row'>";

		  	$varLineTable .= "</br>";
	  
		}else{
		// boian
		$varLineTable .= "<table id='headTable'>";
		$varLineTable .= "<tr><td>Dear Sir/ Madam,</td></tr>";
		$varLineTable .= "<tr><td>With Reference to your offer, we are pleased to give you purchaser order with the following terms & conditions  and as per the accepted Specification(s). You are requested to deliver the products along with the delivery Challan & invoice as per delivery date mentioned without fail.</td></tr>";
		$varLineTable .= "</table></br>";

		 if ($printdocdefine['hasLineTable']) {
		  	$lineTableStructure = $printdocdefine['linetable'];

		  	$varLineTable .= "<table class='print' id='linetable'>";
		  	$varLineTable .= "<thead>";
		  	$varLineTable .= "<tr>";
		  	foreach ($lineTableStructure as $columnKey => $columnFields) {
		    	$varLineTable .= "<th>" . $columnKey . "</th>";
		  	}
		  	$varLineTable .= "</thead>";
		  	$varLineTable .= "<tbody>";

		    //========= from data loop =========
		  	foreach ($doclines as $index => $linedata) {
		    	$i = 0;
		    	$varLineTable .= "<tr>";
		    	foreach ($lineTableStructure as $columnKey => $columnFields) {
			      	$i++;
			      	// if columnFields is array then break down			      	
			      	if(is_array($columnFields)){
			      		$varLineTable .=  "<td class='linetable_td' id='linetable_td" . $i . "'>";
				      	// break down td
				      	foreach ($columnFields as $key => $value) {

				        	if (isset($docdefine['lines'][$value]['fielddesc']) && $docdefine['lines'][$value]['fielddesc'] != "") {
				          		$colon = ":"; $pre1  = "<pre>"; $pre2  = "</pre>";
				          		$varLineTable .=   $pre1 . '<b>' . $docdefine['lines'][$value]['fielddesc'] . '</b>' . $colon  . $doclines[$index][$value] . $pre2;
				        	} else {
				          		$colon = ""; $pre1  = ""; $pre2  = "";
				          		$varLineTable .=   $pre1 . $value . $colon  . $doclines[$index][$value] . $pre2;
				        	}
				      	}
			      		$varLineTable .=  "</td>";

			      	} else {
			      		if($columnKey == "#"){
			      			$varLineTable .= ($columnKey == '#') ? "<td class='linetable_td' id='linetable_td" . $i . "'><div class='avoid'>" . sprintf("%03d", ($index + 1)) . "</td>" : "";
			      		} else {
      						$varLineTable .=  "<td class='linetable_td' id='linetable_td" . $i . "'>"  . $linedata[$columnFields] . "</td>";
			      		}
			      	}

			      	$varLineTable .= "";
		    	}
		    	$varLineTable .= "</tr>";
		  	}
		    //========= from data loop =========

			if ($printdocdefine['hasNetTotalTable']) {
				$netTotalTableStructure = $printdocdefine['nettolaltable'];
				$varLineTable .= 
				"<tr>
					<td colspan='6' class='total'>Sub Total</td>
					<td id='nettotaltable_td2'>" . $docdata[$netTotalTableStructure['totalgarmentqty']] .  "</td>
					<td id='nettotaltable_td3'>" . "" .  "</td>
					<td id='nettotaltable_td3'>" . "" .  "</td>
					<td id='nettotaltable_td3'>" . "" .  "</td>
					<td class='total'>" . $docdata['totalamount'] . "</td>
				</tr>"
				;
			}

			$varLineTable .= "</tbody>";
	  	$varLineTable .= "</table>";

	  	$varLineTable .= "</br><div id='row'>";

	  	$varLineTable .= "<div id='leftdiv' class='samerow'>";
	  	$varLineTable .= "<table class='instruction' id='instruction'>";
	  	$varLineTable .= "<tfoot>";
	  	$varLineTable .= "<tr>";
	  	$varLineTable .= "<td colspan='14' class='' id=''><b>Special Instruction</b></td>";
	  	$varLineTable .= "</tr>";
	  	$varLineTable .= "<tr>";
	  	$varLineTable .= "<td colspan='14' class='' id=''><pre>" . $docdata['specialinstruction'] .  "</pre></td>";
	  	$varLineTable .= "</tr>";
	  	$varLineTable .= "</tfoot>";
	  	$varLineTable .= "</table>";
	  	$varLineTable .= "</div>";

	  	$varLineTable .= "<div id='rightdiv' class='samerow'><table id='footerheader'>";
	  	$varLineTable .= "<tr>";
	  	$varLineTable .= "<th>Additional Cost</th><td>" . $docdata['poadditionalcost'] .  "</td>";
	  	$varLineTable .= "</tr>";

	  	$varLineTable .= "<tr>";
	  	$varLineTable .= "<th>Vat (". $docdata['povatandtax'] ." %)</th><td>" . $docdata['vattaxamount'] .  "</td>";
	  	$varLineTable .= "</tr>";

	  	$varLineTable .= "<tr>";
	  	$varLineTable .= "<th>Discount Amount</th><td>" . $docdata['podiscountamount'] .  "</td>";
	  	$varLineTable .= "</tr>";

	  	$varLineTable .= "<tr class='nettotal'>";
	  	$varLineTable .= "<th>Net Total</th><td>" . $docdata['ponettotal'] .  "</td>";
	  	$varLineTable .= "</tr>";
	  	$varLineTable .= "</table>";
	  	$varLineTable .= "</div>";
	  	$varLineTable .= "</div>";

	  	$varLineTable .= "</br>";
	  	$varLineTable .= "</br>";
	  	$varLineTable .= "<table class='print' id='linetable'>";
	  	$varLineTable .= "<tr>";
	  	$varLineTable .= "<td colspan='4' class='' id=''><b>Total Amount In Words:</b></td>";
	  	$varLineTable .= "<td id='' colspan='8' >" . $docdata['totalamountwords'] .  "</td>";
	  	$varLineTable .= "</tr>";
	  	$varLineTable .= "</table>";
	  	


	  	$varLineTable .= "</br>";
	  	$varLineTable .= "<table class='print' id='linetable'>";
	  	$varLineTable .= "<tfoot>";
	  	$varLineTable .= "<tr>";
	  	$varLineTable .= "<td colspan='14' class='' id=''><b>Terms & Condition</b></td>";
	  	$varLineTable .= "</tr>";
	  	$varLineTable .= "<tr>";
	  	$varLineTable .= "<td colspan='14' class='' id=''><pre>" . $docdata['termsandcondition'] .  "</pre></td>";
	  	$varLineTable .= "</tr>";
	  	$varLineTable .= "</tfoot>";
	  	$varLineTable .= "</table>";

	  	$varLineTable .= "</br>";
	  	$varLineTable .= "<table class='signatureTab' id='signatureTab'>";
	  	$varLineTable .= "<tr>";
	  	// $varLineTable .= "<th colspan='3' class='' id=''>Procurement Department</th>";
	  	$varLineTable .= "<th colspan='4' class='' id=''>Procurement Department</th>";
	  	$varLineTable .= "</tr>";
	  	$varLineTable .= "<tr>";
	  	$varLineTable .= "<th>Prepared</th>";
	  	$varLineTable .= "<th>Checked</th>";
	  	// $varLineTable .= "<th>Verified</th>";
	  	$varLineTable .= "<th>Approved</th>";
	  	$varLineTable .= "</tr>";
	  	$varLineTable .= "<tbody>";
	  	$varLineTable .= "<tr>";
	  	$varLineTable .= "<td></td><td></td><td></td>";
	  	// $varLineTable .= "<td></td><td></td><td></td><td></td>";
	  	$varLineTable .= "</tr>";
	  	$varLineTable .= "</tbody>";
	  	$varLineTable .= "</table>";

	  	$varLineTable .= "</br>";
		} else {
		  	$varLineTable = "";
		}
	}

		return $varLineTable;

 }

}
	




/*
 * Check if we have docnumber
 */
if (!isset($_GET['doctype']) || !isset($_GET['docnumber'])) {
  die("doctype and iddocument required");
}
$docnumber = $_GET['docnumber'];

amendent:
$doctype    = $_GET['doctype'];
$formtype = (isset($_GET['formtype'])) ? $_GET['formtype'] : "";

/*
 * Get json data for this document and decode
 */
$printDocObj = new PrintDoc($doctype, $formtype);
$docdefine = $printDocObj->docdefine;
$docdata = $printDocObj->_readDoc($docnumber, $docdefine);
// echo $docdata;
$docdata  = json_decode($docdata, true);
$formtype = $docdata['formtype'];

/**
 * Update docdefine by formtype
 */
$printDocObj = new PrintDoc($doctype, $formtype);

/*
 * include printdocdefine file
 */
require_once 'printdocdefine.php';
$printdocdefine = printdocdefine($doctype, $formtype);

/**
 * Passing json data
 */
$docdata = json_encode($docdata);
$printdocdefine = json_encode($printdocdefine);

// 1. Get default print format by using getDefaultPrintFormat function
// 2. Print page by using printPage

// 1. Get default print format by using getDefaultPrintFormat function
$printParams = $printDocObj->getDefaultPrintFormat($docdata, $docdefine, $printdocdefine);
// 2. Print page by using printPage
$printDocObj->printPage($printParams);


?>