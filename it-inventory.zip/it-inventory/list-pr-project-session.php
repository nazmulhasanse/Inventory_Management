<?php
$mainHTML  = $_SERVER["DOCUMENT_ROOT"] . '/erp-nonpo/html/listerp.html';
$mainJS    = '/erp-nonpo/js/list-erp.js?t=2017-10-07';
$customJS  = '/erp-nonpo/js/list-pr-project.js?t=2017-10-07';
$apiURL    = '/erp-nonpo/list-pr-project_api.php';
$formId    = 'searchForm';
?>

<!-- Default List CSS -->
<link rel="stylesheet" type="text/css" href="css/listerp.css">
<link rel="stylesheet" type="text/css" href="css/material-button.css">

<?php
include $mainHTML;
?>

<!-- Jquery Library -->
<!-- <script src="/js/jquery-2.1.3.min.js"></script> -->
<!-- <script type="text/javascript" src="api/client_api.js?t=<?php echo time();?>"></script> -->
<script type="text/javascript" src="<?php echo $mainJS; ?>"></script>   
<script type="text/javascript" src="<?php echo $customJS; ?>"></script> 
<script type="text/javascript">
$(document).ready(function() {
    var prepopulate = {};
    var searchParams = (Object.keys(prepopulate).length > 0) ? prepopulate : {};
    ERPLIST._sessionCall = true;
    ERPLIST._URL_API = '<?php echo $apiURL;?>';
    //                  show,   page,   api_url
    // ERPLIST.getListData(50,      1,      apiURL, searchParams);
}); 

ERPLIST.checkAndRetriveSearchData = function(){
    var searchParams = {};
    return searchParams;
}
</script>


<!-- Override some js code  -->
<script type="text/javascript">
// $(document).ajaxStop(function() {
//     $.fancybox.update(); 
// });    
</script>
<!-- Override some CSS -->
<style type="text/css">
    
</style>