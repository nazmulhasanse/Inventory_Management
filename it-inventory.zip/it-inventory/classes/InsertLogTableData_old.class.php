<?php
/**
* Insert Data into Log table for status change
*/

class InsertLogTableData
{
	
	public $conn;
	public $result;
	public $sql;
	public $dbname;

	function __construct($dbnum = '1'){

		if ($dbnum === '2') {
			$this->conn = new ErpDbConn('2');
			$this->dbname = "erpprod_bulbul";
		} else {
			$this->conn = new ErpDbConn;
			$this->dbname = "erpprod";
		}

	}

	public function genericDecoder($row){

	}

	


    public function insertDataIntoLogTable($keyfield, $keyvalue, $tablename, $logtablename, $operationtype){
        date_default_timezone_set("Asia/Dhaka"); 

        $sql = "SELECT * FROM $tablename WHERE $keyfield = '$keyvalue'";
        $allinfo = json_decode( $this->conn->sqlToJson($sql), true);

        foreach ($allinfo as $index => $info) {
            $columnFields = array();
            $fieldValues = array();

            unset($info['idlines']);    

            $info['OPERATIONTYPE'] = $operationtype;
            $info['OPERATIONUSER'] = $_SESSION['USERNAME'];
            $info['OPERATIONTIME'] = date('Y-m-d H:i:s', time());              

            foreach ($info as $fieldname => $fieldvalue) {
            	$fieldvalue = $this->conn->real_escape_string($fieldvalue);
                $columnFields[] = '`'. $fieldname .'`';
                $fieldValues[] = $fieldvalue;
            }

            $columnFields = implode(", ", $columnFields);
            $fieldValues  = "'" . implode("','", $fieldValues) . "'";
            
            $sql = "INSERT INTO $logtablename ($columnFields) VALUES($fieldValues)";
            $queryResult = $this->conn->query($sql);
            if(!$queryResult){
              die("fail query" . $sql); exit();
              return false;
            }
        } 
        return true;
    }	

}
?>