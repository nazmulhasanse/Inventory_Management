<?php 
// ERP existing Database
$db1_hostname = "10.1.2.13";
$db1_username = 'bulbul_php';
$db1_password = 'liubeicaocaosunjian123';
$db1_dbname   = "erpprod";

// New database
$db2_hostname = "10.1.2.13";
$db2_username = "bulbul_php";
$db2_password = "liubeicaocaosunjian123";
$db2_dbname   = "erpprod_bulbul";

$dbConn1 = new mysqli($db1_hostname, $db1_username, $db1_password, $db1_dbname);
$dbConn2 = new mysqli($db2_hostname, $db2_username, $db2_password, $db2_dbname);
if ($dbConn1->connect_error) {error_log("Failed to connect to database->1! " . $dbConn1->connect_error, 0); die("Connection failed DB-1: " . $dbConn1->connect_error);}
if ($dbConn2->connect_error) {error_log("Failed to connect to database->2! " . $dbConn2->connect_error, 0); die("Connection failed DB-2: " . $dbConn2->connect_error);}
?>