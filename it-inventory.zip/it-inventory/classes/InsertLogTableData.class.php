<?php
/**
* Insert Data into Log table for status change
*/
class InsertLogTableData
{
	
	public $conn;
	public $result;
	public $sql;
	public $dbname;

	function __construct($dbnum = '1'){

		if ($dbnum === '2') {
			$this->conn = new ErpDbConn('2');
			$this->dbname = "erpprod_bulbul";
		} else {
			$this->conn = new ErpDbConn;
			$this->dbname = "erpprod";
		}

	}

	public function genericDecoder($row){

	}

	public function insertDataIntoLogTable($keyfield, $keyvalue, $tablename, $logtablename, $forWhich){

		date_default_timezone_set("Asia/Dhaka"); 

		$columnFields = array();
		$fieldValues = array();

		$sql = "SELECT * FROM $tablename WHERE $keyfield = '$keyvalue'";
		$info = json_decode( $this->conn->sqlToJson($sql), true)[0];
		
		unset($info['idlines']);
		unset($info['lineentrytime']);
		unset($info['lastupdateuser']);
		unset($info['lastupdatetime']);

		if($forWhich == 'insert'){
			$info['operationtype'] = 'Insert';				
		} else if($forWhich == 'update'){
			$info['operationtype'] = 'Update';				
			$info['lastupdateuser'] = $_SESSION['USERNAME'];
			$info['lastupdatetime'] = date('Y-m-d H:i:s', time());
		} else if($forWhich == 'delete'){
			$info['operationtype'] = 'Delete';				
			$info['lastupdateuser'] = $_SESSION['USERNAME'];
			$info['lastupdatetime'] = date('Y-m-d H:i:s', time());
		}
		
		foreach ($info as $fieldname => $fieldvalue) {
			$columnFields[] = $fieldname;
			$fieldValues[] = $fieldvalue;
		}

		$columnFields = implode(", ", $columnFields);
		$fieldValues  = "'" . implode("','", $fieldValues) . "'";
		
		$sql = "INSERT INTO $logtablename ($columnFields) VALUES($fieldValues)";
		// echo $sql;
		$this->conn->query($sql);

		return;
	}	


}
?>