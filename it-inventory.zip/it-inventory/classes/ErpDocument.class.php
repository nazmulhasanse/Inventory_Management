<?php
class ErpDocument {
/*
TO DO
find a fix for the below query while creating document. Because it limits the length of docnumber
SET @nextdocnum_formatted = CONCAT(@docacronym , '-' , LPAD(@nextdocnum, 6, '0'));
 */
  public $formId;
  public $formTitle;
  public $privilege = "";

  protected $formStructure     = array();
  protected $formBaseStructure = array();
  protected $formButtons       = array();
  protected $formGroups        = array();
  protected $formLineColumns   = array();
  protected $docobj            = array();

  public $ERP_CONST = array();

  public $URL_DOCDEFINEAPI;
  public $URL_DOCDOCSEARCH;
  public $URL_DOCDOCFORM;
  public $URL_MAINJS;
  public $URL_DOCJS;
  public $URL_DOCJS_CUSTOMIZATION;
  public $URL_DOCCSS;



// Should Foreign Keys and loose relationships (library) be shown here?
  public static $tableStructure = array(
    'schema' => array(
		'tablename'  => 'tnx_demodoc',
    ),
    'header' => array(
		// Identification
		'doctype'           => array('restriction' => 'hidden', 'library' => 'doctype'), 
		'formtype'          => array('restriction' => 'hidden'), 
		'docdate'           => array('fielddesc' => 'Document date', 'restriction' => 'required'), 
		'docstatus'         => array('fielddesc' => 'Status', 'restriction' => 'hidden', 'library' => 'docstatus'), 
		'docnumber'         => array('fielddesc' => 'Document Number'), 
		'company'           => array('fielddesc' => 'Company', 'restriction' => 'required', 'library' => 'Company'), // FK mrd_? currently in the mrd_library
		'buyername'         => array('fielddesc' => 'Buyer Name', 'library' => 'Buyer'),
		'entrypersonbadge'  => array('fielddesc' => 'Entered By', 'restriction' => 'viewonly'),
		'doccreationtime'   => array('fielddesc' => 'Creation Time', 'restriction' => 'viewonly'),
		
		// Othres
		'additionalcomment' => array('fielddesc' => 'Additional Comment', 'textarea' => 'textarea'), 
		'docfilepaths' => array('fielddesc' => 'Document File', 'html_InputTag' => '_file_'), 
    'headercheckbox'    => array('fielddesc' => 'Header Check Box-1', 'html_InputTag' => 'checkbox'), 

		'salesorder'    => array('fielddesc' => 'sales order'), 
    ),

    'lines'  => array(
		// Identification
		'idlines'         => array('restriction' => 'hidden'), // this line's ID
		'linenumber'      => array('fielddesc' => 'Line', 'restriction' => 'viewonly'),
		'linestatus'      => array('fielddesc' => 'Line Status', 'restriction' => 'viewonly'),
		'lineentrytime'   => array('fielddesc' => 'Line Entry Time', 'restriction' => 'viewonly'),
		'linesremarks'    => array('fielddesc' => 'Remarks', 'textarea' => 'textarea'),
		
		// Othres
    'itemtype'        => array('fielddesc' => 'Item Type'),
    'itemcode'        => array('fielddesc' => 'Item Code'),
    'itemlot'         => array('fielddesc' => 'Item Lot'),
    'itemserial'      => array('fielddesc' => 'Item Serial'),
    'tnxqty'          => array('fielddesc' => 'Quantity'),
    'iduom'           => array('fielddesc' => 'UOM', 'library' => 'UOM'),
    'extralinefield1' => array('fielddesc' => 'Extra Line Field1'),
    'linefilepaths' => array('fielddesc' => 'Line File Paths', 'html_InputTag' => '_file_'),
    'linecheckbox'    => array('fielddesc' => 'Line Check Box', 'html_InputTag' => 'checkbox'),
    // 'extralinefield23' => array('fielddesc' => 'Extra Line Field23'),
    'trackingno'        => array('fielddesc' => 'Tracking no'),
		'itemdescription'        => array('fielddesc' => 'item description', 'textarea' => 'textarea'),
    ),
  );

  public function __construct() {
    $formId = 'formERP';


  }

  public static function tableStructureWithVirtual() {
    $tableStructure = self::$tableStructure;
    $tableStructure['lines']['supplierlot']['fielddesc']      = 'Supplier Lot';
    $tableStructure['lines']['supplierlot']['fieldtype']      = 'varchar(30)';
    $tableStructure['lines']['supplierlot']['virtual']        = true;

    $tableStructure['lines']['priceproposal']['fielddesc']      = 'Price Proposal';
    $tableStructure['lines']['priceproposal']['fieldtype']      = '__htmlbutton';
    $tableStructure['lines']['priceproposal']['value']          = 'redo';
    $tableStructure['lines']['priceproposal']['virtual']        = true;

    $tableStructure['header']['downloadcostingsheet']['fielddesc']      = 'Download Costing Sheet';
    $tableStructure['header']['downloadcostingsheet']['fieldtype']      = '__htmlbutton';
    $tableStructure['header']['downloadcostingsheet']['value']          = '_file_download_';
    $tableStructure['header']['downloadcostingsheet']['virtual']        = true;

    return $tableStructure;
  }

  public function __toString() {
    return json_encode($this->docobj);
  }

  /**
   * Generates a form based on a structured list of fields
   */
  public function buildForm() {
    $formStructure = $this->formStructure;
    /*
    Starts echoing the actual form
     */
    echo <<<EOF
EOF;

    echo <<<EOF
<form action="#" method="post" id="$this->formId" autocomplete="off">
    <div id="upperButtonBar" style="height:50px;">

EOF;
    foreach ($this->formButtons as $formButton) {
      echo self::indented(2, self::HTML_button($formButton));
    }
    echo <<<EOF
    </div>
    <div id="formCaption">
        <div class="w40">$this->formTitle</div>
        <div class="w20 text_center">
            <span></span><input type="hidden" name="iddocument" id="iddocument" value=""/>
            <span id="spandocnumber"></span><input type="hidden" name="docnumber" id="spandocnumber" value=""/>
        </div>
        <div class="w40 text_right">
            <span id="spandocstatus"></span><input type="hidden" name="docstatus" id="docstatus" value=""/>
        </div>
        <div class="clearfix"></div>
    </div>
    <div id="formError"></div>

EOF;
    foreach ($this->formGroups as $groupName => $groupFields) {
      $containerName = "fieldset_" . strtolower(str_replace(" ", "", $groupName));
      if ($groupFields != ["lines"]) {
        echo self::indented(2, "<fieldset id=\"$containerName\">");
        echo self::indented(3, "<legend>$groupName</legend>");
        // echo chr(13).chr(10);
        foreach ($groupFields as $groupfield) {
          echo self::indented(3, self::HTML_headerfield($groupfield));
        }
        echo self::indented(2, '</fieldset>');

      } else {
        // Opening up to <table>
        echo <<<EOF
    <div id="formLines">
        <!-- Regular fieldset+legend doesn't work because of the horizontal scroll -->
        <div id="legend">$groupName</div>
        <div id="$containerName">
            <table border="0" cellpadding="0" cellspacing="0">

EOF;

        // <tr> <th></th> </tr>
        echo self::indented(3, '<thead>');
        echo self::indented(4, '<tr>');
        echo self::indented(5, '<th></th>'); // First column contains the floating buttons

        // $formLineFields = array_keys($formStructure['lines']);
        // foreach ($formLineFields as $columnField) {
        foreach ($this->formLineColumns as $columnField) {
          $columnDesc        = isset($formStructure['lines'][$columnField]['fielddesc']) ? $formStructure['lines'][$columnField]['fielddesc'] : $columnField;
          $columnRestriction = isset($formStructure['lines'][$columnField]['restriction']) ? $formStructure['lines'][$columnField]['restriction'] : '';
          $hide              = ($columnRestriction == 'hidden') ? ' style="display:none;"' : '';
          echo self::indented(5, "<th class=\"$columnField\"$hide>$columnDesc</th>");
        }

        echo self::indented(4, '</tr>');
        echo self::indented(3, '</thead>');

        // <tbody> <tr> <td></td> </tr> </tbody>
        echo self::indented(4, '<tbody>');
        echo self::indented(5, '<tr data-id="1" class="editable">');

        // Floating buttons
        echo <<<EOF
                    <td>
                        <div class="div_editButton" style="float:left;position:absolute;display:none;">
                            <input type="button" class="editLine btn-blue material-icons" style="font-size:24px;" value="edit" />
                        </div>
                        <div class="div_labelButton" style="float:left;position:absolute;display:none;">
                            <input type="button" class="printLine btn-blue material-icons" style="font-size:24px;" value="print" />
                        </div>
                    </td>

EOF;
        // foreach ($formLineFields as $columnField) {
        foreach ($this->formLineColumns as $columnField) {
          echo self::indented(5, self::HTML_columnfield($columnField));
        }
        echo self::indented(5, '</tr>');
        echo self::indented(4, '</tbody>');

        // </table> and Closing
        echo self::indented(3, '</table>');
        echo self::indented(2, '</div>');
        echo self::indented(1, '</div>');
      }
    }

    echo <<<EOF
    <span id="lowerButtonBar">
    </span>
</form>

EOF;
  }

  function indented($level, $block) {
    $block         = explode(chr(13) . chr(10), $block);
    $indentedblock = array();
    foreach ($block as $line) {
      array_push($indentedblock, str_repeat("  ", $level) . $line);
    }
    $indentedblock = implode(chr(13) . chr(10), $indentedblock);
    return $indentedblock . chr(13) . chr(10);
  }

  function get_formStructureData($fieldname, $data, $ifnotset, $part) {
    $formStructure = $this->formStructure;
    return (isset($formStructure[$part][$fieldname][$data]) ? $formStructure[$part][$fieldname][$data] : $ifnotset);
  }

  function get_fieldType($fieldname, $part) {
    $fieldrestriction = self::get_formStructureData($fieldname, 'restriction', '', $part);
    $fieldlibrary     = self::get_formStructureData($fieldname, 'fielddlibraryesc', '', $part);
    $dbfieldtype      = self::get_formStructureData($fieldname, 'fieldtype', '', $part);
    $formStructure    = $this->formStructure;

    if ($fieldrestriction == 'hidden') {
      return 'hidden';
    } elseif ($fieldrestriction == 'viewonly' && $part == 'lines') {
      return 'hidden';
    } elseif ($dbfieldtype == 'decimal(18,4)') {
      return 'number';
    } elseif ($dbfieldtype == 'date') {
      return 'date';
    } elseif ($dbfieldtype == 'datetime') {
      return 'datetime';
    // } elseif ($dbfieldtype == 'text') {
    } elseif ($dbfieldtype == '_htmlbutton') {
      return '_htmlbutton';
    } elseif ($dbfieldtype == '__htmlbutton') {
      return '__htmlbutton';
    } elseif ($dbfieldtype == 'htmlbutton_') {
      return 'htmlbutton_';
    } elseif ($dbfieldtype == 'htmlbutton__') {
      return 'htmlbutton__';
    } elseif (isset($formStructure[$part][$fieldname]['textarea'])) {
      return 'textarea';
    } elseif (isset($formStructure[$part][$fieldname]['html_InputTag'])) {
      return $formStructure[$part][$fieldname]['html_InputTag'];  
    } elseif (isset($formStructure[$part][$fieldname]['library'])) {
      return 'select';
    } else {
      return 'text';
    }
  }

  function HTML_button($button) {
    $buttons                     = array();
    $buttons['btnSaveForm'] = <<<EOF
<input type="submit" class="btnEditMode btnSaveForm btn-blue" value="Save (CTRL+S)" title="Save the current document" style="display:none;"/>
EOF;
    $buttons['btnEnterEditMode'] = <<<EOF
<input type="button" class="btnReadMode btnEnterEditMode btn-grey material-icons" value="edit" title="Click to make changes to this document" style="display:none;"/>
EOF;
    $buttons['btnCancelForm'] = <<<EOF
<input type="button" class="btnEditMode btnCancelForm btn-grey material-icons" value="cancel" title="Cancel changes and go back to previous page" style="display:none;"/>
EOF;
    $buttons['btnPrintSheet'] = <<<EOF
<input type="button" class="btnReadMode btnPrintSheet btn-grey material-icons" value="print insert_drive_file" title="Print this document (opens new window)" style="display:none;"/>
EOF;
    $buttons['btnCopyAndNew'] = <<<EOF
<input type="button" class="btnReadMode btnCopyAndNew btn-grey" value="Copy & New" title="Save the current document" style="display:none;"/>
EOF;
    $buttons['btnChangeDocStatus'] = <<<EOF
<input type="button" class="btnReadMode btnChangeDocStatus  btn-grey" value="Close Document" title="Close This Document" style="display:none;"/>
EOF;
    $buttons['btnFileAttachment'] = <<<EOF
<input type="button" class="btnReadMode btnFileAttachment btn-grey" value="Attach File" title="Attach file in document read mode" style="display:none;"/>
EOF;

    return $buttons[$button];
  }

  function HTML_headerfield($fieldname) {
    $formStructure = $this->formStructure;
    $fielddesc     = self::get_formStructureData($fieldname, 'fielddesc', $fieldname, 'header');
    $fieldtype     = self::get_fieldType($fieldname, 'header');
    $btnvalue      = ($fieldtype == '_htmlbutton' || $fieldtype == '__htmlbutton' || $fieldtype == 'htmlbutton_' || $fieldtype == 'htmlbutton__') ? $formStructure['header'][$fieldname]['value'] : '';

    if(isset($formStructure['header'][$fieldname]['groupname'])){
      $groupname     = $formStructure['header'][$fieldname]['groupname'];
      $group = "group";
    }

    $hide = '';
    switch ($fieldtype) {
    case 'text':
      $inputHTML = <<<EOF
<input type="text" name="{$fieldname}" id="{$fieldname}" value=""/>
EOF;
      break;
    case 'hidden':
      $hide      = ' style="display:none;"';
      $inputHTML = <<<EOF
<input type="hidden" name="{$fieldname}" id="{$fieldname}" value=""/>
EOF;
      break;
    case 'select':
      $inputHTML = <<<EOF
<select name="{$fieldname}" id="{$fieldname}">
    <option value="">Select</option>
</select>
EOF;
      break;
    case 'textarea':
      $inputHTML = <<<EOF
<textarea name="{$fieldname}" id="{$fieldname}"></textarea>
EOF;
      break;
    case 'date':
      $inputHTML = <<<EOF
<input type="text" name="{$fieldname}" id="{$fieldname}" class="datepicker" value=""/>
EOF;
      break;
    case 'datetime':
      $inputHTML = <<<EOF
<input type="text" name="{$fieldname}" id="{$fieldname}" class="datetimepicker" value=""/>
EOF;
      break;
    case 'checkbox':
      $inputHTML = <<<EOF
<input type="checkbox" name="{$fieldname}" id="{$fieldname}" class="$group $groupname" onclick="LIZERP.handleCheckBoxClick(this);"/>
EOF;
      break;
    case '_htmlbutton':
      $inputHTML = <<<EOF
<button type="button" id="btn$fieldname" class="btn$fieldname btn-blue" onclick="LIZERP.handleThisButtonAction(this)">$btnvalue</button>
EOF;
      break;
    case '__htmlbutton':
      $inputHTML = <<<EOF
<button type="button" id="btn$fieldname" class="btn$fieldname btn-blue material-icons" onclick="LIZERP.handleThisButtonAction(this)">$btnvalue</button>
EOF;
      break;
    case 'htmlbutton_':
      $inputHTML = <<<EOF
<input type="button" id="btn$fieldname" class="btn$fieldname btn-blue" onclick="LIZERP.handleThisButtonAction(this)" value="$btnvalue"/>
EOF;
      break;
    case 'htmlbutton__':
      $inputHTML = <<<EOF
<input type="button" id="btn$fieldname" class="btn$fieldname btn-blue material-icons" onclick="LIZERP.handleThisButtonAction(this)" value="$btnvalue"/>
EOF;
      break;
    case '_file_':
      $fieldName = $fieldname . "[]";
      $inputHTML = <<<EOF
<div class="fileAttachmentContainer" style="display:none">
  <div class="fileViewerContainer" style="float:left">
    <a href="" target="_blank"><img src="img/fileicon.png" width="30" height="20"/></a>
  </div>
  <div class="fileInputContainer" style="float:left; display:none;">
      <label class="custom-file-upload" id="id_width">
      <input type="file" name="$fieldName" multiple value="$value"$required class="upload_file" onchange="LIZERP.uploadFile(this)"/>
      Upload File
      </label>
  </div>
</div>
EOF;
      break;
    default:
      $inputHTML = <<<EOF
EOF;
      error_log("Unknown field type " . $fieldtype . " for field " . $fieldname);
      self::HTML_headerfield($fieldname, $fielddesc, 'text');
      break;
    }

    // for special case button, file attachment
    if($fieldtype == '_file_'){      
    $template = <<<EOF
<div class="formGroup"$hide>
    $inputHTML
</div>
EOF;
      return $template;
    }


    $template = <<<EOF
<div class="formGroup"$hide>
    <label for="{$fieldname}">{$fielddesc}</label>
    $inputHTML
</div>
EOF;
    return $template;
  }

  function HTML_columnfield($columnField) {
    $formStructure     = $this->formStructure;
    $columnRestriction = isset($formStructure['lines'][$columnField]['restriction']) ? $formStructure['lines'][$columnField]['restriction'] : $columnField;
    $columnType        = self::get_fieldType($columnField, 'lines');
    $hide              = ($columnRestriction == 'hidden') ? ' style="display:none;"' : '';
    $required          = ($columnRestriction == 'required') ? ' required="required"' : '';
    $value             = ($columnField == 'linenumber') ? '1' : '';
    $searchloupe       = ($columnField == 'itemcode') ? '<br/><img src="img/search.png" class="searchItemCode"/>' : '';
    $btnvalue          = ($columnType == '_htmlbutton' || $columnType == '__htmlbutton' || $columnType == 'htmlbutton_' || $columnType == 'htmlbutton__') ? $formStructure['lines'][$columnField]['value'] : '';


    if(isset($formStructure['lines'][$columnField]['groupname'])){
      $groupname     = $formStructure['lines'][$columnField]['groupname'];
      $group = "group";
    }

    switch ($columnType) {
    case 'hidden':
      $inputHTML = <<<EOF
<input type="hidden" name="lines[1][$columnField]" value="$value"$required/>
EOF;
      break;
    case 'date':
      // $inputHTML = "<input type=\"hidden\" name=\"lines[1][$columnField]\" value=\"\" />";
      break;
    case 'textarea':
      $inputHTML = <<<EOF
<textarea name="lines[1][{$columnField}]" id="{$columnField}"$required></textarea>
EOF;
      break;
    case 'select':
      $inputHTML = <<<EOF
<select name="lines[1][{$columnField}]" id="{$columnField}"$required>
    <option value="">Select</option>
</select>
EOF;
      break;
    case 'checkbox':
      $inputHTML = <<<EOF
<input type="checkbox" name="{$columnField}" id="{$columnField}" class="$group $groupname"  onclick="LIZERP.handleCheckBoxClick(this);" />
EOF;
      break;
    case 'number':
      $inputHTML = <<<EOF
<input type="text" name="lines[1][$columnField]" value="$value" min="0" step="any"$required/>
EOF;
      break;
    case '_htmlbutton':
      $inputHTML = <<<EOF
<button type="button" class="btn$columnField btn-blue" onclick="LIZERP.handleThisButtonAction(this)">$btnvalue</button>
EOF;
      break;
    case '__htmlbutton':
      $inputHTML = <<<EOF
<button type="button" class="btn$columnField btn-blue material-icons" onclick="LIZERP.handleThisButtonAction(this)">$btnvalue</button>
EOF;
      break;
    case 'htmlbutton_':
      $inputHTML = <<<EOF
<input type="button" class="btn$columnField btn-blue" onclick="LIZERP.handleThisButtonAction(this)" value="$btnvalue"/>
EOF;
      break;
    case 'htmlbutton__':
      $inputHTML = <<<EOF
<input type="button" class="btn$columnField btn-blue material-icons" onclick="LIZERP.handleThisButtonAction(this)" value="$btnvalue"/>
EOF;
      break;
    case '_file_':
      $fieldName = $columnField . "[]";
      $inputHTML = <<<EOF
<div class="fileAttachmentContainer" style="display:none">
  <div class="fileViewerContainer" style="float:left">
    <a href="" target="_blank"><img src="img/fileicon.png" width="30" height="20"/></a>
  </div>
  <div class="fileInputContainer" style="float:left; display:none;">
      <label class="custom-file-upload" id="id_width">
      <input type="file" name="$fieldName" multiple value="$value"$required class="upload_file" onchange="LIZERP.uploadFile(this)"/>
      Upload File
      </label>
  </div>
</div>
EOF;
      break;   
    default:
      $inputHTML = <<<EOF
<input type="text" name="lines[1][$columnField]" value="$value"$required/>
EOF;
      break;
    }
    if ($columnField == 'linenumber') {
      $inputHTML = '<br/><br/>&nbsp;' . $inputHTML;
    }
    // for special case button, file attachment
    if($columnType == '_htmlbutton' || $columnType== 'htmlbutton_' || $columnType== '__htmlbutton' || $columnType== 'htmlbutton__' || $columnType== 'checkbox' || $columnType == '_file_'){      
    $HTML_columnField = <<<EOF
<td class="$columnField"$hide>
    $inputHTML
</td>
EOF;
      return $HTML_columnField;
    }

    $HTML_columnField = <<<EOF
<td class="$columnField"$hide>
    <span>$value</span>
    $inputHTML
</td>
EOF;
    return $HTML_columnField;
  }
}
?>