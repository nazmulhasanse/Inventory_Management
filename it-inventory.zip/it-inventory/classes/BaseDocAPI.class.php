<?php
/**
* Abstract base class to define model
*/
abstract class BaseDocAPI
{

	//-- attributes declaration
	public $type1 = "success::";
	public $type2 = "warning::";
	public $type3 = "error::";

	public $docStatusTranslatorF  = array('0' => 'Entered', '1' => 'Closed');
	public $docStatusTranslatorB  = array('Entered' => '0', 'Closed' => '1');
	public $lineStatusTranslatorF = array('0' => 'Entered', '1' => 'Closed');
	public $lineStatusTranslatorB = array('Entered' => '0', 'Closed' => '1');


	function __construct(){
		# code...
	}


	function getNextDocNumber($countername){
		$conn = new ErpDbConn;
		$sql = "SELECT prefix, nextnumber from erp_counter where countername='$countername'";
		$prefix        = json_decode($conn->sqlToJson($sql), true)[0]['prefix'];
		$currentdocnum = json_decode($conn->sqlToJson($sql), true)[0]['nextnumber'];

		$sql = "UPDATE erp_counter SET nextnumber=(nextnumber+1) where countername='$countername'";
		$qresult = $conn->query($sql);

		if($qresult){
			return $prefix . "-".$currentdocnum;
		}
	}


	function _changeDocStatus($docnumber, $docstatus, $formStructure){

		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();


		$formStructure = json_decode($formStructure, true);
		$tablename = $formStructure['schema']['tablename'];

		if (!isset($docnumber)) {
			array_push($returnJSON->errormsgs, 'No docnumber parameter.');
			$returnJSON->result = 'error';
			return json_encode($returnJSON);
		}

		$sql = "UPDATE $tablename SET docstatus = '$docstatus' WHERE docnumber = '$docnumber'";
    	$conn = new ErpDbConn;
		$queryResult = $conn->query($sql);

		if($queryResult){
			$returnJSON->result = 'success';
			return json_encode($returnJSON);			
		}

	}

	function _changeLineStatus($docnumber, $linestatus, $formStructure){

		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();


		$formStructure = json_decode($formStructure, true);
		$tablename = $formStructure['schema']['tablename'];

		if (!isset($docnumber)) {
			array_push($returnJSON->errormsgs, 'No docnumber parameter.');
			$returnJSON->result = 'error';
			return json_encode($returnJSON);
		}

		$sql = "UPDATE $tablename SET linestatus = '$linestatus' WHERE docnumber = '$docnumber'";
    	$conn = new ErpDbConn;
		$queryResult = $conn->query($sql);

		if($queryResult){
			$returnJSON->result = 'success';
			return json_encode($returnJSON);			
		}

	}


	function _readDoc($docnumber, $formStructure){
		$conn = new ErpDbConn;
		$formStructure = json_decode($formStructure, true);
		$tablename = $formStructure['schema']['tablename'];

		// get the list of fields
		// $fieldHeader = "h." . implode(", h.", array_diff(array_keys($formStructure['header']), array('docstatus')));
		$fieldHeader = "h." . implode(", h.", array_diff(array_keys($formStructure['header']), array('systemfield')));
		$fieldLines  = implode(",", array_keys($formStructure['lines']));

		// get the header info in docobj
		$sql = "SELECT $fieldHeader
		  FROM  $tablename h
		  WHERE h.docnumber = '$docnumber' LIMIT 1";

		$result = $conn->query($sql);
		$docobj = $result->fetch_assoc();

		foreach ($docobj as $fieldname => $fieldvalue) {
			if ($fieldvalue == NULL) {
			  unset($docobj[$fieldname]);
			}
		}

		// add all the lines in docobj
		$sql = "SELECT $fieldLines FROM $tablename WHERE docnumber = '$docnumber' ORDER BY linenumber ASC";
		$result = $conn->query($sql);
		$lines  = array();
		while ($row = $result->fetch_assoc()) {
		foreach ($row as $fieldname => $fieldvalue) {
		  if ($fieldvalue == NULL) {
		  	$row[$fieldname] = '';
		    // unset($row[$fieldname]);
		  }

		}
		array_push($lines, $row);
		}

		$docobj['lines'] = $lines;
		return json_encode($docobj);

	}


	function _readDocLineWise($docnumber, $formStructure, $idlines){
		$conn = new ErpDbConn;
		$formStructure = json_decode($formStructure, true);
		$tablename = $formStructure['schema']['tablename'];

		// get the list of fields
		// $fieldHeader = "h." . implode(", h.", array_diff(array_keys($formStructure['header']), array('docstatus')));
		$fieldHeader = "h." . implode(", h.", array_diff(array_keys($formStructure['header']), array('systemfield')));
		$fieldLines  = implode(",", array_keys($formStructure['lines']));

		// get the header info in docobj
		$sql = "SELECT $fieldHeader
		  FROM  $tablename h
		  WHERE h.docnumber = '$docnumber' LIMIT 1";

		$result = $conn->query($sql);
		$docobj = $result->fetch_assoc();

		foreach ($docobj as $fieldname => $fieldvalue) {
			if ($fieldvalue == NULL) {
			  unset($docobj[$fieldname]);
			}
		}

		// add all the lines in docobj
		$sql = "SELECT $fieldLines FROM $tablename WHERE docnumber = '$docnumber' AND idlines='$idlines' ORDER BY linenumber ASC";
		// echo $sql;
		// error_log($sql);
		$result = $conn->query($sql);
		$lines  = array();
		while ($row = $result->fetch_assoc()) {
		foreach ($row as $fieldname => $fieldvalue) {
		  if ($fieldvalue == NULL) {
		    // unset($row[$fieldname]);
		  }

		}
		array_push($lines, $row);
		}

		$docobj['lines'] = $lines;
		return json_encode($docobj);

	}



	function _createDoc($docdata, $formStructure){
		$conn = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$formStructure = json_decode($formStructure, true);
		$tablename = $formStructure['schema']['tablename'];
		$doctype   = $formStructure['header']['doctype'];
		$formtype  = $formStructure['header']['formtype'];
		$doccounter= $formStructure['doccounter'];

		$docobj = json_decode($docdata, true);
		$doclins = $docobj['lines'];
		unset($docobj['lines']);

		$sql_array = array();
		$hcolumnFields = array();
		$hfieldValues = array();
		// process header
		$docnumber = $docobj['docnumber'];
		unset($docobj['docnumber']);
		unset($docobj['docstatus']);
		unset($docobj['entrypersonbadge']);
		unset($docobj['doccreationtime']);
		// system entries
		if($docnumber == ''){
			$docnumber = $this->getNextDocNumber($doccounter);
		}
		$hcolumnFields[] = 'docnumber';
		$hfieldValues[]  = $docnumber;

		$hcolumnFields[] = 'entrypersonbadge';
		$hfieldValues[]  = $_SESSION['LoggedBadge'];

		$hcolumnFields[] = 'docstatus';
		$hfieldValues[]  = '0';
		$hcolumnFields[] = 'doccreationtime';
		$hfieldValues[]  = date('Y-m-d H:i:s', time());

		foreach ($docobj as $fieldname => $fieldvalue) {
			$hcolumnFields[] = $fieldname;
			$hfieldValues[] = $fieldvalue;
		}

		// process lines
		foreach ($doclins as $index => $line) {

			$columnFields = array();
			$fieldValues = array();
			unset($line['lineentrytime']);
			unset($line['linestatus']);
			foreach ($line as $fieldname => $fieldvalue) {
				$columnFields[] = $fieldname;
				$fieldValues[] = $fieldvalue;
			}
			// push header data in line
			foreach ($hcolumnFields as $index => $fieldname) {
				$columnFields[] = $fieldname;
				$fieldValues[]  = $hfieldValues[$index];		
			}		

			$columnFields = implode(", ", $columnFields);
			$fieldValues  = "'" . implode("','", $fieldValues) . "'";

			$sql = "INSERT INTO $tablename ($columnFields) VALUES($fieldValues)";
			$sql_array[] = $sql;

		}

		// Execute Query
		foreach ($sql_array as $key => $sql) {
			$result = $conn->query($sql);	  
			if(!$result){
				array_push($returnJSON->errormsgs, "Error, $sql");
				return $returnJSON;
			}
		}
      	$conn->close();

		if ($result) {
			$returnJSON->docnumber = $docnumber;
		} else {
			array_push($returnJSON->errormsgs, "Error, please tell ERP department: commit failed.");
		}
		return $returnJSON;

	}


	function _updateDoc($docdata, $formStructure){
		$conn = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$formStructure = json_decode($formStructure, true);
		$tablename = $formStructure['schema']['tablename'];		

		$newdocobj = json_decode($docdata, true);
		$docnumber = $newdocobj['docnumber'];
		$olddocobj = json_decode($this->_readDoc($docnumber, json_encode($formStructure)), true);

		// $newdocobj['docstatus'] = $this->docStatusTranslatorB[$newdocobj['docstatus']];

		$docLinesArray = $newdocobj['lines']; // format: lines = array(0 => array, 1 => array, ....)
		unset($newdocobj['lines']);
		$docHeaderArray = $newdocobj;

		// Generating query varriables
		// HEADER
		// update SQL for header
		$sql_array = array();
		$updateSet = "";
		foreach ($docHeaderArray as $keyHeader => $valueHeader) {
		if ($keyHeader != 'docnumber') {
			$updateSet .= $keyHeader . "=" . "'" . $valueHeader . "',";
		}
		}	
		
		date_default_timezone_set("Asia/Dhaka");
		$updateSet .= "lastupdateuser =" . "'" . $_SESSION["USERNAME"] . "',"; 

		$lastUpdateTime  = date('Y-m-d H:i:s', time());
		$updateSet .= "lastupdatetime =" . "'" . $lastUpdateTime . "',"; 

		$updateSet = rtrim($updateSet ,',');
		$sqlH = "UPDATE $tablename SET $updateSet WHERE docnumber = '$docnumber'";
		
		// LINES
		// Case 1 - New Lines: idlines will be blank. (user can add new lines in document's update mode.)
		// Case 2 - Existing Lines: idlines will be specified. (user just updated these lines)
		// Case 3 - Removed Lines: line will be missing.

		// Calculate the differences
		foreach ($docLinesArray as $docLine) {
			$lineNumbers_new[] = $docLine['linenumber'];
		}
		$lineNumbers_new = array_unique($lineNumbers_new, SORT_NUMERIC);
		foreach ($olddocobj['lines'] as $docLine) {
			$lineNumbers_old[] = $docLine['linenumber'];
		}
		$lineNumbers_old = array_unique($lineNumbers_old, SORT_NUMERIC);

		$lineNumbers_added   = array_diff($lineNumbers_new, $lineNumbers_old);
		$lineNumbers_same    = array_intersect($lineNumbers_new, $lineNumbers_old);
		$lineNumbers_removed = array_diff($lineNumbers_old, $lineNumbers_new);


		/*
		Iterate through the lines and build an array of SQL queries
		*/
		foreach ($docLinesArray as $lineIndex => $LineArray) {
		// here, value is also an array
		// $idlines_this = $LineArray['idlines'];
		$this_linenumber = $LineArray['linenumber'];
		unset($LineArray['idlines']);

		if (in_array($this_linenumber, $lineNumbers_added)) {
			  // Case 1 - New Line
				$columnFields = array();
				$fieldValues = array();
				unset($LineArray['lineentrytime']);
				foreach ($LineArray as $fieldname => $fieldvalue) {
					$columnFields[] = $fieldname;
					$fieldValues[] = $fieldvalue;
				}
				$columnFields[] = 'docnumber';
				$fieldValues[] = $docnumber;

				$columnFields = implode(", ", $columnFields);
				$fieldValues  = "'" . implode("','", $fieldValues) . "'";
				$sql = "INSERT INTO $tablename ($columnFields) VALUES($fieldValues)";
				$sql_array[] = $sql;

			} else {
			  // Case 2 - Existing Line
				$updateSet = "";
				foreach ($LineArray as $fieldname => $fieldvalue) {
					$updateSet .= $fieldname . "=" . "'" . $fieldvalue . "',";
				}

				$updateSet = rtrim($updateSet ,',');
				$sql = "UPDATE $tablename SET $updateSet WHERE docnumber = '$docnumber' AND linenumber = '$this_linenumber'";
				$sql_array[] = $sql;
			}
		}

		// Case 3 - Removed Lines
		if (sizeof($lineNumbers_removed) > 0) {
			$lineNumbers_removed = implode(",", $lineNumbers_removed);
			$sql = "DELETE FROM $tablename WHERE docnumber = '$docnumber' AND linenumber IN ($lineNumbers_removed)";
			$sql_array[] = $sql;
		}


		// Execute Query
		$sql_array[] = $sqlH;
		foreach ($sql_array as $key => $sql) {
			$result = $conn->query($sql);	  
			if(!$result){
				array_push($returnJSON->errormsgs, "Error, $sql");
				return $returnJSON;
			}
		}
		$conn->close();

		if ($result) {
			$returnJSON->docnumber = $docnumber;
		} else {
			array_push($returnJSON->errormsgs, "Error, please tell ERP department: commit failed.");
		}
		return $returnJSON;

	}







	function _searchDoc($formStructure, $where, $columns) {

	  $conn = new ErpDbConn;

	  $formStructure = json_decode($formStructure, true);
	  $tablename = $formStructure['schema']['tablename'];


	  $groupby_array = array();
	  // check if columns are valid fields
	  $columns_array = explode(",", $columns);
	  foreach ($columns_array as $column) {
	    $returnJSON = new stdClass();
	    // check if the docobj is valid
	    $returnJSON->errormsgs = $this->_validField($formStructure, $column);

	    if (count($returnJSON->errormsgs) > 0) {
	      // if validation fails, don't continue
	      die("column $column does not exists!");
	    }


	    if ($lines == 'no' && !in_array($column, array_keys($formStructure['header']))) {
	      die("column $column does not exists in header table!");
	    }

	    // Group By only header columns
	    if (in_array($column, array_keys($formStructure['header']))) {
	      $groupby_array[] = $column;
	    }
	  }

	  // where clause
	  $where_array = json_decode($where, true);
	  $whereClause = $this->_whereClause($where_array);

	  // build the query
	  $sql      = "SELECT $columns FROM $tablename WHERE $whereClause GROUP BY " . implode(",", $groupby_array);
	  // error_log($sql);
	  // return $sql;
	  return $conn->sqlToJson($sql);
	}


	function _validField($formStructure, $field, $position = null) {
	  $errormsgs          = array();
	  $headerFields_array = array_keys($formStructure['header']);
	  $linesFields_array  = array_keys($formStructure['lines']);

	  if ($position == null) {
	    if (in_array($field, $headerFields_array) || in_array($field, $linesFields_array)) {
	      // return true;
	    } else {
	      array_push($errormsgs, "$field is not a valid field!");
	    }
	  } else {
	    if ($position == 'header') {
	      if (in_array($field, $headerFields_array)) {
	        // return true;
	      } else {
	        array_push($errormsgs, "$field is not a valid field in Header!");
	      }
	    } elseif ($position == 'lines') {
	      if (in_array($field, $linesFields_array)) {
	        // return true;
	      } else {
	        array_push($errormsgs, "$field is not a valid field in Lines!");
	      }
	    }
	  }
	  return $errormsgs;
	}


	function _whereClause($where_array) {
		$conn = new ErpDbConn;
	  // recursive function for multidimensional array to string, string enclosed by parenthesis

	  $acceptedCompOperators = array('=', '!=', '<', '<=', '>', '>=', 'LIKE', 'IN');
	  $acceptedLogOperators  = array('AND', 'OR', 'NOT');

	  $x = ""; // initializing where clause
	  foreach ($where_array as $condition) {
	    if (is_array($condition)) {

	      if ($this->_no_element_array($condition)) {
	        // one single condition. e.g. array("`age`",">",5)

	        // check if field is valid
	        $field = $condition[0];
	        if ($field[0] == "`" && $field[strlen($field) - 1] == "`") {
	          // check if enclosed by backticks
	          $field_nb = substr($field, 1, -1); // removing backtics
	        } else {
	          die("ERROR: $field is not enclosed by backticks!");
	        }

	        // check if comparator is valid
	        $comparator = $condition[1];
	        if (!in_array($comparator, $acceptedCompOperators)) {
	          die("ERROR: Invalid comparator $comparator");
	        }

	        // check if non-numeric searched values are single-quoted
	        $search = $condition[2];
	        if (!is_numeric($search)) {
	          if (!($search[0] == "'" && $search[strlen($search) - 1] == "'")) {
	            // check if not enclosed by single-quotes
	            die("ERROR: non-numeric values are not single quoted!");
	          }
	          // $search = "'" . $conn->real_escape_string(substr($search, 1, -1)) . "'"; // doing real_escape inside quoted string
	          $search = "'" . substr($search, 1, -1) . "'"; // doing real_escape inside quoted string
	        }

	        // add to where clause
	        $x .= "( $field $comparator $search )";

	      } else {
	        // because this condition contains multiple condition
	        $x .= "(" . $this->_whereClause($condition) . ")";
	      }

	    } else {
	      // logical operators
	      if (in_array($condition, $acceptedLogOperators)) {
	        $x .= " " . $condition . " ";
	      } else {
	        die("Invalid logical operator: " . $condition);
	      }
	    }
	  }
	  // this hack might cause trouble in the future! users can break by searching )(
	  // one solution is to have a 2-pass system, where
	  // the first pass validates the client input and outputs a perfectly formatted array (with all "AND", etc.)
	  // and the second pass will do a dumb translation into a string
	  $x = str_replace(")(", ") AND (", $x); // if no logical operator given, then AND will be assumed
	  return $x;
	}


	function _no_element_array($array) {
	  // function for checking if an array has no array-element
	  $x = 0;
	  foreach ($array as $value) {
	    $x += (is_array($value)) ? 1 : 0;
	  }
	  return ($x == 0) ? true : false;
	}


}
?>