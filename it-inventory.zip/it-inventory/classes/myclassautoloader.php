<?php
// function myclass_autoloader($class) {
// 	$directory = $GLOBALS['directory'];	
// 	require_once $_SERVER['DOCUMENT_ROOT'] . "/erp-apparel/classes/" . $class . '.class.php';
// }
// spl_autoload_register('myclass_autoloader');

function myclass_autoloader($class) {
    $thisModuleClasses = __DIR__ . '/' . $class . '.class.php'; // __DIR__ gives this file directory
    $pathPDMClasses = $_SERVER['DOCUMENT_ROOT'] . '/pdm/classes/' . $class . '.class.php';
    $pathZERPPDMClasses = $_SERVER['DOCUMENT_ROOT'] . '/zerp/pkg/pdm/classes/' . $class . '.class.php';
    $pathCommonClasses = $_SERVER['DOCUMENT_ROOT'] . '/classes/' . $class . '.class.php';

    if (file_exists($thisModuleClasses)) {
    	require_once __DIR__ . "/" . $class . '.class.php';

    } elseif (file_exists($pathPDMClasses)) {
    	require_once $_SERVER['DOCUMENT_ROOT'] . '/pdm/classes/' . $class . '.class.php';

    } elseif (file_exists($pathZERPPDMClasses)) {
        require_once $_SERVER['DOCUMENT_ROOT'] . '/zerp/pkg/pdm/classes/' . $class . '.class.php';

    } elseif (file_exists($pathCommonClasses)) {
        require_once $pathCommonClasses ;
    }
}
spl_autoload_register('myclass_autoloader');
?>