<?php
class ErpDocumentTemplate5 {
/*
TO DO
find a fix for the below query while creating document. Because it limits the length of docnumber
SET @nextdocnum_formatted = CONCAT(@docacronym , '-' , LPAD(@nextdocnum, 6, '0'));
 */
  public $formId;
  public $formTitle;
  public $privilege = "";

  protected $formStructure     = array();
  protected $formBaseStructure = array();
  protected $formButtons       = array();
  protected $formGroups        = array();
  protected $formLineColumns   = array();
  protected $docobj            = array();

  public $ERP_CONST = array();

  public $URL_DOCDEFINEAPI;
  public $URL_DOCDOCSEARCH;
  public $URL_DOCDOCFORM;
  public $URL_DOCJS;

  public $URL_MAINJS  = './js/erpdocument_template5.js';    
  public $URL_DOCCSS  = 'css/docerp_template5.css';

// Should Foreign Keys and loose relationships (library) be shown here?
  public static $tableStructure = array(
    'schema' => array(
		'tablename'  => 'erp_fabricmaterialline',
    ),
    'header' => array(
      	// Identification
    'doctype'                    => array('restriction' => 'hidden', 'library' => 'doctype'), 
    'formtype'                   => array('restriction' => 'hidden'), 
    'docdate'                    => array('fielddesc' => 'Document date', 'restriction' => 'required'), 
    'docstatus'                  => array('fielddesc' => 'Status', 'restriction' => 'hidden', 'library' => 'docstatus'), 
    'docnumber'                  => array('fielddesc' => 'Document Number'), 
    'parentdocnumber'            => array('fielddesc' => 'Parent Document Number'), 
    'projectiondocnumber'        => array('fielddesc' => 'Projection Document Number'), 
    'company'                    => array('fielddesc' => 'Company', 'restriction' => 'required', 'library' => 'Company'), // FK mrd_? currently in the mrd_library
    // 'buyername'                  => array('fielddesc' => 'Buyer Name', 'library' => 'Buyer'),
    'entrypersonbadge'           => array('fielddesc' => 'Entered By', 'restriction' => 'viewonly'),
    'creationuser'               => array('fielddesc' => 'Creation User', 'restriction' => 'viewonly'),
    'doccreationtime'            => array('fielddesc' => 'Creation Time', 'restriction' => 'viewonly'),
    'lastupdateuser'             => array('fielddesc' => 'Last Update User', 'restriction' => 'viewonly'),
    'lastupdatetime'             => array('fielddesc' => 'Last Update Time', 'restriction' => 'viewonly'),
    'confirmperson'              => array('fielddesc' => 'Confirmed By', 'restriction' => 'viewonly'),
    'mllineconfirmtime'          => array('fielddesc' => 'Confirmed Time', 'restriction' => 'viewonly'),
    'ldcslnumber'                => array('fielddesc' => 'LDCSL Number'),
    
    'itemcode'                   => array('fielddesc' => 'Full Item Code', 'textarea' => 'textarea'),
    'projectionitemcode'         => array('fielddesc' => 'Projection Itemcode'),
    'previousitemcode'           => array('fielddesc' => 'Evolve From Previous Item Code', 'restriction' => 'viewonly'),
    'unitprice'                  => array('fielddesc' => 'Fabric Unit Price'),
    'currency'                   => array('fielddesc' => 'Currency', 'library' => 'Currency'),
    // 'designtype'                 => array('fielddesc' => 'Fabric Design Type'),
    // 'composition'                => array('fielddesc' => 'Fabric Composition'),
    // 'construction'               => array('fielddesc' => 'Fabric Construction'),
    // 'fabricopenortubular'        => array('fielddesc' => 'Fabric Open/Tube'),
    // 'yarntypeandeffect'          => array('fielddesc' => 'Yarn Type, Effect and Manufacturing Process'),
    // 'functionalproperties'       => array('fielddesc' => 'Functional Properties'),
    // 'colornameandcode'           => array('fielddesc' => 'Color'),
    // 'attachingmethod'            => array('fielddesc' => 'Attaching Method'),
    // 'membranename'               => array('fielddesc' => 'Membrane Name'),
    // 'bondingmethod'              => array('fielddesc' => 'Bonding Method'),
    // 'bindersname'                => array('fielddesc' => 'Binders Name'),
    'materiallistid'             => array('fielddesc' => 'Material List ID'),
    // 'suppliername'               => array('fielddesc' => 'Supplier Name', 'library' => 'Suppliers'),
    // 'processlevel'               => array('fielddesc' => 'Process Level'),
    // 'placement'                  => array('fielddesc' => 'Placement'),
    'processesbeforesewing'      => array('fielddesc' => 'Processes Before Sewing', 'restriction' => 'required', 'textarea' => 'textarea'),
    'processesaftersewing'       => array('fielddesc' => 'Processes After Sewing', 'textarea' => 'textarea'),
    'itemdescription'            => array('fielddesc' => 'Item Description', 'textarea' => 'textarea'),
    'nominatedsuppliername'      => array('fielddesc' => 'Nominated Supplier Name'),
    'nominatedsupplieraddress'   => array('fielddesc' => "Nominated Supplier's Contract", 'textarea' => 'textarea'),
    'garmentmodel'               => array('fielddesc' => "garment ref./Model/Article"),
    'nominatedsupplier'          => array('fielddesc' => 'Nominated Supplier', 'library' => 'yes_no'),
    'incoterms'                  => array('fielddesc' => 'Incoterms'),
    'pricerequisitionnumber'     => array('fielddesc' => 'Fabric Price Requisition No.', 'lookup' => true),
    'swatchreference'            => array('fielddesc' => 'Swatch Reference#'),
    'isinformtobom'              => array('fielddesc' => 'Inform to BOM'),
    'supplierreferencenumber'    => array('fielddesc' => 'Fabric Ref./Model/Article', 'textarea' => 'textarea'),
    'sewingbonding'              => array('fielddesc' => 'Sewing/Bonding', 'library' => 'sewingbonding'), 
    // 'fabriccolor'                => array('fielddesc' => 'Fabric Color/Panton No.'),
    'iduom'                      => array('fielddesc' => 'UOM', 'library' => 'UOM'),
    'priceuom'                   => array('fielddesc' => 'UOM', 'library' => 'UOM'),
    'pricecurrency'              => array('fielddesc' => 'Currency', 'library' => 'Currency'),
    'deliveryterm'               => array('fielddesc' => 'Delivery Term'),
    'designid'                   => array('fielddesc' => 'Design ID', 'lookup' => true, 'restriction' => 'required'),
    'developmentstatus'          => array('fielddesc' => 'Development Status', 'library' => 'developmentstatus', 'restriction' => 'required'),
    'reffrompvsdevelopment'      => array('fielddesc' => 'Reference from Previous Development'), 
    'colorcategory'              => array('fielddesc' => 'Color Name and Code', 'textarea' => 'textarea'),
    'colornameorcode'            => array('fielddesc' => 'Color Name/Color Code From Tachpcak', 'textarea' => 'textarea', 'restriction' => 'required'),
    'yarncount'                  => array('fielddesc' => 'Yarn Count'),
    'yarnbrand'                  => array('fielddesc' => 'Yarn Brand'),
    'endcustomeravailable'       => array('fielddesc' => 'Available', 'library' => 'YesNo'),
    'paymentterm'                => array('fielddesc' => 'Payment Term'),
    'orderqtycondition'          => array('fielddesc' => 'Order Qty Condition (MOQ/MCQ/Fixed batch size)', 'library' => 'YesNo'),
    'supplierunitprice'          => array('fielddesc' => 'Supplier Fabric Price'),
    'nominatedyarnsupplier'      => array('fielddesc' => 'Nominated Yarn Supplier'),
    'yarnply'                    => array('fielddesc' => 'Yarn Ply'),
    'supplieryarncode'           => array('fielddesc' => "Supplier's Yarn Code"),
    'cuttablewidth'              => array('fielddesc' => "Cuttable Width"),
    'conditiondetails'           => array('fielddesc' => 'Condition Details', 'textarea' => 'textarea'),
    'followingprocessafterfinishedfabric'           => array('fielddesc' => 'Following Process After Finished Fabric', 'textarea' => 'textarea'),
    'instructionfortextile'           => array('fielddesc' => 'Instruction for Textile', 'textarea' => 'textarea'),
    'instructionforbom'           => array('fielddesc' => 'Instruction for BOM', 'textarea' => 'textarea'),

    //for item spec
    
    'opentube'             => array('fielddesc' => "Open/Tube"),
    'itemtype'             => array('fielddesc' => 'Item Type'),
    'fabricgsm'            => array('fielddesc' => 'Fabric GSM'),
    'fabricwidth'          => array('fielddesc' => 'Fabric Width (Inch)'),
    'fabricdesigntype'     => array('fielddesc' => 'Fabric Design Type'),
    'composition'          => array('fielddesc' => 'Composition'),
    'construction'         => array('fielddesc' => 'Construction'),
    'yarntem'              => array('fielddesc' => 'Yarn TEM', 'textarea' => 'textarea'),
    'functionalproperties' => array('fielddesc' => 'Functional Properties', 'textarea' => 'textarea'),
    'attachingmethod'      => array('fielddesc' => 'Attaching Method'),
    'membranename'         => array('fielddesc' => 'Membrane Name'),
    'epi_ppi'              => array('fielddesc' => 'EPIxPPI'),
    'subcategory'          => array('fielddesc' => 'Sub Category'),
    'lengthandwidth'       => array('fielddesc' => 'Length and Width'),
    'numply'               => array('fielddesc' => 'Num ply'),
    'garmentsize'          => array('fielddesc' => 'Garment Size'),
    'productcode'          => array('fielddesc' => 'Product Code'),
    'widthuom'             => array('fielddesc' => 'Width UoM'),
    'colorcode'            => array('fielddesc' => 'Color Code'),

    ),

    'lines'  => array(
      	// Identification
		'idlines'         => array('restriction' => 'hidden'), // this line's ID
		'linenumber'      => array('fielddesc' => 'Line', 'restriction' => 'viewonly'),
		'linestatus'      => array('fielddesc' => 'Line Status'),
		'lineentrytime'   => array('fielddesc' => 'Line Entry Time'),
		'linesremarks'    => array('fielddesc' => 'Lines Remarks', 'textarea' => 'textarea'),

		// Othres
		

		// 'extralinefield23' => array('fielddesc' => 'Extra Line Field23'),
    ),
  );



  public function __construct() {
    $formId = 'formERP';
    $conn = new ErpDbConn;

    $lngObj = new ErpString($_SESSION['LNG'], 'AppS');
    $this->docStr = $lngObj->docStr;

    $missingFields = array();

    $schemapart = 'header';
    $fieldList  = $conn->showColumns(self::$tableStructure['schema']['tablename']);
    $crossCheck = self::$tableStructure[$schemapart];
    foreach ($fieldList as $key => $value) {
      if (!isset(self::$tableStructure[$schemapart][$value['Field']])) {
        self::$tableStructure[$schemapart][$value['Field']] = array();
        error_log("Missing $schemapart field in docall_define.php: " . $value['Field']);
      } else {
        unset($crossCheck[$value['Field']]);
      }
      self::$tableStructure[$schemapart][$value['Field']]['fieldtype'] = $value['Type'];
    }
    foreach ($crossCheck as $key => $value) {
      $missingFields[] = $key;
    }


    $schemapart = 'lines';
    $fieldList  = $conn->showColumns(self::$tableStructure['schema']['tablename']);
    $crossCheck = self::$tableStructure[$schemapart];
    foreach ($fieldList as $key => $value) {
      if (!isset(self::$tableStructure[$schemapart][$value['Field']])) {
        self::$tableStructure[$schemapart][$value['Field']] = array();
        error_log("Missing $schemapart field in docall_define.php: " . $value['Field']);
      } else {
        unset($crossCheck[$value['Field']]);
      }
      self::$tableStructure[$schemapart][$value['Field']]['fieldtype'] = $value['Type'];
    }
    foreach ($crossCheck as $key => $value) {
      $missingFields[] = $key;
    }

    if(count($missingFields) > 0){
    	$missingFields = implode(", ", $missingFields);
    	echo "<script type='text/javascript'>alert('$missingFields are missing in database table');</script>";
    }


  }

  public static function tableStructureWithVirtual() {
    $tableStructure = self::$tableStructure;
    $tableStructure['header']['currency']['fielddesc']        = 'Currency';
    $tableStructure['lines']['supplierlot']['fielddesc']      = 'Supplier Lot';
    $tableStructure['lines']['supplierlot']['fieldtype']      = 'varchar(30)';
    $tableStructure['lines']['supplierlot']['virtual']        = true;
    return $tableStructure;
  }

  public function __toString() {
    return json_encode($this->docobj);
  }

  /**
   * Generates a form based on a structured list of fields
   */
  public function buildForm() {
    $formStructure = $this->formStructure;
    /*
    Starts echoing the actual form
     */
    echo <<<EOF
EOF;

    echo <<<EOF
<form action="#" method="post" id="$this->formId" autocomplete="off">
    <div id="upperButtonBar" style="height:50px;">

EOF;
    foreach ($this->formButtons as $formButton) {
      echo self::indented(2, self::HTML_button($formButton));
    }
    echo <<<EOF
    </div>

<div id="divMother">


    <div id="leftListDiv">
      <span></span>
    </div>
    <div id="rightFormDiv" style="display:none;" >
      <div id="dragbar"></div>
      <div style="float:right;">
        <input type="button" class="btnEditMode btnCancelForm btnEC3 btn-grey material-icons" value="cancel" title="Cancel line" style="display:none;"/>
      </div>
      <br/>    

    <div id="formCaption" style="display:none;">
        <div class="w40">$this->formTitle</div>
        <div class="w20 text_center">
            <span></span><input type="hidden" name="iddocument" id="iddocument" value=""/>
            <span id="spandocnumber"></span><input type="hidden" name="docnumber" id="spandocnumber" value=""/>
        </div>
        <div class="w40 text_right">
            <span id="spandocstatus"></span><input type="hidden" name="docstatus" id="docstatus" value=""/>
        </div>
        <div class="clearfix"></div>
    </div>
    <div id="formError"></div>

EOF;
    foreach ($this->formGroups as $groupName => $groupFields) {
      $containerName = "fieldset_" . strtolower(str_replace(" ", "", $groupName));
      if ($groupFields != ["lines"]) {
        echo self::indented(2, "<fieldset id=\"$containerName\">");
        echo self::indented(3, "<legend>$groupName</legend>");
        // echo chr(13).chr(10);
        foreach ($groupFields as $groupfield) {
          echo self::indented(3, self::HTML_headerfield($groupfield));
        }
        echo self::indented(2, '</fieldset>');

      } else {
        // Opening up to <table>
        echo <<<EOF
    <div id="formLines">
        <!-- Regular fieldset+legend doesn't work because of the horizontal scroll -->
        <div id="legend">$groupName</div>
        <div id="$containerName">
            <table border="0" cellpadding="0" cellspacing="0">

EOF;

        // <tr> <th></th> </tr>
        echo self::indented(3, '<thead>');
        echo self::indented(4, '<tr>');
        echo self::indented(5, '<th></th>'); // First column contains the floating buttons

        // $formLineFields = array_keys($formStructure['lines']);
        // foreach ($formLineFields as $columnField) {
        foreach ($this->formLineColumns as $columnField) {
          $columnDesc        = isset($formStructure['lines'][$columnField]['fielddesc']) ? $formStructure['lines'][$columnField]['fielddesc'] : $columnField;
          $columnRestriction = isset($formStructure['lines'][$columnField]['restriction']) ? $formStructure['lines'][$columnField]['restriction'] : '';
          $hide              = ($columnRestriction == 'hidden') ? ' style="display:none;"' : '';
          echo self::indented(5, "<th class=\"$columnField\"$hide>$columnDesc</th>");
        }

        echo self::indented(4, '</tr>');
        echo self::indented(3, '</thead>');

        // <tbody> <tr> <td></td> </tr> </tbody>
        echo self::indented(4, '<tbody>');
        echo self::indented(5, '<tr data-id="1" class="editable">');

        // Floating buttons
        echo <<<EOF
                    <td>
                        <div class="div_editButton" style="float:left;position:absolute;display:none;">
                            <input type="button" class="editLine btn-blue material-icons" style="font-size:24px;" value="edit" />
                        </div>
                        <div class="div_labelButton" style="float:left;position:absolute;display:none;">
                            <input type="button" class="printLine btn-blue material-icons" style="font-size:24px;" value="print" />
                        </div>
                    </td>

EOF;
        // foreach ($formLineFields as $columnField) {
        foreach ($this->formLineColumns as $columnField) {
          echo self::indented(5, self::HTML_columnfield($columnField));
        }
        echo self::indented(5, '</tr>');
        echo self::indented(4, '</tbody>');

        // </table> and Closing
        echo self::indented(3, '</table>');
        echo self::indented(2, '</div>');
        echo self::indented(1, '</div>');
      }
    }

    echo <<<EOF
    <span id="lowerButtonBar">
    </span>

    </div>
 </div>    <!-- divMother end -->
</form>

EOF;
  }

  function indented($level, $block) {
    $block         = explode(chr(13) . chr(10), $block);
    $indentedblock = array();
    foreach ($block as $line) {
      array_push($indentedblock, str_repeat("  ", $level) . $line);
    }
    $indentedblock = implode(chr(13) . chr(10), $indentedblock);
    return $indentedblock . chr(13) . chr(10);
  }

  function get_formStructureData($fieldname, $data, $ifnotset, $part) {
    $formStructure = $this->formStructure;
    return (isset($formStructure[$part][$fieldname][$data]) ? $formStructure[$part][$fieldname][$data] : $ifnotset);
  }

  function get_fieldType($fieldname, $part) {
    $fieldrestriction = self::get_formStructureData($fieldname, 'restriction', '', $part);
    $fieldlibrary     = self::get_formStructureData($fieldname, 'fielddlibraryesc', '', $part);
    $dbfieldtype      = self::get_formStructureData($fieldname, 'fieldtype', '', $part);
    $formStructure    = $this->formStructure;

    if ($fieldrestriction == 'hidden') {
      return 'hidden';
    } elseif ($fieldrestriction == 'viewonly' && $part == 'lines') {
      return 'hidden';
    } elseif ($dbfieldtype == 'decimal(18,4)') {
      return 'number';
    } elseif ($dbfieldtype == 'date') {
      return 'date';
    } elseif ($dbfieldtype == 'datetime') {
      return 'datetime';
    // } elseif ($dbfieldtype == 'text') {
    } elseif (isset($formStructure[$part][$fieldname]['textarea'])) {
      return 'textarea';
    } elseif (isset($formStructure[$part][$fieldname]['library'])) {
      return 'select';
    } else {
      return 'text';
    }
  }

  function HTML_button($button) {
    $buttons                     = array();
    $buttons['btnSaveForm'] = <<<EOF
<input type="button" class="btnEditMode btnSaveForm btnEC1 btn-blue" value="Save (CTRL+S)" title="Save the current document" style="display:none;"/>
EOF;
    $buttons['btnNew'] = <<<EOF
<input type="button" class="btnAllMode btnNew btn-blue" value="New (CTRL+N)" title="New document" style="display:none;"/>
EOF;
    $buttons['btnEnterEditMode'] = <<<EOF
<input type="button" class="btnReadMode btnEnterEditMode btn-grey material-icons" value="edit" title="Click to make changes to this document" style="display:none;"/>
EOF;
    $buttons['btnCancelForm'] = <<<EOF
<input type="button" class="btnEditMode btnCancelForm btnEC2 btn-grey material-icons" value="cancel" title="Cancel changes and go back to previous page" style="display:none;"/>
EOF;
    $buttons['btnPrintSheet'] = <<<EOF
<input type="button" class="btnReadMode btnPrintSheet btn-grey material-icons" value="print insert_drive_file" title="Print this document (opens new window)" style="display:none;"/>
EOF;
    $buttons['btnPrint'] = <<<EOF
<input type="button" class="btnAllMode btnPrint btn-grey material-icons" value="print insert_drive_file" title="Print this document (opens new window)" style="display:none;"/>
EOF;
    $buttons['btnCopyAndNew'] = <<<EOF
<input type="button" class="btnReadMode btnCopyAndNew btn-grey" value="Copy & New" title="Save the current document" style="display:none;"/>
EOF;
    $buttons['btnChangeDocStatus'] = <<<EOF
<input type="button" class="btnReadMode btnChangeDocStatus  btn-grey" value="Change Doc Status" title="Complete This Document" style="display:none;"/>
EOF;
    $buttons['btnCompleteProducedStatus'] = <<<EOF
<input type="button" class="btnAllMode  btnCompleteProducedStatus  btn-grey" value="Mark as Produced & Complete FSS Status" title="Mark as Produced & Complete FSS Status" style="display:none;"/>
EOF;
    $buttons['btnChangeFSSStatus'] = <<<EOF
<input type="button" class="btnAllMode  btnChangeFSSStatus  btn-grey" value="Complete FSS Status" title="Complete FSS Status" style="display:none;"/>
EOF;
    $buttons['btnPurchased'] = <<<EOF
<input type="button" class="btnAllMode  btnPurchased  btn-grey" value="Mark as Purchased" title="Mark as Purchased" style="display:none;"/>
EOF;
    $buttons['btnProduced'] = <<<EOF
<input type="button" class="btnAllMode  btnProduced  btn-grey" value="Mark as Produced" title="Mark as Produced" style="display:none;"/>
EOF;
    $buttons['removeLine'] = <<<EOF
<input type="button" class="btnReadMode removeLine btn-grey material-icons" value="delete" title="Remove the current line" style="display:none;"/>
EOF;
    $buttons['btnevolveLine'] = <<<EOF
<input type="button" class="btnReadMode btnevolveLine btn-blue " value="Evolve" title="Evolve the current line" style="display:none;"/>
EOF;
    $buttons['btnLookup'] = <<<EOF
<button type="button" class="btnEditMode btnLookup" title="Click this for look up data" style="margin-left:-3px; color:blue;" onclick="LIZERP.handleLookup(this)" ><i class="material-icons">search</i></button>
EOF;
    $buttons['btnModifyLine'] = <<<EOF
<input type="button" class="btnReadMode btnModifyLine btn-grey" value="Modify" title="Modify this line" style="display:none;"/>
EOF;
    $buttons['btnCancelLine'] = <<<EOF
<input type="button" class="btnReadMode btnCancelLine btn-grey" value="Cancel" title="Cancle this line" style="display:none;"/>
EOF;

    return $buttons[$button];
  }

  function HTML_headerfield($fieldname) {
    $formStructure = $this->formStructure;
    $fielddesc     = self::get_formStructureData($fieldname, 'fielddesc', $fieldname, 'header');
    $fieldtype     = self::get_fieldType($fieldname, 'header');

    $btnLookup = '';
    if(isset($formStructure['header'][$fieldname]['lookup'])){
      $btnLookup     = $this->HTML_button('btnLookup');
    }

    $hide = '';
    switch ($fieldtype) {
    case 'text':
      $inputHTML = <<<EOF
<input type="text" name="{$fieldname}" id="{$fieldname}" value=""/>
EOF;
      break;
    case 'hidden':
      $hide      = ' style="display:none;"';
      $inputHTML = <<<EOF
<input type="hidden" name="{$fieldname}" id="{$fieldname}" value=""/>
EOF;
      break;
    case 'select':
      $inputHTML = <<<EOF
<select name="{$fieldname}" id="{$fieldname}">
    <option value="">Select</option>
</select>
EOF;
      break;
       case 'number':
      $inputHTML = <<<EOF
<input type="number" name="{$fieldname}" value="" min="0" step="any"$required/>
EOF;
      break;
    case 'textarea':
      $inputHTML = <<<EOF
<textarea name="{$fieldname}" id="{$fieldname}"></textarea>
EOF;
      break;
    case 'date':
      $inputHTML = <<<EOF
<input type="text" name="{$fieldname}" id="{$fieldname}" class="datepicker" value=""/>
EOF;
      break;
    case 'datetime':
      $inputHTML = <<<EOF
<input type="text" name="{$fieldname}" id="{$fieldname}" class="datetimepicker" value=""/>
EOF;

      break;
    default:
      $inputHTML = <<<EOF
EOF;
      error_log("Unknown field type " . $fieldtype . " for field " . $fieldname);
      self::HTML_headerfield($fieldname, $fielddesc, 'text');
      break;
    }
    $template = <<<EOF
<div class="formGroup"$hide>
    <label for="{$fieldname}">{$fielddesc}</label>
    $inputHTML $btnLookup
</div>
EOF;
    return $template;
  }

  function HTML_columnfield($columnField) {
    $formStructure     = $this->formStructure;
    $columnRestriction = isset($formStructure['lines'][$columnField]['restriction']) ? $formStructure['lines'][$columnField]['restriction'] : $columnField;
    $columnType        = self::get_fieldType($columnField, 'lines');
    $hide              = ($columnRestriction == 'hidden') ? ' style="display:none;"' : '';
    $required          = ($columnRestriction == 'required') ? ' required="required"' : '';
    $value             = ($columnField == 'linenumber') ? '1' : '';
    $searchloupe       = ($columnField == 'itemcode') ? '<br/><img src="img/search.png" class="searchItemCode"/>' : '';

    switch ($columnType) {
    case 'hidden':
      $inputHTML = <<<EOF
<input type="hidden" name="lines[1][$columnField]" value="$value"$required/>
EOF;
      break;
    case 'date':
      // $inputHTML = "<input type=\"hidden\" name=\"lines[1][$columnField]\" value=\"\" />";
      break;
    case 'textarea':
      $inputHTML = <<<EOF
<textarea name="lines[1][{$columnField}]" id="{$columnField}"$required></textarea>
EOF;
      break;
    case 'select':
      $inputHTML = <<<EOF
<select name="lines[1][{$columnField}]" id="{$columnField}"$required>
    <option value="">Select</option>
</select>
EOF;
      break;
    case 'number':
      $inputHTML = <<<EOF
<input type="text" name="lines[1][$columnField]" value="$value" min="0" step="any"$required/>
EOF;
      break;
    default:
      $inputHTML = <<<EOF
<input type="text" name="lines[1][$columnField]" value="$value"$required/>
EOF;
      break;
    }
    if ($columnField == 'linenumber') {
      $inputHTML = '<br/><br/>&nbsp;' . $inputHTML;
    }
    $HTML_columnField = <<<EOF
<td class="$columnField"$hide>
    <span>$value</span>
    $inputHTML
</td>
EOF;
    return $HTML_columnField;
  }
}
?>