<?php
class ErpDocListAB extends ErpDocListTemplate {
  public function __construct() {
  	self::$tableStructure['schema']['tablename'] = 'tnx_bom_accessory';
    parent::__construct();

    /**
     * Five place need to change if you want to change doctype
     * ******* Just need to change doctype ******** 
     * 1. erpdocument.php
     * 2. erpdocument_define.php
     * 3. myclassautoloader.php
     * 4. This child class
     * 5. printdocdefine.php
     */

    /**
     * Initializes the content of the "constants"
     * and Setting Parameter
     */
    $rootPath = $_SERVER['DOCUMENT_ROOT'];
    $thisPath = dirname($_SERVER['PHP_SELF']);
    $onlyPath = str_replace($rootPath, '', $thisPath);
    $directorypath = $onlyPath;
    // $directorypath = '/templates/code-framework/form-framework3';
    $directorypath = $onlyPath;
    $this->_URL_DOCUMENTAPI = $directorypath . '/doc-list-ab_api.php';
    $this->_URL_DOCDEFINEAPI = $directorypath . '/erpdocument_define.php?doctype=AB';

    $this->URL_DOCDOCSEARCH        = 'erpdocument.php';
    $this->URL_DOCDOCFORM          = 'erpdocument.php?doctype=AB';
    
    $this->URL_MAINJS              = './js/erpdoclist_template.js';    
    $this->URL_DOCCSS              = 'css/erpdoclist_template.css';

    $this->URL_DOCJS               = './js/doc-list-ab.js';
    $this->URL_DOCJS_CUSTOMIZATION = './js/doc-list-ab-customization.js';


    $this->formId    = 'formERP';
    $this->formTitle = 'Accessories BOM';
    $this->_ERP_DOCACRONYM = 'AB';
    $this->_DOC_COUNTERNAME = 'counter_ABL';
    $this->formButtons = ['btnNew', 'btnSaveForm', 'btnCancelForm', 'btnEnterEditMode', 'btnCopyAndNew', 'btnMultipleCopyAndNew', 'removeLine', 'btnSpacer50px', 'btnImportBOM', 'btnMultipleEdit'];


    $this->formGroups['Item Information']    =    ['entitynumber', 'docnumber', 'doclinenumber', 'docdate', 'ldcslnumber', 'company', 'doctype', 'formtype', 'ItemName', 'itemdescription', 'Color', 'docstatus', 'linestatus'];

    $this->formGroups['Related to the Garment']    =    ['ProcessLevel', 'Placement', 'Size', 'GarmentDesignOrColor', 'ReqQty'];

    $this->formGroups['Consumption and Process Loss']    =   ['UOM', 'Consumption', 'ProcessLoss', 'FinalReqQty'];

    $this->formGroups['Comments']    =   ['note'];

    // $this->formGroups['Item Information']  = ['entitynumber', 'docnumber', 'docdate', 'company', 'doctype', 'formtype', 'buyername', 'subdoclinenumber', 'docstatus'];
    
    // $this->formGroups['Related to the Garment']    = ['TraceID', 'Placement', 'Size', 'Color', 'Source', 'Specification', 'ItemName', 'GarmentDesignOrColor', 'ProcessLevel'];
    
    // $this->formGroups['Consumption and Process Loss']    = ['NominatedSupplier', 'Consumption', 'UOM', 'ProcessLoss', 'ConsumptionEntryTime', 'GarmentQty_Dzn', 'GarmentQtyEntryTime', 'GarmentQtyChangeRate', 'ReqQty'];
    
    // $this->formGroups['Comments']    = ['ReadyForBooking', 'RFB_Time', 'BookingApproval', 'BATime', 'MaterialRemarks', 'RowTester', 'ExpectedInHouseDate', 'ExpectedInHouseChangeRate', 'FinalConsumption', 'FinalProcessLoss', 'FinalGarmentQty_Dzn', 'FinalExpectedInHouseDate', 'FinalReqQty'];
    
    $this->formGroups['System Information']    = ['entrypersonbadge', 'doccreationtime'];


    $conn = new ErpDbConn;
    /**
     * Check doc counter is exist or not,
     * if not exist then create doc counter
     */
    $sql = "SELECT * FROM erp_counter WHERE countername = '$this->_DOC_COUNTERNAME'";
    $result = $conn->query($sql);
    if ($result->num_rows == 0) {
      $sql = "INSERT INTO erp_counter (countername, prefix, nextnumber) VALUES ('$this->_DOC_COUNTERNAME', '$this->_ERP_DOCACRONYM', '1')";
      $result = $conn->query($sql);
    }

  }

  function array_delete($array, $element) {
    return array_diff($array, [$element]);
  }

  function formStructure($doctype, $formtype, $crudmode) {
    /*
    First, make tableStructure (DB table description)
     */

    $tableStructure = self::tableStructureWithVirtual();

    /*
    Make formStructure (HTML form description)
    Load fields to be used by form builder
     */
    $formStructure = array();

    $formStructure['title']  = $this->formTitle;
    $formStructure['schema'] = $tableStructure['schema'];
    $formStructure['doccounter'] = $this->_DOC_COUNTERNAME;

    /*
    Load tableStructure into formStructure
    This loads the field details
     */
    foreach ($this->formGroups as $groupName => $groupFields) {
      foreach ($groupFields as $groupfield) {
        $formStructure['header'][$groupfield] = $tableStructure['header'][$groupfield];
      }
    }

    /*
    Adapt formStructure
     */
    // docnumber is inserted after loading tableStructure
    $formStructure['header']['docnumber']                = $tableStructure['header']['docnumber'];
    $formStructure['header']['docnumber']['fielddesc']   = 'BOM Line No.';
    // $formStructure['header']['docnumber']['restriction'] = 'hidden';
    $formStructure['header']['entitynumber']['fielddesc'] = 'BOM No.';
    $formStructure['header']['doctype']['default']       = $doctype;
    $formStructure['header']['formtype']['default']      = $formtype;

    unset($formStructure['header']['extraheaderfield2']);


    /**
     * Cross check with database table -------------------------------------------------------------------------------------------------
     */
    $conn = new ErpDbConn;
    $missingFields = array();

    $schemapart = 'header';
    $fieldList  = $conn->showColumns($formStructure['schema']['tablename']);
    $crossCheck = $formStructure[$schemapart];
    foreach ($fieldList as $key => $value) {
      if (!isset($formStructure[$schemapart][$value['Field']])) {
        // $formStructure[$schemapart][$value['Field']] = array();
        // error_log("Missing $schemapart field in docall_define.php: " . $value['Field']);
      } else {
        unset($crossCheck[$value['Field']]);
        $formStructure[$schemapart][$value['Field']]['fieldtype'] = $value['Type'];
      }
    }
    foreach ($crossCheck as $key => $value) {
      $missingFields[] = $key;
    }
    if(count($missingFields) > 0){
    	$missingFields = implode(", ", $missingFields);
    	echo "<script type='text/javascript'>alert('$missingFields are missing in database table');</script>";
    }
    /**
     * Cross check end ---------------------------------------------------------------------------------------------------------------
     */





    /*
    Now implement all different formtypes
     */
    if (isset($formtype)) {
      switch ($formtype) {
      case 'formtype1':

        break;
      case 'formtype2':

        break;

      default:
        //
        break;
      }
    }


    if (isset($crudmode)) {
      switch ($crudmode) {
      case 'create':
        unset($formStructure['header']['doctype']);
        unset($formStructure['header']['docnumber']);
        unset($formStructure['header']['docstatus']);
        unset($formStructure['lines']['lineentrytime']);
        break;

      case 'update':
        break;
      case 'read':
        unset($formStructure['lines']['supplierlot']);
        break;

      default:
        //
        break;
      }
    }

    $this->formStructure = $formStructure;
    return $formStructure;
  }

}
?>