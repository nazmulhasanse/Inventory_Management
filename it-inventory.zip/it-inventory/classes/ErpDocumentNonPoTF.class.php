<?php
class ErpDocumentNonPoTF extends ErpDocumentTemplate6 {
  public function __construct() {
    self::$tableStructure['schema']['tablename'] = 'erp_balance_transaction';
    parent::__construct();

    /**
     * Seven place need to change if you want to change doctype
     * ******* Just need to change doctype ******** 
     * 1. erpdocument.php
     * 2. erpdocument_define.php
     * 3. myclassautoloader.php
     * 4. This child class
     * 5. printdocdefine.php
     * 6. documents-home.php
     * 7. docmx_search.php
     */

    /**
     * Initializes the content of the "constants"
     * and Setting Parameter
     */
    $rootPath = $_SERVER['DOCUMENT_ROOT'];
    $thisPath = dirname($_SERVER['PHP_SELF']);
    $onlyPath = str_replace($rootPath, '', $thisPath);
    $directorypath = $onlyPath;
    
    // $directorypath = '/complate-framework';
    $this->_URL_DOCUMENTAPI        = $directorypath . '/docnonpotf_api.php';
    $this->_URL_DOCDEFINEAPI       = $directorypath . '/erpdocument_define.php?doctype=TF';
    
    $this->URL_DOCDOCSEARCH        = 'docnonpotf_search.php';
    $this->URL_DOCDOCFORM          = 'erpdocument.php?doctype=TF';
    $this->URL_MAINJS              = './js/erpdocument_template6.js';
    $this->URL_DOCJS               = './js/docnonpotf.js';
    $this->URL_DOCJS_CUSTOMIZATION = './js/docnonpotf-customization.js';
    $this->URL_DOCCSS              = 'css/docerp_template6.css';



    $this->formId    = 'formERP';
    $this->formTitle = 'Transfer Document';
    $this->_ERP_DOCACRONYM = 'TF';
    $this->_ERP_DOCTYPE = 'TF';
    $this->_DOC_COUNTERNAME = 'counter_NP_TF';

    $this->_DOCSTATUS = array(
      '0' => 'Entered',
      '1' => 'Sent to Textile',
      '2' => 'Sent to NOW',
      '100K' => 'Fake'
      );

    $this->_LINESTATUS = array(
      '0' => 'Entered',
      '1' => 'Sent to Textile',
      '9' => 'Cancelled',
      '100K' => 'Fake'
      );

    /**
     * Change here according to requirement
     */
    /**
     * Form upper button
     */
    $this->formButtons = ['btnSaveForm', 'btnCancelForm', 'btnEnterEditMode', 'btnPrintSheet'];
    // $this->formButtons = ['btnSaveForm', 'btnCancelForm', 'btnEnterEditMode', 'btnPrintSheet', 'btnSentTextile', 'btnParentPO', 'btnAmend', 'btnParentPO', 'btnSendToTextile', 'btnAutoRevised'];
    // $this->formButtons = ['btnSaveForm', 'btnCancelForm', 'btnEnterEditMode', 'btnPrintSheet', 'btnSentTextile'];
    // $this->linesButtons = ['newLine', 'saveLine', 'saveLineAndNew', 'copyAndNewLine', 'removeLine'];
    $this->linesButtons = ['newLine', 'saveLine', 'removeLine','btnCancelDocLine'];


    /**
     * Document Header
     */
    $this->formGroups['Document Information']  = ['formtype', 'doctype', 'docstatus', 'docnumber', 'docdate', 'company', 'mrnumber'];
    
    /**
     * Document Line
     */
    $this->formGroups['Line__Line Group 1']      = ['idlines','linenumber'];
      
    $this->formGroups['Line__Line Group 2']      = ['itemnature', 'itemcode', 'itemname', 'itemdescription'];

    $this->formGroups['Line__Line Group 3']      = ['tnxquantity', 'uom', 'binlocation', 'qualitylevelcode'];



    $this->formGroups['Line Information']        = ['lines'];
    // $this->formGroups['Document File']        = ['docfilepaths'];
    $this->formGroups['System Information']      = ['entrypersonbadge', 'entrypersonname', 'doccreationtime', 'lastupdateuser', 'lastupdatetime'];

    $this->formLineColumns = ['idlines', 'linenumber' , 'linestatus', 'templatecode', 'transactiontype', 'projectcode', 'itemnature', 'itemcode', 'itemname', 'itemdescription', 'tnxquantity', 'uom', 'whlocation', 'binlocation', 'qualitylevelcode'];



    /**
     * Check doc counter is exist or not,
     * if not exist then create doc counter
     */
    $conn = new ErpDbConn;
    $sql = "SELECT * FROM erp_counter WHERE countername = '$this->_DOC_COUNTERNAME'";
    $result = $conn->query($sql);
    if ($result->num_rows == 0) {
      $sql = "INSERT INTO erp_counter (countername, prefix, nextnumber) VALUES ('$this->_DOC_COUNTERNAME', '$this->_ERP_DOCACRONYM', '1')";
      $result = $conn->query($sql);
    }

  }

  function array_delete($array, $element) {
    return array_diff($array, [$element]);
  }

  function formStructure($doctype, $formtype, $crudmode) {
    /*
    First, make tableStructure (DB table description)
     */

    $tableStructure = self::tableStructureWithVirtual();

    /*
    Make formStructure (HTML form description)
    Load fields to be used by form builder
     */
    $formStructure = array();

    $formStructure['title']  = $this->formTitle;
    $formStructure['schema'] = $tableStructure['schema'];
    $formStructure['doccounter'] = $this->_DOC_COUNTERNAME;
    $formStructure['docstatus'] = $this->_DOCSTATUS;
    $formStructure['linestatus'] = $this->_LINESTATUS;


    /*
    Load tableStructure into formStructure
    This loads the field details
     */
    foreach ($this->formGroups as $groupName => $groupFields) {
      $lineGroup = explode("__", $groupName)[0];
      if ($groupFields != ["lines"] && $lineGroup != "Line") {
        foreach ($groupFields as $groupfield) {
          $formStructure['header'][$groupfield] = $tableStructure['header'][$groupfield];
        }
      } else {
        foreach ($this->formLineColumns as $groupfield) {
          $formStructure['lines'][$groupfield] = $tableStructure['lines'][$groupfield];
        }
      }
    }

    /*
    Adapt formStructure
     */
    // docnumber is inserted after loading tableStructure
    $formStructure['header']['docnumber']                = $tableStructure['header']['docnumber'];
    $formStructure['header']['docnumber']['fielddesc']   = 'Document Number';
    $formStructure['header']['docnumber']['restriction'] = 'hidden';
    $formStructure['header']['doctype']['default']       = $doctype;
    $formStructure['header']['formtype']['default']      = $formtype;
    $formStructure['lines']['doclinenumber']['restriction']= 'viewonly';
    


    /**
     * Cross check with database table -------------------------------------------------------------------------------------------------
     */
    $conn = new ErpDbConn;
    $missingFields = array();

    $schemapart = 'header';
    $fieldList  = $conn->showColumns($formStructure['schema']['tablename']);
    $crossCheck = $formStructure[$schemapart];
    foreach ($fieldList as $key => $value) {
      if (!isset($formStructure[$schemapart][$value['Field']])) {
        // $formStructure[$schemapart][$value['Field']] = array();
        // error_log("Missing $schemapart field in docall_define.php: " . $value['Field']);
      } else {
        unset($crossCheck[$value['Field']]);
        $formStructure[$schemapart][$value['Field']]['fieldtype'] = $value['Type'];
      }
    }
    unset($crossCheck['_btn_downloadcostingsheet']); // virtual form field
    foreach ($crossCheck as $key => $value) {
      $missingFields[] = $key;
    }

    $schemapart = 'lines';
    $fieldList  = $conn->showColumns($formStructure['schema']['tablename']);
    $crossCheck = $formStructure[$schemapart];
    foreach ($fieldList as $key => $value) {
      if (!isset($formStructure[$schemapart][$value['Field']])) {
        // $formStructure[$schemapart][$value['Field']] = array();
        // error_log("Missing $schemapart field in docall_define.php: " . $value['Field']);
      } else {
        unset($crossCheck[$value['Field']]);
        $formStructure[$schemapart][$value['Field']]['fieldtype'] = $value['Type'];
      }
    }
    unset($crossCheck['_btn_priceproposal']);  // virtual form field
    foreach ($crossCheck as $key => $value) {
      $missingFields[] = $key;
    }
    if(count($missingFields) > 0){
        $missingFields = implode(", ", $missingFields);
        echo "<script type='text/javascript'>alert('$missingFields are missing in database table');</script>";
    }
    /**
     * Cross check end ---------------------------------------------------------------------------------------
     */


    /*
    Process group checkbox
     */
    // // for line
    // array_push($this->formGroups['Document Information'], 'headergcb1_groupcheckbox_1');
    // $formStructure['header']['headergcb1_groupcheckbox_1']['fielddesc']      = 'Header Group Check Box-1';
    // $formStructure['header']['headergcb1_groupcheckbox_1']['html_InputTag']  = 'checkbox';
    // $formStructure['header']['headergcb1_groupcheckbox_1']['groupname']      = 'gp1';

    // array_push($this->formGroups['Document Information'], 'headergcb1_groupcheckbox_2');
    // $formStructure['header']['headergcb1_groupcheckbox_2']['fielddesc']      = 'Header Group Check Box-2';
    // $formStructure['header']['headergcb1_groupcheckbox_2']['html_InputTag']  = 'checkbox';
    // $formStructure['header']['headergcb1_groupcheckbox_2']['groupname']      = 'gp1';


    // $formStructure['header']['requestor']['restriction'] = 'required';
    // $formStructure['lines']['pricerequisitionnumber']['fielddesc'] = 'Fabric Price Requisition No.';

    /*
    Now implement all different formtypes
     */
    if (isset($formtype)) {
      switch ($formtype) {

      case 'IU':
        $this->formTitle = 'Stock Transaction';
        $this->_ERP_DOCACRONYM = 'TF';
        /**
         * unset header fields
         */

        // unset($formStructure['header']['purchasemode']);
        // $this->formGroups['Document Information']  = $this->array_delete($this->formGroups['Document Information'], 'purchasemode');

        // $formStructure['lines']['doclinenumber']['fielddesc']= 'Requisition Line No.';   
        // unset($formStructure['lines']['requisitionlinenumber']);
        // $this->formLineColumns = $this->array_delete($this->formLineColumns, 'requisitionlinenumber');
        // $this->formGroups['Line__Line Group 1']  = $this->array_delete($this->formGroups['Line__Line Group 1'], 'requisitionlinenumber');


        break;

      case 'TF':
        $this->formTitle = 'Stock Transaction';
        $this->_ERP_DOCACRONYM = 'TF';

        break;

      case 'TI':
        $this->formTitle = 'Stock Transaction';
        $this->_ERP_DOCACRONYM = 'TF';

        break;

      
      default:
        //
        break;
      }
    }

    if (isset($crudmode)) {
      switch ($crudmode) {
      case 'create':
        // unset($formStructure['header']['doctype']);
        // unset($formStructure['header']['docnumber']);
        // unset($formStructure['header']['docstatus']);
        // unset($formStructure['lines']['lineentrytime']);
  
        // unset($formStructure['lines']['_btn_priceproposal']);
        // unset($formStructure['header']['_btn_downloadcostingsheet']);        
        break;

      case 'update':
        break;
      case 'read':
        // unset($formStructure['lines']['supplierlot']);
        // unset($formStructure['lines']['_btn_priceproposal']);
        // unset($formStructure['header']['_btn_downloadcostingsheet']);

        break;

      default:
        //
        break;
      }
    }

    $this->formStructure = $formStructure;
    /*
    Special HTML tag
    unset group checkbox
     */
    // For header data
    // unest virtual field
    // unset($formStructure['header']['headergcb1_groupcheckbox_1']);
    // unset($formStructure['header']['headergcb1_groupcheckbox_2']);
    // $formStructure['header']['headergcb1']['fielddesc']      = 'Header Group Check Box-1';
    // $formStructure['header']['headergcb1']['html_InputTag']  = 'checkbox';
    // $formStructure['header']['headergcb1']['groupname']      = 'gp1';

    return $formStructure;
  }

}
?>