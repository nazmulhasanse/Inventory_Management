<?php
/**
* This class will handle everything 
* for revise spec form
*/
class LineDocRR extends HtmlFormBuilder
{
	// declare class attribute
	public $conn;
	public $queryResult;
	public $sql;
	public $dbname;
	public $formId = 'formERP';
	public $formTitle = 'Create Manual RR';
	public $doc_api = 'newrr_api.php';
	public $formCSS = 'css/generalform.css';
	public $formJS = 'js/newrr.js';
	public $formButtons = array();
	public $lockFields = array();

	public $formStructure = array(
		'fabrictrackingno'          => array('fielddesc' => 'Tracking No.', 'restriction' => 'required'),

		'rrnumber'                  => array('fielddesc' => 'RR No.', 'restriction' => 'viewonly', 'lookup' => true),
		'rrtype'                    => array('fielddesc' => 'RR Type', 'libraryname' => 'rrtype', 'restriction' => 'required'),
		'rrstatus'                  => array('fielddesc' => 'RR Status', 'libraryname' => 'rrstatus', 'restriction' => 'required'),

		'salesorder'                => array('fielddesc' => 'Sales Order', 'restriction' => 'required'),
		'company'                   => array('fielddesc' => 'Division', 'libraryname' => 'company'),
		'endcustomer'               => array('fielddesc' => 'End Customer', 'libraryname' => 'buyer'),

		'itemtype'                  => array('fielddesc' => 'Item Type', 'restriction' => 'viewonly'),
		'itemcode'                  => array('fielddesc' => 'Itemcode', 'restriction' => 'required'),
		'itemdescription'           => array('fielddesc' => 'Item Description', 'fieldtype' => 'textarea'),
		
		'requiredgrossqty'          => array('fielddesc' => 'Required Gross Qty', 'fieldtype' => 'number'),
		'requirednetqty'            => array('fielddesc' => 'Required Net Qty', 'fieldtype' => 'number'),
		'iduom'                     => array('fielddesc' => 'UOM', 'libraryname' => 'UOM'),
		
		'dlvbrktext' => array('fielddesc' => 'Delivery Line Breakdown', 'fieldtype' => 'textarea'),
		'origin' => array('fielddesc' => 'Origin', 'restriction' => 'viewonly', 'fieldvalue' => 'Manual Entry'),

		'sewingstartdate'           => array('fielddesc' => 'Sewing Start Date', 'fieldtype' => 'date'),
		'sewingfinisheddate'        => array('fielddesc' => 'Sewing Finish Date', 'fieldtype' => 'date'),
		'sewingperiod'              => array('fielddesc' => 'Sewing Period'),
		'fabricusageperday'         => array('fielddesc' => 'Fabric Use/Day'),
		'processbeforesewing'       => array('fielddesc' => 'Process Before Sewing'),
		'processaftersewing'        => array('fielddesc' => 'Process After Sewing'),
		'bomdocnumber'              => array('fielddesc' => 'BOM No.', 'lookup' => true),
		'bomlinenumber'             => array('fielddesc' => 'BOM Line No.'),
		
		'cpdocnumber'               => array('fielddesc' => 'CP No.', 'lookup' => true),
		'ldcslnumber'               => array('fielddesc' => 'Item Line No.'),
		'unitprice'                 => array('fielddesc' => 'Unit Price'),
		'pricerequisitionnumber'    => array('fielddesc' => 'Previous Requisition No.'),
		'previousitemcode'          => array('fielddesc' => 'Previous Item Code'),
		'previousfmdocnumber'       => array('fielddesc' => 'Previous FM'),
		'fmdocnumber'               => array('fielddesc' => 'FM', 'restriction' => 'hidden'),
		'projectionfmdocnumber'     => array('fielddesc' => 'Projection FM'),
		'parentidlines'             => array('fielddesc' => 'Parent RR idlines'),
		'parentrrnumber'            => array('fielddesc' => 'Parent RR'),
		'nominatedsupplier'         => array('fielddesc' => 'Nominated Supplier'),
		'nominatedsuppliername'     => array('fielddesc' => 'Nominated Supplier Name'),
		
		'nominatedsupplieraddress'  => array('fielddesc' => 'Nominated Supplier Address'),
		'supplierreferencenumber'   => array('fielddesc' => 'Supplier Reference No.'),
		'paymentterm'                 => array('fielddesc' => 'Payment Term', 'restriction' => 'hidden'),
		'deliveryterm'              => array('fielddesc' => 'Delivery Term', 'restriction' => 'hidden'),
		'groupprojection'           => array('fielddesc' => 'groupprojection', 'restriction' => 'hidden'),
		'salesorderdeliverylinenumber' => array('fielddesc' => 'Sales Order Delivery Line No'),
	);
	
	// declare class method
	public function __construct($dbnum = 1) {
		if ($dbnum === '2') {
			$this->conn = new ErpDbConn('2');
			$this->dbname = "erpprod_bulbul";
		} else {
			$this->conn = new ErpDbConn;
			$this->dbname = "erpprod";
		}
	}

	public function buildEntityForm(){

		$entityForm = '';
		$tr = '';

		foreach ($this->formStructure as $fieldname => $fieldproperties) {
			$fieldproperties['fieldname'] = $fieldname;
			$fielddesc  = $fieldproperties['fielddesc'];

			$fieldproperties['fieldid'] =  $fieldname;
			$fieldproperties['fieldclass'] =  $fieldname;

			//get lock fields
			if($fieldproperties['restriction'] == 'viewonly'){
				$this->lockFields[] = $fieldname;
			}

			$HTML_inputField = $this->makeHTML_inputField($fieldproperties);

			$lookupbtn = "";
			$lookup = (isset( $fieldproperties['lookup'])) ? $fieldproperties['lookup'] : false;
			if($lookup){
				$lookupbtn = $this->makeHTML_button('lookup');
			}

			$restriction = ( isset($fieldproperties['restriction']) ) ? $fieldproperties['restriction'] : '';
			$requiredSpan = "";
			if($restriction == 'required'){
				$requiredSpan = "<span style='color:red; font-weight:bold;font-size: 25px; vertical-align: middle;'>*</span>";
			}

			if($restriction == 'hidden'){
				$tr .= "<tr class='hidden'><th class='$fieldname'>$fielddesc</th><td class='$fieldname'>$HTML_inputField $lookupbtn</td></tr>";
			}else{
				$tr .= "<tr><th class='$fieldname'>$fielddesc</th><td class='$fieldname'>$HTML_inputField $lookupbtn $requiredSpan</td></tr>";
			}
			
		}

		$entityForm .= "<form id='formERP'>";
		$entityForm .= "<table id='newrr'><thead><tr><th>Fields</th><td>Field Value</td></tr></thead><tbody>$tr</tbody></table>";
		$entityForm .= "</br>";
		$entityForm .= "<div id='lowerbutton'>";
		$entityForm .= "<div class='inline'><input type='button' class='btnSave btn-blue btnReadMode btnEnterEditMode' value='Edit' title='Edit'/></div>";
		$entityForm .= "<div class='inline'><input type='button' class='btnSave btn-blue btnEditMode' value='Save' title='Save' onclick = 'LIZERP.saveForm()'/></div>";
		$entityForm .= "<div class='inline'><input type='button' class='btnCancel btn-blue' value='Cancel' title='Cancel' onclick = ''/></div>";
		$entityForm .= "</div>";
		$entityForm .= "</form>";

		return $entityForm;
	}


	public function getEntity($entityKey){

		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$sql = "SELECT *, 'yes' AS fromrevisetable from erp_dev_revisefabricspec where devidlines='$entityKey'";
		$queryResult = $this->conn->query($sql);

		if($queryResult->num_rows > '0'){
			$data = $this->conn->resultToJson($queryResult);
		}else{
			$sql = "SELECT *, idlines AS devidlines, 'no' AS fromrevisetable from erp_dev_documents where idlines='$entityKey'";
			$data = $this->conn->sqlToJson($sql);
			$data = json_decode($data, true);
			unset($data[0]['idlines']);
			$data = json_encode($data);
		}
		$this->conn->close();
		return $data;

	}

	public function setEntity($docdata){

		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$docobj = json_decode($docdata, true);
		$devidlines = $docobj['org_lines']['devidlines'];

		$sql = "SELECT * FROM erp_dev_revisefabricspec WHERE devidlines='$devidlines'";
		$queryResult = $this->conn->query($sql);

		if($queryResult->num_rows > '0'){
			$returnJSON = $this->updateEntity($docdata);
		}else{
			$returnJSON = $this->createEntity($docdata);
		}

      	$this->conn->close();
		return json_encode($returnJSON);

	}


	public function createEntity($docdata){

		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$docobj = json_decode($docdata, true);

		// for original line
		$columnFields = array();
		$fieldValues = array();
		foreach ($docobj['org_lines'] as $fieldname => $fieldvalue) {
			$columnFields[] = $fieldname;
			$fieldValues[]  = $fieldvalue;
		}
		$columnFields = implode(", ", $columnFields);
		$fieldValues  = "'" . implode("','", $fieldValues) . "'";
		$sql = "INSERT INTO erp_dev_revisefabricspec ($columnFields) VALUES($fieldValues)";
		$sql_array[] = $sql;

		// for revise line
		$columnFields = array();
		$fieldValues = array();
		foreach ($docobj['rev_lines'] as $fieldname => $fieldvalue) {
			$columnFields[] = $fieldname;
			$fieldValues[]  = $fieldvalue;
		}
		$columnFields = implode(", ", $columnFields);
		$fieldValues  = "'" . implode("','", $fieldValues) . "'";
		$sql = "INSERT INTO erp_dev_revisefabricspec ($columnFields) VALUES($fieldValues)";
		$sql_array[] = $sql;

		foreach ($sql_array as $key => $sql) {
			$queryResult = $this->conn->query($sql);	  
			if(!$queryResult){
				array_push($returnJSON->errormsgs, "Error, $sql");
				return $returnJSON;
			}
		}

		$returnJSON->result = 'success';
		$returnJSON->devidlines = $docobj['org_lines']['devidlines']; // just like return entity number after create entity
		return $returnJSON;

	}


	public function updateEntity($docdata){
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$docobj = json_decode($docdata, true);
		$org_idlines = $docobj['org_lines']['idlines'];
		$rev_idlines = $docobj['rev_lines']['idlines'];

		// for original line
		$columnFields = array();
		$fieldValues = array();
		foreach ($docobj['org_lines'] as $fieldname => $fieldvalue) {
			// $columnFields[] = $fieldname;
			// $fieldValues[]  = $fieldvalue;
			$org_updateSet .= $fieldname . "=" . "'" . $fieldvalue . "',";
		}
					
		$org_updateSet = rtrim($org_updateSet ,',');
		$sql = "UPDATE erp_dev_revisefabricspec SET $org_updateSet WHERE idlines = '$org_idlines'";
		$sql_array[] = $sql;

		// for revise line
		$columnFields = array();
		$fieldValues = array();
		foreach ($docobj['rev_lines'] as $fieldname => $fieldvalue) {
			// $columnFields[] = $fieldname;
			// $fieldValues[]  = $fieldvalue;
			$rev_updateSet .= $fieldname . "=" . "'" . $fieldvalue . "',";
		}
		
		$rev_updateSet = rtrim($rev_updateSet ,',');
		$sql = "UPDATE erp_dev_revisefabricspec SET $rev_updateSet WHERE idlines = '$rev_idlines'";
		$sql_array[] = $sql;

		foreach ($sql_array as $key => $sql) {
			$queryResult = $this->conn->query($sql);	  
			if(!$queryResult){
				array_push($returnJSON->errormsgs, "Error, $sql");
				return $returnJSON;
			}
		}

		$returnJSON->result = 'success';
		$returnJSON->devidlines = $docobj['org_lines']['devidlines']; // just like return entity number after create entity
		return $returnJSON;
	}


}
?>