<?php
/**
* 
*/
class HtmlFormBuilder
{
	
	function __construct(){

	}


	/**
	 * Generate Production Search Form ----------------------------------------------------------------------------------------
	 */
	public function makeDropdpwn_Library($fieldproperties){
		$conn = new ErpDbConn();

		$fieldname   = $fieldproperties['fieldname'];
		$fielddesc   = ( isset($fieldproperties['fielddesc']) ) ? $fieldproperties['fielddesc'] : $fieldname;
		$fieldvalue  = ( isset($fieldproperties['fieldvalue']) ) ? $fieldproperties['fieldvalue'] : '';
		$libraryname = ( isset($fieldproperties['libraryname']) ) ? $fieldproperties['libraryname'] : '';
		$fieldid     = ( isset($fieldproperties['fieldid']) ) ? $fieldproperties['fieldid'] : $fieldname;
		$fieldclass  = ( isset($fieldproperties['fieldclass']) ) ? $fieldproperties['fieldid'] : $fieldname;
		$restriction = ( isset($fieldproperties['restriction']) ) ? $fieldproperties['restriction'] : '';
		if( $restriction == 'viewonly'){
			$restriction = 'disabled=disabled';
		} else if($restriction == 'hidden'){
			$type = 'hidden';
		}

		$sql = "";
		$options = "";
		if($libraryname == "itemtype"){
			$sql = "SELECT ItemType AS code, ItemDescription AS description FROM mrd_itemtype_description";
		} else {
			$sql = "SELECT Code AS code, Description AS description FROM mrd_library WHERE LibraryName = '$libraryname'";
		}

		$queryResult = $conn->query($sql);
		while($row = $queryResult->fetch_assoc()){
			$code = $row['code'];
			$description = $row['description'];
			$selected = ($searchvalue == $code) ? "selected" : "";
			$options .= "<option value='$code' $selected>$description</option>";
		}
		$selectTag = "
		<select name='$fieldname' class='$fieldclass' id='$fieldid'>
			<option value=''>----------</option>
			$options
		</select>";
		$conn->close();
		return $selectTag;
	}


	public function makeHTML_inputField($fieldproperties){
		$inputField = '';
		

		$fieldname   = $fieldproperties['fieldname'];
		$fielddesc   = ( isset($fieldproperties['fielddesc']) ) ? $fieldproperties['fielddesc'] : $fieldname;
		$fieldvalue  = ( isset($fieldproperties['fieldvalue']) ) ? $fieldproperties['fieldvalue'] : '';
		$libraryname = ( isset($fieldproperties['libraryname']) ) ? $fieldproperties['libraryname'] : '';
		$fieldid     = ( isset($fieldproperties['fieldid']) ) ? $fieldproperties['fieldid'] : $fieldname;
		$fieldclass  = ( isset($fieldproperties['fieldclass']) ) ? $fieldproperties['fieldid'] : $fieldname;
		$restriction = ( isset($fieldproperties['restriction']) ) ? $fieldproperties['restriction'] : '';
		$fieldtype   = ( isset($fieldproperties['fieldtype']) ) ? $fieldproperties['fieldtype'] : '';
		if( $restriction == 'viewonly'){
			$restriction = 'disabled=disabled';
		} else if($restriction == 'hidden'){
			$type = 'hidden';
		}

		// override by global variable like $_GET, $_POST
		$fieldvalue =  (isset($_GET[$fieldname]) && $_GET[$fieldname] != '') ? $_GET[$fieldname] : $fieldvalue;

		if($libraryname != ''){
			$inputField = $this->makeDropdpwn_Library($fieldproperties);
		} else {
			if($fieldtype == 'number'){
				$inputField = "<input type='number' name='$fieldname' value='$fieldvalue' id='$fieldid' class='$fieldclass' $restriction />";
			}else if($fieldtype == 'textarea'){
				$inputField = "<textarea name='$fieldname' value='$fieldvalue' id='$fieldid' class='$fieldclass' $restriction></textarea>";
			}else if($fieldtype == 'date'){
				$inputField = "<input type='text' name='$fieldname' value='$fieldvalue' id='$fieldid' class='$fieldclass datepicker' $restriction />";
			}else{
				$inputField = "<input type='text' name='$fieldname' value='$fieldvalue' id='$fieldid' class='$fieldclass' $restriction />";
			}
			
		}
		
		return $inputField;

	}

	function makeHTML_button($button){
    $buttons                     = array();
    $buttons['btnSaveForm'] = <<<EOF
<input type="button" class="btnEditMode btnSaveForm btn-blue" value="Confirm Spec & Send Item Code Request" title="Save the current document" onclick = 'LIZERP.saveconfirmItemSpecForm();'"/>
EOF;
    $buttons['btnEnterEditMode'] = <<<EOF
<button type="button" class="btnReadMode btnEnterEditMode btn-grey" title="Edit" style="display:none;"><i class="material-icons">edit</i>Edit</button>
EOF;
    $buttons['btnCancelForm'] = <<<EOF
<input type='button' class='btnEditMode btnCancelForm btn-blue' value='Cancel' title='Cancel' onclick = 'ERPLIST.closeconfirmItemSpecForm()'/>
EOF;
    $buttons['lookup'] = <<<EOF
<button type="button" class="btnEditMode btnLookup" title="Click this for look up data" onclick="LIZERP.handleLookup(this);" ><i class="material-icons">search</i></button>
EOF;
    $buttons['_ckb_lineChooser'] = <<<EOF
<input type="checkbox" class="lineChooser" title="Click this for select this" onclick="LIZERP.handleCheckBoxClick(this);" />
EOF;
    $buttons['btnGenerateDesignId'] = <<<EOF
<button type="button" class="btnEditMode btnGenerateDesignId" title="Click this for generate design id" onclick="LIZERP.generateDesignId();" >Generate design Id</button>
EOF;

    return $buttons[$button];

	}
	function generalHTMLFormCSS(){
    $formCSS = <<<EOF
<style type="text/css">
input[type="button"]:disabled {
    background: #dddddd;
}
input[readonly="readonly"] {
     color            : #333333;
     background-color : #EEEEFF;
}
input[disabled="disabled"] {
     color            : #333333;
     background-color : #EEEEFF;
}
textarea[disabled="disabled"] {
     color            : #333333;
     background-color : #EEEEFF;
}
select[disabled="disabled"] {
     color            : #333333;
     background-color : #EEEEFF;
}	
input[type="text"],
input[type="email"],
input[type="number"],
select,
textarea {
    font-family   : Arial;
    font-size     : 13px;
    padding       : 2px;
    border        : 1px solid #7F7F7F;
    border-radius : 3px;
}
</style>
EOF;
	return $formCSS;
	}


}
?>