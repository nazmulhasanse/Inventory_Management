<?php
class ErpDocumentTemplate9 {
/*
TO DO
find a fix for the below query while creating document. Because it limits the length of docnumber
SET @nextdocnum_formatted = CONCAT(@docacronym , '-' , LPAD(@nextdocnum, 6, '0'));
 */
  public $formId;
  public $formTitle;
  public $privilege = "";
  public $lineGroups = "";

  protected $formStructure     = array();
  protected $formBaseStructure = array();
  protected $formButtons       = array();
  protected $formGroups        = array();
  protected $formLineColumns   = array();
  protected $docobj            = array();

  public $ERP_CONST = array();

  public $URL_DOCDEFINEAPI;
  public $URL_DOCDOCSEARCH;
  public $URL_DOCDOCFORM;
  public $URL_MAINJS;
  public $URL_DOCJS;
  public $URL_DOCJS_CUSTOMIZATION;
  public $URL_DOCCSS;
  public $URL_DOCVIEWJS;


// Should Foreign Keys and loose relationships (library) be shown here?
  public static $tableStructure = array(
    'schema' => array(
		'tablename'  => 'erp_bulk_documents',
    ),
    'header' => array(
         // Identification
         'doctype'            => array('fielddesc' => 'doctype', 'restriction' => 'hidden', 'library' => 'doctype'), 
         'formtype'           => array('fielddesc' => 'formtype', 'restriction' => 'hidden'), 
         'docdate'            => array('fielddesc' => 'Document date', 'restriction' => 'required'), 
         'docstatus'          => array('fielddesc' => 'Status', 'restriction' => 'hidden', 'library' => 'docstatus'), 
         'docnumber'          => array('fielddesc' => 'Document Number', 'restriction' => 'hidden'), 
         'company'            => array('fielddesc' => 'Division', 'restriction' => 'required', 'library' => 'Company'), // FK mrd_? currently in the mrd_library
         'buyername'          => array('fielddesc' => 'Buyer Name', 'library' => 'Buyer'),
         'entrypersonbadge'   => array('fielddesc' => 'Entered By', 'restriction' => 'viewonly'),
         'doccreationtime'    => array('fielddesc' => 'Creation Time', 'restriction' => 'viewonly'),
         'entrypersonname'    => array('fielddesc' => 'Entry Person Name', 'restriction' => 'viewonly'),
         'lastupdateuser'     => array('fielddesc' => 'Last Update User', 'restriction' => 'viewonly'),
         'lastupdatetime'     => array('fielddesc' => 'Last Update Time', 'restriction' => 'viewonly'),
         'bomconfirmtime'     => array('fielddesc' => 'Confirm Time', 'restriction' => 'viewonly'),
         'cpconfirmtime'      => array('fielddesc' => 'Confirm Time', 'restriction' => 'viewonly'),
         
         // for common
         
         
         
         
         'supplierreference'  => array('fielddesc' => "Supplier's Reference No."),    
         'creationuser'       => array('fielddesc' => "Creation user"),
         
         
         'costcenter'         => array('fielddesc' => "Cost Center"),    
         'costdept'           => array('fielddesc' => "Cost Dept", 'textarea' => 'textarea'),   
         
         'purchasemode'       => array('fielddesc' => "Procurer"),    
         'warrantyexpiredate' => array('fielddesc' => "Warranty Expire Date", 'date' => 'date'),    
         'suppliername'       => array('fielddesc' => "Supplier Name"),    
         'supplieraddress'    => array('fielddesc' => "Supplier Address", 'textarea' => 'textarea'),    
         'contactno'          => array('fielddesc' => "Contact No"),    
         'attention'          => array('fielddesc' => "Attention"),    
         'totalamount'        => array('fielddesc' => "Total Amount"),    
         'currency'           => array('fielddesc' => "Currency"),   
         'useandcompbenefit' => array('fielddesc' => "Usage & Compliance Benefits", 'textarea' => 'textarea'),   
         'economicbenefit'   => array('fielddesc' => "Economic Benefits", 'textarea' => 'textarea'),   
         
         'poadditionalcost'   => array('fielddesc' => "Additional Cost"),    
         'povatandtax'        => array('fielddesc' => "Vat & Tax(%)"),    
         'podiscountamount'   => array('fielddesc' => "Discount Amount"),    
         'podiscountper'      => array('fielddesc' => "Discount Percentage"),    
         'ponettotal'         => array('fielddesc' => "Net Total"), 
         'podeliverydate'     => array('fielddesc' => 'Delivery Date'),
         
         
         'totalamountwords'   => array('fielddesc' => "Net Total in Words", 'textarea' => 'textarea'), 
         
         'termsandcondition'  => array('fielddesc' => 'Terms & Condition', 'textarea' => 'textarea'),   
         'specialinstruction' => array('fielddesc' => 'Special Instruction', 'textarea' => 'textarea'),  
         
         'challanno'          => array('fielddesc' => 'Challan No'),
         'whlocation'         => array('fielddesc' => 'Receiving Location'), 
         'projectcode'        => array('fielddesc' => 'Project'), 
         'mrnumber'           => array('fielddesc' => 'MR No.'), 

         //Accessories
         'masterreference'      => array('fielddesc' => 'Master Ref#'), 
         'ordertype'            => array('fielddesc' => 'Order Type', 'library' => 'access_ordertype'), 
         'materialsource'       => array('fielddesc' => 'Material Source', 'library' => 'access_action'), 
         'deliverydatebysales'  => array('fielddesc' => 'Requested Delivery Date by Sales & Marketing', 'date' => 'date'), 
         'supplierdeliverydate' => array('fielddesc' => 'Supplier Delivery Date', 'date' => 'date'), 
         'localforeign'         => array('fielddesc' => 'Local/Foreign', 'library' => 'access_purchaseorigin'), 
         'customer'             => array('fielddesc' => 'Customer', 'library' => 'Buyer'), 
         'customerpo'           => array('fielddesc' => 'Customer PO No.', 'textarea' => 'textarea'), 
         'season'               => array('fielddesc' => 'Season', 'library' => 'Season'), 
         // 'brand'                => array('fielddesc' => 'Brand/Department'), 
         'project'              => array('fielddesc' => 'WO No/Project'),
         'pinumber'             => array('fielddesc' => 'PI No.'),
         'style'                => array('fielddesc' => 'Style'), 

         
         'usersectionheadsign'    => array('fielddesc' => 'Requested by: User Section (Centre) Head'), 
         'userdepartmentheadsign' => array('fielddesc' => 'Approved by: User Department Head'), 
         'approvalofcoosign'      => array('fielddesc' => 'Approved by: COO'), 
         'approvalofceo'          => array('fielddesc' => 'Approved by: CEO / on behalf of'), 
         
         
         'isbudgeted'             => array('fielddesc' => 'Budgeted', 'library' => 'YesNo'), 
         'isreplacement'          => array('fielddesc' => 'Replacement', 'library' => 'YesNo'), 
         'isnew'                  => array('fielddesc' => 'New', 'library' => 'YesNo'), 

         'trackingnumber' => array('fielddesc' => 'Tracking No.'),
         'budget'         => array('fielddesc' => 'Budget'),
         'utilized'       => array('fielddesc' => 'Utilized'),
         'balance'        => array('fielddesc' => 'Balance'), 

         'sectionsigndatetime'    => array('fielddesc' => 'Section Request Time'), 
         'departmentsigndatetime' => array('fielddesc' => 'Department Approval Time'), 
         'coosigndatetime'        => array('fielddesc' => 'COO Approval Time'), 
         'ceosigndatetime'        => array('fielddesc' => 'CEO Approval Time'), 
         
         'remarks'                => array('fielddesc' => 'Remarks', 'textarea' => 'textarea'), 

         //Inventory
         'company'        => array('fielddesc' => 'Legal Entry', 'library' => 'company'), 
         'department'     => array('fielddesc' => 'Department'),
         'section'        => array('fielddesc' => 'Section'), 
         'name'           => array('fielddesc' => 'Name'), 
         'designation'    => array('fielddesc' => 'Designation'), 
         'contactnumber'  => array('fielddesc' => 'Mobile no.'), 
         
         'employeeid'     => array('fielddesc' => 'Employee ID.'), 
         'logsheetnumber' => array('fielddesc' => 'Log Sheet No.'), 
         'username'       => array('fielddesc' => 'Username'), 
         'useremail'      => array('fielddesc' => 'Liz Mail'), 
         'domainid'       => array('fielddesc' => 'Domain'), 
         'active'         => array('fielddesc' => 'Is Active?', 'library' => 'YesNo', 'restriction' => 'required'), 

         //For INT PO
         'PO_Number'            => array('fielddesc' => 'PO Number'), 
         'PR_Number'            => array('fielddesc' => 'PR Number'), 
         'Inventory_ID'         => array('fielddesc' => 'Inventory ID'), 
         'Inventory_Type'       => array('fielddesc' => 'Inventory Type', 'library' =>'pctype'), 
         'Serial_Number'        => array('fielddesc' => 'Serial Number'), 
         'Capex_Number'         => array('fielddesc' => 'Capex Number'), 
         'Purchase_Price'       => array('fielddesc' => 'Purchase Price'), 
         'Currency'             => array('fielddesc' => 'Currency', 'library' =>'Currency'), 
         'Purchase_Date'        => array('fielddesc' => 'Purchase Date', 'date' => 'date'), 
         'Expired_Service_Date' => array('fielddesc' => 'Expired Service Date', 'date' => 'date'), 
         'Company_Name'         => array('fielddesc' => 'Company Name'), 
         'Employee_Name'        => array('fielddesc' => 'Employee Name'), 
         'Employee_ID'          => array('fielddesc' => 'Employee ID'), 
         'Department'           => array('fielddesc' => 'Department'), 
         'Section'              => array('fielddesc' => 'Section'), 
         'Contact_Number'       => array('fielddesc' => 'Contact Number'), 
         'Vendor_Name'          => array('fielddesc' => 'Vendor Name'), 
         'Brand'                => array('fielddesc' => 'Brand', 'library' =>'brand'), 
         'Model'                => array('fielddesc' => 'Model'), 
         'Processor'            => array('fielddesc' => 'Processor', 'library' =>'processor'), 
         'RAM'                  => array('fielddesc' => 'RAM', 'library' =>'ram'), 
         'HDD'                  => array('fielddesc' => 'HDD', 'library' =>'hdd'), 
         

    ),

    'lines'  => array(
        	// Identification
        'idlines'                         => array('fielddesc' => 'ID Lines', 'restriction'  => 'hidden'), // this line's ID
        'linenumber'                      => array('fielddesc' => 'Line', 'restriction' => 'viewonly'),
        'doclinenumber'                   => array('fielddesc' => 'Doc Line No', 'restriction' => 'viewonly'),
        'parentdoclinenumber'             => array('fielddesc' => 'Parent BOM Line No.', 'restriction' => 'viewonly'),
        'linestatus'                      => array('fielddesc' => 'Line Status', 'restriction' => 'viewonly'),
        'lineentrytime'                   => array('fielddesc' => 'Line Entry Time', 'restriction' => 'hidden'),
        'linesremarks'                    => array('fielddesc' => 'Remarks', 'textarea' => 'textarea'),
        'purposeofbackup'                 => array('fielddesc' => 'Purpose of Backup', 'textarea' => 'textarea'),
        'action'                          => array('fielddesc' => 'Action'),
        
        
        'fabriccolor'                     => array('fielddesc' => 'Fabric Color/Panton No.'),
        
        'currency'                        => array('fielddesc' => 'Currency', 'library' => 'Currency'),
        'itemcodestatus'                  => array('fielddesc' => 'Item Code Status', 'library' => 'itemcodestatus'),
        'itemtype'                        => array('fielddesc' => 'Item Type'),
        'requisitionlinenumber'           => array('fielddesc' => 'Requisition Line No.'),
        
        'itemname'                        => array('fielddesc' => 'Item Name'),
        'itemnature'                      => array('fielddesc' => 'Item Nature'),
        // 'brand'                           => array('fielddesc' => 'Brand'),
        'color'                           => array('fielddesc' => 'Color'),
        'sizeormeasurement'               => array('fielddesc' => 'Size or Measurement'),
        'itemdescription'                 => array('fielddesc' => 'Item Description', 'textarea' => 'textarea'),
        'itemcode'                        => array('fielddesc' => 'Full Item Code'),
        
        'orderqty'                        => array('fielddesc' => 'Order Qty'),
        'iduom'                           => array('fielddesc' => 'UoM'),
        'deliverydate'                    => array('fielddesc' => 'Delivery Date'),
        'purchasemode'                    => array('fielddesc' => 'Procurer'),
        
        'unitprice'                       => array('fielddesc' => 'Unit Price'),
        'extracost'                       => array('fielddesc' => 'Extra Cost'),
        'amountwithoutdiscount'           => array('fielddesc' => 'Amount without Discount'),
        'discountamount'                  => array('fielddesc' => 'Discount Amount'),
        'amount'                          => array('fielddesc' => 'Price (Amount in BDT)'),
        'capexno'                         => array('fielddesc' => 'Capex No.'),
        'costcenter'                      => array('fielddesc' => 'Cost Center'),    
        'costdept'                        => array('fielddesc' => 'Cost Dept', 'textarea' => 'textarea'), 
        'company'                         => array('fielddesc' => 'Division'),  
        'extracostdescription'            => array('fielddesc' => 'Extra Cost Description', 'textarea' => 'textarea'), 
        'discountpercentage'              => array('fielddesc' => 'Discount Percentage'),  
        
        'project'                         => array('fielddesc' => 'Project'),
        // 'itemnature'                   => array('fielddesc' => 'Item Nature', 'library' => 'NonPOItemNature'),
        
        'prlineno'                    => array('fielddesc' => 'PR Line No.'),  
        'polineno'                    => array('fielddesc' => 'PO Line No.'),  
        'tnxquantity'                 => array('fielddesc' => 'Quantity'),  
        'quantity'                    => array('fielddesc' => 'Quantity'),  
        'usefullife'                  => array('fielddesc' => 'Useful life'),  
        'inhouseperiod'               => array('fielddesc' => 'In house Period'),  
        'uom'                         => array('fielddesc' => 'UoM'),  
        'whlocation'                  => array('fielddesc' => 'Warehouse Location'), 
        'binlocation'                 => array('fielddesc' => 'Bin Location'),  
        'qualitylevelcode'            => array('fielddesc' => 'Quality Level'), 
        'templatecode'                => array('fielddesc' => 'Template', 'library' => 'stocktransactiontemplate'), 
        'projectcode'                 => array('fielddesc' => 'Project'), 
        'transactiontype'             => array('fielddesc' => 'Transaction Type'),
        'purpose'                     => array('fielddesc' => 'Purpose of Use'), 
        'chemicalnature'              => array('fielddesc' => 'Chemical Nature'), 
        'chemicalcharecter'           => array('fielddesc' => 'Chemical Charecteristics'), 
        'supplierorigin'              => array('fielddesc' => 'Supplier Origin'), 
        
        'requestername'               => array('fielddesc' => 'Requestor Name'),  
        'requestercontactno'          => array('fielddesc' => 'Requestor Contact No.'),  
        'capexfilepaths'              => array('fielddesc' => 'Capex Attachment', 'html_InputTag' => '_file_'),
        'enduserrequisitionfilepaths' => array('fielddesc' => 'End User Requisition Attachment', 'html_InputTag' => '_file_'),
        'quotationsfilepaths'         => array('fielddesc' => 'Quotations Attachment', 'html_InputTag' => '_file_'),
        'csfilepathas'                => array('fielddesc' => 'CS Attachment', 'html_InputTag' => '_file_'),
        
        //Accessories
        'placement'                => array('fielddesc' => 'Placement'),  
        'trimscatagory'            => array('fielddesc' => 'Trims Catagory', 'library' => 'Elastic_Category'),  
        'cartontype'               => array('fielddesc' => 'Carton Type', 'library' => 'CartonType'),  
        'pricecalculationunit'     => array('fielddesc' => 'Price Calculation Unit', 'library' => 'access_PriceCalculationUnit', 'restriction' => 'required'),  
        'priceperSQM'              => array('fielddesc' => 'Price Per SQM'),  
        // 'construction'              => array('fielddesc' => 'Construction', 'library' => 'construction'),  
        // 'composition'              => array('fielddesc' => 'Composition', 'library' => 'composition'),  
        // 'shadeno'              => array('fielddesc' => 'Shade No.', 'restriction' => 'required'),  
        // 'elasticcode'              => array('fielddesc' => 'Elastic Code', 'restriction' => 'required'),  
        // 'width'              => array('fielddesc' => 'Width', 'restriction' => 'required'),  
        // 'widthuom'              => array('fielddesc' => 'Width UoM', 'library' => 'UOM', 'restriction' => 'required'),  
        'etadate'                 => array('fielddesc' => 'ETA Date', 'date' => 'date'),  
        'exchangerate'            => array('fielddesc' => 'Exchange Rate'),  
        'stockclassification'     => array('fielddesc' => 'Stock Classification', 'library' => 'stockclassification'),  
        'stockclassificationdate' => array('fielddesc' => 'Stock Classification Date', 'date' => 'date'),  
        
        'subcode01'              => array('fielddesc' => 'Sub Code 01'), 
        'subcode02'              => array('fielddesc' => 'Sub Code 02'), 
        'subcode03'              => array('fielddesc' => 'Sub Code 03'), 
        'subcode04'              => array('fielddesc' => 'Sub Code 04'), 
        'subcode05'              => array('fielddesc' => 'Sub Code 05'), 
        'subcode06'              => array('fielddesc' => 'Sub Code 06'), 
        'subcode07'              => array('fielddesc' => 'Sub Code 07'), 
        'subcode08'              => array('fielddesc' => 'Sub Code 08'), 
        'subcode09'              => array('fielddesc' => 'Sub Code 09'), 
        'subcode10'              => array('fielddesc' => 'Sub Code 10'), 
        'subcode11'              => array('fielddesc' => 'Sub Code 11'), 
        'subcode12'              => array('fielddesc' => 'Sub Code 12'), 

        //Inventory

       'warrantyexpiredate' => array('fielddesc' => "Warranty Expire Date", 'date' => 'date'),    
       'suppliername'       => array('fielddesc' => "Supplier Name"),    
       'supplieraddress'    => array('fielddesc' => "Supplier Address", 'textarea' => 'textarea'),
       'purchasedate'       => array('fielddesc' => 'Purchase Date', 'date' => 'date'),  
       'ponumber'           => array('fielddesc' => 'PO No.'), 
       'capexnumber'        => array('fielddesc' => 'Capex No.'), 

        
        'serialnumber'    => array('fielddesc' => 'Serial No.'), 
        'inventoryid'     => array('fielddesc' => 'Inventory ID.'), 
        
        'laptopordesktop'   => array('fielddesc' => 'Inventory Type', 'library' => 'pctype'),  
        'ram'               => array('fielddesc' => 'RAM', 'library' =>'ram'),  
        'hdd'               => array('fielddesc' => 'Hard Drive', 'library' =>'hdd'),  
        'addtionalharddisk' => array('fielddesc' => 'Additional Hard Drive', 'library' =>'hdd'),  
        'processor'         => array('fielddesc' => 'Processor', 'library' =>'processor'),  
        'brand'             => array('fielddesc' => 'Brand', 'library' =>'brand'),  
        'keyboard'          => array('fielddesc' => 'Keyboard', 'library' =>'YesNo'),  
        'mouse'             => array('fielddesc' => 'Mouse', 'library' =>'ITINV_Mouse'),  
        'extramonitor'      => array('fielddesc' => 'Extra Monitor', 'library' =>'YesNo'),  
        'bag'               => array('fielddesc' => 'Laptop Bag', 'library' =>'YesNo'),  
        'itpolicy'          => array('fielddesc' => 'IT Policy', 'library' =>'YesNo'),  
        
    		'username'        => array('fielddesc' => 'User Name'), 

        'receivedate'        => array('fielddesc' => 'Receive Date'), 
        'receivetype'        => array('fielddesc' => 'Receive Type', 'library' =>'receivetype'), 
        'returndate'        => array('fielddesc' => 'Return Date'), 
        'returntype'        => array('fielddesc' => 'Return Type', 'library' =>'returntype'), 

        'model'                => array('fielddesc' => 'Model'), 
        'remarks'                => array('fielddesc' => 'Remarks', 'textarea' => 'textarea'), 


        //Accessories
        'fabricationplacementattc'        => array('fielddesc' => 'Technical Documents Apparel', 'html_InputTag' => '_file_'),
        'fabricationplacementtextileattc' => array('fielddesc' => 'Technical Documents Textile', 'html_InputTag' => '_file_'),
        'garmentpicattc'                  => array('fielddesc' => 'Garment picture', 'html_InputTag' => '_file_'),
        'sizecolorbreakdownattc'          => array('fielddesc' => 'Size colorbreakdown', 'html_InputTag' => '_file_'),
        'measurementsheetattc'            => array('fielddesc' => 'Measurement sheet', 'html_InputTag' => '_file_'),
        
        'linecreationuser'              => array('fielddesc' => 'Creation User', 'restriction' => 'viewonly'),
        'linecreationtime'              => array('fielddesc' => 'Creation Time', 'restriction' => 'viewonly'),
        'lastlineupdateuser'              => array('fielddesc' => 'Last Update User', 'restriction' => 'viewonly'),
        'lastlineupdatetime'              => array('fielddesc' => 'Last Update Time', 'restriction' => 'viewonly'),


        //For INT PO
         'PO_Number'            => array('fielddesc' => 'PO Number'), 
         'PR_Number'            => array('fielddesc' => 'PR Number'), 
         'Inventory_ID'         => array('fielddesc' => 'Inventory ID'), 
         'Inventory_Type'       => array('fielddesc' => 'Inventory Type', 'library' =>'pctype'), 
         'Serial_Number'        => array('fielddesc' => 'Serial Number'), 
         'Capex_Number'         => array('fielddesc' => 'Capex Number'), 
         'Purchase_Price'       => array('fielddesc' => 'Purchase Price'), 
         'Currency'             => array('fielddesc' => 'Currency', 'library' =>'Currency'), 
         'Purchase_Date'        => array('fielddesc' => 'Purchase Date', 'date' => 'date'), 
         'Expired_Service_Date' => array('fielddesc' => 'Expired Service Date', 'date' => 'date'), 
         'Company_Name'         => array('fielddesc' => 'Company Name'), 
         'Employee_Name'        => array('fielddesc' => 'Employee Name'), 
         'Employee_ID'          => array('fielddesc' => 'Employee ID'), 
         'Department'           => array('fielddesc' => 'Department'), 
         'Section'              => array('fielddesc' => 'Section'), 
         'Contact_Number'       => array('fielddesc' => 'Contact Number'), 
         'Vendor_Name'          => array('fielddesc' => 'Vendor Name'), 
         'Brand'                => array('fielddesc' => 'Brand', 'library' =>'brand'), 
         'Model'                => array('fielddesc' => 'Model'), 
         'Processor'            => array('fielddesc' => 'Processor', 'library' =>'processor'), 
         'RAM'                  => array('fielddesc' => 'RAM', 'library' =>'ram'), 
         'HDD'                  => array('fielddesc' => 'HDD', 'library' =>'hdd'), 
    ),
  );


  public function __construct() {
    $formId = 'formERP';
    $conn = new ErpDbConn;

    $lng = (isset($_SESSION['LNG'])) ? $_SESSION['LNG'] : 'en';
    $lngObj = new ErpString($lng, 'AppS');
    $this->docStr = $lngObj->docStr;
  }

  public static function tableStructureWithVirtual() {
    $tableStructure = self::$tableStructure;
    $tableStructure['lines']['supplierlot']['fielddesc']      = 'Supplier Lot';
    $tableStructure['lines']['supplierlot']['fieldtype']      = 'varchar(30)';
    $tableStructure['lines']['supplierlot']['virtual']        = true;

    $tableStructure['lines']['_btn_deliveryline']['fielddesc']      = 'Delivery Line';
    $tableStructure['lines']['_btn_deliveryline']['fieldtype']      = '__htmlbutton';
    $tableStructure['lines']['_btn_deliveryline']['value']          = 'open_in_new';
    $tableStructure['lines']['_btn_deliveryline']['virtual']        = true;

    $tableStructure['lines']['_ckb_linechooser']['fielddesc']      = 'Select Line';
    $tableStructure['lines']['_ckb_linechooser']['fieldtype']      = '_htmlcheckbox';
    $tableStructure['lines']['_ckb_linechooser']['value']          = '';
    $tableStructure['lines']['_ckb_linechooser']['virtual']        = true;

    $tableStructure['header']['_btn_downloadcostingsheet']['fielddesc']      = 'Download Costing Sheet';
    $tableStructure['header']['_btn_downloadcostingsheet']['fieldtype']      = '__htmlbutton';
    $tableStructure['header']['_btn_downloadcostingsheet']['value']          = '_file_download_';
    $tableStructure['header']['_btn_downloadcostingsheet']['virtual']        = true;

    return $tableStructure;
  }

  public function __toString() {
    return json_encode($this->docobj);
  }

  /**
   * Generates a form based on a structured list of fields
   */
  public function buildForm() {
    $formStructure = $this->formStructure;
    /*
    Starts echoing the actual form
     */
    echo <<<EOF
EOF;
echo <<<EOF
<div class="erpFormProcessingOverlay" id="erpFormProcessingOverlay" style="display:block;">
  <div class="erpFormProcessingOverlay-body" id="erpFormProcessingOverlay-body">
	  <center><img src="img/spinner.gif"></center>
		<div id="erpFormProcessingOverlay-message" style="color:black; font-weight:bold; font-size:20px;"><center>Processing, please wait.</center></div>
	</div>  
</div>
EOF;

    echo <<<EOF
<form action="#" method="post" id="$this->formId" autocomplete="off" style="display:none;">
    <div id="upperButtonBar" style="height:50px;">

EOF;
    foreach ($this->formButtons as $formButton) {
      echo self::indented(2, self::HTML_button($formButton));
    }
    echo <<<EOF
    </div>
    <div id="formCaption">
        <div class="w40">$this->formTitle</div>
        <div class="w20 text_center">
            <span></span>
            <span id="spandocnumber"></span><input type="hidden" name="docnumber" id="spandocnumber" value=""/>
        </div>
        <div class="w40 text_right">
            <span id="spandocstatus"></span>
        </div>
        <div class="clearfix"></div>
    </div>
    <div id="formError"></div>
    <div id="formAlert"><i class="material-icons">info</i><span></span></div>

EOF;
    foreach ($this->formGroups as $groupName => $groupFields) {
      $containerName = "fieldset_" . strtolower(str_replace(" ", "", $groupName));
      $lineGroup = explode("__", $groupName)[0];
      if ($groupFields != ["lines"] && $lineGroup != "Line") {
        echo self::indented(2, "<fieldset id=\"$containerName\">");
        echo self::indented(3, "<legend>$groupName</legend>");
        // echo chr(13).chr(10);
        foreach ($groupFields as $groupfield) {
          echo self::indented(3, self::HTML_headerfield($groupfield));
        }
        echo self::indented(2, '</fieldset>');

      } else if($lineGroup == "Line"){
        $groupName = explode("__", $groupName)[1];
        $containerName = "fieldset_" . strtolower(str_replace(" ", "", $groupName));
        $this->lineGroups .= self::indented(2, "<fieldset id=\"$containerName\">");
        $this->lineGroups .= self::indented(3, "<legend>$groupName</legend>");
        // echo chr(13).chr(10);
        foreach ($groupFields as $groupfield) {
          $this->lineGroups .= self::indented(3, self::HTML_lineFieldGroup($groupfield));
        }
        $this->lineGroups .= self::indented(2, '</fieldset>');

      } else {
        // Opening up to <table>

        echo <<<EOF
    <div id="formLinesContainer">    

    <div id="formLinesFieldset" style="display:block; float:left;">
    <!-- <div id="formLinesFieldset" style="display:block;"> -->
    <div id="formLineslegend">$groupName</div>

EOF;
        foreach ($this->linesButtons as $linesButton) {
          echo self::indented(2, self::HTML_button($linesButton));
        }
        echo <<<EOF
    <div class="clearfix"></div>
    <div id="leftFormLines">    
    <div id="formLines">
        <!-- Regular fieldset+legend doesn't work because of the horizontal scroll -->
        <!-- <div id="legend">$groupName</div> this code is comment 2017-08-01 -->
        <div id="$containerName">
            <span id="spanBtnFileAttachment">
            &nbsp;&nbsp;
            <input type="button" class="btnReadMode btnFileAttachment btn-grey" value="Attach File" title="Attach File line wise in Document" style="display:none;"/> 
            <br/><br/>
            </span>
            <table border="0" cellpadding="0" cellspacing="0">

EOF;

        // <tr> <th></th> </tr>
        echo self::indented(3, '<thead>');
        echo self::indented(4, '<tr>');
        echo self::indented(5, '<th></th>'); // First column contains the floating buttons

        // $formLineFields = array_keys($formStructure['lines']);
        // foreach ($formLineFields as $columnField) {
        foreach ($this->formLineColumns as $columnField) {
          $columnDesc        = isset($formStructure['lines'][$columnField]['fielddesc']) ? $formStructure['lines'][$columnField]['fielddesc'] : $columnField;
          $columnRestriction = isset($formStructure['lines'][$columnField]['restriction']) ? $formStructure['lines'][$columnField]['restriction'] : '';
          $hide              = ($columnRestriction == 'hidden') ? ' style="display:none;"' : '';
          echo self::indented(5, "<th class=\"$columnField\"$hide>$columnDesc</th>");
        }

        echo self::indented(4, '</tr>');
        echo self::indented(3, '</thead>');

        // <tbody> <tr> <td></td> </tr> </tbody>
        echo self::indented(4, '<tbody>');
        // echo self::indented(5, '<tr data-id="1" class="valid">');
        echo self::indented(5, '<tr data-id="1" class="editable">');

        // Floating buttons
        echo <<<EOF
                    <td>
                        <div class="div_editButton" style="float:left;position:absolute;display:none;">
                            <input type="button" class="editLine btn-blue material-icons" style="font-size:24px; display:none" value="edit" />
                        </div>
                        <div class="div_labelButton" style="float:left;position:absolute;display:none;">
                            <input type="button" class="printLine btn-blue material-icons" style="font-size:24px;" value="print" />
                        </div>
                    </td>

EOF;
        // foreach ($formLineFields as $columnField) {
        foreach ($this->formLineColumns as $columnField) {
          echo self::indented(5, self::HTML_columnfield($columnField));
        }
        echo self::indented(5, '</tr>');
        echo self::indented(4, '</tbody>');

        // </table> and Closing
        echo self::indented(3, '</table>');
        echo self::indented(2, '</div>');
        echo self::indented(1, '</div>');
        echo '</div>';



    echo <<<EOF
    <div id="rightFormLines" style="display:none;">
      <div id="dragbar"></div>
      <fieldset id="rightFormButtons"> 
        <div style="float:right; display:inline-block;">
          <!--<input type="button" class="btnEditMode saveLine btn-blue" value="Save" title="Save current line" style="display:block;"/>-->        
          <!--<input type="button" class="btnEditMode saveLineAndNew btn-blue" value="Save & New" title="Save the current line and new line" style="display:none;"/>-->
          <input type="button" class="btnEditMode cancelLine btn-grey material-icons" value="cancel" title="Cancel line" style="display: none;"> 
        </div>
      </fieldset>
      <br/>
    $this->lineGroups
    </div> <!-- close rightFormLines-->
    </div> <!-- close formLinesFieldset-->
    </div> <!-- close formLinesContainer-->
    <div class="clearfix"></div>
EOF;

      }
    }

    echo <<<EOF
    <span id="lowerButtonBar">
    </span>
</form>

EOF;
  }

  function indented($level, $block) {
    $block         = explode(chr(13) . chr(10), $block);
    $indentedblock = array();
    foreach ($block as $line) {
      array_push($indentedblock, str_repeat("  ", $level) . $line);
    }
    $indentedblock = implode(chr(13) . chr(10), $indentedblock);
    return $indentedblock . chr(13) . chr(10);
  }

  function get_formStructureData($fieldname, $data, $ifnotset, $part) {
    $formStructure = $this->formStructure;
    return (isset($formStructure[$part][$fieldname][$data]) ? $formStructure[$part][$fieldname][$data] : $ifnotset);
  }

  function get_fieldType($fieldname, $part, $extra = '') {
    $fieldrestriction = self::get_formStructureData($fieldname, 'restriction', '', $part);
    $fieldlibrary     = self::get_formStructureData($fieldname, 'fielddlibraryesc', '', $part);
    $dbfieldtype      = self::get_formStructureData($fieldname, 'fieldtype', '', $part);
    $formStructure    = $this->formStructure;

    if ($fieldrestriction == 'hidden') {
      return 'hidden';
    } elseif ($fieldrestriction == 'viewonly' && $extra == 'lines-group') { 
      return 'viewonly';
    } elseif ($fieldrestriction == 'viewonly' && $part == 'lines') {
      return 'hidden';
    } elseif ($fieldrestriction == 'fileattachment') {
      return 'fileattachment';
    } elseif ($dbfieldtype == 'decimal(18,4)') {
      return 'number';
    } elseif ($dbfieldtype == 'decimal(18,2)') {
      return 'number';
    } elseif ($dbfieldtype == 'decimal(18,0)') {
      return 'number';
    } elseif ($dbfieldtype == 'int(6)') {
      return 'number';
    } elseif ($dbfieldtype == 'date') {
      return 'date';
    } elseif ($dbfieldtype == 'datetime') {
      return 'datetime';
    // } elseif ($dbfieldtype == 'text') {
    } elseif ($dbfieldtype == '_htmlbutton') {
      return '_htmlbutton';
    } elseif ($dbfieldtype == '__htmlbutton') {
      return '__htmlbutton';
    } elseif ($dbfieldtype == 'htmlbutton_') {
      return 'htmlbutton_';
    } elseif ($dbfieldtype == 'htmlbutton__') {
      return 'htmlbutton__';
    } elseif ($dbfieldtype == '_htmlcheckbox') {
      return '_htmlcheckbox';
    } elseif (isset($formStructure[$part][$fieldname]['textarea'])) {
      return 'textarea';
    } elseif (isset($formStructure[$part][$fieldname]['date'])) {
      return 'date';
    } elseif (isset($formStructure[$part][$fieldname]['html_InputTag'])) {
      return $formStructure[$part][$fieldname]['html_InputTag'];  
    } elseif (isset($formStructure[$part][$fieldname]['library'])) {
        if(isset($formStructure[$part][$fieldname]['class'])){
          return 'select2';
        }else{
          return 'select';
        }
      
    } else {
      return 'text';
    }
  }

  function HTML_button($button) {
    $docStr = $this->docStr;
    
    $buttons                     = array();
    $buttons['btnSaveForm'] = <<<EOF
<button type="button" class="btnEditMode btnSaveForm btn-blue" title="Save" style="display:none;"><i class="material-icons">save</i>$docStr->saveText</button>
EOF;
    $buttons['btnEnterEditMode'] = <<<EOF
<button type="button" class="btnReadMode btnEnterEditMode btn-grey" title="Edit" style="display:none;"><i class="material-icons">edit</i>$docStr->editText</button>
EOF;
    $buttons['btnCancelForm'] = <<<EOF
<input type="button" class="btnEditMode btnCancelForm btn-grey material-icons" value="cancel" title="Cancel changes and go back to previous page" style="display:none;"/>
EOF;
    $buttons['saveLine'] = <<<EOF
<input type="button" class="btnEditMode saveLine btn-blue" value="$docStr->saveLineText" title="Save current line" style="display:block;"/> 
EOF;
    $buttons['saveLineAndNew'] = <<<EOF
<input type="button" class="btnEditMode saveLineAndNew btn-blue" value="$docStr->saveNnewLineText" title="Save the current line and new line" style="display:none;"/>
EOF;
    $buttons['btnPrintSheet'] = <<<EOF
<input type="button" class="btnReadMode btnPrintSheet btn-grey material-icons" value="print insert_drive_file" title="Print this document (opens new window)" style="display:none;"/>
EOF;
    $buttons['btnFileAttachment'] = <<<EOF
<button type="button" class="btnReadMode btnFileAttachment btn-grey" title="Attach file in document read mode" style="display:none;"><i class="material-icons">attach_file</i>$docStr->fileAttachmentText</button>
EOF;
    $buttons['btnLookup'] = <<<EOF
<button type="button" class="btnEditMode btnLookup" title="Click this for look up data" style="margin-left:-3px; color:blue;" onclick="LIZERP.handleLookup(this)" ><i class="material-icons">search</i></button>
EOF;
    $buttons['btnCopyAndNew'] = <<<EOF
<input type="button" class="btnReadMode btnCopyAndNew btn-grey" value="Copy & New" title="Create new document from this document" style="display:none;"/>
EOF;
    $buttons['btnDocumentList'] = <<<EOF
<input type="button" class="btnReadMode btnDocumentList btn-grey material-icons" value="list" title="Document List" style="display:none;"/>
EOF;
    $buttons['btnHome'] = <<<EOF
<input type="button" class="btnReadMode btnHome btn-grey material-icons" value="home" title="Home" style="display:none;"/>
EOF;
    $buttons['btnSpacer10'] = <<<EOF
 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
EOF;
    $buttons['btnSpacer50px'] = <<<EOF
<img src="data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==" style="margin: 0px 0px 0px 50px"/>
EOF;
    $buttons['btnStatusBySection'] = <<<EOF
<input type="button" class="btnReadMode btnStatusBySection  btn-grey" value="Confirm & Send to Section Head" title="Confirm & Send to Section Head" style="display:none;"/>
EOF;
    $buttons['btnStatusByDept'] = <<<EOF
<input type="button" class="btnReadMode btnStatusByDept  btn-grey" value="Confirm & Send to Dept. Head" title="Confirm & Send to Dept. Head" style="display:none;"/>
EOF;
    $buttons['btnStatusByCOO'] = <<<EOF
<input type="button" class="btnReadMode btnStatusByCOO  btn-grey" value="Confirm & Send to COO" title="Confirm & Send to COO" style="display:none;"/>
EOF;
    $buttons['btnStatusByCEO'] = <<<EOF
<input type="button" class="btnReadMode btnStatusByCEO  btn-grey" value="Confirm & Send to CEO" title="Confirm & Send to CEO" style="display:none;"/>
EOF;
    $buttons['btnConfirmation'] = <<<EOF
<input type="button" class="btnReadMode btnConfirmation  btn-grey" value="Review & Approve" title="Document confirmation" style="display:none;"/>
EOF;
    $buttons['btnInformCapacityPlan'] = <<<EOF
<input type="button" class="btnReadMode btnInformCapacityPlan  btn-grey" value="$docStr->informCPText" title="Inform Capacity Plan" style="display:none;"/>
EOF;
    $buttons['btnInformBOM'] = <<<EOF
<input type="button" class="btnReadMode btnInformBOM  btn-grey" value="$docStr->informBOMText" title="Inform to Bill of Materials" style="display:none;"/>
EOF;
    $buttons['btnSendRequest'] = <<<EOF
<input type="button" class="btnReadMode btnSendRequest  btn-grey" value="Send Request" title="Sent Request" style="display:none;"/>
EOF;
    $buttons['btnPlanforInquiry'] = <<<EOF
<input type="button" class="btnEditMode btnPlanforInquiry btn-grey" value="Plan for Inquiry" title="Plan for Inquiry" style="display:none;"/>
EOF;
    $buttons['btnInformApparelPlanner'] = <<<EOF
<input type="button" class="btnReadMode btnInformApparelPlanner btn-grey" value="$docStr->confirmMaterialText" title="Inform to Apparel Planner" style="display:none;"/>
EOF;
    $buttons['btnImportBOM'] = <<<EOF
<input type="button" class="btnEditMode btnImportBOM btn-blue" value="Import BOM" title="Import Bill of Material" style="display:none;"/>
EOF;
    $buttons['btnFreezeDoc'] = <<<EOF
<input type="button" class="btnReadMode btnFreezeDoc  btn-grey" value="Freeze this Document" title="Freeze this Document" style="display:none;"/>
EOF;
    $buttons['newLine'] = <<<EOF
<input type="button" class="btnEditMode newLine btn-blue" value="$docStr->newLineText" title="$docStr->newLineTittleText" style="display:none;"/>
EOF;
    $buttons['copyAndNewLine'] = <<<EOF
<input type="button" class="btnEditMode copyAndNewLine btn-grey" value="$docStr->copyNnewLineText" title="Copy the current line as new" style="display:none;"/>
EOF;
    $buttons['removeLine'] = <<<EOF
<input type="button" class="btnEditMode removeLine btn-grey material-icons" value="delete" title="Remove the current line" style="display:none;"/>
EOF;
  $buttons['btnModifyLine'] = <<<EOF
<input type="button" class="btnReadMode btnModifyLine btn-grey" value="$docStr->modifyLineText" title="Modify this line" style="display:none;"/>
EOF;
    $buttons['btnCancelLine'] = <<<EOF
<input type="button" class="btnReadMode btnCancelLine btn-grey" value="$docStr->cancelLineText" title="Cancle this line" style="display:none;"/>
EOF;
    $buttons['btnAcknowledgeCancellation'] = <<<EOF
<input type="button" class="btnReadMode btnAcknowledgeCancellation btn-grey" value="Acknowledge Cancelation" title="Cancle this Document" style="display:none;"/>
EOF;
    $buttons['btnSentTextile'] = <<<EOF
<input type="button" class="btnReadMode btnSentTextile btn-grey" value="Send to Textile" title="Send to Textile" style="display:none;"/>
EOF;
  
  $accessUser = array('sabbir.rahman', 'mohidul', 'mohidul');
  $buttons['btnSendToTextile'] = '';
  if($_SESSION['USERNAME'] == 'mamun' || $_SESSION['USERNAME'] == 'imtenaj.mollah'  || $_SESSION['USERTYPE'] == 'System Admin' || $_SESSION['USERNAME'] == 'imtenaj.mollah' || in_array($_SESSION['USERNAME'], $accessUser) ){
    $buttons['btnSendToTextile'] = <<<EOF
<input type="button" class="btnReadMode btnSendToTextile btn-grey" value="Send to NOW" title="Send to Textile" style="display:none;"/>
EOF;
  }
    $buttons['btnDeleteDoc'] = <<<EOF
<input type="button" class="btnReadMode btnDeleteDoc btn-grey" value="$docStr->deleteText" title="Delete this Document" style="display:none;"/>
EOF;
    $buttons['btnParentPO'] = <<<EOF
<input type="button" class="btnReadMode btnParentPO btn-grey" value="Parent PO" title="Parent PO" style="display:none;"/>
EOF;
    $buttons['btnRevise'] = <<<EOF
<input type="button" class="btnEditMode btnRevise btn-grey" value="$docStr->reviseText" title="Revise BOM Line" style="display:none;"/>
EOF;
    $buttons['btnAmend'] = <<<EOF
<input type="button" class="btnReadMode btnAmend btn-grey" value="Amend" title="Amend PO" style="display:none;"/>
EOF;
    $buttons['btnAutoRevised'] = <<<EOF
<input type="button" class="btnReadMode btnAutoRevised btn-blue" value="Auto Revised" title="Auto Update Revised PO" style="display:none;"/>
EOF;
    $buttons['btnCancelDocLine'] = <<<EOF
<input type="button" class="btnEditMode btnCancelDocLine btn-grey" value="$docStr->cancelLineText" title="Cancle this line" style="display:none;"/>
EOF;
    return $buttons[$button];
  }

  function HTML_headerfield($fieldname) {
    $formStructure = $this->formStructure;
    $fielddesc     = self::get_formStructureData($fieldname, 'fielddesc', $fieldname, 'header');
    $fieldtype     = self::get_fieldType($fieldname, 'header');

    
    $btnvalue      = ($fieldtype == '_htmlbutton' || $fieldtype == '__htmlbutton' || $fieldtype == 'htmlbutton_' || $fieldtype == 'htmlbutton__') ? $formStructure['header'][$fieldname]['value'] : '';

    if(isset($formStructure['header'][$fieldname]['groupname'])){
      $groupname     = $formStructure['header'][$fieldname]['groupname'];
      $group = "group";
    }

    $btnLookup = '';
    if(isset($formStructure['header'][$fieldname]['lookup'])){
      $btnLookup     = $this->HTML_button('btnLookup');
    }


    $hide = '';
    switch ($fieldtype) {
    case 'text':
      $inputHTML = <<<EOF
<input type="text" name="{$fieldname}" id="{$fieldname}" value=""/>
EOF;
      break;
    case 'hidden':
      $hide      = ' style="display:none;"';
      $inputHTML = <<<EOF
<input type="hidden" name="{$fieldname}" id="{$fieldname}" value=""/>
EOF;
      break;
    case 'select':
      $inputHTML = <<<EOF
<select name="{$fieldname}" id="{$fieldname}">
    <option value="">Select</option>
</select>
EOF;
      break;
    case 'textarea':
      $inputHTML = <<<EOF
<textarea name="{$fieldname}" id="{$fieldname}"></textarea>
EOF;
      break;
    case 'date':
      $inputHTML = <<<EOF
<input type="text" name="{$fieldname}" id="{$fieldname}" class="datepicker" value=""/>
EOF;
      break;
    case 'datetime':
      $inputHTML = <<<EOF
<input type="text" name="{$fieldname}" id="{$fieldname}" class="datetimepicker" value=""/>
EOF;
      break;
    case 'number':
      $inputHTML = <<<EOF
<input type="number" name="{$fieldname}" id="{$fieldname}"  value="0" min="0" step="1"/>
EOF;
      break;        
    case 'checkbox':
      $inputHTML = <<<EOF
<input type="checkbox" name="{$fieldname}" id="{$fieldname}" class="$group $groupname" onclick="LIZERP.handleCheckBoxClick(this);"/>
EOF;
      break;
    case '_htmlbutton':
      $inputHTML = <<<EOF
<button type="button" id="$fieldname" class="$fieldname btn-blue" onclick="LIZERP.handleThisButtonAction(this)">$btnvalue</button>
EOF;
      break;
    case '__htmlbutton':
      $inputHTML = <<<EOF
<button type="button" id="$fieldname" class="$fieldname btn-blue material-icons" onclick="LIZERP.handleThisButtonAction(this)">$btnvalue</button>
EOF;
      break;
    case 'htmlbutton_':
      $inputHTML = <<<EOF
<input type="button" id="$fieldname" class="$fieldname btn-blue" onclick="LIZERP.handleThisButtonAction(this)" value="$btnvalue"/>
EOF;
      break;
    case 'htmlbutton__':
      $inputHTML = <<<EOF
<input type="button" id="$fieldname" class="$fieldname btn-blue material-icons" onclick="LIZERP.handleThisButtonAction(this)" value="$btnvalue"/>
EOF;
      break;      
    case '_file_':
      $fieldName = $fieldname . "[]";
      $inputHTML = <<<EOF
<div class="fileAttachmentContainer" style="display:none">
  <div class="fileInputContainer" style="float:left; display:none;">
      <label class="custom-file-upload" id="id_width">
      <input type="button" name="$fieldName" multiple value="$value"$required class="upload_file" onclick="LIZERP.uploadFile(this)"/>
      Upload File
      </label>
  </div>
  <div class="clearfix"></div>
  <div class="fileViewerContainer" style="float:left">
    <a href="" target="_blank"><img src="img/fileicon.png" width="30" height="20"/></a>
  </div>
</div>
EOF;
      break;
    default:
      $inputHTML = <<<EOF
EOF;
      error_log("Unknown field type " . $fieldtype . " for field " . $fieldname);
      self::HTML_headerfield($fieldname, $fielddesc, 'text');
      break;
    }

    // for special case button, file attachment
    if($fieldtype == '_file_'){      
    $template = <<<EOF
<div class="formGroup"$hide>
    $inputHTML
</div>
EOF;
      return $template;
    }

    $template = <<<EOF
<div class="formGroup"$hide>
    <label for="{$fieldname}">{$fielddesc}</label>
    $inputHTML $btnLookup
</div>
EOF;
    return $template;
  }

  function HTML_lineFieldGroup($fieldname) {
    $formStructure = $this->formStructure;
    $fielddesc     = self::get_formStructureData($fieldname, 'fielddesc', $fieldname, 'lines');
    $fieldtype     = self::get_fieldType($fieldname, 'lines', 'lines-group');
    $fieldid = 'lg_' . $fieldname;
    $btnvalue          = ($fieldtype == '_htmlbutton' || $fieldtype == '__htmlbutton' || $fieldtype == 'htmlbutton_' || $fieldtype == 'htmlbutton__') ? $formStructure['lines'][$columnField]['value'] : '';

    if(isset($formStructure['lines'][$fieldname]['groupname'])){
      $groupname     = $formStructure['lines'][$fieldname]['groupname'];
      $group = "group";
    }

    $btnLookup = '';
    if(isset($formStructure['lines'][$fieldname]['lookup'])){
      $btnLookup     = $this->HTML_button('btnLookup');
    }


    $hide = '';
    switch ($fieldtype) {
    case 'text':
      $inputHTML = <<<EOF
<input type="text" name="{$fieldname}" id="{$fieldid}" value=""/>
EOF;
      break;
    case 'hidden':
      $hide      = ' style="display:none;"';
      $inputHTML = <<<EOF
<input type="hidden" name="{$fieldname}" id="{$fieldid}" value=""/>
EOF;
      break;
    case 'viewonly':
      $hide      = '';
      $inputHTML = <<<EOF
<input type="text" name="{$fieldname}" id="{$fieldid}" value="" readonly=readonly />
EOF;
      break;
    case 'select':
      $inputHTML = <<<EOF
<select name="{$fieldname}" id="{$fieldid}">
    <option value="">Select</option>
</select>
EOF;
      break;
    case 'select2':
      $inputHTML = <<<EOF
<select name="{$fieldname}" id="{$fieldid}" class="select2">
    <option value="">Select</option>
</select>
EOF;
      break;
    case 'textarea':
      $inputHTML = <<<EOF
<textarea name="{$fieldname}" id="{$fieldid}"></textarea>
EOF;
      break;
    case 'date':
      $inputHTML = <<<EOF
<input type="text" name="{$fieldname}" id="{$fieldid}" class="datepicker" value=""/>
EOF;
      break;
    case 'datetime':
      $inputHTML = <<<EOF
<input type="text" name="{$fieldname}" id="{$fieldid}" class="datetimepicker" value=""/>
EOF;
      break;
    case 'number':
      $inputHTML = <<<EOF
<input type="number" name="{$fieldname}" id="{$fieldid}"  value="0" min="0" step="any"/>
EOF;
      break;      
    case 'checkbox':
      $inputHTML = <<<EOF
<input type="checkbox" name="{$fieldname}" id="{$fieldid}" class="$group $groupname" onclick="LIZERP.handleCheckBoxClick(this);"/>
EOF;
    $fieldname = $fieldid;
      break;
    case '_htmlbutton':
      $inputHTML = <<<EOF
<button type="button" id="$fieldname" class="$fieldname btn-blue" onclick="LIZERP.handleThisButtonAction(this)">$btnvalue</button>
EOF;
      break;
    case '__htmlbutton':
      $inputHTML = <<<EOF
<button type="button" id="$fieldname" class="$fieldname btn-blue material-icons" onclick="LIZERP.handleThisButtonAction(this)">$btnvalue</button>
EOF;
      break;
    case 'htmlbutton_':
      $inputHTML = <<<EOF
<input type="button" id="$fieldname" class="$fieldname btn-blue" onclick="LIZERP.handleThisButtonAction(this)" value="$btnvalue"/>
EOF;
      break;
    case 'htmlbutton__':
      $inputHTML = <<<EOF
<input type="button" id="$fieldname" class="$fieldname btn-blue material-icons" onclick="LIZERP.handleThisButtonAction(this)" value="$btnvalue"/>
EOF;
      break;  
    default:
      $inputHTML = <<<EOF
EOF;
      error_log("Unknown field type " . $fieldtype . " for field " . $fieldname);
      self::HTML_headerfield($fieldname, $fielddesc, 'text');
      break;
    }
    $template = <<<EOF
<div class="formGroup"$hide>
    <label for="{$fieldname}_xxx">{$fielddesc}</label>
    $inputHTML $btnLookup
</div>
EOF;
    return $template;
  }

  function HTML_columnfield($columnField) {
    $formStructure     = $this->formStructure;
    $columnRestriction = isset($formStructure['lines'][$columnField]['restriction']) ? $formStructure['lines'][$columnField]['restriction'] : $columnField;
    $columnType        = self::get_fieldType($columnField, 'lines');
    $hide              = ($columnRestriction == 'hidden') ? ' style="display:none;"' : '';
    $required          = ($columnRestriction == 'required') ? ' required="required"' : '';
    $value             = ($columnField == 'linenumber') ? '1' : '';
    $searchloupe       = ($columnField == 'itemcode') ? '<br/><img src="img/search.png" class="searchItemCode"/>' : '';
    $btnvalue          = ($columnType == '_htmlbutton' || $columnType == '__htmlbutton' || $columnType == 'htmlbutton_' || $columnType == 'htmlbutton__'  || $columnType == '_htmlcheckbox') ? $formStructure['lines'][$columnField]['value'] : '';

    if(isset($formStructure['lines'][$columnField]['groupname'])){
      $groupname     = $formStructure['lines'][$columnField]['groupname'];
      $group = "group";
    }


    switch ($columnType) {
    case 'hidden':
      $inputHTML = <<<EOF
<input type="hidden" name="lines[1][$columnField]" value="$value"$required/>
EOF;
      break;
    // case 'date':
      // $inputHTML = "<input type=\"hidden\" name=\"lines[1][$columnField]\" value=\"\" />";
      // break;
    case 'textarea':
      $inputHTML = <<<EOF
<textarea name="lines[1][{$columnField}]" id="{$columnField}"$required></textarea>
EOF;
      break;
    case 'select':
      $inputHTML = <<<EOF
<select name="lines[1][{$columnField}]" id="{$columnField}"$required>
    <option value="">Select</option>
</select>
EOF;
      break;
//     case 'checkbox':
//       $inputHTML = <<<EOF
// <input type="checkbox" name="{$columnField}" id="{$columnField}" class="$group $groupname"  onclick="LIZERP.handleCheckBoxClick(this);" />
// EOF;
//       break;      
    case 'number':
      $inputHTML = <<<EOF
<input type="number" name="lines[1][$columnField]" value="$value" min="0" step="any"$required/>
EOF;
      break;
    case '_htmlbutton':
      $inputHTML = <<<EOF
<button type="button" class="$columnField btn-blue" onclick="LIZERP.handleThisButtonAction(this)">$btnvalue</button>
EOF;
      break;
    case '__htmlbutton':
      $inputHTML = <<<EOF
<button type="button" class="$columnField btn-normal material-icons" onclick="LIZERP.handleThisButtonAction(this)">$btnvalue</button>
EOF;
      break;
    case 'htmlbutton_':
      $inputHTML = <<<EOF
<input type="button" class="$columnField btn-blue" onclick="LIZERP.handleThisButtonAction(this)" value="$btnvalue"/>
EOF;
      break;
    case 'htmlbutton__':
      $inputHTML = <<<EOF
<input type="button" class="$columnField btn-blue material-icons" onclick="LIZERP.handleThisButtonAction(this)" value="$btnvalue"/>
EOF;
      break;
    case '_htmlcheckbox':
      $inputHTML = <<<EOF
<input type="checkbox" class="$columnField btn-checkbox" onclick="LIZERP.handleCheckBoxClick(this)"/>
EOF;
      break;
    case '_file_':
      $fieldName = $columnField . "[]";
      $inputHTML = <<<EOF
<div class="fileAttachmentContainer" style="display:none">
  <div class="fileViewerContainer" style="float:left">
    <a href="" target="_blank"></a>
  </div>
  <div class="fileInputContainer" style="float:left; display:none;">
      <label class="custom-file-upload" id="id_width">
      <input type="file" name="$fieldName" multiple value="$value"$required class="upload_file" onchange="LIZERP.uploadFile(this)"/>
      Upload File
      </label>
  </div>
</div>
EOF;
      break;   
    default:
      $inputHTML = <<<EOF
<input type="text" name="lines[1][$columnField]" value="$value"$required/>
EOF;
      break;
    }


    // for special case button, check box, file attachment
    if($columnType == '_htmlcheckbox' || $columnType == '_htmlbutton'  || $columnType == '__htmlbutton' || $columnType == 'htmlbutton_' || $columnType == 'htmlbutton__' || $columnType == '_file_'){      
    $HTML_columnField = <<<EOF
<td class="$columnField"$hide>
    $inputHTML
</td>
EOF;
    return $HTML_columnField;
    }


    if ($columnField == 'linenumber') {
      $inputHTML = '<br/><br/>&nbsp;' . $inputHTML;
    }


    $HTML_columnField = <<<EOF
<td class="$columnField"$hide>
    <span>$value</span>
    $inputHTML
</td>
EOF;
    return $HTML_columnField;
  }
}
?>