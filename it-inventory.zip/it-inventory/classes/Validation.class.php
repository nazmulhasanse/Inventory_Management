<?php
/**
 * Form validation class.
 *
 * @author Al-Mamun
 * @class creation date: 2016-12-21 
 * @see   [<description>]
 */
class Validation
{

    public static $regexes = Array(
        'date'        => "^[0-9]{4}[-/][0-9]{1,2}[-/][0-9]{1,2}\$",
        'amount'      => "^[-]?[0-9]+\$",
        'number'      => "^[-]?[0-9,]+\$",
        'alfanum'     => "^[0-9a-zA-Z ,.-_\\s\?\!]+\$",
        'not_empty'   => "[a-z0-9A-Z]+",
        'words'       => "^[A-Za-z]+[A-Za-z \\s]*\$",
        'phone'       => "^[0-9]{10,11}\$",
        'zipcode'     => "^[1-9][0-9]{3}[a-zA-Z]{2}\$",
        'plate'       => "^([0-9a-zA-Z]{2}[-]){2}[0-9a-zA-Z]{2}\$",
        'price'       => "^[0-9.,]*(([.,][-])|([.,][0-9]{2}))?\$",
        '2digitopt'   => "^\d+(\,\d{2})?\$",
        '2digitforce' => "^\d+\,\d\d\$",
        'anything'    => "^[\d\D]{1,}\$"
    );


    function __construct(){
        # code...
    }

    /**
     * Check string has special character or not
     * 
     * @param  [string]  $string [any string with special character]
     * @return boolean           [return 0 if false, return 1 if true]
     */
    public function isValidString($string) {
        // a - z /* a to z */
        // A - Z /* A to Z */
        // 0 - 9 /* 0 to 9 */
        // _ -  underscore & dash 
        // ~ ! @ # $% ^ & * () /* allowed special characters */
        // \s White space
        // \/ for slash
        // \\\\ for back slash --need four back slash
        // return preg_match('/^[a-zA-Z0-9\s_~\-@#\$%&*\(\)]+$/',$string);
        // return preg_match('/^[a-zA-Z0-9\s,.:\/_~\-@#\$%&*\(\)]+$/',$string);
        // return preg_match('/^[a-zA-Z0-9\s,\\\\.:\/_\-+<>@\$%&*\?\(\)]+$/',$string);
        return preg_match('/^[a-zA-Z0-9\s,\\\\.:\/_\-+<>=@#\$%&*\?\(\)]+$/',$string);
    }
    
    /**
     * Remove special character from given string
     * 
     * @param  [string] $string [any string with special character]
     * @return [string]         [without any special character]
     */
    public function cleanString($string) {
        // Replaces all spaces with ''
        // Removes special chars.
        return preg_replace('/[^a-zA-Z0-9\s,\\\\.:\/_\-+<>=@#\$%&*\?\(\)]/', '', $string);
        // return preg_replace('/[^a-zA-Z0-9\s\-]/', '', $string);
        // return $string;
    }
    

    /**
     * Validates an email address
     *
     * @param  string  $key        The name of the posted field
     * @param  string  $value      The value of the posted field
     * @param  string  $ruleValue  The value of the rule
     */
    private function validEmail($key, $value, $ruleValue){
        # code...
    }
    
    /**
     * Validates an URL
     *
     * @param  string  $key        The name of the posted field
     * @param  string  $value      The value of the posted field
     * @param  string  $ruleValue  The value of the rule
     */
    private function validURL($key, $value, $ruleValue){
        # code...
    }
    
    


	function validDocobj($formStructure, $docobj) {
	  $errormsgs     = array();

	  $docLinesArray = $docobj['lines']; // format: lines = array(0 => array, 1 => array, ....)
	  unset($docobj['lines']);
	  $docHeaderArray = $docobj;
	  unset($docobj);

	  // input-value validation for header
	  foreach ($formStructure['header'] as $field => $definition) {

	    $fielddesc   = (isset($definition['fielddesc'])) ? $definition['fielddesc'] : $field;
	    $restriction = (isset($definition['restriction'])) ? $definition['restriction'] : NULL;
	    $library     = (isset($definition['library'])) ? $definition['library'] : NULL;
	    $fieldtype   = $definition['fieldtype'];

	    $inputValue       = (isset($docHeaderArray[$field])) ? $docHeaderArray[$field] : NULL;
	    $validInputErrors = $this->validInputValues($restriction, $library, $fieldtype, $fielddesc, $inputValue);
	    $errormsgs        = array_merge($errormsgs, $validInputErrors);
	  }


	  // input-value validation for each line
	  if(isset($formStructure['lines'])){
		  foreach ($formStructure['lines'] as $field => $definition) {
		    $fielddesc   = (isset($definition['fielddesc'])) ? $definition['fielddesc'] : $field;
		    $restriction = (isset($definition['restriction'])) ? $definition['restriction'] : NULL;
		    $library     = (isset($definition['library'])) ? $definition['library'] : NULL;
		    $fieldtype   = $definition['fieldtype'];

		    foreach ($docLinesArray as $lineIndex => $LineArray) {
		      $inputValue       = (isset($LineArray[$field])) ? $LineArray[$field] : NULL;
		      $validInputErrors = $this->validInputValues($restriction, $library, $fieldtype, $fielddesc, $inputValue);
		      $errormsgs        = array_merge($errormsgs, $validInputErrors);
		    }
		  }
	  }

	  return $errormsgs;
	}



	function validInputValues($restriction, $library, $fieldtype, $fielddesc, $inputValue) {
	  $errormsgs  = array();
	  $dateFormat = "Y-m-d";
	  // required
	  if ($restriction == 'required' && ($inputValue == NULL || $inputValue == "")) {
	    array_push($errormsgs, "$fielddesc is required, but value is not entered!");
	  }

	  if ($inputValue != NULL) {
	    // if inputted
	    // max length
	    $fieldMaxLength = $this->fieldMaxLength($fieldtype);
	    if (strlen($inputValue) > $fieldMaxLength) {
	      array_push($errormsgs, "Input value $inputValue exceeds the allowed maxlength ($fieldMaxLength) for $fielddesc");
	    }

	    // data type
	    if ($fieldtype == 'DATE' && !validDateTime($inputValue, $dateFormat)) {
	      array_push($errormsgs, "Input value $inputValue contains invalid date format for $fielddesc");
	    }
	    if ((strpos($fieldtype, 'INT') !== false) && ((string) (int) $inputValue !== (string) $inputValue)) {
	      array_push($errormsgs, "Input value $inputValue entered for $fielddesc is not valid integer!");
	    }
	    if ((strpos($fieldtype, 'DECIMAL') !== false) && !is_numeric($inputValue)) {
	      array_push($errormsgs, "Input value $inputValue entered for $fielddesc is not valid numeric!");
	    }

	    // $validationObj = new Validation();
	    $isValidStr = $this->isValidString($inputValue);
	    if($isValidStr == 0){
	      array_push($errormsgs, "Input value $inputValue entered for $fielddesc has special character! \n\nRemove special character from this field.\n");
	    }

	  }

	  return $errormsgs;
	}


	function fieldMaxLength($fieldtype) {
	  $fieldtype = strtoupper($fieldtype);
	  if (strpos($fieldtype, '(') !== false) {
	    $maxlength = (int) str_replace(")", "", str_replace("(", "", substr($fieldtype, strpos($fieldtype, '('))));
	    // don't return from here or DECIMAL will get a bad result like (float) 18.4
	  }
	  if ($fieldtype == 'DATE') {
	    $maxlength = 10;
	  }

	  if ($fieldtype == 'DATETIME') {
	    $maxlength = 19;
	  }

	  if ($fieldtype == 'INT') {
	    $maxlength = 11;
	  }

	  if ($fieldtype == 'SMALLINT') {
	    $maxlength = 6;
	  }

	  if ($fieldtype == 'TEXT') {
	    $maxlength = 65535;
	  }

	  if (strpos($fieldtype, 'VARCHAR') !== false) {
	    $maxlength = preg_replace("/[^0-9]/", "", $fieldtype);
	  }

	  if (strpos($fieldtype, 'DECIMAL') !== false) {
	    $maxlength = preg_replace("/[^0-9]/", "", explode(".", $fieldtype)[0]);
	  }

	  return $maxlength;
	}


	function validDocLineobj($formStructure, $lineObj){
		$newLineObj = array();
		foreach ($lineObj as $fieldname => $fieldvalue) {
			$fieldvalue = $this->cleanString($fieldvalue);
			$newLineObj[$fieldname] = $fieldvalue;
		}
		return $newLineObj;	
	}



}

// test this class
// $validationObj = new Validation();
// echo $validationObj->isValidString('abc@de&$f g');
// echo $validationObj->cleanString('a|"bc!@£de^&$f g');
?>