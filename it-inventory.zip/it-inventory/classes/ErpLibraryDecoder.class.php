<?php
/**
* ERP Library Data decoder
*/
class ErpLibraryDecoder
{
	
	public $conn;
	public $result;
	public $sql;
	public $dbname;

	function __construct($dbnum = '1'){

		if ($dbnum === '2') {
			$this->conn = new ErpDbConn('2');
			$this->dbname = "erpprod_bulbul";
		} else {
			$this->conn = new ErpDbConn;
			$this->dbname = "erpprod";
		}

	}

	public function genericDecoder($row){

	}

	public function libraryCodeToDescDecoder($LibraryName, $code){
		$sql = "SELECT Code AS code, Description AS description FROM mrd_library WHERE LibraryName = '$LibraryName' AND Code = '$code'";
		$queryResult = $this->conn->query($sql);
		$row = $queryResult->fetch_assoc();
		$desc = $row['description'];
		return $desc;
	}

	public function libraryDescToCodeDecoder($LibraryName, $desc){
		$sql = "SELECT Code AS code, Description AS description FROM mrd_library WHERE LibraryName = '$LibraryName' AND Description = '$desc'";
		$queryResult = $this->conn->query($sql);
		$row = $queryResult->fetch_assoc();
		$code = $row['code'];
		return $code;
	}


}
?>