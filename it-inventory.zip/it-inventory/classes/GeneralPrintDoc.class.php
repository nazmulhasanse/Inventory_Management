<?php
/**
* Print Doc Class
 * require config.php
 * require ErpDbConn.class.php
 *
 * ****************
 * Author: Al-Mamun
 * Date: 2017-01-14
 * **************** 
*/
class GeneralPrintDoc extends BaseDocAPI
{
	
	private $printFormat;
	private $printParams = array();

	function __construct(){
	}


	function processBarcode($barcodeText, $barcodeType, $barcodeSize, $barcodeOrientation){
		$barcode_api_url    = "$serverUrl/labeling/barcode_api.php";
		$barcodeType        = "code128";
		$barcodeSize        = 40;
		$barcodeOrientation = "horizontal";
		return "<img alt='ERROR!' src='$url?codetype=$barcodeType&size=$barcodeSize&text=$barcodeText&orientation=$barcodeOrientation' />";
	}

	public function getDefaultPrintFormat($docdata, $docdefine, $printdocdefine){
		$docdata = json_decode($docdata, true);
		$docdefine = json_decode($docdefine, true);
		$printdocdefine = json_decode($printdocdefine, true);

		$doclines = $docdata['lines'];
		unset($docdata['lines']);

		/**
		 * Decode company name 
		 * if company code have in doc data
		 */
		if(isset($docdata['company'])){
			$companyCode    = $docdata['company'];
			$pdmObj = new Pdm();
			$companyInfo = $pdmObj->getLibraryDescription('company', $companyCode);
			$companyInfo    = json_decode($companyInfo, true);
			$company = $companyInfo[0]['Description'];
			$companyAddress = $companyInfo[0]['Zone'];
		} else {
			$company = $printdocdefine['company'];
			$companyAddress = $printdocdefine['companyAddress'];
		}

		/**
		 * Process Barcode
		 * if need to print barcode
		 */
		if($printdocdefine['printBarcode']){
			$barcodeText = $docdata[$barcodeKey]; // barcodeKey = docnumber
			$barcode = $this->processBarcode($barcodeText);
			$docdata['barcode'] = $barcode;
		} else {
			$docdata['barcode'] = "";
		}

		/**
		 * Get head table
		 */
		$headTable = $this->getHeadTable_printFormat($docdata, $docdefine, $printdocdefine);
		/**
		 * Get line Table
		 */
		$lineTable = $this->getLineTable_printFormat($docdata, $doclines, $docdefine, $printdocdefine);
		/**
		 * Get notes Table
		 */		
		$notesTable = $this->getNotes_printFormat($docdefine, $printdocdefine);
		/**
		 * Get notes Table
		 */		
		$gatePassPage = $this->getGatePassPage_printFormat($company, $companyAddress, $docdata, $doclines, $docdefine, $printdocdefine);

		/**
		 * Process default print format
		 */
		$printParams = array();
		$printParams['pageTittle'] = $docdata['docnumber'];
		$printParams['company'] = $company;
		$printParams['companyAddress'] = $companyAddress;
		$printParams['docTittle'] = $docdefine['title'];
		$printParams['docSubTittle'] = $printdocdefine['subFormTittle'];
		if(!$printdocdefine['hasDocSubTittle']) $printParams['docSubTittle'] = '';
		$printParams['headTable'] = $headTable;
		$printParams['lineTable'] = $lineTable;
		$printParams['notesTable'] = $notesTable;
		$printParams['gatePassPage'] = $gatePassPage;
		$this->printParams = $printParams;
		return $this->printParams;

	}


	function getHeadTable_printFormat($docdata, $docdefine, $printdocdefine){
		$varHeadTable = "";
		if ($printdocdefine['hasHeadTable']) {
		  	$headTableStructure = $printdocdefine['headertable'];
		  	$varHeadTable = "<table id='headTable'>";
		  	$varHeadTable .= "<tr>";
		  	$i = 1;
		  	//             column      columnvalues
		  	foreach ($headTableStructure as $columnNo => $columnFields) {

		    	$varHeadTable .= "<td class='headTable_td' id='headTable_td" . $i . "'>";
		    	$varSubHeadTable = "<table id='subheadTable'><tr><td></td></tr>";
		    	$j = 1;
		    	foreach ($columnFields as $key => $keyField) {
		      		if (isset($docdefine['header'][$keyField]['fielddesc'])) {
		          		$varSubHeadTable .= "<tr>
		          								<td class='subheadTable_td' id='subheadTable_td" . $j . "'>" . $docdefine['header'][$keyField]['fielddesc'] . "</td>
		                                  		<td class='subheadTable_colon'>:</td>
		                                  		<td class='subheadTable_td' id='subheadTable_td" . ((int) $j + 1) . "'>" . $docdata[$keyField] . "</td>
		                                	</tr>";
		      		} else {     
		          		$varSubHeadTable .= "<tr>
		          								<td class='subheadTable_td' id='subheadTable_td" . $j . "'>" . $keyField . "</td>
		                                  		<td class='subheadTable_colon'>:</td>
		                                  		<td class='subheadTable_td' id='subheadTable_td" . ((int) $j + 1) . "'>" . $docdata[$keyField] . "</td>
		                                	</tr>";
		      		}
		    	}
		    	$varSubHeadTable .= "</table>";
		    	$varHeadTable .= $varSubHeadTable . "</td>";
		    $i++;
		  }

		  $varHeadTable .= "</tr>";
		  $varHeadTable .= "</table>";
		} else {
		  	$varHeadTable = "";
		}

		return $varHeadTable;

	}

	function getLineTable_printFormat($docdata, $doclines, $docdefine, $printdocdefine){
		$varLineTable = "";
		if ($printdocdefine['hasLineTable']) {
		  	$lineTableStructure = $printdocdefine['linetable'];

		  	$varLineTable = "<table class='print' id='linetable'>";
		  	$varLineTable .= "<thead>";
		  	$varLineTable .= "<tr>";
		  	foreach ($lineTableStructure as $columnKey => $columnFields) {
		    	$varLineTable .= "<th>" . $columnKey . "</th>";
		  	}
		  	$varLineTable .= "</thead>";
		  	$varLineTable .= "<tbody>";

		    //========= from data loop =========
		  	foreach ($doclines as $index => $linedata) {
		    	$i = 0;
		    	$varLineTable .= "<tr>";
		    	foreach ($lineTableStructure as $columnKey => $columnFields) {
			      	$i++;
			      	// if columnFields is array then break down			      	
			      	if(is_array($columnFields)){
				      	// break down td
				      	foreach ($columnFields as $key => $value) {

				        	if (isset($docdefine['lines'][$value]['fielddesc']) && $docdefine['lines'][$value]['fielddesc'] != "") {
				          		$colon = ":"; $pre1  = "<pre>"; $pre2  = "</pre>";
				          		$varLineTable .=   $pre1 . $docdefine['lines'][$value]['fielddesc'] . $colon  . $doclines[$index][$value] . $pre2;
				        	} else {
				          		$colon = ""; $pre1  = ""; $pre2  = "";
				          		$varLineTable .=   $pre1 . $value . $colon  . $doclines[$index][$value] . $pre2;
				        	}
				      	}

			      	} else {
			      		if($columnKey == "#"){
			      			$varLineTable .= ($columnKey == '#') ? "<td class='linetable_td' id='linetable_td" . $i . "'><div class='avoid'>" . sprintf("%03d", ($index + 1)) . "</td>" : "";
			      		} else {
      						$varLineTable .=  "<td class='linetable_td' id='linetable_td" . $i . "'>"  . $linedata[$columnFields] . "</td>";
			      		}
			      	}

			      	$varLineTable .= "";
		    	}
		    	$varLineTable .= "</tr>";
		  	}
		    //========= from data loop =========

			if ($printdocdefine['hasNetTotalTable']) {
				$netTotalTableStructure = $printdocdefine['nettolaltable'];
				$varLineTable .= 
				"<tr>
					<td colspan='7' class='nettotaltable_td' id='nettotaltable_td1'>Net Total</td>
					<td id='nettotaltable_td2'>" . $docdata[$netTotalTableStructure['totalgarmentqty']] .  "</td>
					<td id='nettotaltable_td3'>" . "" .  "</td>
					<td id='nettotaltable_td3'>" . "" . "</td>
					<td id='nettotaltable_td3'>" . $docdata['totalamount'] . "</td>
				</tr>
				<tr>
					<td colspan='3' class='nettotaltable_td' id='nettotaltable_td1'>Total Amount In Words:</td>
					<td id='' colspan='8' >" . $docdata['totalamountwords'] .  "</td>
				</tr>"
				;
			}

		  	$varLineTable .= "</tbody>";
		  	$varLineTable .= "</table>";
		} else {
		  	$varLineTable = "";
		}

		return $varLineTable;

	}

	function getLineTableForGatePass_printFormat($docdata, $doclines, $docdefine, $printdocdefine){
		$varLineTable = "";
		if ($printdocdefine['hasLineTable']) {
		  	$lineTableStructure = $printdocdefine['gatepasstable'];

		  	$varLineTable = "<table class='print' id='linetable'>";
		  	$varLineTable .= "<thead>";
		  	$varLineTable .= "<tr>";
		  	foreach ($lineTableStructure as $columnKey => $columnFields) {
		    	$varLineTable .= "<th>" . $columnKey . "</th>";
		  	}
		  	$varLineTable .= "</thead>";
		  	$varLineTable .= "<tbody>";

		    //========= from data loop =========
		  	foreach ($doclines as $index => $linedata) {
		    	$i = 0;
		    	$varLineTable .= "<tr>";
		    	foreach ($lineTableStructure as $columnKey => $columnFields) {
			      	$i++;
			      	// if columnFields is array then break down			      	
			      	if(is_array($columnFields)){
				      	// break down td
				      	foreach ($columnFields as $key => $value) {

				        	if (isset($docdefine['lines'][$value]['fielddesc']) && $docdefine['lines'][$value]['fielddesc'] != "") {
				          		$colon = ":"; $pre1  = "<pre>"; $pre2  = "</pre>";
				          		$varLineTable .=   $pre1 . $docdefine['lines'][$value]['fielddesc'] . $colon  . $doclines[$index][$value] . $pre2;
				        	} else {
				          		$colon = ""; $pre1  = ""; $pre2  = "";
				          		$varLineTable .=   $pre1 . $value . $colon  . $doclines[$index][$value] . $pre2;
				        	}
				      	}

			      	} else {
			      		if($columnKey == "#"){
			      			$varLineTable .= ($columnKey == '#') ? "<td class='linetable_td' id='linetable_td" . $i . "'><div class='avoid'>" . sprintf("%03d", ($index + 1)) . "</td>" : "";
			      		} else {
      						$varLineTable .=  "<td class='linetable_td' id='linetable_td" . $i . "'>"  . $linedata[$columnFields] . "</td>";
			      		}
			      	}

			      	$varLineTable .= "";
		    	}
		    	$varLineTable .= "</tr>";
		  	}
		    //========= from data loop =========

			if ($printdocdefine['hasNetTotalTable']) {
				$netTotalTableStructure = $printdocdefine['nettolaltable'];
				$varLineTable .= 
				"<tr>
					<td colspan='4' class='nettotaltable_td' id='nettotaltable_td1'>Net Total</td>
					<td id='nettotaltable_td2'>" . $docdata[$netTotalTableStructure['totalgarmentqty']] .  "</td>
					<td id='nettotaltable_td3'>" . $docdata[$netTotalTableStructure['totalcartonqty']] . "</td>
				</tr>";
			}



		  	$varLineTable .= "</tbody>";
		  	$varLineTable .= "</table>";
		} else {
		  	$varLineTable = "";
		}

		return $varLineTable;

	}

	/**
	 * [getNotes_printFormat description]
	 * @param  [type] $docdefine      [description]
	 * @param  [type] $printdocdefine [description]
	 * @return [type]                 [description]
	 */
	function getNotes_printFormat($docdefine, $printdocdefine){

		if ($printdocdefine['hasNotesTable']) {
		  	$varNotesTable = 
		  	'<div id="div_notes">
		      	<p>' . $printdocdefine['note'] . '</p>
		      	<table id="notestable">
		        	<tr><td id="notestable_td1"><dt class="notes_dt"><span>Receive Date</span></dt></td><td></td><td></td></tr>
		        	<tr>
		          		<td id="notestable_td1"><dt class="notes_dt"><span>Name</span></dt> </td>
		          		<td id="notestable_td2"><dt id="notes_dt2"><span></span></dt></td>
		          		<td id="notestable_td3"><dt id="notes_dt3"><span></span></dt></td>
		        	</tr>
		        	<tr>
		          		<td id="notestable_td1"> <dt class="notes_dt"><span>Desigantion</span></dt></td>
		          		<td id="notestable_td2">Store Incharge</td>
		          		<td id="notestable_td3">Authorise Signature</td>
		        	</tr>
		     	</table>
		    </div>';
		} else {
		  $varNotesTable = "";
		}

		return $varNotesTable;

	}


	function getGatePassPage_printFormat($company, $companyAddress, $docdata, $doclines, $docdefine, $printdocdefine){

		if ($printdocdefine['hasGatePassTable']) {
			/**
			 * Get head table
			 */
			$headTable = $this->getHeadTable_printFormat($docdata, $docdefine, $printdocdefine);
			/**
			 * Get line Table
			 */
			$lineTable = $this->getLineTableForGatePass_printFormat($docdata, $doclines, $docdefine, $printdocdefine);
			/**
			 * Get Signature Table
			 */
			$varSignatureTable = $this->getSignatureTable_printFormat($printdocdefine);


			// if ($printdocdefine['hasNetTotalTable'] ) {
			// 	$netTotalTableStructure = $printdocdefine['nettolaltable'];
			// 	$varGatepassTable .= "<tr><td colspan='2' id='nettotaltable_td1'>Net Total</td><td id='nettotaltable_td2'>" . $arrayNetTotals[$netTotalTableStructure['iduom']] . " " . $lines[0]['iduom'] . "<br>" . $arrayNetTotals[$netTotalTableStructure['elementuom']] . " " . $lines[0]['elementuom'] . "</td></tr>";
			// }
			// $varGatepassTable .= "</tbody></table>";

			$varGatePassPage = '
			<div id="div_companyinfo">
				<p id="div_companyinfo_name">' . $company . '</p>
				<p id="div_companyinfo_address">' . $companyAddress . '</p>
				</div>
			<div id="div_doctittle">GATE PASS</div>'
			. $headTable
			. $lineTable
			. $varSignatureTable;

		} else {
				$varGatepassTable = "";
				$varGatePassPage  = "";
		}

		return $varGatePassPage;


	}

	/*
	 * Draw Signature Table
	 */
	function getSignatureTable_printFormat($printdocdefine){

		if ($printdocdefine['hasSignTable']) {
		  $signTableStructure = $printdocdefine['signaturetable'];
		  $i                  = 1;
		  $varSignatureTable       = "<table id='signtable'><tr>";
		  foreach ($signTableStructure as $columnKey => $columnFields) {
		    $varSignatureTable .= "<td class='signtable_td' id='signtable_td" . $i . "'><dt class='signtable_dt'><span></span><br>" . $columnFields . "</dt></td>";
		    $i++;
		  }
		  $varSignatureTable .= "</tr></table>";
		} else {
		  $varSignatureTable = "";
		}

		return $varSignatureTable;

	}



}
?>