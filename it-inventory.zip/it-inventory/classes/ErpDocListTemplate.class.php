<?php
class ErpDocListTemplate {
/*
TO DO
find a fix for the below query while creating document. Because it limits the length of docnumber
SET @nextdocnum_formatted = CONCAT(@docacronym , '-' , LPAD(@nextdocnum, 6, '0'));
 */
  public $formId;
  public $formTitle;
  public $privilege = "";

  protected $formStructure     = array();
  protected $formBaseStructure = array();
  protected $formButtons       = array();
  protected $formGroups        = array();
  protected $formLineColumns   = array();
  protected $docobj            = array();

  public $ERP_CONST = array();

  public $URL_DOCDEFINEAPI;
  public $URL_DOCDOCSEARCH;
  public $URL_DOCDOCFORM;
  public $URL_DOCJS;

  public $URL_MAINJS  = './js/erplistdoc_template.js';    
  public $URL_DOCCSS  = 'css/erplistdoc_template.css';

  // Should Foreign Keys and loose relationships (library) be shown here?
  public static $tableStructure = array(
    'schema' => array(
    'tablename'  => 'tnx_demodoc',
    ),
    'header' => array(
        // Identification
        'doctype'             => array('restriction' => 'hidden', 'library' => 'doctype'), 
        'formtype'            => array('restriction' => 'hidden'), 
        'doclinenumber'       => array('fielddesc' => 'BOM Line No.', 'restriction' => 'viewonly'), 
        'docdate'             => array('fielddesc' => 'Document date', 'restriction' => 'required'), 
        'docstatus'           => array('fielddesc' => 'Doc Status', 'restriction' => 'hidden'), 
        'linestatus'          => array('fielddesc' => 'Line Status', 'restriction' => 'hidden'), 
        'entitynumber'        => array('fielddesc' => 'Entity Number', 'restriction' => 'hidden'), 
        'docnumber'           => array('fielddesc' => 'Document Number', 'restriction' => 'hidden'), 
        'company'             => array('fielddesc' => 'Division', 'restriction' => 'hidden', 'library' => 'Company'), // FK mrd_? currently in the mrd_library
        'buyername'           => array('fielddesc' => 'Buyer Name', 'library' => 'Buyer'),
        'entrypersonbadge'    => array('fielddesc' => 'Entered By', 'restriction' => 'viewonly'),
        'doccreationtime'     => array('fielddesc' => 'Creation Time', 'restriction' => 'viewonly'),
        
        // Othres
        //'additionalcomment' => array('fielddesc' => 'Additional Comment', 'textarea' => 'textarea'), 
        'referenceno'               => array('fielddesc' => 'Reference No.'),
        'processname'               => array('fielddesc' => 'Process Name'),
        'version'                   => array('fielddesc' => 'Version'),
        'criterialist'              => array('fielddesc' => 'Criteria List', 'textarea' => 'textarea'),
        
        'buyername'                 => array('fielddesc' => 'End Customer', 'library' => 'Buyer', 'restriction' => 'required'), 
        'orderstatus'               => array('fielddesc' => 'Sales Order Status', 'library' => 'OrderStatus', 'restriction' => 'required'), 
        'salesorder'                => array('fielddesc' => 'SO No.'), 
        'program'                   => array('fielddesc' => 'Program/Season'), 
        'style'                     => array('fielddesc' => 'Garment Style'), 
        'sizeofld'                  => array('fielddesc' => 'Size of Lab-dip'),
        'optionno'                  => array('fielddesc' => 'No. of Option'),
        'subdoclinenumber'          => array('fielddesc' => 'SO Delivery Line No.'),
        'ldcslnumber'               => array('fielddesc' => 'SO Item Line No.', 'restriction' => 'hidden'),
        'quantity'                  => array('fielddesc' => 'Garment Quantity in Pcs'),
        'TraceID'                   => array('fielddesc' => 'Trace ID'),
        'Placement'                 => array('fielddesc' => 'Placement'),
        'Color'                     => array('fielddesc' => 'Item Color', 'textarea' => 'textarea'),
        'Source'                    => array('fielddesc' => 'Source'),
        'Specification'             => array('fielddesc' => 'Specification'),
        'ItemName'                  => array('fielddesc' => 'Item Name'),
        'GarmentDesignOrColor'      => array('fielddesc' => 'Garment Design Or Color'),
        'ProcessLevel'              => array('fielddesc' => 'Process Level'),
        'Size'                      => array('fielddesc' => 'Garment Size'),

        'NominatedSupplier'         => array('fielddesc' => 'Nominated Supplier'),
        'Consumption'               => array('fielddesc' => 'Consumption Per Dozen'),
        'UOM'                       => array('fielddesc' => 'UOM', 'library' => 'UOM'),
        'ProcessLoss'               => array('fielddesc' => 'Process Loss (%)'),
        'ConsumptionEntryTime'      => array('fielddesc' => 'Consumption Entry Time'),
        'GarmentQty_Dzn'            => array('fielddesc' => 'Garment Qty (Dzn)'),
        'GarmentQtyEntryTime'       => array('fielddesc' => 'Garment Qty Entry Time'),
        'GarmentQtyChangeRate'      => array('fielddesc' => 'Garment Qty Change Rate'),
        'ReqQty'                    => array('fielddesc' => 'Garment Quantity in Pcs'),
        'ReadyForBooking'           => array('fielddesc' => 'Ready For Booking', 'library' => 'yes_no'),
        'RFB_Time'                  => array('fielddesc' => 'RFB_Time'),
        'BookingApproval'           => array('fielddesc' => 'Booking Approval', 'library' => 'yes_no'),
        'BATime'                    => array('fielddesc' => 'BA Time'),
        'MaterialRemarks'           => array('fielddesc' => 'Material Remarks'),
        'RowTester'                 => array('fielddesc' => 'Row Tester'),
        'ExpectedInHouseDate'       => array('fielddesc' => 'Expected InHouse Date'),
        'ExpectedInHouseChangeRate' => array('fielddesc' => 'Expected InHouse Change Rate'),
        'FinalConsumption'          => array('fielddesc' => 'Final Consumption'),
        'FinalProcessLoss'          => array('fielddesc' => 'Final Process Loss'),
        'FinalGarmentQty_Dzn'       => array('fielddesc' => 'Final Garment Qty (Dzn)'),
        'FinalExpectedInHouseDate'  => array('fielddesc' => 'Final Expected InHouse Date'),
        'FinalReqQty'               => array('fielddesc' => 'Total Required Qty'),
        'note'                      => array('fielddesc' => 'Note', 'textarea' => 'textarea'),
        'itemdescription'           => array('fielddesc' => 'Item Description', 'textarea' => 'textarea'),
        
        ),
        
        'lines' => array(
        // Identification
        'idlines'             => array('restriction' => 'hidden'), // this line's ID
        'linenumber'          => array('fielddesc' => 'Line', 'restriction' => 'viewonly'),

    // Othres
    // 'itemtype'        => array('fielddesc' => 'Item Type'),
    // 'itemcode'        => array('fielddesc' => 'Item Code'),
    // 'itemlot'         => array('fielddesc' => 'Item Lot'),
    // 'itemserial'      => array('fielddesc' => 'Item Serial'),
    // 'tnxqty'          => array('fielddesc' => 'Quantity'),
    // 'iduom'             => array('fielddesc' => 'UOM', 'library' => 'UOM'),
    ),
  );

  public function __construct() {
    $formId = 'formERP';
    $conn = new ErpDbConn;
    $missingFields = array();
  }

  public static function tableStructureWithVirtual() {
    $tableStructure = self::$tableStructure;
    $tableStructure['lines']['supplierlot']['fielddesc']      = 'Supplier Lot';
    $tableStructure['lines']['supplierlot']['fieldtype']      = 'varchar(30)';
    $tableStructure['lines']['supplierlot']['virtual']        = true;
    return $tableStructure;
  }

  public function __toString() {
    return json_encode($this->docobj);
  }

  /**
   * Generates a form based on a structured list of fields
   */
  public function buildForm() {
    $formStructure = $this->formStructure;
    /*
    Starts echoing the actual form
     */
    echo <<<EOF
EOF;

echo <<<EOF
<div id="upperButtonBar" style="height:40px;">
EOF;
  foreach ($this->formButtons as $formButton) {
    echo self::indented(2, self::HTML_button($formButton));
  }
echo <<<EOF
</div>

<div id="listLoadingDiv">
  <center><img src="/images/loading_spinner.gif"></center>
</div>

<div id="messageBar" class="messageBar"></div>

<div> <!-- mother div -->
<div id="listCntrDiv"></div>
EOF;

    echo <<<EOF
<div id="formDiv">    
<form action="#" method="post" id="$this->formId" autocomplete="off">
    <div id="rightFormDiv" style="display:block;" >

      <div id="dragbar"></div>
      <fieldset id="rightFormButtons"> 
        <div style="float:right; display:inline-block;">
          <input type="button" class="btnEditMode btnCancelForm btnEC3 btn-grey material-icons" value="cancel" title="Cancel line" style="display:none;"/>
        </div>
      </fieldset>

      <div id="formCaption" style="display:none;">
          <div class="w40">$this->formTitle</div>
          <div class="w20 text_center">
              <span></span><input type="hidden" name="iddocument" id="iddocument" value=""/>
              <span id="spandocnumber"></span><input type="hidden" name="docnumber" id="spandocnumber" value=""/>
          </div>
          <div class="w40 text_right">
              <span id="spandocstatus"></span><input type="hidden" name="docstatus" id="docstatus" value=""/>
          </div>
          <div class="clearfix"></div>
      </div>
      <div id="formError"></div>

EOF;
    foreach ($this->formGroups as $groupName => $groupFields) {
      $containerName = "fieldset_" . strtolower(str_replace(" ", "", $groupName));

      echo self::indented(2, "<fieldset id=\"$containerName\">");
      echo self::indented(3, "<legend>$groupName</legend>");
      // echo chr(13).chr(10);
      foreach ($groupFields as $groupfield) {
        echo self::indented(3, self::HTML_headerfield($groupfield));
      }
      echo self::indented(2, '</fieldset>');

    }

    echo <<<EOF
    <span id="lowerButtonBar">
    </span>

    </div>
</form>
</div> <!-- form div end -->
</div> <!-- mother div end -->
EOF;
  }



  function indented($level, $block) {
    $block         = explode(chr(13) . chr(10), $block);
    $indentedblock = array();
    foreach ($block as $line) {
      array_push($indentedblock, str_repeat("  ", $level) . $line);
    }
    $indentedblock = implode(chr(13) . chr(10), $indentedblock);
    return $indentedblock . chr(13) . chr(10);
  }

  function get_formStructureData($fieldname, $data, $ifnotset, $part) {
    $formStructure = $this->formStructure;
    return (isset($formStructure[$part][$fieldname][$data]) ? $formStructure[$part][$fieldname][$data] : $ifnotset);
  }

  function get_fieldType($fieldname, $part) {
    $fieldrestriction = self::get_formStructureData($fieldname, 'restriction', '', $part);
    $fieldlibrary     = self::get_formStructureData($fieldname, 'fielddlibraryesc', '', $part);
    $dbfieldtype      = self::get_formStructureData($fieldname, 'fieldtype', '', $part);
    $formStructure    = $this->formStructure;

    if ($fieldrestriction == 'hidden') {
      return 'hidden';
    } elseif ($fieldrestriction == 'viewonly' && $part == 'lines') {
      return 'hidden';
    } elseif ($dbfieldtype == 'decimal(18,4)') {
      return 'number';
    } elseif ($dbfieldtype == 'date') {
      return 'date';
    } elseif ($dbfieldtype == 'datetime') {
      return 'datetime';
    // } elseif ($dbfieldtype == 'text') {
    } elseif (isset($formStructure[$part][$fieldname]['textarea'])) {
      return 'textarea';
    } elseif (isset($formStructure[$part][$fieldname]['library'])) {
      return 'select';
    } else {
      return 'text';
    }
  }

  function HTML_button($button) {
    $buttons                     = array();
    $buttons['btnSaveForm'] = <<<EOF
<input type="button" class="btnEditMode btnSaveForm btnEC1 btn-blue" value="Save (CTRL+S)" title="Save the current document" style="display:none;"/>
EOF;
    $buttons['btnNew'] = <<<EOF
<input type="button" class="btnReadMode btnAllMode btnNew btn-blue" value="Create New" title="New document" style="display:none;"/>
EOF;
    $buttons['btnImportBOM'] = <<<EOF
<input type="button" class="btnReadMode btnAllMode btnImportBOM btn-grey" value="Import BOM" title="Import BOM" style="display:none;"/>
EOF;
    $buttons['btnMultipleEdit'] = <<<EOF
<input type="button" class="btnReadMode btnAllMode btnMultipleEdit btn-grey" value="Edit Multiple Line" title="Edit Multiple Line" style="display:none;"/>
EOF;
    $buttons['btnEnterEditMode'] = <<<EOF
<input type="button" class="btnReadMode btnEnterEditMode btn-grey material-icons" value="edit" title="Click to make changes to this document" style="display:none;"/>
EOF;
    $buttons['btnCancelForm'] = <<<EOF
<input type="button" class="btnEditMode btnCancelForm btnEC2 btn-grey material-icons" value="cancel" title="Cancel changes and go back to previous page" style="display:none;"/>
EOF;
    $buttons['btnPrintSheet'] = <<<EOF
<input type="button" class="btnReadMode btnPrintSheet btn-grey material-icons" value="print insert_drive_file" title="Print this document (opens new window)" style="display:none;"/>
EOF;
    $buttons['btnCopyAndNew'] = <<<EOF
<input type="button" class="btnReadMode btnCopyAndNew btn-grey" value="Copy & New" title="Save the current document" style="display:none;"/>
EOF;
    $buttons['btnMultipleCopyAndNew'] = <<<EOF
<input type="button" class="btnReadMode btnMultipleCopyAndNew btn-grey" value="Multiple Copy & New" title="Save the current document" style="display:none;"/>
EOF;
    $buttons['btnChangeDocStatus'] = <<<EOF
<input type="button" class="btnReadMode btnChangeDocStatus  btn-grey" value="Change Doc Status" title="Complete This Document" style="display:none;"/>
EOF;
    $buttons['btnNext'] = <<<EOF
<input type="button" class="btnReadMode btnNext  btn-grey" value="Project Details" title="Create or View Fabric List" style="display:none;"/>
EOF;
    $buttons['removeLine'] = <<<EOF
<input type="button" class="btnReadMode removeLine btn-grey material-icons" value="delete" title="Remove the current line" style="display:none;"/>
EOF;
    $buttons['btnSpacer10'] = <<<EOF
 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
EOF;
    $buttons['btnSpacer50px'] = <<<EOF
<img src="data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==" style="margin: 0px 0px 0px 50px"/>
EOF;

    return $buttons[$button];
  }

  function HTML_headerfield($fieldname) {
    $formStructure = $this->formStructure;
    $fielddesc     = self::get_formStructureData($fieldname, 'fielddesc', $fieldname, 'header');
    $fieldtype     = self::get_fieldType($fieldname, 'header');

    $hide = '';
    switch ($fieldtype) {
    case 'text':
      $inputHTML = <<<EOF
<input type="text" name="{$fieldname}" id="{$fieldname}" value=""/>
EOF;
      break;
    case 'hidden':
      $hide      = ' style="display:none;"';
      $inputHTML = <<<EOF
<input type="hidden" name="{$fieldname}" id="{$fieldname}" value=""/>
EOF;
      break;
    case 'select':
      $inputHTML = <<<EOF
<select name="{$fieldname}" id="{$fieldname}">
    <option value="">Select</option>
</select>
EOF;
      break;
    case 'textarea':
      $inputHTML = <<<EOF
<textarea name="{$fieldname}" id="{$fieldname}"></textarea>
EOF;
      break;
    case 'date':
      $inputHTML = <<<EOF
<input type="text" name="{$fieldname}" id="{$fieldname}" class="datepicker" value=""/>
EOF;
      break;
    case 'datetime':
      $inputHTML = <<<EOF
<input type="text" name="{$fieldname}" id="{$fieldname}" class="datetimepicker" value=""/>
EOF;
      break;
    default:
      $inputHTML = <<<EOF
EOF;
      error_log("Unknown field type " . $fieldtype . " for field " . $fieldname);
      self::HTML_headerfield($fieldname, $fielddesc, 'text');
      break;
    }
    $template = <<<EOF
<div class="formGroup"$hide>
    <label for="{$fieldname}">{$fielddesc}</label>
    $inputHTML
</div>
EOF;
    return $template;
  }









/**
 * doc number generate
 * docuemt create, 
 * document edit and 
 * document read
 * validation checking
 * ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
 */

  function getNextDocNumber($countername){
    $conn = new ErpDbConn;
    $sql = "SELECT prefix, nextnumber from erp_counter where countername='$countername'";
    $prefix        = json_decode($conn->sqlToJson($sql), true)[0]['prefix'];
    $currentdocnum = json_decode($conn->sqlToJson($sql), true)[0]['nextnumber'];

    $sql = "UPDATE erp_counter SET nextnumber=(nextnumber+1) where countername='$countername'";
    $qresult = $conn->query($sql);

    if($qresult){
      return $prefix . "-".$currentdocnum;
    }
  }


  function _createDoc($docdata, $formStructure){
    $conn = new ErpDbConn;
    $returnJSON            = new stdClass();
    $returnJSON->errormsgs = array();

    $formStructure = json_decode($formStructure, true);
    $tablename = $formStructure['schema']['tablename'];
    $doctype   = $formStructure['header']['doctype'];
    $formtype  = $formStructure['header']['formtype'];
    $doccounter= $formStructure['doccounter'];

    $docobj = json_decode($docdata, true);
    $doclins = $docobj['lines'];
    unset($docobj['lines']);

    $sql_array = array();
    $columnFields = array();
    $fieldValues = array();
    // process header
    unset($docobj['docnumber']);
    unset($docobj['docstatus']);
    unset($docobj['entrypersonbadge']);
    unset($docobj['doccreationtime']);
    // system entries
    $docnumber = $this->getNextDocNumber($doccounter);
    $columnFields[] = 'docnumber';
    $fieldValues[]  = $docnumber;

    $columnFields[] = 'entrypersonbadge';
    $fieldValues[]  = $_SESSION['LoggedBadge'];

    $columnFields[] = 'docstatus';
    $fieldValues[]  = 'Entered';
    $columnFields[] = 'doccreationtime';
    $fieldValues[]  = date('Y-m-d H:i:s', time());

    foreach ($docobj as $fieldname => $fieldvalue) {
      $columnFields[] = $fieldname;
      $fieldValues[] = $fieldvalue;
    }
    

    $columnFields = implode(", ", $columnFields);
    $fieldValues  = "'" . implode("','", $fieldValues) . "'";

    $sql = "INSERT INTO $tablename ($columnFields) VALUES($fieldValues)";
    $sql_array[] = $sql;

    // Execute Query
    foreach ($sql_array as $key => $sql) {
      $result = $conn->query($sql);   
      if(!$result){
        array_push($returnJSON->errormsgs, "Error, $sql");
        return $returnJSON;
      }
    }
        $conn->close();

    if ($result) {
      $returnJSON->docnumber = $docnumber;
    } else {
      array_push($returnJSON->errormsgs, "Error, please tell ERP department: commit failed.");
    }
    return $returnJSON;

  }


  function _updateDoc($docdata, $formStructure){
    $conn = new ErpDbConn;
    $returnJSON            = new stdClass();
    $returnJSON->errormsgs = array();

    $formStructure = json_decode($formStructure, true);
    $tablename = $formStructure['schema']['tablename'];   

    $newdocobj = json_decode($docdata, true);
    $docnumber = $newdocobj['docnumber'];
    $olddocobj = json_decode($this->readDoc($docnumber, json_encode($formStructure)), true);
    unset($newdocobj['lines']);
    $docHeaderArray = $newdocobj;

    // Generating query varriables
    // HEADER
    // update SQL for header
    $sql_array = array();
    foreach ($docHeaderArray as $keyHeader => $valueHeader) {
      if ($keyHeader != 'docnumber') {
        $updateSet .= $keyHeader . "=" . "'" . $valueHeader . "',";
      }
    }     
    $updateSet = rtrim($updateSet ,',');
    $sql = "UPDATE $tablename SET $updateSet WHERE docnumber = '$docnumber'";
    

    // Execute Query
    $sql_array[] = $sql;
    foreach ($sql_array as $key => $sql) {
      $result = $conn->query($sql);   
      if(!$result){
        array_push($returnJSON->errormsgs, "Error, $sql");
        return $returnJSON;
      }
    }
    $conn->close();

    if ($result) {
      $returnJSON->docnumber = $docnumber;
    } else {
      array_push($returnJSON->errormsgs, "Error, please tell ERP department: commit failed.");
    }
    return $returnJSON;

  }


  function _readDoc($docnumber, $formStructure){
    $conn = new ErpDbConn;
    $formStructure = json_decode($formStructure, true);
    $tablename = $formStructure['schema']['tablename'];

    // get the list of fields
    // $fieldHeader = "h." . implode(", h.", array_diff(array_keys($formStructure['header']), array('docstatus')));
    $fieldHeader = "h." . implode(", h.",  array_keys($formStructure['header'])  );

    // get the header info in docobj
    $sql = "SELECT $fieldHeader
      FROM  $tablename h
      WHERE h.docnumber = '$docnumber' LIMIT 1";

    $result = $conn->query($sql);
    $docobj = $result->fetch_assoc();

    foreach ($docobj as $fieldname => $fieldvalue) {
      if ($fieldvalue == NULL) {
        unset($docobj[$fieldname]);
      }
    }

    $docobj['lines'] = '';
    return json_encode($docobj);
  }

}
?>