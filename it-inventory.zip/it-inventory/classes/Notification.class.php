<?php
/**
* Notification Handler Class
*/
class Notification
{
	public $erpConnObj = "";

	function __construct($db = 1) {
		if($db == 2){
			$this->erpConnObj = new ErpDbConn('2');
		} else {
			$this->erpConnObj = new ErpDbConn;
		}
	}

	function getNotification($sql){             
		$result = $this->erpConnObj->query($sql);
		return $result->num_rows;
		// return 0;
	}
}
?>