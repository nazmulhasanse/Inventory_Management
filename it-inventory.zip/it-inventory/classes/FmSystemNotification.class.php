<?php
/**
* This class will handle all notification
* details and single (just number)
* date: 2017-07-17
*/
class FmSystemNotification
{

	public $conn;
	public $queryResult;
	public $sql;
	public $dbname;

	public function __construct($dbnum = 1) {
		if ($dbnum === '2') {
			$this->conn = new ErpDbConn('2');
			$this->dbname = "erpprod_bulbul";
		} else {
			$this->conn = new ErpDbConn;
			$this->dbname = "erpprod";
		}
	}


	function getModificationCancellationNotification_SO(){
		$sql = "SELECT docnumber FROM erp_salesorder WHERE islinefreezed = '1'";
		$queryResult = $this->conn->query($sql);
		$notreadyformodification = $queryResult->num_rows;

		$notreadyldcslnumbers = '';
		$proceededDocumentNos = array();
		if($notreadyformodification > 0){
			while ( $row = $queryResult->fetch_assoc() ) {
				$docnumber = $row['docnumber'];
				if(!in_array($docnumber, $proceededDocumentNos)){
					$proceededDocumentNos[] = $docnumber;
					$notreadyldcslnumbers .=  $row['docnumber']. ', ';
				}
			}
		}

		$sql = "SELECT docnumber FROM erp_salesorder WHERE islinefreezed = '2' AND linestatus = '0'";
		$queryResult = $this->conn->query($sql);
		$readyformodification = $queryResult->num_rows;

		$readyldcslnumbers = '';
		$proceededDocumentNos = array();
		if($readyformodification > 0){
			while ( $row = $queryResult->fetch_assoc() ) {
				$docnumber = $row['docnumber'];
				if(!in_array($docnumber, $proceededDocumentNos)){
					$proceededDocumentNos[] = $docnumber;
					$readyldcslnumbers .=  $row['docnumber']. ', ';
				}
				
			}
		}

		$count = $notreadyformodification + $readyformodification;

		$count = ($count > 0) ? "(<span class = 'notification'>$count</span>)" : "";
		// $ldcslnumbers = '';
		$notreadyldcslnumbers = ($notreadyldcslnumbers != '') ?  substr($notreadyldcslnumbers,0,154) . ' ..... these SO have been requested for Modification/Cancellation' : '';
		$readyldcslnumbers = ($readyldcslnumbers != '') ?  substr($readyldcslnumbers,0,154) . ' ..... these SO is ready for Modification/Cancellation' : '';
		return array(
			'count'   => $count,
			'msg1'    => $notreadyldcslnumbers,
			'msg2'    => $readyldcslnumbers,
			'showDetailsMsg' => 'yes'
			);
	}

	function getModificationCancellationNotification_ML(){

	}	

	function getNewRRNotification_SO($formtype){
		$sql = "SELECT distinct(salesorder) AS `sonewrr` FROM erp_rrlines WHERE rrstatus='0' AND rrtype like '%$formtype%' GROUP BY salesorder";
		$queryResult = $this->conn->query($sql);
		$notreadyformodification = $queryResult->num_rows;

		$allsonewrr = '';
		while( $row = $queryResult->fetch_assoc() ) {
			$sonewrr = $row['sonewrr'];
			$allsonewrr .= $sonewrr. ', ';
		}


		$allsonewrr = ($allsonewrr != '') ?  substr($allsonewrr,0,154) . ' ..... new RR Created for this Sales Order.' : '';
		return array(
			'msg1'    => $allsonewrr,
			'showDetailsMsg' => 'yes'
			);
	}
		
	function getModificationCancellationNotification_BOM(){

		$formtype = $_GET['formtype']; 
		$sql = "SELECT ldcslnumber FROM erp_salesorder WHERE (showmodcxlbtnforbom != '0' OR showmodcxlbtnforml != '0') AND formtype LIKE '%$formtype%'";
		$queryResult = $this->conn->query($sql);
		$notreadyformodification = $queryResult->num_rows;

		$notreadyldcslnumbers = '';
		if($notreadyformodification > 0){
			while ($row = $queryResult->fetch_assoc() ) {
				$notreadyldcslnumbers .= $row['ldcslnumber'] . ', ';
			}
		}		

		$sql = "SELECT ldcslnumber FROM erp_salesorder WHERE materialliststatus = '3' AND isbomcreated = '0' AND formtype LIKE '%$formtype%'";
		error_log('tre' .$sql);
		$queryResult = $this->conn->query($sql);
		$noofConfirmML = $queryResult->num_rows;

		$ConfirmMLldcslnumbers = '';
		if($noofConfirmML > 0){
			while ($row = $queryResult->fetch_assoc() ) {
				$ConfirmMLldcslnumbers .= $row['ldcslnumber'] . ', ';
			}
		}

		// $sql = "SELECT ldcslnumber FROM erp_salesorder WHERE (islinefreezed = '2' AND linestatus = '0') OR bomfreezestatus = '2'";
		// $queryResult = $this->conn->query($sql);
		// $readyformodification = $queryResult->num_rows;

		// $readyldcslnumbers = '';
		// if($readyformodification > 0){
		// 	while ( $row = $queryResult->fetch_assoc() ) {
		// 		$readyldcslnumbers .= $row['ldcslnumber'] . ', ';
		// 	}
		// }

		// $count = $notreadyformodification + $readyformodification;
		$count1 = $notreadyformodification + $noofConfirmML;

		$count1 = ($count1 > 0) ? "(M/C: <span class = 'notification'>$notreadyformodification</span>)(ML: <span class = 'notification'>$noofConfirmML</span>)" : "";
		// $ldcslnumbers = '';
		$notreadyldcslnumbers = ($notreadyldcslnumbers != '') ?  substr($notreadyldcslnumbers,0,152) . ' ..... these item line have been requested for Modification/Cancellation' : '';
		$ConfirmMLldcslnumbers = ($ConfirmMLldcslnumbers != '') ?  substr($ConfirmMLldcslnumbers,0,152) . ' ..... ML Confirmed for these item line' : '';
		return array(
			'count'   => $count1,
			'msg1'    => $notreadyldcslnumbers,
			'msg2'    => $ConfirmMLldcslnumbers,
			'showDetailsMsg' => 'yes'
			);

	}
	function getModificationCancellationNotification_CP(){
		$formtype = $_GET['formtype']; 
		$sql = "SELECT ldcslnumber FROM erp_salesorder WHERE showmodcxlbtnforcp != '0' AND formtype LIKE '%$formtype%'";
		$queryResult = $this->conn->query($sql);
		$notreadyformodification = $queryResult->num_rows;		

		$notreadyldcslnumbers = '';
		if($notreadyformodification > 0){
			while ( $row = $queryResult->fetch_assoc() ) {
				$notreadyldcslnumbers .= $row['ldcslnumber'] . ', ';
			}
		}

		$sql = "SELECT ldcslnumber FROM erp_salesorder WHERE (linestatus = '1' OR linestatus = '3') AND iscpcreated = '0' AND docstatus != '9' AND origin != 'Merging_Old_SO' AND formtype LIKE '%$formtype%'";
		$queryResult = $this->conn->query($sql);
		$noofInformCP = $queryResult->num_rows;

		$InformCPldcslnumbers = '';
		if($noofInformCP > 0){
			while ($row = $queryResult->fetch_assoc() ) {
				$InformCPldcslnumbers .= $row['ldcslnumber'] . ', ';
			}
		}		

		// $sql = "SELECT ldcslnumber FROM erp_salesorder WHERE (islinefreezed = '2' AND linestatus = '0') OR cpfreezestatus = '2'";
		// $queryResult = $this->conn->query($sql);
		// $readyformodification = $queryResult->num_rows;

		// $readyldcslnumbers = '';
		// if($readyformodification > 0){
		// 	while ( $row = $queryResult->fetch_assoc() ) {
		// 		$readyldcslnumbers .= $row['ldcslnumber'] . ', ';
		// 	}
		// }

		// $count = $notreadyformodification + $readyformodification;

		$count1 = $notreadyformodification + $noofInformCP;

		$count1 = ($count1 > 0) ? "(M/C: <span class = 'notification'>$notreadyformodification</span>)(Inform to CP: <span class = 'notification'>$noofInformCP</span>)" : "";
		// $ldcslnumbers = '';
		$notreadyldcslnumbers = ($notreadyldcslnumbers != '') ?  substr($notreadyldcslnumbers,0,163) . ' ..... these item line have been requested for Modification/Cancellation' : '';
		$InformCPldcslnumbers = ($InformCPldcslnumbers != '') ?  substr($InformCPldcslnumbers,0,163) . ' ..... these Item Line have Informed to CP' : '';
		return array(
			'count'   => $count1,
			'msg1'    => $notreadyldcslnumbers,
			'msg2'    => $InformCPldcslnumbers,
			'showDetailsMsg' => 'yes'
		);

	}
	function getModificationCancellationNotification_RR(){

	}
}
?>