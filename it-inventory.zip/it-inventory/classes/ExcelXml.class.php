<?php
/**
 * Simple excel writer class with no external dependencies, drop it in and have fun
 * @author Matt Nowack
 * @link https://gist.github.com/ihumanable/929039/edit
 * @license Unlicensed
 * @version 1.0
 */
class ExcelXml {
  private $col;
  private $row;
  private $data;
  private $title;
  private $top;
  private $bottom;
  
  /**
   * Safely encode a string for use as a filename
   * @param string $title The title to use for the file
   * @return string The file safe title
   */
  static function filename($title) {
    $result = strtolower(trim($title));
    $result = str_replace("'", '', $result);
    $result = preg_replace('#[^a-z0-9_]+#', '-', $result);
    $result = preg_replace('#\-{2,}#', '-', $result);
    return preg_replace('#(^\-+|\-+$)#D', '', $result);
  }
  
  /**
   * Builds a new Excel Spreadsheet object
   * @return Excel The Spreadsheet
   */
  function __construct($title) {
    $this->title = $title;
    $this->col = 0;
    $this->row = 0;
    $this->data = '';
    // $this->bofMarker();
  }
  
  /**
   * Transmits the proper headers to cause a download to occur and to identify the file properly
   * @return nothing
   */
  function headers($filesize = 100) {
    // header("Content-Type: application/force-download");
    // header("Content-Type: application/octet-stream");
    // header("Content-Type: application/download");
    // // header("Content-Disposition: attachment;filename=" . Excel::filename($this->title) . ".xls ");
    // header("Content-Disposition: attachment;filename=" . Excel::filename($this->title) . ".xml ");
    // header("Content-Transfer-Encoding: binary ");

    // // new by mamun: 2018-04-24
    // // link: http://krasimirtsonev.com/blog/article/php-export-mysql-data-to-xls-file
    // header("Pragma: no-cache");
    // header("Expires: 0");
    
    // Send the headers
    header("Content-Type: application/force-download");
    header('Content-type: application/vnd.ms-excel');
    header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
    header("Expires: Mon, 26 Jul 1997 05:00:00 GMT"); // Date in the past
    header("Content-Length: " . $filesize);
    header("Content-Disposition: inline; filename=" . ExcelXml::filename($this->title) . ".xml");

  }

  /**
   * Moves internal cursor to the top of the page, row = 0
   * @return nothing
   */
  function top() {
    $top = <<<EOF
<?xml version="1.0"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:o="urn:schemas-microsoft-com:office:office"
 xmlns:x="urn:schemas-microsoft-com:office:excel"
 xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:html="http://www.w3.org/TR/REC-html40">
 <DocumentProperties xmlns="urn:schemas-microsoft-com:office:office">
  <Created>2018-02-13T10:00:55Z</Created>
  <Version>15.00</Version>
 </DocumentProperties>
 <OfficeDocumentSettings xmlns="urn:schemas-microsoft-com:office:office">
  <AllowPNG/>
 </OfficeDocumentSettings>
 <ExcelWorkbook xmlns="urn:schemas-microsoft-com:office:excel">
  <WindowHeight>9720</WindowHeight>
  <WindowWidth>24000</WindowWidth>
  <WindowTopX>0</WindowTopX>
  <WindowTopY>0</WindowTopY>
  <ProtectStructure>False</ProtectStructure>
  <ProtectWindows>False</ProtectWindows>
 </ExcelWorkbook>
 <Styles>
  <Style ss:ID="Default" ss:Name="Normal">
   <Alignment ss:Vertical="Bottom"/>
   <Borders/>
   <Font ss:FontName="Calibri" x:Family="Swiss" ss:Size="11" ss:Color="#000000"/>
   <Interior/>
   <NumberFormat/>
   <Protection/>
  </Style>
  <Style ss:ID="s62">
   <NumberFormat ss:Format="Short Date"/>
  </Style>
  <Style ss:ID="s65">
   <Font ss:FontName="Calibri" x:Family="Swiss" ss:Size="12" ss:Color="#000000"
    ss:Bold="1"/>
    <Interior ss:Color="#E8E8E8" ss:Pattern="Solid"/>
  </Style>

  <Style ss:ID="s22">
   <NumberFormat ss:Format="yyyy\-mm\-dd"/>
  </Style>
 </Styles>
 <Worksheet ss:Name="Sheet1">

  <Table x:FullRows="1" ss:DefaultRowHeight="15">
   <Column ss:Index="2" ss:Width="54.75"/>
   <Column ss:Width="116.25"/>
   <Column ss:Width="56.25"/>
EOF;

    $this->top = $top;
    return $top;

  }


  function bottom(){
    $bottom = <<<EOF
  </Table>
  <WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel">
   <PageSetup>
    <Header x:Margin="0.3"/>
    <Footer x:Margin="0.3"/>
    <PageMargins x:Bottom="0.75" x:Left="0.7" x:Right="0.7" x:Top="0.75"/>
   </PageSetup>
   <Print>
    <ValidPrinterInfo/>
    <HorizontalResolution>600</HorizontalResolution>
    <VerticalResolution>600</VerticalResolution>
   </Print>
   <Selected/>
   <Panes>
    <Pane>
     <Number>3</Number>
     <ActiveRow>3</ActiveRow>
     <ActiveCol>2</ActiveCol>
    </Pane>
   </Panes>
   <ProtectObjects>False</ProtectObjects>
   <ProtectScenarios>False</ProtectScenarios>
  </WorksheetOptions>
 </Worksheet>
</Workbook>
EOF;

    $this->bottom = $bottom;
    return $bottom;

  }

  
  function send() {
    // $this->eofMarker();
    $top = $this->top();
    $bottom = $this->bottom();

    $output = $top . $this->data . $bottom;
    $filesize = strlen($output);
    $this->headers($filesize);
    echo $output;

  }
  
  /**
   * Writes the Excel Beginning of File marker
   * @see pack()
   * @return nothing
   */
  private function bofMarker() { 
    $this->data .= pack("ssssss", 0x809, 0x8, 0x0, 0x10, 0x0, 0x0);  
  }
  
  /**
   * Writes the Excel End of File marker
   * @see pack()
   * @return nothing
   */
  private function eofMarker() { 
    $this->data .= pack("ss", 0x0A, 0x00); 
  }
  
  /**
   * Moves internal cursor left by the amount specified
   * @param optional integer $amount The amount to move left by, defaults to 1
   * @return integer The current column after the move
   */
  function left($amount = 1) {
    $this->col -= $amount;
    if($this->col < 0) {
      $this->col = 0;
    }
    return $this->col;
  }
  
  /**
   * Moves internal cursor right by the amount specified
   * @param optional integer $amount The amount to move right by, defaults to 1
   * @return integer The current column after the move
   */
  function right($amount = 1) {
    $this->col += $amount;
    return $this->col;
  }
  
  /**
   * Moves internal cursor up by amount
   * @param optional integer $amount The amount to move up by, defaults to 1
   * @return integer The current row after the move
   */  
  function up($amount = 1) {
    $this->row -= $amount;
    if($this->row < 0) {
      $this->row = 0;
    }
    return $this->row;
  }
  
  /**
   * Moves internal cursor down by amount
   * @param optional integer $amount The amount to move down by, defaults to 1
   * @return integer The current row after the move
   */
  function down($amount = 1) {
    $this->row += $amount;
    return $this->row;
  }
  

  
  /**
   * Moves internal cursor all the way left, col = 0
   * @return nothing
   */
  function home() {
    $this->col = 0;
  }
  
  /**
   * Writes a number to the Excel Spreadsheet
   * @see pack()
   * @param integer $value The value to write out
   * @return nothing
   */
  function number($value) {
    $thisNbr .= "<Cell ss:StyleID='Default'><Data ss:Type='Number'>$value</Data></Cell>"; 
    $this->data .= $thisNbr . PHP_EOL; 
    return $thisNbr;
  }

  /**
   * Writes a number to the Excel Spreadsheet
   * @see pack()
   * @param integer $value The value to write out
   * @return nothing
   */
  function date($value) {
    $length = strlen($value);
    $thisDate = "<Cell ss:StyleID='s22'><Data ss:Type='DateTime'>$value</Data></Cell>"; 
    if($value == '' || $value == null || $value == '0000-00-00'){
      $thisDate = "<Cell ss:StyleID='Default'><Data ss:Type='String'>0000-00-00</Data></Cell>"; 
    } else if($length != 10){
        $thisDate = "<Cell ss:StyleID='Default'><Data ss:Type='String'>0000-00-00</Data></Cell>"; 
    }
    $this->data .= $thisDate . PHP_EOL; 
    return $thisDate;
  }

  /**
   * Writes a string (or label) to the Excel Spreadsheet
   * @see pack()
   * @param string $value The value to write out
   * @return nothing
   */
  function labelHeader($value) { 
    $length = strlen($value);
    // $this->data .= pack("ssssss", 0x204, 8 + $length, $this->row, $this->col, 0x0, $length); 
    // $this->data .= $value; 
    $thisLbl .= "<Cell ss:StyleID='s65'><Data ss:Type='String'>$value</Data></Cell>"; 
    // echo "<br><br>" . $thisLbl;
    $this->data .= $thisLbl . PHP_EOL; 
    return $thisLbl;
  }
  function label($value) { 
    $length = strlen($value);
    // $this->data .= pack("ssssss", 0x204, 8 + $length, $this->row, $this->col, 0x0, $length); 
    // $this->data .= $value; 
    $thisLbl .= "<Cell ss:StyleID='Default'><Data ss:Type='String'>$value</Data></Cell>"; 
    // echo "<br><br>" . $thisLbl;
    $this->data .= $thisLbl . PHP_EOL; 
    return $thisLbl;
  }

  function newTable(){
    // $thisTable = "<Table ss:ExpandedColumnCount="10" ss:ExpandedRowCount="115" x:FullColumns="1" x:FullRows="1" ss:DefaultRowHeight="15">";
  }

  function newRow($properties = ''){
    $thisRow = "<Row ss:Height='18' ss:StyleID='s62'>";
    $this->data .= $thisRow . PHP_EOL; 
    return $thisRow;
  }

  function endRow($properties = ''){
    $thisRow = "</Row>";
    $this->data .= $thisRow . PHP_EOL; 
    return $thisRow;
  }

}



// $xls = new Excel('Report');
// foreach ($rows as $num => $row) {
//   $xls->home();
//   $xls->label($row['id']);
//   $xls->right();
//   $xls->label($row['title']);
//   $xls->down();
// }
// ob_start();
// $data = ob_get_clean();
// file_put_contents(__DIR__ .'/report.xls', $data);



/**
 * How to use this function
 * @var string
 */
// $title = "your-work-sheet";
// $colors = array("red", "blue", "green", "yellow", "orange", "purple");

// $xls = new Excel($title);

// foreach ($colors as $color){
//  $xls->home();
//  $xls->label($color);
//  $xls->right();
//  $xls->down();
// };
// $xls->send();


// ob_start();
// $data = ob_get_clean();
// file_put_contents('report.xls', $data);
// file_put_contents(__DIR__ .'/report.xls', $data);






////////////////////////////// Another One Base ////////////////////////////////////////////////////////////
/*
//Beginning of file...
function xlsBOF() {
   echo pack("ssssss", 0x809, 0x8, 0x0, 0x10, 0x0, 0x0);  
   return;
}

//End of file...
function xlsEOF() {
   echo pack("ss", 0x0A, 0x00);
   return;
}

//Creates a heading...
function xlsWriteLabel($Row, $Col, $Value ) {
   $L = strlen($Value);
   echo pack("ssssss", 0x204, 8 + $L, $Row, $Col, 0x0, $L);
   echo $Value;
   return;
}

//Test Data
$result='this is a test';

//Send Headers
header("Pragma: public");
header("Expires: 0");
header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
header("Content-Type: application/force-download");
header("Content-Type: application/octet-stream");
header("Content-Type: application/download");;
header("Content-Disposition: attachment;filename=test.xls ");
header("Content-Transfer-Encoding: binary ");

//XLS Data Cell
$title = 'test';
xlsBOF();
xlsWriteLabel(0,0,$result);
xlsEOF();
*/
////////////////////////////// Another One Base ////////////////////////////////////////////////////////////
?>