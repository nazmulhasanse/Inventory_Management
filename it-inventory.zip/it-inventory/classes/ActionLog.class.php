<?php
/**
* Action log class to keep track
*/
class ActionLog
{
	function __construct() {
	}
	function registryUserAction($action, $case = "", $reference = "", $pageid = ""){

		$reference = mysql_real_escape_string( $reference );
		$username = $_SESSION["USERNAME"];
		$today = date('Y-m-d H:i:s', time());

		$sql = "INSERT INTO tnx_action_log (`Time`, `username`, `Action` , `Case`, `Reference`, `page_id`) 
				VALUES ('$today' , '$username' , '$action' , '$case' , '$reference', '$pageid')";
				//                   mamun        add         user      tarik
    	
    	$conn = new ErpDbConn('2');
    	$conn->query($sql);
    	unset($conn);
	}

}
?>