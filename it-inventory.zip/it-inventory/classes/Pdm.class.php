<?php
/**
* PDM Class
 * require config.php
 * require ErpDbConn.class.php
 *
 * ****************
 * Author: Al-Mamun
 * Date: 2017-01-13
 * **************** 
*/
class Pdm
{
	public $conn;
	public $result;
	public $sql;
	public $dbname;	
	
	public function __construct($dbnum = 1) {
		if ($dbnum === '2') {
			$this->conn = new ErpDbConn('2');
			$this->dbname = "erpprod_bulbul";
		} else {
			$this->conn = new ErpDbConn;
			$this->dbname = "erpprod";
		}
	}

	/**
	 * [getLibraryDescription description]
	 * @param  [type] $library [Library Name]
	 * @param  [type] $code    [Code]
	 * @return [JSON]          [Return json data]
	 */
	public function getLibraryDescription($library, $code){
		$query = "SELECT * FROM mrd_library WHERE LibraryName = '$library' AND Code = '$code'";
		return $this->conn->sqlToJson($query);
	}


	public function getLibrary($params) {
	  	// for compatiblity with old code, accept strings
	  	if (is_string($params)) {
	    	$library = $params;
	  	} else {
	    	$library = $params['library'];
	  	}

	  	if ($library == 'itemtype') {
	    	$sql = "SELECT ItemType AS Code, ItemDescription AS Description FROM mrd_itemtype_description ORDER BY ItemType";

	  	} else if ($library == 'stocktype') {
	  		$whereclauses = "";
	  		if(isset($params['stocktypename'])){
	  			$stocktypename = $params['stocktypename'];
	  			$whereclauses = " WHERE stocktype = '$stocktypename'";
	  		}
	    	$sql = "SELECT idstocktype as Code, stocktype as Description FROM erpprod.erp_mrd_stocktype $whereclauses";

	  	} else if ($library == 'whlocation') {
	    	$sql = "SELECT idmrd_location as Code, locationname as Description FROM erpprod.mrd_location WHERE locationtype = 'WH'";

	  	} else if ($library == 'pdlocation') {

		    if (isset($params['company'])) {
		      $company = $params['company'];
		      $sql     = "SELECT child.idmrd_location AS Code, child.locationname AS Description
		              FROM erpprod.mrd_location child
		              JOIN erpprod.mrd_location parent ON child.idparentlocation = parent.idmrd_location
		              WHERE child.locationtype = 'PD'
		                    AND parent.locationname IN (SELECT Description FROM erpprod.mrd_library WHERE LibraryName = 'company' AND Code = '$company')
		              ";
		    } else {
		      $sql = "SELECT idmrd_location as Code, locationname as Description FROM erpprod.mrd_location WHERE locationtype = 'PD'";
		    }

	  	} else if ($library == 'location') {

	    	$whereclauses = array();
		    if (isset($params['parent'])) {
		      array_push($whereclauses, "idparentlocation = " . sanitizeSuperStrict($params['parent']));
		    }
		    if (isset($params['type'])) {
		      array_push($whereclauses, "locationtype = '" . sanitizeSuperStrict($params['type']) . "'");
		    }
		    if (count($whereclauses) == 0) {
		      array_push($whereclauses, "idparentlocation = 0");
		    }
		    $sql = "SELECT idmrd_location as Code, locationname as Description FROM erpprod.mrd_location WHERE " . implode(' AND ', $whereclauses);

	  	} else if ($library == 'construction') {
	  		$sql = "SELECT Description AS Code, Description FROM mrd_library WHERE LibraryName IN ('construction_kgf', 'construction_wgf') ORDER BY Description";
	    	// $sql = "SELECT Code, Description FROM mrd_library WHERE LibraryName IN ('construction_kgf', 'construction_wgf') ORDER BY Description";
	    	// return $sql;

	  	} else {
	    	$sql = "SELECT Code, Description FROM mrd_library WHERE LibraryName = '$library' ORDER BY Description";
	  	}

	  	$result = $this->conn->query($sql);
	  	$libraryArray = array();
	  	while ($row = $result->fetch_assoc()) {
	    	$Code                = $row['Code'];
	    	$libraryArray[$Code] = $row['Description'];
	  	}
	  	$this->conn->close();
	  	return json_encode($libraryArray, JSON_PRETTY_PRINT);
	}


}
?>