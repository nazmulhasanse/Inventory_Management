<?php
/**
 * Author: Al-Mamun
 * Date: 2017-04-07
 */
class FabricDesignId {

  public $fabricdesignid;
  public $constraction;
  public $composition;
  public $fabricgsm;
  public $error_state;

  /**
   * Instantiates a new fabricdesignid or loads from DB
   */
  public function __construct($fabricdesignid = 0) {
    // if parameter has been passed, try to load the fabricdesignid from DB
    // if failed, instantiate a new fabricdesignid and update $error_state (should we throw an error instead?)
    // in either case, the result is stored in this->fabricdesignid
    $fabricdesignid = (int) $fabricdesignid;

	$conn   = new ErpDbConn;
    if($fabricdesignid == 0){
		$sql = "INSERT INTO erp_fabricdesignid VALUES ()";
		$conn->conn->query($sql);
		$this->fabricdesignid = $conn->conn->insert_id;

    } else {

		$sql    = "SELECT * FROM erpprod.erp_fabricdesignid WHERE fabricdesignid = $fabricdesignid";
		$result = $conn->conn->query($sql);
		if ($result->num_rows > 0) {
		  	$row = $result->fetch_assoc();
			$this->fabricdesignid = $row['fabricdesignid'];
			$this->construction   = $row['construction'];
			$this->composition    = $row['composition'];
			$this->fabricgsm      = $row['fabricgsm'];
		}

    }

    unset($conn);
  }

  public function __destruct() {
  }

  public function __tostring() {
    return $this->fabricdesignid;
  }

  /**
   * Immediately updates the DB to add the specifications
   */
  public function registerFabricSpecifications($specifications) {
    $this->construction   = (string) $specifications['construction'];
    $this->composition = (string) $specifications['composition'];
    $this->fabricgsm  = (string) $specifications['fabricgsm'];

    $conn   = new ErpDbConn;
    $sql = "UPDATE erpprod.erp_fabricdesignid SET construction = '$this->construction', composition = '$this->composition', fabricgsm = '$this->fabricgsm' WHERE fabricdesignid = $this->fabricdesignid";
    $result = $conn->conn->query($sql);
    unset($conn);
  }

}
?>