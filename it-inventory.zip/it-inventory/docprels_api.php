<?php
session_start();
$directory = __DIR__ ;
// require_once __DIR__ . "/classes/config.php";
require_once $_SERVER["DOCUMENT_ROOT"] . '/includes/configli.php'; // mysql connections
require_once __DIR__ . "/classes/myclassautoloader.php";
require_once __DIR__ . "/api/FileClient.class.php";
/**
* ThisDocAPI class
*/
class ThisDocAPI extends BaseDocAPI
{

	function __construct(){
	}



	function readDoc($docnumber){

		$genericDocument = new ErpDocumentPRELS();
		$formStructure = json_encode($genericDocument->formStructure('NP', 'PR', 'read'), JSON_PRETTY_PRINT);

		$docnumber = $_GET['docnumber'];
		$apiObj = new ThisDocAPI();
		$docData = $apiObj->_readDoc($docnumber, $formStructure);
		$docObj = json_decode($docData, true);

		// again read doc with doctype and formtype
		$doctype = $docObj['doctype'];
		$formtype = $docObj['formtype'];
		$formStructure = json_encode($genericDocument->formStructure($doctype, $formtype, 'read'), JSON_PRETTY_PRINT);
		$docData = $apiObj->_readDoc($docnumber, $formStructure);
		$docObj = json_decode($docData, true);

		// $docObj['docstatus'] = $apiObj->docStatusTranslatorF[$docObj['docstatus']];

		$docLines = $docObj['lines'];
		unset($docObj['lines']);
		$newDocLines = array();
		foreach ($docLines as $docLine) {
			$currLine                = $docLine;
			// $currLine['linestatus'] = $this->lineStatusTranslatorF[$docLine['linestatus']];
			array_push($newDocLines, $currLine);
		}
		$docObj['lines'] = $newDocLines;

		return json_encode($docObj);

	}

	function readDocLineWise($docnumber, $idlines){

		$genericDocument = new ErpDocumentPRELS();
		$formStructure = json_encode($genericDocument->formStructure('NP', 'PR', 'read'), JSON_PRETTY_PRINT);

		// $docnumber = $_GET['docnumber'];
		$docData = $this->_readDocLineWise($docnumber, $formStructure , $idlines);
		$docObj = json_decode($docData, true);

		$doctype = $docObj['doctype'];
		$formtype = $docObj['formtype'];
		$formStructure = json_encode($genericDocument->formStructure($doctype, $formtype, 'read'), JSON_PRETTY_PRINT);
		$docData = $this->_readDocLineWise($docnumber, $formStructure , $idlines);
		$docObj = json_decode($docData, true);


		$docLines = $docObj['lines'];
		unset($docObj['lines']);
		$newDocLines = array();
		foreach ($docLines as $docLine) {
			$currLine                = $docLine;
			array_push($newDocLines, $currLine);
		}
		$docObj['lines'] = $newDocLines;
		return json_encode($docObj);

	}



	function saveDoc($docdata, $formStructure){

		$docobj = json_decode($docdata, true);
		$doctype = $docobj['doctype'];
		$formtype = $docobj['formtype'];

		$genericDocument = new ErpDocumentPRELS();
		$formStructure = json_encode($genericDocument->formStructure($doctype, $formtype, 'create'), JSON_PRETTY_PRINT);		

		if(isset($docobj['docnumber']) && $docobj['docnumber'] != ""){ // update Doc
			$returnJSON = $this->updateDoc($docdata, $formStructure);
			return json_encode($returnJSON);	
		} else {													   // create Doc
			$returnJSON = $this->createDoc($docdata, $formStructure);
			$returnJSON->createdocheader = "yes";
			return json_encode($returnJSON);
		}
	}



	function createDoc($docdata, $formStructure){
		$conn = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$formStructure = json_decode($formStructure, true);
		$tablename = $formStructure['schema']['tablename'];
		$doctype   = $formStructure['header']['doctype'];
		$formtype  = $formStructure['header']['formtype'];
		$doccounter= $formStructure['doccounter'];

		$docobj = json_decode($docdata, true);
		$doclins = $docobj['lines'];
		unset($docobj['lines']);

		foreach ($docobj as $key => $value) {
			$newValue = str_replace("'", "\'", $value);
			$docobj[$key] = $newValue;
		}

		foreach ($doclins as $key => $value) {
			$newValue = str_replace("'", "\'", $value);
			$doclins[$key] = $newValue;
		}

		$docnumber = $this->getNextDocNumber($doccounter);
		$docobj['docnumber'] = $docnumber;
		$newDocLines = array();
		foreach ($doclins as $docLine) {

			$currLine                = $docLine;
			// translate line status
			$currLine['doclinenumber'] = $docnumber . '-' . $currLine['linenumber'];
			// unset some field
			array_push($newDocLines, $currLine);
		}
		$docobj['lines'] = $newDocLines;

		// system entries
		// $docobj['lines'] = $doclins;

		$returnJSON = $this->_createDoc(json_encode($docobj), json_encode($formStructure));

		if($returnJSON->docnumber != ''){
			$sqlArray = array();
			foreach ($newDocLines as $index => $line) {
				$rrnumber = $line['rrnumber'];
				$doclinenumber = $line['doclinenumber'];
				$sql = "UPDATE erp_rrlines SET rrstatus = 3 , powonumber = '$returnJSON->docnumber',powolinenumber='$doclinenumber' WHERE rrnumber='$rrnumber'";
				$sqlArray[] = $sql;
			}	

			foreach ($sqlArray as $index => $sql) {
				$resultUpdate = $conn->query($sql);
			}

		}


		return $returnJSON;

	}


	function _createDoc($docdata, $formStructure){
		date_default_timezone_set("Asia/Dhaka");
		$conn = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$formStructure = json_decode($formStructure, true);
		$tablename = $formStructure['schema']['tablename'];
		$doctype   = $formStructure['header']['doctype'];
		$formtype  = $formStructure['header']['formtype'];
		$doccounter= $formStructure['doccounter'];

		$docobj = json_decode($docdata, true);
		$doclins = $docobj['lines'];
		unset($docobj['lines']);

		$sql_array = array();
		$hcolumnFields = array();
		$hfieldValues = array();
		// process header
		$docnumber = $docobj['docnumber'];
		unset($docobj['docnumber']);
		unset($docobj['docstatus']);
		unset($docobj['entrypersonbadge']);
		unset($docobj['entrypersonname']);
		unset($docobj['doccreationtime']);
		// system entries
		if($docnumber == ''){
			$docnumber = $this->getNextDocNumber($doccounter);
		}
		$hcolumnFields[] = 'docnumber';
		$hfieldValues[]  = $docnumber;

		$hcolumnFields[] = 'entrypersonbadge';
		$hfieldValues[]  = $_SESSION['LoggedBadge'];

		$entrypersonname = "";
		$sqlGetName = "SELECT * from mrd_employee_basicinfo where Badge='".$_SESSION['LoggedBadge']."';";
		$result = $conn->query($sqlGetName);
		while($row = $result->fetch_assoc()){
			$entrypersonname = $row['Name'];
		}
		$hcolumnFields[] = 'entrypersonname';
		$hfieldValues[]  = $entrypersonname;

		$hcolumnFields[] = 'docstatus';
		$hfieldValues[]  = '0';
		$hcolumnFields[] = 'doccreationtime';
		$hfieldValues[]  = date('Y-m-d H:i:s', time());

		foreach ($docobj as $fieldname => $fieldvalue) {
			$hcolumnFields[] = $fieldname;
			$hfieldValues[] = $fieldvalue;
		}

		// process lines
		foreach ($doclins as $index => $line) {

			$columnFields = array();
			$fieldValues = array();
			unset($line['lineentrytime']);
			unset($line['linestatus']);
			unset($line['idlines']);
			foreach ($line as $fieldname => $fieldvalue) {
				$columnFields[] = $fieldname;
				$fieldValues[] = $fieldvalue;
			}
			// push header data in line
			foreach ($hcolumnFields as $index => $fieldname) {
				$columnFields[] = $fieldname;
				$fieldValues[]  = $hfieldValues[$index];		
			}		

			$columnFields = implode(", ", $columnFields);
			$fieldValues  = "'" . implode("','", $fieldValues) . "'";

			$sql = "INSERT INTO $tablename ($columnFields) VALUES($fieldValues)";
			$sql_array[] = $sql;

		}

		// Execute Query
		foreach ($sql_array as $key => $sql) {
			$result = $conn->query($sql);	  
			if(!$result){
				array_push($returnJSON->errormsgs, "Error, $sql");
				return $returnJSON;
			}
		}
      	$conn->close();

		if ($result) {
			$returnJSON->docnumber = $docnumber;
		} else {
			array_push($returnJSON->errormsgs, "Error, please tell ERP department: commit failed.");
		}
		return $returnJSON;

	}

	function updateDoc($docdata, $formStructure){
		$conn = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$formStructure = json_decode($formStructure, true);
		$tablename = $formStructure['schema']['tablename'];		

		$newdocobj = json_decode($docdata, true);
		$docnumber = $newdocobj['docnumber'];
		
		$doclins = $newdocobj['lines']; // format: lines = array(0 => array, 1 => array, ....)
		unset($newdocobj['lines']);

		foreach ($newdocobj as $key => $value) {
			$newValue = str_replace("'", "\'", $value);
			$newdocobj[$key] = $newValue;
		}
		
		foreach ($doclins as $key => $value) {
			$newValue = str_replace("'", "\'", $value);
			$doclins[$key] = $newValue;
		}

		$newDocLines = array();
		foreach ($doclins as $docLine) {

			$currLine                = $docLine;
			// translate line status
			$currLine['doclinenumber'] = $docnumber . '-' . $currLine['linenumber'];
			// $currLine['itemcode'] = $docnumber . '-' . $currLine['linenumber'];
			// unset some field
			unset($currLine['linestatus']);
			unset($currLine['lineentrytime']);
			array_push($newDocLines, $currLine);
		}

		$newdocobj['lines'] = $newDocLines;
		// $newdocobj['docstatus'] = $this->docStatusTranslatorB[$newdocobj['docstatus']]; // it should be base class
		$returnJSON = $this->_updateDoc(json_encode($newdocobj), json_encode($formStructure));

		$updatePOInfo = ['itemcode','itemname','itemdescription','unitprice','iduom','extracost','deliverydate','orderqty','sizeormeasurement','brand','costdept','costcenter','amountwithoutdiscount','discountamount','amount','currency','capexno','suppliername','supplieraddress','purchasemode','currency','company'];
		$updateString = "";
		foreach ($updatePOInfo as $key => $value) {
			$updateString .= 'po.'.$value. '= pr.'.$value.', ';
		}

		$updateString = rtrim($updateString, ',');

		if($returnJSON->docnumber != ''){
			$sqlArray = array();
			$prLineArray = array();
			foreach ($newDocLines as $index => $line) {
				$doclinenumber = $line['doclinenumber'];
				$sql = "UPDATE  erp_nonpo po, erp_nonpo pr SET $updateString WHERE po.requisitionlinenumber=pr.doclinenumber AND pr.doclinenumber='$doclinenumber'";
				$sqlArray[] = $sql;
				$prLineArray[] = $doclinenumber;
			}	

			foreach ($sqlArray as $index => $sql) {
				$resultUpdate = $conn->query($sql);
			}

		}

		return $returnJSON;

	}


	function _updateDoc($docdata, $formStructure){
		$conn = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$formStructure = json_decode($formStructure, true);
		$tablename = $formStructure['schema']['tablename'];		

		$newdocobj = json_decode($docdata, true);
		$docnumber = $newdocobj['docnumber'];
		$olddocobj = json_decode($this->_readDoc($docnumber, json_encode($formStructure)), true);

		// $newdocobj['docstatus'] = $this->docStatusTranslatorB[$newdocobj['docstatus']];

		$docLinesArray = $newdocobj['lines']; // format: lines = array(0 => array, 1 => array, ....)
		unset($newdocobj['lines']);
		$docHeaderArray = $newdocobj;

		// Generating query varriables
		// HEADER
		// update SQL for header
		$sql_array = array();
		$updateSet = "";
		foreach ($docHeaderArray as $keyHeader => $valueHeader) {
		if ($keyHeader != 'docnumber') {
			$updateSet .= $keyHeader . "=" . "'" . $valueHeader . "',";
		}
		}

		date_default_timezone_set("Asia/Dhaka");
		$updateSet .= "lastupdateuser =" . "'" . $_SESSION["USERNAME"] . "',"; 

		$lastUpdateTime  = date('Y-m-d H:i:s', time());
		$updateSet .= "lastupdatetime =" . "'" . $lastUpdateTime . "',"; 

		$updateSet = rtrim($updateSet ,',');
		$sqlH = "UPDATE $tablename SET $updateSet WHERE docnumber = '$docnumber'";
		
		// LINES
		// Case 1 - New Lines: idlines will be blank. (user can add new lines in document's update mode.)
		// Case 2 - Existing Lines: idlines will be specified. (user just updated these lines)
		// Case 3 - Removed Lines: line will be missing.

		// Calculate the differences
		foreach ($docLinesArray as $docLine) {
			$lineNumbers_new[] = $docLine['linenumber'];
		}
		$lineNumbers_new = array_unique($lineNumbers_new, SORT_NUMERIC);
		foreach ($olddocobj['lines'] as $docLine) {
			$lineNumbers_old[] = $docLine['linenumber'];
		}
		$lineNumbers_old = array_unique($lineNumbers_old, SORT_NUMERIC);

		$lineNumbers_added   = array_diff($lineNumbers_new, $lineNumbers_old);
		$lineNumbers_same    = array_intersect($lineNumbers_new, $lineNumbers_old);
		$lineNumbers_removed = array_diff($lineNumbers_old, $lineNumbers_new);


		/*
		Iterate through the lines and build an array of SQL queries
		*/
		foreach ($docLinesArray as $lineIndex => $LineArray) {
		// here, value is also an array
		// $idlines_this = $LineArray['idlines'];
		$this_linenumber = $LineArray['linenumber'];
		unset($LineArray['idlines']);

		if (in_array($this_linenumber, $lineNumbers_added)) {
			  // Case 1 - New Line
				$columnFields = array();
				$fieldValues = array();
				unset($LineArray['lineentrytime']);
				foreach ($LineArray as $fieldname => $fieldvalue) {
					$columnFields[] = $fieldname;
					$fieldValues[] = $fieldvalue;
				}
				$columnFields[] = 'docnumber';
				$fieldValues[] = $docnumber;

				$columnFields = implode(", ", $columnFields);
				$fieldValues  = "'" . implode("','", $fieldValues) . "'";
				$sql = "INSERT INTO $tablename ($columnFields) VALUES($fieldValues)";
				$sql_array[] = $sql;

			} else {
			  // Case 2 - Existing Line
				$updateSet = "";
				foreach ($LineArray as $fieldname => $fieldvalue) {
					$updateSet .= $fieldname . "=" . "'" . $fieldvalue . "',";
				}			
				$updateSet = rtrim($updateSet ,',');
				$sql = "UPDATE $tablename SET $updateSet WHERE docnumber = '$docnumber' AND linenumber = '$this_linenumber'";
				$sql_array[] = $sql;
			}
		}

		// Case 3 - Removed Lines
		if (sizeof($lineNumbers_removed) > 0) {
			$lineNumbers_removed = implode(",", $lineNumbers_removed);
			$sql = "DELETE FROM $tablename WHERE docnumber = '$docnumber' AND linenumber IN ($lineNumbers_removed)";
			$sql_array[] = $sql;
		}


		// Execute Query
		$sql_array[] = $sqlH;
		foreach ($sql_array as $key => $sql) {
			$result = $conn->query($sql);	  
			if(!$result){
				array_push($returnJSON->errormsgs, "Error, $sql");
				return $returnJSON;
			}
		}

        $insertlogObj = new InsertLogTableData();
        $insertlogObj->insertDataIntoLogTable_New('docnumber', $docnumber, 'erp_nonpo', 'erp_nonpo_log', 'Update');		
		$conn->close();

		if ($result) {
			$returnJSON->docnumber = $docnumber;
		} else {
			array_push($returnJSON->errormsgs, "Error, please tell ERP department: commit failed.");
		}
		return $returnJSON;

	}



	function changeDocStatus($docnumber, $docstatus){

		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$genericDocument = new ErpDocumentPRELS();
		$formStructure = json_encode($genericDocument->formStructure($formtype, $crudmode), JSON_PRETTY_PRINT);

		$returnJSON = $this->_changeDocStatus($docnumber, $docstatus, $formStructure);

		// $this->updateAllRRLineStatus_sentToTextile($docnumber);

		return $returnJSON;

	}

	function getSupplierName($suppliername){
		$conn = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();


		$sql = "SELECT distinct(suppliername) AS SupplierName FROM `mrd_suppliers` WHERE address is not null AND suppliername is not null AND suppliername like '%$suppliername%' AND itemtype like '%ELS%'";
		$queryResult = $conn->query($sql);

		$arraySupplierName = array();
		while( $row = $queryResult->fetch_assoc() ){
			$arraySupplierName[] = $row['SupplierName'];
		}

	    $conn->close();

	   	return json_encode($arraySupplierName);
	}


	function getSupplierAddress($suppliername){
		$conn = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();


		$sql = "SELECT address, country FROM `mrd_suppliers` WHERE suppliername= '$suppliername'";
		// $queryResult = $conn->query($sql);

		// $row = $queryResult->fetch_assoc();
		// $SupplierAddress =  $row['SupplierAddress'];

	   //  $conn->close();

	   // return json_encode($SupplierAddress);
        return $conn->sqlToJson($sql);
	}



	function _saveLine($line){
		$conn = new ErpDbConn;
		date_default_timezone_set("Asia/Dhaka"); 
		$insertlogObj = new InsertLogTableData();

		$lineObj = json_decode($line, true);

    	$allowedField = array('subcode01', 'subcode04', 'subcode05', 'subcode06');
		foreach ($lineObj as $fieldname => $fieldvalue) {
			if (in_array($fieldname, $allowedField)){
				if (preg_match('/^[a-zA-Z0-9\s,\/\-+#%.\(\)=_]+$/', $fieldvalue)){
				} else{
					$retrnData['isApprove'] = 'No';
					return json_encode($retrnData);
				}
        	}
		}

		$newFullItemCode = $this->itemCodeCreateor($lineObj);

		foreach ($lineObj as $key => $value) {
			$newValue = str_replace("'", "\'", $value);
			$lineObj[$key] = $newValue;
		}
		
		$docnumber = $lineObj['docnumber'];
		$idlines = $lineObj['idlines'];

		$doctype = $lineObj['doctype'];
		$formtype = $lineObj['formtype'];

		$genericDocument = new ErpDocumentPRELS();
		$formStructure = json_encode($genericDocument->formStructure($doctype, $formtype, 'create'), JSON_PRETTY_PRINT);	
		$formStructure = json_decode($formStructure, true);

		$tablename = $formStructure['schema']['tablename'];
		$doccounter= $formStructure['doccounter'];


        if($idlines == ''){
            if(isset($lineObj['linecreationtime'])) $lineObj['linecreationtime'] = date('Y-m-d H:i:s', time());
            if(isset($lineObj['linecreationuser'])) $lineObj['linecreationuser'] = $_SESSION['USERNAME'];
    
        } else{
            if(isset($lineObj['linecreationtime'])) unset($lineObj['linecreationtime']);
            if(isset($lineObj['linecreationuser'])) unset($lineObj['linecreationuser']);  
        }
        if($docnumber != ''){
            if(isset($lineObj['lastupdateuser'])) $lineObj['lastupdateuser'] = $_SESSION['USERNAME'];
            if(isset($lineObj['lastupdatetime'])) $lineObj['lastupdatetime'] = date('Y-m-d H:i:s', time());
        }        
        
		// create doc with this line
		if($docnumber == ""){
			// process lines
			$columnFields = array();
			$fieldValues = array();
			unset($lineObj['linenumber']);
			unset($lineObj['lineentrytime']);
			unset($lineObj['linestatus']);
			unset($lineObj['idlines']);
			// process header
			unset($lineObj['docnumber']);
			unset($lineObj['docstatus']);
			unset($lineObj['entrypersonbadge']);
			unset($lineObj['entrypersonname']);
			unset($lineObj['doccreationtime']);

			$docnumber = $this->getNextDocNumber($doccounter);
			$lineObj['docnumber'] = $docnumber;
			$lineObj['linenumber'] = '1';

			// apply critaria if have
			$lineObj['doclinenumber'] = $docnumber . '-' . $lineObj['linenumber'];
			// $lineObj['itemcode'] = $docnumber . '-' . $lineObj['linenumber'];
			$lineObj['itemcode'] = $newFullItemCode;
			$polinenumber = $lineObj['doclinenumber'];

			if($lineObj['suppliername'] != '' AND $lineObj['unitprice'] != '' AND $lineObj['currency'] != ''){
				$lineObj['linestatus'] = '1';
			}else{
				$lineObj['linestatus'] = '0';
			}
			
			foreach ($lineObj as $fieldname => $fieldvalue) {
				$columnFields[] = $fieldname;
				$fieldValues[] = $fieldvalue;
			}		

			$columnFields[] = 'entrypersonbadge';
			$fieldValues[]  = $_SESSION['LoggedBadge'];


			$entrypersonname = "";
			$sqlGetName = "SELECT * from mrd_employee_basicinfo where Badge='".$_SESSION['LoggedBadge']."';";
			$result = $conn->query($sqlGetName);
			while($row = $result->fetch_assoc()){
				$entrypersonname = $row['Name'];
			}
			$columnFields[] = 'entrypersonname';
			$fieldValues[]  = $entrypersonname;

			$columnFields[] = 'docstatus';
			$fieldValues[]  = '0';
			$columnFields[] = 'doccreationtime';
			$fieldValues[]  = date('Y-m-d H:i:s', time());


			$columnFields = implode(", ", $columnFields);
			$fieldValues  = "'" . implode("','", $fieldValues) . "'";
			$sql = "INSERT INTO $tablename ($columnFields) VALUES($fieldValues)";

			// return $sql;
			$conn->conn->query($sql);
			$idlines = $conn->conn->insert_id;

            $insertlogObj->insertDataIntoLogTable_New('idlines', $idlines, 'erp_nonpo', 'erp_nonpo_log', 'Create');

			$lineData = $this->readDocLineWise($docnumber, $idlines);
			$lineObj = json_decode($lineData, true);
			$lineObj['doccreate'] = 'yes';
			return json_encode($lineObj);

		}

		// insert new line
		if($idlines == ""){

			// process lines
			$columnFields = array();
			$fieldValues = array();
			unset($lineObj['linenumber']);
			unset($lineObj['lineentrytime']);
			unset($lineObj['linestatus']);
			unset($lineObj['idlines']);

			$sql = "SELECT idlines, linenumber FROM $tablename WHERE docnumber = '$docnumber' ORDER BY idlines DESC";
			$queryResult = $conn->query($sql);
			$last_linenumber =  $queryResult->fetch_assoc()['linenumber'];
			$lineObj['linenumber'] = (int)$last_linenumber + 1;

			// apply critaria if have
			$lineObj['doclinenumber'] = $docnumber . '-' . $lineObj['linenumber'];
			// $lineObj['itemcode'] = $docnumber . '-' . $lineObj['linenumber'];
			$lineObj['itemcode'] = $newFullItemCode;
			$polinenumber = $lineObj['doclinenumber'];

			if($lineObj['suppliername'] != '' AND $lineObj['unitprice'] != '' AND $lineObj['currency'] != ''){
				$lineObj['linestatus'] = '1';
			}else{
				$lineObj['linestatus'] = '0';
			}
			
			foreach ($lineObj as $fieldname => $fieldvalue) {
				$columnFields[] = $fieldname;
				$fieldValues[] = $fieldvalue;
			}		


			$columnFields = implode(", ", $columnFields);
			$fieldValues  = "'" . implode("','", $fieldValues) . "'";
			$sql = "INSERT INTO $tablename ($columnFields) VALUES($fieldValues)";

			$conn->conn->query($sql);
			$idlines = $conn->conn->insert_id;

			$insertlogObj->insertDataIntoLogTable_New('idlines', $idlines, 'erp_nonpo', 'erp_nonpo_log', 'Create');
			
			return $this->readDocLineWise($docnumber, $idlines);

		}

		// update line
		if($idlines != ""){
			unset($lineObj['linenumber']);
			unset($lineObj['lineentrytime']);
			unset($lineObj['linestatus']);

			$doclinenumber =  $lineObj['doclinenumber'];
			$lineObj['itemcode'] = $newFullItemCode;

			if($lineObj['suppliername'] != '' AND $lineObj['unitprice'] != '' AND $lineObj['currency'] != ''){
				$lineObj['linestatus'] = '1';
			}else{
				$lineObj['linestatus'] = '0';
			}
			
			date_default_timezone_set("Asia/Dhaka");
			$updateSet = "";
			foreach ($lineObj as $fieldname => $fieldvalue) {
				$updateSet .= $fieldname . "=" . "'" . $fieldvalue . "',";
			}		



			$updateSet .= "lastlineupdateuser =" . "'" . $_SESSION["USERNAME"] . "',"; 
			
			// $updateSet .= "itemcode =" . "'" . $newFullItemCode . "',"; 

			$lastLineUpdateTime  = date('Y-m-d H:i:s', time());
			$updateSet .= "lastlineupdatetime =" . "'" . $lastLineUpdateTime . "',"; 

			$updateSet = rtrim($updateSet ,',');
			$sql = "UPDATE $tablename SET $updateSet WHERE idlines = '$idlines'";

			// return $sql;

			$conn->query($sql);

			$insertlogObj->insertDataIntoLogTable_New('idlines', $idlines, 'erp_nonpo', 'erp_nonpo_log', 'Update');

			return $this->readDocLineWise($docnumber, $idlines);

		}

	}

	function updateTotalAmount($docnumber){
		$conn = new ErpDbConn;

		$sqlTotalAmount = "SELECT SUM(amount) AS totalamount FROM erp_nonpo WHERE docnumber='$docnumber'";
		$queryResult = $conn->query($sqlTotalAmount);

		$row = $queryResult->fetch_assoc();

		$totalamount = $row['totalamount'];

		$f = new NumberToWordConverter;
		$totalamountwords = $f->numberTowords($totalamount);

		$sqlUpdateTotalAmount = "UPDATE erp_nonpo SET totalamount='$totalamount',totalamountwords='$totalamountwords' WHERE docnumber='$docnumber'";
		$queryResult = $conn->query($sqlUpdateTotalAmount);

	}



	function cancelPRLine($idlines){
		$returnJson = new stdClass();
		$conn = new ErpDbConn;
		$insertlogObj = new InsertLogTableData();
		$lastlineupdateuser  = $_SESSION["USERNAME"];
		$lastLineUpdateTime  = date('Y-m-d H:i:s', time());

		$sqlpr = "SELECT polinenumber, doclinenumber FROM erp_nonpo WHERE idlines = '$idlines'";
		$queryResultPR = $conn->query($sqlpr);
		$rowpr = $queryResultPR->fetch_assoc();
		$polinenumber = $rowpr['polinenumber'];
		$prlinenumber = $rowpr['doclinenumber'];

		$sql1 = "SELECT * FROM erp_balance_transaction WHERE polineno = '$polinenumber' AND polineno !='' AND polineno is not null AND templatecode = 'T03' AND tnxquantity > 0";
		$queryResult1 = $conn->query($sql1);
		$queryRowsNum = $queryResult1->num_rows;
		if($queryRowsNum != 0){
			$returnJson->isApprove = 'No';
			return json_encode($returnJson);
		}

		$sqlUpdate = "UPDATE erp_nonpo SET linestatus = '9', lastlineupdateuser = '$lastlineupdateuser', lastlineupdatetime = '$lastLineUpdateTime' WHERE idlines = '$idlines'";
		$queryResult = $conn->query($sqlUpdate);

		$insertlogObj->insertDataIntoLogTable_New('idlines', $idlines, 'erp_nonpo', 'erp_nonpo_log', 'Update');

		//auto update po
		$sqlUpdatePO = "UPDATE erp_nonpo SET linestatus = '9', lastlineupdateuser = '$lastlineupdateuser', lastlineupdatetime = '$lastLineUpdateTime' WHERE doclinenumber = '$polinenumber'";
		$queryUpdatePO = $conn->query($sqlUpdatePO);

		$insertlogObj->insertDataIntoLogTable_New('doclinenumber', $polinenumber, 'erp_nonpo', 'erp_nonpo_log', 'Update');

		if($queryUpdatePO){
			$returnJson->result = 'success';
		} else {
			$returnJson->result = 'fail';
		}
		$conn->close();
		return json_encode($returnJson);
	}


	function uploadFile($formStructure){

		$conn = new ErpDbConn;		
		$returnJSON  = new stdClass();
		$returnJSON->errormsgs = array();

		$fileClientObj = new FileClient();
		$docnumber = $_POST['docnumber'];
		$linenumber = $_POST['linenumber'];
		$directorypath = $_POST['directorypath'];
		$filepathsavingcolumnname = $_POST['filepathsavingcolumnname'];

	    $rootPath = $_SERVER['DOCUMENT_ROOT'];
	    $thisPath = dirname($_SERVER['PHP_SELF']);
	    $onlyPath = str_replace($rootPath, '', $thisPath);
	    // $directoryPath = $rootPath . "/attachments/erp-inquiry/inquiry-requisition/" . $docnumber . "-" . $linenumber;
	    $directoryPath = $rootPath . $directorypath;

		$n = 0;
		$filePaths = array();
		foreach($_FILES as $file){

		    $fileFieldName = "file_" . $n;
			$file = $_FILES[$fileFieldName];
			$fileName = $_FILES[$fileFieldName]['name'];
			$fileNewName = $docnumber . "--" . $linenumber . "_" . $fileName; // if user want to rename file name
			$n++;

			$filePath = $fileClientObj->saveFileInGivenDirectory_SingleFile($directoryPath, $fileFieldName, $file, true, $fileNewName);
			if(!$filePath){
				array_push($returnJSON->errormsgs, $fileName);
				$returnJSON->result = 'fail to upload';
				return json_encode($returnJSON);
			} 
			$filePath = "/attachments" . explode("attachments", $filePath)[1];
			$filePaths[] = $filePath;
		}

		if(count($filePaths) > 1){
			$filePaths = implode("::", $filePaths);
		} else {
			$filePaths = $filePaths[0] . "::";
		}

		$formStructure = json_decode($formStructure, true);
		$tablename = $formStructure['schema']['tablename'];

		// concate file path if exist
		$sql = "SELECT $filepathsavingcolumnname FROM $tablename WHERE docnumber = '$docnumber' AND linenumber = '$linenumber'";
		$queryResult = $conn->query($sql);
		$row = $queryResult->fetch_assoc();
		$filePath = $row[$filepathsavingcolumnname];
		if($filePath != "" && $filePath != null){
			// $filePath = explode("::", $filePath);
			$filePaths = $filePath . $filePaths;
		}

        $sql = "UPDATE $tablename SET $filepathsavingcolumnname = '$filePaths' WHERE docnumber = '$docnumber' AND linenumber = '$linenumber'";
		$queryResult  = $conn->query($sql);

		if($queryResult){
			$returnJSON->result = 'success';
			return json_encode($returnJSON);			
		} else {
			array_push($returnJSON->errormsgs, $sql);
			return json_encode($returnJSON);
		}

	}


	function deletePRLine($idlines){
		$returnJson = new stdClass();
		$conn = new ErpDbConn;
        $insertlogObj = new InsertLogTableData();

        $sql = "SELECT * FROM erp_nonpo WHERE idlines='$idlines'";
		$queryResultPR = $conn->query($sql);
		$rowpr = $queryResultPR->fetch_assoc();
		$polinenumber = $rowpr['polinenumber'];
		if($polinenumber != ''){
			$returnJson->isApprove = 'No';
			return json_encode($returnJson);
		}

        $insertlogObj->insertDataIntoLogTable_New('idlines', $idlines, 'erp_nonpo', 'erp_nonpo_log', 'Delete');

		$sqlDelete = "DELETE FROM erp_nonpo WHERE idlines='$idlines'";
		$queryResult = $conn->query($sqlDelete);

		if($queryResult){
			$returnJson->result = 'success';
		} else {
			$returnJson->result = 'fail';
		}
		$conn->close();
		return json_encode($returnJson);
	}

	function deleteFile($formStructure){

		$conn = new ErpDbConn;		
		$returnJSON  = new stdClass();
		$returnJSON->errormsgs = array();

	    $rootPath = $_SERVER['DOCUMENT_ROOT'];
	    // $directoryPath = $rootPath . "/attachments/erp-inquiry/inquiry-requisition/" . $docnumber . "-" . $linenumber;
	    $filepathcolumnname =  $_POST['filepathcolumnname'];
	    $keycolumnname =  $_POST['keycolumnname'];
	    $keycolumnvalue =  $_POST['keycolumnvalue'];
	    $filePath =  $_POST['filePath'];
	    $searchPath = $filePath;
	    $deletePath = $filePath;

	    $filePath = substr($filePath, 1);
		$filePath = $rootPath . $filePath;

		$fileClientObj = new FileClient();
		$result = $fileClientObj->deleteFile($filePath);

		$formStructure = json_decode($formStructure, true);
		$tablename = $formStructure['schema']['tablename'];

		// concate file path if exist
		$sql = "SELECT $filepathcolumnname FROM $tablename WHERE $keycolumnname = '$keycolumnvalue'";
		$queryResult = $conn->query($sql);
		$row = $queryResult->fetch_assoc();
		$existFilePath = $row[$filepathcolumnname];

		if($existFilePath != "" && $existFilePath != null){

			$allFilePaths = split("::", $existFilePath);
			$deleteFilePath = array($deletePath);

			$keepFilePaths = array_diff($allFilePaths, $deleteFilePath);
			$keepFilePaths = implode("::", $keepFilePaths);

	        $sql = "UPDATE $tablename SET $filepathcolumnname = '$keepFilePaths' WHERE $keycolumnname = '$keycolumnvalue'";
			$queryResult  = $conn->query($sql);

			if($queryResult){
				$returnJSON->result = 'success';
				return json_encode($returnJSON);			
			} else {
				array_push($returnJSON->errormsgs, $sql);
				return json_encode($returnJSON);
			}
		
		} else {

			$returnJSON->result = 'fail';
			return json_encode($returnJSON);		

		}


	}

    function itemCodeCreateor($lineObj){
      	$conn = new ErpDbConn;

	    //Default values
		$formtype          = "ELS";
		$productorfullitem = "Full Item";
		$lotcontrolled     = "1";
		$serialized        = "0";
		$qualitycontrolled = "1";
		$asset             = "0";
		$defaultiduom      = "yd";
		$defaultelementuom = "bx";
		$isactive          = "1";
		
		//Come from Line
		$construction = $lineObj['subcode02'];  	//for Item code serial
		$composition         = $lineObj['subcode03'];   			//for Item code serial
		$color      = $lineObj['subcode04'];   			//for Item code serial
		$shadeno   = $lineObj['subcode05'];		//for Item code serial
		$elasticcode   = $lineObj['subcode06'];		//for Item code serial
		$width   = $lineObj['subcode07'];		//for Item code serial
		$widthuom    = $lineObj['subcode08'];
		$ItemType      = $lineObj['trimscatagory'];
		$Description      = $lineObj['subcode01'];


		//Get Code from library by description
	    $sql = "SELECT Code AS ItemTypeCode FROM mrd_library WHERE LibraryName = 'Elastic_Category' AND Description = '$ItemType'";
	    $queryResult = $conn->query($sql);
	    $ItemTypeCode = $queryResult->fetch_assoc()['ItemTypeCode'];

	    $sql1 = "SELECT Code AS CompositionCode FROM mrd_library WHERE LibraryName = 'Composition' AND Description = '$composition'";
	    $queryResult1 = $conn->query($sql1);
	    $CompositionCode = $queryResult1->fetch_assoc()['CompositionCode'];      

	    $sql2 = "SELECT Code AS ConstructionCode FROM mrd_library WHERE LibraryName = 'Construction' AND Description = '$construction'";
	    $queryResult2 = $conn->query($sql2);
	    $ConstructionCode = $queryResult2->fetch_assoc()['ConstructionCode'];      

	    $sql3 = "SELECT Code AS WidthUOMCode FROM mrd_library WHERE LibraryName = 'UOM' AND Description = '$widthuom'";
	    $queryResult3 = $conn->query($sql3);
	    $WidthUOMCode = $queryResult3->fetch_assoc()['WidthUOMCode'];


	    //get ItemCodeSerial if exists
	    $sql = "SELECT DISTINCT
	                itemcodeserial
	            FROM
	                mrd_item_codes
					WHERE color     = '$color'
					AND diameter    = '$width'
					AND buyer_color = '$shadeno'
					AND buyer_code  = '$elasticcode'
					AND full_specs  = '$Description'
					AND itemcodeserial > '1500'";

	    $queryResult = $conn->query($sql);
	    $itemcodeserial = $queryResult->fetch_assoc()['itemcodeserial'];

	    if($itemcodeserial == ""){
	        $sql = "SELECT max(itemcodeserial) AS itemserial FROM mrd_item_codes WHERE itemcodeserial > '1500'";
	        $queryResult = $conn->query($sql);

	        $maxitemcodeserial = $queryResult->fetch_assoc()['itemserial'];
	        if($maxitemcodeserial == "") $maxitemcodeserial = "1500";
	        $itemcodeserial = $maxitemcodeserial + '1';
	        
	    }


	    //Descriptions for mrd_item_codes Table
	    $itemdescription = $formtype . ", " . $ItemType . ", " . $width . " "  . $WidthUOMCode . ", " . $color . ", " . $Description;

	    $wh_description1 = $ItemType;
	        
	    $wh_description2 = $color . ", " .  $width . " "  . $WidthUOMCode;

	    
	    //Make & Check ItemCode exists or not
	    $itemcode = $formtype . "-" . $ItemTypeCode . "-" . $itemcodeserial;

	    $sql = "SELECT COUNT(*) AS num FROM mrd_item_codes WHERE ItemCode = '$itemcode'";
	    $queryResult = $conn->query($sql);
	    $num = $queryResult->fetch_assoc()['num'];

	    if($num == 0){
	         
	     	$sql1 = "INSERT INTO mrd_item_codes (ItemType, ItemCode, productorfullitem, itemcodeserial, lotcontrolled, serialized, qualitycontrolled, asset, defaultiduom, defaultelementuom, itemdescription, wh_description1, wh_description2, color, diameter,itemcategory, isactive, Composition, Construction, buyer_color, buyer_code, full_specs) VALUES ('$formtype', '$itemcode', '$productorfullitem', '$itemcodeserial', '$lotcontrolled', '$serialized', '$qualitycontrolled', '$asset', '$defaultiduom', '$defaultelementuom', '$itemdescription', '$wh_description1', '$wh_description2', '$color', '$width', '$ItemTypeCode', '$isactive', '$CompositionCode', '$ConstructionCode', '$shadeno', '$elasticcode', '$Description')";   

	        // echo $sql."case-2";
	        $queryResult1 = $conn->query($sql1);
	    }

	    $conn->close();
	    return $itemcode;

    }	
		
	function checkMasterReff($searchParams){
	    $conn = new ErpDbConn;
	  
	    $MasterReference = $searchParams['masterreference'];

	    $sql = "SELECT * FROM erp_nonpo WHERE masterreference='$MasterReference'";
	   	$queryResult = $conn->query($sql);
	    $queryRowsNum = $queryResult->num_rows;

	    $conn->close();
		if($queryRowsNum == 0){
			return 0;
		}else{
			return 1;
		}

	}	

	function checkSupplierName($searchParams){
	    $conn = new ErpDbConn;
	  
	    $suppliername = $searchParams['suppliername'];

	    $sql = "SELECT * FROM mrd_suppliers WHERE suppliername='$suppliername'";
	   	$queryResult = $conn->query($sql);
	    $queryRowsNum = $queryResult->num_rows;

	    $conn->close();
		if($queryRowsNum == 0){
			return 0;
		}else{
			return 1;
		}

	}		

}


/**
 * Routing ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 */
if ( basename(__FILE__) == basename($_SERVER["SCRIPT_FILENAME"]) ) {
    // called directly
	if ( $_SERVER['REQUEST_METHOD'] == 'GET' ) {

		if(isset($_GET['reqType'])){

			$reqType = $_GET['reqType'];
			$obTest  = new ThisDocAPI();

			if($reqType == 'readDoc') {

				$docnumber = $_GET['docnumber'];
				$idlines   = $_GET['idlines'];
				if($idlines != ""){
					$returnData = $obTest->readDocLineWise($docnumber, $idlines);
				} else {
					$returnData = $obTest->readDoc($docnumber);
				}
				echo $returnData;

			}

			if($reqType == '_searchDoc') {
				$genericDocument = new ErpDocumentPRELS();
				$formStructure = json_encode($genericDocument->formStructure('NP', '', ''), JSON_PRETTY_PRINT);

				$where = $_GET['where'];
				$columns = $_GET['columns'];
				$returnData = $obTest->_searchDoc($formStructure, $where, $columns);
				echo $returnData;
			}

			if($reqType == 'searchHeaderInfo') {

				$returnData = $obTest->searchHeaderInfo($_GET);
				echo $returnData;

			}


			if($reqType == 'autoRevisedButtonVisibility') {

				$returnData = $obTest->autoRevisedButtonVisibility($_GET['docnumber']);
				echo $returnData;

			}



			if($reqType == 'getSupplierName') {

				$suppliername = $_GET['suppliername'];
				$returnData = $obTest->getSupplierName($suppliername);
				echo $returnData;

			}

			if($reqType == 'getSupplierAddress') {

				$suppliername = $_GET['suppliername'];
				$returnData = $obTest->getSupplierAddress($suppliername);
				echo $returnData;

			}
			if($reqType == 'checkMasterReff') {

				$returnData = $obTest->checkMasterReff($_GET);
				echo $returnData;

			}
			if($reqType == 'checkSupplierName') {

				$returnData = $obTest->checkSupplierName($_GET);
				echo $returnData;

			}

			if($reqType == 'checkItemCodeAndAutoFill') {

				$itemcode   = $_GET['itemcode'];
				$returnData = $obTest->checkItemCodeAndAutoFill($itemcode);
				echo $returnData;

			}

		}


	} else if( $_SERVER['REQUEST_METHOD'] == 'POST' ){
	
		if(isset($_POST['reqType'])){

			$reqType = $_POST['reqType'];
			$obTest  = new ThisDocAPI();

			if($reqType == "saveDoc"){
		
				$docobj = $_POST['docobj'];
				$returnData = $obTest->saveDoc($docobj);
				echo $returnData;
			}

			if($reqType == "_saveLine"){
		
				$line = $_POST['line'];
				$returnData = $obTest->_saveLine($line);
				echo $returnData;
			}

			if($reqType == "changeDocStatus"){

				$docnumber = $_POST['docnumber'];
				$docstatus = $_POST['docstatus'];
				$returnData = $obTest->changeDocStatus($docnumber, $docstatus);
				echo $returnData;
			}

			if($reqType == "cancelPRLine"){

				$idlines = $_POST['idlines'];
				$returnData = $obTest->cancelPRLine($idlines);
				echo $returnData;
			}		
			
			if($reqType == "uploadFile"){

				$genericDocument = new ErpDocumentPRELS();
				$formStructure = json_encode($genericDocument->formStructure($formtype, $crudmode), JSON_PRETTY_PRINT);				
				$returnData = $obTest->uploadFile($formStructure);
				echo $returnData;
			}

			if($reqType == "deleteFile"){

				$genericDocument = new ErpDocumentPRELS();
				$formStructure = json_encode($genericDocument->formStructure($formtype, $crudmode), JSON_PRETTY_PRINT);				
				$returnData = $obTest->deleteFile($formStructure);
				echo $returnData;
			}

			if($reqType == "deletePRLine"){

				$idlines = $_POST['idlines'];
				$returnData = $obTest->deletePRLine($idlines);
				echo $returnData;
			}


		}



	}

} else {
    // included/required

}
?>