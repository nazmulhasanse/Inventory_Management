<?php
/**
 * require config.php
 * require ErpDbConn.class.php
 *
 * In this DBClient Class do not apply any hardcode, 
 * evry function should be dynamic
 *
 * ****************
 * Author: Al-Mamun
 * ****************
 */
class DbClient
{
	public $conn;
	public $result;
	public $sql;
	public $dbname;

	public function __construct($dbnum = 1) {
		if ($dbnum === '2') {
			$this->conn = new ErpDbConn('2');
			$this->dbname = "erpprod_bulbul";
		} else {
			$this->conn = new ErpDbConn;
			$this->dbname = "erpprod";
		}
	}


	function getSqlToJsonData($sql){
		return $this->conn->sqlToJson($sql);
	}

	function justExecuteQuery($sql){
		$result = $this->conn->query($sql);
		return ($result) ? "success" : "fail";
	}


	function getSqlToData($sql){
		return $this->conn->sqlToJson($sql);
	}

	function getLibraryData($libraryName){

		$sql = "SELECT * FROM mrd_library WHERE LibraryName = '$libraryName'";
		return $this->conn->sqlToJson($sql);

	}

	function getCustomLibrary($sql){
		$queryResult = $this->conn->query($sql);
		$libraryArray = array();
		while ($row = $queryResult->fetch_assoc()) {
			$Code                = $row['code'];
			$libraryArray[$Code] = $row['description'];
		}
		return json_encode($libraryArray, JSON_PRETTY_PRINT);
	}

	function getLibraryDataWBP($libraryName){

		$all_buyer_array = array();
		$query = "SELECT Code FROM `mrd_library` WHERE `LibraryName` LIKE 'SampleStageBuyerName'";
		$result = $this->conn->query($query);	

		while ($row = $result->fetch_assoc()) {
			$all_buyer_array[] = $row["Code"];
		}

		$privilege_buyer_array = array();
		foreach ($all_buyer_array as $each_buyer) { 
			$module = "swo";
			$section = "$each_buyer";
			$privilege = userPrivileges($module,$section);
			if ($privilege['R']) {
				$privilege_buyer_array[] = $each_buyer;
			}
		}
		$buyer = "'" . implode("','", $privilege_buyer_array) . "'";
		$array_count = sizeof($privilege_buyer_array);

		if ($array_count != '0') {
			$buyer = "AND Code IN ($buyer)";
		} else {
			$buyer = "";
		}

		$sql = "SELECT * FROM mrd_library WHERE LibraryName = '$libraryName' $buyer";
		return $this->conn->sqlToJson($sql);

	}

	function getLibraryData_ConsTruction($libraryName){

		$sql = "SELECT * FROM mrd_library WHERE LibraryName IN('construction_wgf', 'construction_kgf')";
		return $this->conn->sqlToJson($sql);

	}


	function readTable($tablename, $whereparam){
		$whereparam = json_decode($whereparam, true);
		$wheres = array();
		foreach ($whereparam as $key => $value) {
			$wheres[] = $key . "= '" .$value . "'";
		}

		$wheres = implode(" AND ", $wheres);
		if($wheres == ""){$wheres = "1=1";}
		$sql = "SELECT * FROM $tablename WHERE $wheres";
		return $this->conn->sqlToJson($sql);
	}

	function getStructure($tableNames){

		$tableNames = "'" . implode("','", $tableNames) . "'";

		$sql = "SELECT * FROM INFORMATION_SCHEMA.COLUMNS
  					WHERE table_name IN ($tableNames)
  					AND table_schema = '$this->dbname'";
  		$qResult = $this->conn->query($sql);	
  		
  		$structure = array();
  		while ($row = $qResult->fetch_assoc()) {

  			$tableName = $row['TABLE_NAME'];
  			$columnName = $row['COLUMN_NAME'];

			$fieldtype = $this->mysqlToHtmlTypeConverter($row['DATA_TYPE']); 
			$structure[$tableName][$columnName]['type'] = $fieldtype;

			$structure[$tableName][$columnName]['sequence']  = $row['ORDINAL_POSITION'];
			$structure[$tableName][$columnName]['default']   = $row['COLUMN_DEFAULT'];

			$structure[$tableName][$columnName]['required']  = ($row['IS_NULLABLE'] == 'NO' && $row['COLUMN_DEFAULT'] == "") ? true : false ;
			$structure[$tableName][$columnName]['dbfield']   = $row['COLUMN_NAME'];

			$commentrules = $this->processCommentColumn($row['COLUMN_COMMENT']);
			$structure[$tableName][$columnName]['fielddesc'] = $commentrules['fielddesc'];
			$structure[$tableName][$columnName]['placeholder'] = $commentrules['placeholder'];
			$structure[$tableName][$columnName]['islibrary'] = $commentrules['islibrary'];
			$structure[$tableName][$columnName]['libraryname'] = $commentrules['libraryname'];
			$structure[$tableName][$columnName]['issystem'] = $commentrules['issystem'];
			$structure[$tableName][$columnName]['systemtype'] = $commentrules['systemtype'];
			$structure[$tableName][$columnName]['isvisible'] = $commentrules['isvisible'];

  		}

  		return json_encode($structure);

	}

	function getStructure_SQL($sql){
	
  		$qResult = $this->conn->query($sql);	
  		
		$structure = array();
		while ($row = $qResult->fetch_assoc()) {

			$key = $row['COLUMN_NAME'];

			$fieldtype = $this->mysqlToHtmlTypeConverter($row['DATA_TYPE']); 
			$structure[$key]['type'] = $fieldtype;

			$structure[$key]['sequence']  = $row['ORDINAL_POSITION'];
			$structure[$key]['default']   = $row['COLUMN_DEFAULT'];
			$structure[$key]['columnkey'] = $row['COLUMN_KEY'];  

			// $structure[$key]['required']  = ($row['IS_NULLABLE'] == 'NO' && $row['COLUMN_DEFAULT'] != NULL) ? true : false ;
			$structure[$key]['required']  = ($row['IS_NULLABLE'] == 'NO' && $row['COLUMN_DEFAULT'] == "") ? true : false ;
			$structure[$key]['dbfield']   = $row['COLUMN_NAME'];

			$commentrules = $this->processCommentColumn($row['COLUMN_COMMENT']);
			$structure[$key]['fielddesc'] = $commentrules['fielddesc'];
			$structure[$key]['placeholder'] = $commentrules['placeholder'];
			$structure[$key]['islibrary'] = $commentrules['islibrary'];
			$structure[$key]['libraryname'] = $commentrules['libraryname'];
			$structure[$key]['issystem'] = $commentrules['issystem'];
			$structure[$key]['systemtype'] = $commentrules['systemtype'];
			$structure[$key]['isvisible'] = $commentrules['isvisible'];

		}

		return json_encode($structure);

	}	
	
	function getDbTablesStructure_SQL2($sql){
	
  		$qResult = $this->conn->query($sql);	
  		
		$structure = array();
		while ($row = $qResult->fetch_assoc()) {

			$key = $row['COLUMN_NAME'];

			$fieldtype = $this->mysqlToHtmlTypeConverter($row['DATA_TYPE']); 
			$structure[$key]['type'] = $fieldtype;

			$structure[$key]['sequence']  = $row['ORDINAL_POSITION'];
			$structure[$key]['default']   = $row['COLUMN_DEFAULT'];
			$structure[$key]['columnkey'] = $row['COLUMN_KEY'];  

			// $structure[$key]['required']  = ($row['IS_NULLABLE'] == 'NO' && $row['COLUMN_DEFAULT'] != NULL) ? true : false ;
			$structure[$key]['required']  = ($row['IS_NULLABLE'] == 'NO' && $row['COLUMN_DEFAULT'] == "") ? true : false ;
			$structure[$key]['dbfield']   = $row['COLUMN_NAME'];

			$commentrules = $this->processCommentColumn($row['COLUMN_COMMENT']);
			$structure[$key]['fielddesc'] = $commentrules['fielddesc'];
			$structure[$key]['placeholder'] = $commentrules['placeholder'];
			$structure[$key]['islibrary'] = $commentrules['islibrary'];
			$structure[$key]['libraryname'] = $commentrules['libraryname'];
			$structure[$key]['issystem'] = $commentrules['issystem'];
			$structure[$key]['systemtype'] = $commentrules['systemtype'];
			$structure[$key]['isvisible'] = $commentrules['isvisible'];

		}

		return json_encode($structure);

	}	


	function mysqlToHtmlTypeConverter($mysqltype){

		if($mysqltype == "varchar") return "text";
		if($mysqltype == "int") return "number";
		if($mysqltype == "text") return "textarea";
		if($mysqltype == "date") return "date";
		if($mysqltype == "datetime") return "date";

	}

	function processCommentColumn($comment){

		$comment = json_decode($comment, true);

		$commentrules = array();
		$commentrules['fielddesc'] = $comment['fielddesc'];
		$commentrules['placeholder'] = (isset($comment['placeholder'])) ? $comment['placeholder'] : "";
		$commentrules['islibrary'] = (isset($comment['library'])) ? true : false;
		$commentrules['libraryname'] = $comment['library'];
		$commentrules['issystem'] = (isset($comment['system'])) ? true : false;
		$commentrules['systemtype'] = $comment['system'];
		$commentrules['isvisible'] = (isset($comment['isvisible']) && $comment['isvisible'] == false) ? false : true;

		return $commentrules; 
	}

	/**
	 * [formVarification description]
	 * Form varification
	 */
	function formVarification($postData, $formStructure, $dbTableStruceture){

		$data = json_decode($postData, true);
		$test = $data['lines'][0];
		$fieldnames = array_keys($test);

		$formStructure = json_decode($formStructure, true);
		$dbTableStruceture = json_decode($dbTableStruceture, true);
		$dbTableStruceture = array_keys($dbTableStruceture);
		
		error_log("==========================================================M ". json_encode($formStructure));
		error_log("==========================================================M ". json_encode($fieldnames));
		// field name varification
		foreach ($fieldnames as $index => $fieldname) {
			if(!in_array($fieldname, $formStructure)){
				return false;
			}
			if(!in_array($fieldname, $dbTableStruceture)){
				return false;
			}
		}

		// pass each field with formstructure and dbfieldstructure [with user or system entry value] 
		$isvalid = $this->fieldvalueVarification($postData, $formStructure, $dbTableStruceture);
		if(!$isvalid){
			return false;
		}

		return true;

	}

	function fieldvalueVarification($postData, $formStructure, $dbTableStruceture){
		// $formStructure = json_decode($formStructure, true);
		// $dbTableStruceture = json_decode($dbTableStruceture, true);
		// $dbTableStruceture = array_keys($dbTableStruceture);
		return true;
	}





	//--------- VS2 ------------------------------------------------------------------------------------------------------------------------------------------------


	function processFieldBehaviourVS2($fieldBehaviour){

		$fieldBehaviourRules = array();
		$fieldBehaviourRules['islibrary'] =  false;
		$fieldBehaviourRules['issystem'] =  false;
		$fieldBehaviourRules['isdetect'] =  false;

		if($fieldBehaviour == "library"){
			$fieldBehaviourRules['islibrary'] =  true;
		} else if($fieldBehaviour == "system"){
			$fieldBehaviourRules['issystem'] =  true;
		} else if($fieldBehaviour == "detect"){
			$fieldBehaviourRules['isdetect'] =  true;
		}

		return $fieldBehaviourRules; 

	}

	/**
	 * [formVarification description]
	 * Form varification
	 */
	function formVarificationVS2($postData, $formFields, $formStruceture){

		$data = json_decode($postData, true);
		$test = $data['lines'][0];
		$fieldnames = array_keys($test);

		$formFields = json_decode($formFields, true);
		$formStruceture = json_decode($formStruceture, true);
		$formStruceture = array_keys($formStruceture);
		
		// field name varification
		foreach ($fieldnames as $index => $fieldname) {
			if(!in_array($fieldname, $formFields)){
				return false;
			}
		}

		// pass each field with formFields and dbfieldstructure [with user or system entry value] 
		$isvalid = $this->fieldvalueVarificationVS2($postData, $formStruceture);
		if(!$isvalid){
			return false;
		}

		return true;

	}	

	function fieldvalueVarificationVS2($postData, $formStruceture){
		// $formStructure = json_decode($formStructure, true);
		// $dbTableStruceture = json_decode($dbTableStruceture, true);
		// $dbTableStruceture = array_keys($dbTableStruceture);
		return true;
	}

}
?>