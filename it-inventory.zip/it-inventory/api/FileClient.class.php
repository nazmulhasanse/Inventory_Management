<?php
/**
* FileClient Class
* This class will handle file uploading and deleting
* Do not write any hardcode in this class, everything should be dynamic
*
******************************
** Author: Al-Mamun         **
** Module Name: includes    **
** Crated date:             **
******************************
*/
class FileClient
{	
	/**
	 * Variable declaration
	 */
	public $test;
	
	/**
	 * Method definition
	 */
	function __construct() {
	}

	function deleteFile($filePath){
		unlink($filePath);
		return $filePath;
	}

	function createDirectory($directoryPath){
		$createTargetDirectory = mkdir($directoryPath, 0777, true) or die();
		return $directoryPath;
	}

	function fileValidationCheck_SingleFile($fileFieldName){

		$isValid = true;
		$allowed = array("jpg", "png","PNG","JPG", "xlsx", "pdf", "xls", "");
		return $isValid;

	}

	function fileValidationCheck_MultipleFile($fileFieldName){

		$isValid = false;

		$allowed = array("jpg", "png","PNG","JPG", "xlsx", "pdf", "xls", "");
		if ($_FILES[$fileFieldName]) {

		    $files = $_FILES[$fileFieldName];
		    $cnt=0;
		    foreach($files['size'] as $eachSize) {
		        if($eachSize > 0) $cnt++;
		    }
		    if ($cnt > 0) {
		    	$isValid = true;
		    }

		}
		if($isValid){		
		    $max_size = 10*1024*1024; // 10 MB
		    foreach ($files['name'] as $index => $file_name) {
		        $file_size = $files["size"][$index];
		        $file_error = $files["error"][$index];

		        $file_extension = strtolower(end(explode(".", $file_name)));
		        if (!in_array($file_extension, $allowed)) {
		            die ($file_extension . "file extension is not allowed!");
		        }
		        if ($file_size > $max_size) {
		            die ($file_name . " is larger than 10MB");
		        }
		        if ($file_error !== 0) {
		            die ($file_name . "error with code " . $file_error);
		        }
		    }
		}

		return $isValid;

	}


	function uploadAttachment_SingleFile_WithFileNewName($targetDirectory, $file, $fileNewName){
		$returnFilePaths = "";

		// $file is array, it contains some informatio
		// 1. name
		// 2. size
		// 3...
		// So single file is also array
	    if(is_array($file) && !is_array($file['name'])){
	    	$file_name = $file['name'];
	        $file_extension_array = explode(".", $file_name);
	        $file_extension = strtolower(end($file_extension_array));
	    	$uploaded_directory   = $targetDirectory ."/";
	        if(isset($fileNewName) && $fileNewName != ""){
	        	$file_name_new = $fileNewName;
	        } else {
	        	 $file_name_new = $file_extension_array[0] ."_." . $file_extension;
	        }
	        $file_destination = $uploaded_directory . $file_name_new; 

	        if(!move_uploaded_file($file['tmp_name'], $file_destination)){
	        	 die ($file_name . " fail to upload");
	        }
	        $returnFilePath = $file_destination;
	        return $returnFilePath;
	    }

	    return $returnFilePaths;
	}


	function uploadAttachment_SingleFile_WithDefaultName($targetDirectory, $files){
		$returnFilePaths = "";

		// $file is array, it contains some informatio
		// 1. name
		// 2. size
		// 3...
		// So single file is also array		
	    if(is_array($files) && !is_array($files['name'])){
	    	$file_name = $files['name'];
	        $file_extension_array = explode(".", $file_name);
	        $file_extension = strtolower(end($file_extension_array));
	    	$uploaded_directory   = $targetDirectory ."/";
	        $file_name_new = $file_extension_array[0] ."_." . $file_extension;
	        $file_destination = $uploaded_directory . $file_name_new; 

	        if(!move_uploaded_file($files['tmp_name'], $file_destination)){
	        	 die ($file_name . " fail to upload");
	        }
	        $returnFilePath = $file_destination;
	        return $returnFilePath;
	    }

	    return $returnFilePaths;
	}


	function saveFileInGivenDirectory_SingleFile($directoryPath, $fileFieldName, $file, $isApplyNewName, $fileNewName){

		$uploadedFilesPaths = "";
		if (!file_exists($directoryPath)) {
			$this->createDirectory($directoryPath);
		}

		$isValidFile = $this->fileValidationCheck_SingleFile($fileFieldName);
		if($isValidFile){
			if($isApplyNewName){
				$uploadedFilesPaths = $this->uploadAttachment_SingleFile_WithFileNewName($directoryPath, $file, $fileNewName);
			} else {
				$uploadedFilesPaths = $this->uploadAttachment_SingleFile_WithDefaultName($directoryPath, $file);
			}
			return $uploadedFilesPaths;
		}

		return false;

	}

	function readFiles($dir, $directory){
		// file size will give by bytes
		$noFiles = 0;
		$allFiles = array();
		if (is_dir($dir)) {
			//open dir
			if ($opendir = opendir($dir)) {
				//read dir
				while (($file = readdir($opendir)) !== false) {//read dir
					if ($file != "." && $file !="..") {
						if ($noFiles == 100) {
							break;
						}
						$file_en = urlencode($file);
						$fileName = $file;
						$filePath = $dir. "/" . $file;
						$filePath2 = $directory. "/" . $file;
						$fileSize = filesize("$dir/$file");
						// $fileLink = "<a target='_blank' href='$dir/$file'>";
						$noFiles ++;

						$fileInfo = array(
							'fileName' => $fileName,
							'filePath' => $filePath,
							'filePath2' => $filePath2,
							'fileSize' => $fileSize,
							// 'fileLink' => $fileLink,
							);
						array_push($allFiles, $fileInfo);
					}
				}
				closedir($opendir);
			}
		}


		if( count($allFiles) > 0 ){
			$allFiles = json_encode($allFiles);
		} else {
			$allFiles = "";
		}
		return $allFiles;

	}

	/**
	 * This function will copy all file in a given directory 
	 * @param  [type] $src [description]
	 * @param  [type] $dst [description]
	 * @return [type]      [description]
	 */
	function copyAllFile($src,$dst){
		$dir = $src;
		if (!file_exists($dst)) {
			$this->createDirectory($dst);
		}
		$noFiles = 0;
		if (is_dir($dir)) {
			//open dir
			if ($opendir = opendir($dir)) {
				//read dir
				while (($file = readdir($opendir)) !== false) {//read dir
					if ($file != "." && $file !="..") {
						if ($noFiles == 100) {
							break;
						}
						$file_en = urlencode($file);
						copy($src . '/' . $file, $dst . '/' . $file); 
						$noFiles ++;
					}
				}
				closedir($opendir);
			}
		}

	}


	/**
	 * This function will copy specific file in a given directory 
	 * @param  [type] $src           [description]
	 * @param  [type] $dst           [description]
	 * @param  [type] $selectedfiles [description]
	 * @return [type]                [description]
	 */
	function copyFile($src,$dst, $selectedfiles){
		$dir = $src;
		// check first src is exist or not?
		if(is_dir($dir)){
		} else {
			return false;
		}

		if (!file_exists($dst)) {
			$this->createDirectory($dst);
		}
		$noFiles = 0;
		if (is_dir($dir)) {
			//open dir
			if ($opendir = opendir($dir)) {
				//read dir
				while (($file = readdir($opendir)) !== false) {//read dir
					if ($file != "." && $file !="..") {
						if ($noFiles == 100) {
							break;
						}

						if(in_array($file, $selectedfiles)){
							$file_en = urlencode($file);
							copy($src . '/' . $file, $dst . '/' . $file); 
							$noFiles ++;
						}
					}
				}
				closedir($opendir);
			}
		}

	}


}
?>