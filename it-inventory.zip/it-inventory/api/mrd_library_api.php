<?php
session_start();
$directory = __DIR__ ;
$directory = substr($directory, 0, -4);
require_once $directory . "/classes/config.php";
require_once $directory . "/classes/myclassautoloader.php";

if (basename(__FILE__) == basename($_SERVER["SCRIPT_FILENAME"])) {
  // called directly
  if ($_SERVER['REQUEST_METHOD'] == 'GET') {

    if (isset($_GET['library']) && isset($_GET['code'])) {
      
      $pdmObj = new Pdm();
      echo $pdmObj->getLibraryDescription($_GET['library'], $_GET['code']);

    } else if (isset($_GET['library'])) {

      $pdmObj = new Pdm();
      echo $pdmObj->getLibrary($_GET);

    } else {

      die("Library not specified!");
    }

  } else if( $_SERVER['REQUEST_METHOD'] == 'POST' ){

  }

} else {
  // included/required
}
?>