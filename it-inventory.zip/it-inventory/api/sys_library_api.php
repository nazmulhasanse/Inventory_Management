<?php
/**
* System library api
 * require config.php
 * require ErpDbConn.class.php
 * This Api is for object oriented code
 *
 * ****************
 * Author: Al-Mamun
 * Date: 2017-08-15
 * **************** 
*/
session_start();
$directory = __DIR__ ;
$directory = substr($directory, 0, -4);
require_once $_SERVER["DOCUMENT_ROOT"] . '/includes/configli.php';         // mysqli connections
require_once $directory . "/classes/myclassautoloader.php";
require_once __DIR__. '/SysLibrary.class.php';


if (basename(__FILE__) == basename($_SERVER["SCRIPT_FILENAME"])) {
  // called directly
  if ($_SERVER['REQUEST_METHOD'] == 'GET') {

    if(isset($_GET['library']) && isset($_GET['code'])) {
      
      $sysLibObj = new SysLibrary();
      echo $sysLibObj->getLibraryDescription($_GET['library'], $_GET['code']);

    } else if (isset($_GET['library'])) {

      $sysLibObj = new SysLibrary();
      echo $sysLibObj->getLibrary($_GET);

    } else {

      die("Library not specified!");
    }

  } else if( $_SERVER['REQUEST_METHOD'] == 'POST' ){

  }



} else {

  // included/required
  
}
?>