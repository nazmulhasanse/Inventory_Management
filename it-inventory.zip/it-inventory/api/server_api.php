<?php
session_start();
require_once $_SERVER["DOCUMENT_ROOT"] . "/includes/config.php";
require_once $_SERVER["DOCUMENT_ROOT"] . "/classes/ErpDbConn.class.php";
require_once $_SERVER["DOCUMENT_ROOT"] . "/classes/ErpString.class.php";
require_once "DbClient.class.php";
require_once "FileClient.class.php";


/**
 * API Routing ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 */
if ( basename(__FILE__) == basename($_SERVER["SCRIPT_FILENAME"]) ) {
    // called directly
	if ( $_SERVER['REQUEST_METHOD'] == 'GET' ) {

		if(isset($_GET['reqType'])){

			$reqType = $_GET['reqType'];
			$dbClient = new DbClient;

			if($reqType == 'getAppLanguage'){
				$lng = isset($_SESSION['LNG']) ? $_SESSION['LNG'] : 'en';
				$lngObj = new ErpString($lng, 'AppS');
				$lngJson = $lngObj->getAppString();
				echo json_encode($lngJson);
			}

			if($reqType == 'getLibraryData'){

				$libraryName = $_GET['libraryname'];
				$libraryData = $dbClient->getLibraryData($libraryName);
				echo $libraryData;
			}
			
			if($reqType == 'getSqlToJsonData'){

				$sql = $_GET['sql'];
				$jsonData = $dbClient->getSqlToJsonData($sql);
				echo $jsonData;
			}

			if($reqType == 'getCustomLibrary'){

				$sql = $_GET['sql'];
				$jsonData = $dbClient->getCustomLibrary($sql);
				echo $jsonData;
			}


			if($reqType == 'getLibraryData_ConsTruction'){

				$libraryName = $_GET['libraryname'];
				$libraryData = $dbClient->getLibraryData_ConsTruction($libraryName);
				echo $libraryData;
			}
			

			if($reqType == 'read'){

				$tablename = $_GET['tablename'];
				$whereparam = (isset($_GET['whereparam'])) ? $_GET['whereparam'] : '' ;
				$returnData = $dbClient->readTable($tablename, $whereparam);
				echo $returnData;
			}

			if($reqType == 'getStructure'){

				$tableNames  = $_GET['tablenames'];
				$dbnum  = $_GET['dbnum'];
				$dbClient = new DbClient($dbnum);
				$structure = $dbClient->getStructure($tableNames);
				echo $structure;

			}

			if($reqType == 'getStructure_SQL'){

				$sql  = $_GET['sql'];
				$structure = $dbClient->getStructure_SQL($sql);
				echo $structure;

			}

			
			if($reqType == 'getDbTablesStructure_SQL2'){

				$sql  = $_GET['sql'];
				$structure = $dbClient->getDbTablesStructure_SQL2($sql);
				echo $structure;

			}
			
			if($reqType == 'getFormStructure'){

				$formtype  = $_GET['formtype'];
				$crudmode  = $_GET['crudmode'];
				$dbClient = new DbClient();
				$formStructure = $dbClient->getFormStructure($formtype, $crudmode);
				echo $formStructure;

			}

			if($reqType == 'idfloorsection'){

				$dbClient = new DbClient();
				$returnData = $dbClient->getIdFloorSection();
				echo $returnData;

			}			

			if($reqType == 'getSqlToData'){

				$sql = $_GET['sql'];
				$returnData = $dbClient->getSqlToData($sql);
				echo $returnData;
			}

			if($reqType == 'readFiles'){

				$fileClient = new FileClient();
				$directory = $_GET['directory'];
				$dir = "../.." . $directory;
				$returnData = $fileClient->readFiles($dir, $directory);
				echo $returnData;
			}

		}


	} else if( $_SERVER['REQUEST_METHOD'] == 'POST' ){
	
		if(isset($_POST['reqType'])){

			$reqType = $_POST['reqType'];
			$dbClient  = new DbClient();

			if($reqType == "testPost"){
				$postData = $_POST['postdata'];
				$returnData = $dbClient->testPost($postData);
				echo $returnData;
			}

			if($reqType == "justExecuteQuery"){
				$postData = $_POST['data'];
				$queryResult = $dbClient->justExecuteQuery($postData);
				echo $queryResult;
			}


		}

	}

} else {
    // included/required
}
?>