<script type="text/javascript">
var xFileNewName = "";
var xPWONumber = "";
var xStrikeOffOrderID = "";


function initializePost(){

	// $("#formstrikeoff_createmode").on('submit',(function(e) {
	$("#formstrikeoff_createmode").unbind().bind('submit',(function(e) {
		e.preventDefault();

        var r = deleteLastEmptyLine();
		$.ajax({
			url: "sample-strikeoff_api.php",// Url to which the request is send
			type: "POST",             		// Type of request to be send, called as method
			data: new FormData(this), 		// Data sent to server, a set of key/value pairs (i.e. form fields and values)
			contentType: false,       		// The content type used when sending data to the server.
			cache: false,             		// To unable request pages to be cached
			processData:false,        		// To send DOMDocument or non processed data file it is set to false
			success: function(data)   		// A function to be called if request succeeds
			{
				viewStrikeoffOrder(data);
				console.log(data);
			}
		});

	}));

}



function initializePost_DesignSoftcopy(parentWorkOrder){

    var uploadDirectory = ( parentWorkOrder.indexOf('t') > -1 ) ? "attachments/strikeoff_files/"+parentWorkOrder : "attachments/sample_files/images/"+parentWorkOrder;

    $("#formUploadDesignSoftcopy").unbind().bind('submit',(function(e) {
        // alert("kk");
        e.preventDefault();

        // alert("test"+parentWorkOrder);

        var formData = new FormData(this);
        formData.append('reqType', 'uploadDesignSoftcopy');
        formData.append('directory', uploadDirectory);       

        $.ajax({
            url: "printingdept_api.php",
            type: "POST",                   
            data: formData,         
            contentType: false,             
            cache: false,                   
            processData:false,              
            success: function(data)         
            {   
                // alert(data);
                parent.$.fancybox.close();
                if(jsClientReturnMsgTypeDetector(data) == "success"){
                    getDesignerTodoListData();
                }
            }
        });

    }));

}



function deleteLastEmptyLine(){
    // var r = $('table#linestable_createmode tr:last input[name=designnumber]').val();
    var isEmptyLastLine = true
    $('#linestable_createmode tr:last input').each(function(){
        if($(this).val() != ""){
            isEmptyLastLine = false;
        }
    });
    if(isEmptyLastLine){
        $('#linestable_createmode tr:last-child').remove();
        return true;
    }
    return false;
}

function deleteLastEmptyLine_AddMoreMode(){
    var isEmptyLastLine = true
    $('#linestable_addmoremode tr:last input').each(function(){
        if($(this).val() != ""){
            isEmptyLastLine = false;
        }
    });
    if(isEmptyLastLine){
        $('#linestable_addmoremode tr:last-child').remove();
        return true;
    }
    return false;
}


function readFile(directory, container){

	$(container).empty();
	var attachmentImages = "";
						// var dir = "given directory";
	var fileextension = [".png", ".jpg", ".pdf", ".xlsx"];
	$.ajax({
	    				//This will retrieve the contents of the folder if the folder is configured as 'browsable'
		async: false,
		url  : directory,
	    success: function (data) {
	        			//Lsit all png file names in the page
	        $(data).find("a:contains(" + (fileextension[0]) + "), a:contains(" + (fileextension[1]) + "), a:contains(" + (fileextension[2]) + "), a:contains(" + (fileextension[3]) + ")").each(function () {
	        	var dt = new Date();
	            var filename = $(this).attr("href");
                // filename = filename.replace('%20', ' ');
                filename=filename.replace(/%20/gi,' ');
	            var ext = filename.substr(filename.lastIndexOf('.') + 1);
	            var btnDelete = "<input type='button' value='delete' onclick='deleteFile(\""+ directory +"\"   " +','+ " \""+ filename +"\" " +','+ " \""+ container +"\" )'/></div>";
	            if(ext == "pdf"){
	            	attachmentImages = "<div class='file'><a class='fancybox' target='_blank' href='"+directory+"/"+filename+"'><div class='caption_wrapper'><img class='border' src='css/previewPDF.png' height='150px' width='180px'></img><div class='caption_description'><p class='caption_description_content'>"+ filename +"</p></div></div></a>" + btnDelete;
	            } else if(ext == "xlsx"){
	            	attachmentImages = "<div class='file'><a class='fancybox' target='_blank' href='"+directory+"/"+filename+"'><div class='caption_wrapper'><img class='border' src='css/previewXLSX.png' height='150px' width='180px'></img><div class='caption_description'><p class='caption_description_content'>"+ filename +"</p></div></div></a>" + btnDelete;
	            } else {
	            	attachmentImages = "<div class='file'><a class='fancybox' target='_blank' href='"+directory+"/"+filename+"'><div class='caption_wrapper'><img class='border' src='" + directory +"/" + filename + "?mpic="+ dt +"' height='150px' width='180px'></img><div class='caption_description'><p class='caption_description_content'>"+ filename +"</p></div></div></a>" + btnDelete;
	            }
	            		// $("body").append($("<img src=" + dir +"/" + filename + "></img>"));
	            $(container).append(attachmentImages);

            });
	    }, 
	    error: function(){
	    	attachmentImages = "";
	    }
	});	

}


function readFileAsReport(directory, container){

    $(container).empty();
    var attachmentImages = "";
                        // var dir = "given directory";
    var fileextension = [".png", ".jpg", ".pdf", ".xlsx"];
    $.ajax({
                        //This will retrieve the contents of the folder if the folder is configured as 'browsable'
        async: false,
        url  : directory,
        success: function (data) {
                        //Lsit all png file names in the page
            $(data).find("a:contains(" + (fileextension[0]) + "), a:contains(" + (fileextension[1]) + "), a:contains(" + (fileextension[2]) + "), a:contains(" + (fileextension[3]) + ")").each(function () {
                var dt = new Date();
                var filename = $(this).attr("href");
                var ext = filename.substr(filename.lastIndexOf('.') + 1);
                if(ext == "pdf"){
                    attachmentImages = "<div class='file'><a class='fancybox' target='_blank' href='"+directory+"/"+filename+"'><div class='caption_wrapper'><img class='border' src='css/previewPDF.png' height='150px' width='180px'></img><div class='caption_description'><p class='caption_description_content'>"+ filename +"</p></div></div></a>";
                } else if(ext == "xlsx"){
                    attachmentImages = "<div class='file'><a class='fancybox' target='_blank' href='"+directory+"/"+filename+"'><div class='caption_wrapper'><img class='border' src='css/previewXLSX.png' height='150px' width='180px'></img><div class='caption_description'><p class='caption_description_content'>"+ filename +"</p></div></div></a>";
                } else {
                    attachmentImages = "<div class='file'><a class='fancybox' target='_blank' href='"+directory+"/"+filename+"'><div class='caption_wrapper'><img class='border' src='" + directory +"/" + filename + "?mpic="+ dt +"' height='150px' width='180px'></img><div class='caption_description'><p class='caption_description_content'>"+ filename +"</p></div></div></a>";
                }
                        // $("body").append($("<img src=" + dir +"/" + filename + "></img>"));
                $(container).append(attachmentImages);

            });
        }, 
        error: function(){
            attachmentImages = "";
        }
    }); 

}



function deleteFile(directory, filename, feedBackContainer){

    $.ajax({
        type: 'POST',
        data: {
            reqType: 'deletefile',
            directory: directory,
            filename: filename,
        },
        url: 'sample-strikeoff_api.php',
        success: function(msg) {
            console.log("------>"+msg)
            readFile( directory, feedBackContainer );
        },
        error: function(){
        	alert("error");
        }
    })
	
}

function deleteFile_givenPath(filePath){

    alert(filePath);
    $.ajax({
        type: 'POST',
        data: {
            reqType: 'deleteFile_givenPath',
            filePath: filePath,
        },
        url: 'sample-strikeoff_api.php',
        success: function(msg) {
            console.log("------>"+msg)
        },
        error: function(){
            alert("error");
        }
    }) 

}

function deleteLinesFile(filePath, strikeofforderid, pwonumber){

    $.ajax({
        type: 'POST',
        data: {
            reqType: 'deleteLinesFile',
            pwonumber: pwonumber,
            filePath: filePath,
        },
        url: 'sample-strikeoff_api.php',
        success: function(msg) {
            viewStrikeoffOrder(strikeofforderid);
            console.log("------>"+msg)
        },
        error: function(){
            alert("error");
        }
    }) 

}

function deleteLinesFile_Sample(filePath, SampleWorkOrderID, pwonumber){

    $.ajax({
        type: 'POST',
        data: {
            reqType: 'deleteLinesFile',
            pwonumber: pwonumber,
            filePath: filePath,
        },
        url: 'sample-strikeoff_api.php',
        success: function(msg) {
            viewPWOLines(SampleWorkOrderID, "#PWOsContainer_ViewMode");
            // viewStrikeoffOrder(strikeofforderid);
            console.log("------>"+msg)
        },
        error: function(){
            alert("error");
        }
    }) 

}



// var formData = new FormData();
// for (var key in data) {
//   formData.append(key, data[key]);
// }


$(document).ready(function (e) {

    $('#moreFileUploadForm').on('submit',(function(e) {

    	var uploadDirectory = "attachments/strikeoff_files/"+gStONumber;

        e.preventDefault();
        var formData = new FormData(this);
        formData.append('reqType', 'uploadMoreFile_MER');
        formData.append('data', uploadDirectory);

        $.ajax({
            type:'POST',
            url: $(this).attr('action'),
            data:formData,
            cache:false,
            contentType: false,
            processData: false,
            success:function(data){
                console.log("success");
                console.log(data);
                readFile(uploadDirectory, "#fileAppendDiv" )
                
            },
            error: function(data){
                console.log("error");
                console.log(data);
            }
        });

    }));

    $("#moreFileUploadForm #ImageBrowse").on("change", function() {
        $("#moreFileUploadForm").submit();
    });







    $('#moreFileUploadForm_sample').on('submit',(function(e) {

        var uploadDirectory = "attachments/sample_files/images/"+gSWONumber;

        e.preventDefault();
        var formData = new FormData(this);
        formData.append('reqType', 'uploadMoreFile_MER');
        formData.append('data', uploadDirectory);

        $.ajax({
            type:'POST',
            url: $(this).attr('action'),
            data:formData,
            cache:false,
            contentType: false,
            processData: false,
            success:function(data){
                console.log("success");
                console.log(data);
                readFile(uploadDirectory, "#fileAppendDiv" )
                
            },
            error: function(data){
                console.log("error");
                console.log(data);
            }
        });

    }));

    $("#moreFileUploadForm_sample #ImageBrowse").on("change", function() {
        $("#moreFileUploadForm_sample").submit();
    });


});



function submitFormAuto_uploadLineFile(file, strikeofforderid, strikeofforder, pwonumber, designnumber){

    xFileNewName = designnumber + pwonumber + strikeofforder ;
    xPWONumber = pwonumber;
    xStrikeOffOrderID = strikeofforderid;
    console.log(strikeofforderid + "-----" +strikeofforder+ "-----"+pwonumber+ "-----"+designnumber);
    

    $('.formlinefileuplod').submit(function(e){
        
            e.preventDefault();

            var uploadDirectory = "attachments/strikeoff_files/"+gStONumber;

            var formData = new FormData(this);
            formData.append('reqType', 'uploadLineFile');
            formData.append('data', uploadDirectory);
            formData.append('fileNewName', xFileNewName);
            formData.append('pwonumber', xPWONumber);

            $.ajax({
                type:'POST',
                url: $(this).attr('action'),
                data:formData,
                cache:false,
                contentType: false,
                processData: false,
                success:function(data){
                    viewStrikeoffOrder(xStrikeOffOrderID);
                    console.log(data);                    
                },
                error: function(data){
                    console.log("error");
                    console.log(data);
                }
            });


        return false;
    });


    $(".formlinefileuplod").submit();

}




function submitFormAuto_uploadLineFile_Sample(file, SampleWorkOrderID, SampleWorkOrder, StyleNumber, pwonumber, designnumber){

    xFileNewName = designnumber + pwonumber + StyleNumber + SampleWorkOrder ;
    xPWONumber = pwonumber;
    xStrikeOffOrderID = SampleWorkOrderID;
    

    $('.formlinefileuplod').submit(function(e){
        
            e.preventDefault();
            var uploadDirectory = "attachments/sample_files/images/"+SampleWorkOrder;

            var formData = new FormData(this);
            formData.append('reqType', 'uploadLineFile');
            formData.append('data', uploadDirectory);
            formData.append('fileNewName', xFileNewName);
            formData.append('pwonumber', xPWONumber);

            $.ajax({
                type:'POST',
                url: $(this).attr('action'),
                data:formData,
                cache:false,
                contentType: false,
                processData: false,
                success:function(data){
                    // alert(data);
                    viewPWOLines(SampleWorkOrderID, "#PWOsContainer_ViewMode");
                    readFile( uploadDirectory, "#fileAppendDiv" );
                    console.log(data);                    
                },
                error: function(data){
                    console.log("error");
                    console.log(data);
                }
            });


        return false;
    });


    $(".formlinefileuplod").submit();

}












// method 1---------------------------------------------------------------------------------------------------------------------------------------
$(".formS .ttt").on("change", function(event) {

    var form = $(this).parent();
    var data = form.serialize();
    // alert(data);
    form.submit();

    // var $target = $( event.target );
    // $target.closest("form").submit();

});

$('.formS').on('submit',(function(e) {
    e.preventDefault();
    var formObj = $( this ).serializeArray();
    var formData = $( this ).serialize();
    alert(formData);

    var formData = new FormData(this);
    formData.append('reqType', 'uploadMoreFile_MER');
    formData.append('data', 'uploadDirectory');
    console.log(formData);

    // $.ajax({
    //     type:'POST',
    //     url: $(this).attr('action'),
    //     data:formData,
    //     cache:false,
    //     contentType: false,
    //     processData: false,
    //     success:function(data){
    //         console.log("success");
    //         console.log(data);
    //         readFile(uploadDirectory, "#fileAppendDiv" )
            
    //     },
    //     error: function(data){
    //         console.log("error");
    //         console.log(data);
    //     }
    // });

}));
//----------------------------------------------------------------------------------------------------------------------------------------------------------------





// Metod 2--------------------------------------------------------------------------------------------------------------------
https://abandon.ie/notebook/simple-file-uploads-using-jquery-ajax
// Variable to store your files
var files;

// Add events
$('input[type=file]').on('change', prepareUpload);

// Grab the files and set them to our variable
function prepareUpload(event)
{
  files = event.target.files;
}



$('form').on('submit', uploadFiles);

// Catch the form submit and upload the files
function uploadFiles(event)
{
  event.stopPropagation(); // Stop stuff happening
    event.preventDefault(); // Totally stop stuff happening

    // START A LOADING SPINNER HERE

    // Create a formdata object and add the files
    var data = new FormData();
    $.each(files, function(key, value)
    {
        data.append(key, value);
    });

    $.ajax({
        url: 'submit.php?files',
        type: 'POST',
        data: data,
        cache: false,
        dataType: 'json',
        processData: false, // Don't process the files
        contentType: false, // Set content type to false as jQuery will tell the server its a query string request
        success: function(data, textStatus, jqXHR)
        {
            if(typeof data.error === 'undefined')
            {
                // Success so call function to process the form
                submitForm(event, data);
            }
            else
            {
                // Handle errors here
                console.log('ERRORS: ' + data.error);
            }
        },
        error: function(jqXHR, textStatus, errorThrown)
        {
            // Handle errors here
            console.log('ERRORS: ' + textStatus);
            // STOP LOADING SPINNER
        }
    });
}



// You need to add server side validation and better error handling here

$data = array();

if(isset($_GET['files']))
{  
    $error = false;
    $files = array();

    $uploaddir = './uploads/';
    foreach($_FILES as $file)
    {
        if(move_uploaded_file($file['tmp_name'], $uploaddir .basename($file['name'])))
        {
            $files[] = $uploaddir .$file['name'];
        }
        else
        {
            $error = true;
        }
    }
    $data = ($error) ? array('error' => 'There was an error uploading your files') : array('files' => $files);
}
else
{
    $data = array('success' => 'Form was submitted', 'formData' => $_POST);
}

echo json_encode($data);
//-----------------------------------------------------------------------------------------------------------------------------------


// Method 3 --------------------------------------------------------------------------------------------------------------------------
http://saravanan.tomrain.com/jquery-ajax-file-upload/

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Jquery Ajax File Upload</title>
</head>
<body>
    <input type="file" name="image" id="image">
    <div class="result"></div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script>
    $(document).ready(function(){
        $('#image').change(function(e){
            var file = this.files[0];
            var form = new FormData();
            form.append('image', file);
            $.ajax({
                url : "upload.php",
                type: "POST",
                cache: false,
                contentType: false,
                processData: false,
                data : form,
                success: function(response){
                    $('.result').html(response.html)
                }
            });
        });
    });
    </script>
</body>
</html>


<?php

$file = $_FILES['image'];


/* Allowed file extension */
$allowedExtensions = ["gif", "jpeg", "jpg", "png", "svg"];

$fileExtension = explode(".", $file["name"]);

/* Contains file extension */
$extension = end($fileExtension);

/* Allowed Image types */
$types = ['image/gif', 'image/png', 'image/x-png', 'image/pjpeg', 'image/jpg', 'image/jpeg','image/svg+xml'];

if(in_array(strtolower($file['type']), $types) 
    // Checking for valid image type
    && in_array(strtolower($extension), $allowedExtensions) 
    // Checking for valid file extension
    && !$file["error"] > 0)
    // Checking for errors if any
    { 
    if(move_uploaded_file($file["tmp_name"], 'images/'.$file['name'])){
        header('Content-Type: application/json');
        echo json_encode(['html' => 'File Upload successfull.']);    
    }else{
        header('Content-Type: application/json');
        echo json_encode(['html' => 'Unable to move image. Is folder writable?']);    
    }
}else{    
    header('Content-Type: application/json');
    echo json_encode(['html' => 'Please upload only png, jpg images']);
}

?>


</script>