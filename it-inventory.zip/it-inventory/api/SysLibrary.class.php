<?php
/**
* PDM Class
 * require config.php
 * require ErpDbConn.class.php
 *
 * ****************
 * Author: Al-Mamun
 * Date: 2017-01-13
 * **************** 
*/
class SysLibrary
{
	public $conn;
	public $result;
	public $sql;
	public $dbname;	
	
	public function __construct($dbnum = 1) {
		if ($dbnum === '2') {
			$this->conn = new ErpDbConn('2');
			$this->dbname = "erpprod_bulbul";
		} else {
			$this->conn = new ErpDbConn;
			$this->dbname = "erpprod";
		}
	}

	/**
	 * [getLibraryDescription description]
	 * @param  [type] $library [Library Name]
	 * @param  [type] $code    [Code]
	 * @return [JSON]          [Return json data]
	 */
	public function getLibraryDescription($library, $code){
		$query = "SELECT * FROM erp_sys_dropdown_options WHERE libraryname = '$library' AND code = '$code'";
		return $this->conn->sqlToJson($query);
	}

	public function getLibraryCode($library, $description){
		$query = "SELECT * FROM erp_sys_dropdown_options WHERE libraryname = '$library' AND description = '$description'";
		return $this->conn->sqlToJson($query);
	}


	public function getLibrary($params) {
	  	// for compatiblity with old code, accept strings
	  	if (is_string($params)) {
	    	$library = $params;
	  	} else {
	    	$library = $params['library'];
	  	}

	 	if ($library == 'stocktype') {
	  		$whereclauses = "";
	  		if(isset($params['stocktypename'])){
	  			$stocktypename = $params['stocktypename'];
	  			$whereclauses = " WHERE stocktype = '$stocktypename'";
	  		}
	    	$sql = "SELECT idstocktype as Code, stocktype as Description FROM erpprod.erp_mrd_stocktype $whereclauses";

	  	} else {
	    	$sql = "SELECT Code, Description FROM erp_sys_dropdown_options WHERE libraryname = '$library' ORDER BY Description";
	  	}

	  	$result = $this->conn->query($sql);
	  	$libraryArray = array();
	  	while ($row = $result->fetch_assoc()) {
	    	$Code                = $row['Code'];
	    	$libraryArray[$Code] = $row['Description'];
	  	}
	  	$this->conn->close();
	  	return json_encode($libraryArray, JSON_PRETTY_PRINT);
	}


}
?>