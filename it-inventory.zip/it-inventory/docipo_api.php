<?php
session_start();
$directory = __DIR__ ;
// require_once __DIR__ . "/classes/config.php";
require_once $_SERVER["DOCUMENT_ROOT"] . '/includes/configli.php'; // mysql connections
require_once __DIR__ . "/classes/myclassautoloader.php";
require_once __DIR__ . "/api/FileClient.class.php";
/**
* ThisDocAPI class
*/
class ThisDocAPI extends BaseDocAPI
{

	function __construct(){
	}



	function readDoc($docnumber){

		$genericDocument = new ErpDocumentIPO();
		$formStructure = json_encode($genericDocument->formStructure('IPO', 'IPO', 'read'), JSON_PRETTY_PRINT);

		$docnumber = $_GET['docnumber'];
		$apiObj = new ThisDocAPI();
		$docData = $apiObj->_readDoc($docnumber, $formStructure);
		$docObj = json_decode($docData, true);

		// again read doc with doctype and formtype
		$doctype = $docObj['doctype'];
		$formtype = $docObj['formtype'];
		$formStructure = json_encode($genericDocument->formStructure($doctype, $formtype, 'read'), JSON_PRETTY_PRINT);
		$docData = $apiObj->_readDoc($docnumber, $formStructure);
		$docObj = json_decode($docData, true);

		// $docObj['docstatus'] = $apiObj->docStatusTranslatorF[$docObj['docstatus']];

		$docLines = $docObj['lines'];
		unset($docObj['lines']);
		$newDocLines = array();
		foreach ($docLines as $docLine) {
			$currLine                = $docLine;
			// $currLine['linestatus'] = $this->lineStatusTranslatorF[$docLine['linestatus']];
			array_push($newDocLines, $currLine);
		}
		$docObj['lines'] = $newDocLines;

		return json_encode($docObj);

	}

	function readDocLineWise($docnumber, $idlines){

		$genericDocument = new ErpDocumentIPO();
		$formStructure = json_encode($genericDocument->formStructure('IPO', 'IPO', 'read'), JSON_PRETTY_PRINT);

		// $docnumber = $_GET['docnumber'];
		$docData = $this->_readDocLineWise($docnumber, $formStructure , $idlines);
		$docObj = json_decode($docData, true);

		$doctype = $docObj['doctype'];
		$formtype = $docObj['formtype'];
		$formStructure = json_encode($genericDocument->formStructure($doctype, $formtype, 'read'), JSON_PRETTY_PRINT);
		$docData = $this->_readDocLineWise($docnumber, $formStructure , $idlines);
		$docObj = json_decode($docData, true);


		$docLines = $docObj['lines'];
		unset($docObj['lines']);
		$newDocLines = array();
		foreach ($docLines as $docLine) {
			$currLine                = $docLine;
			array_push($newDocLines, $currLine);
		}
		$docObj['lines'] = $newDocLines;
		return json_encode($docObj);

	}



	function saveDoc($docdata, $formStructure){

		$docobj = json_decode($docdata, true);
		$doctype = $docobj['doctype'];
		$formtype = $docobj['formtype'];

		$genericDocument = new ErpDocumentIPO();
		$formStructure = json_encode($genericDocument->formStructure($doctype, $formtype, 'create'), JSON_PRETTY_PRINT);		

		if(isset($docobj['docnumber']) && $docobj['docnumber'] != ""){ // update Doc
			$returnJSON = $this->updateDoc($docdata, $formStructure);
			return json_encode($returnJSON);	
		} else {													   // create Doc
			$returnJSON = $this->createDoc($docdata, $formStructure);
			$returnJSON->createdocheader = "yes";
			return json_encode($returnJSON);
		}
	}



	function createDoc($docdata, $formStructure){
		$conn = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$formStructure = json_decode($formStructure, true);
		$tablename = $formStructure['schema']['tablename'];
		$doctype   = $formStructure['header']['doctype'];
		$formtype  = $formStructure['header']['formtype'];
		$doccounter= $formStructure['doccounter'];

		$docobj = json_decode($docdata, true);
		$doclins = $docobj['lines'];
		unset($docobj['lines']);

		foreach ($docobj as $key => $value) {
			$newValue = str_replace("'", "\'", $value);
			$docobj[$key] = $newValue;
		}

		foreach ($doclins as $key => $value) {
			$newValue = str_replace("'", "\'", $value);
			$doclins[$key] = $newValue;
		}

		$docnumber = $this->getNextDocNumber($doccounter);
		$docobj['docnumber'] = $docnumber;
		$newDocLines = array();
		foreach ($doclins as $docLine) {

			$currLine                = $docLine;
			// translate line status
			$currLine['doclinenumber'] = $docnumber . '-' . $currLine['linenumber'];
			// unset some field
			array_push($newDocLines, $currLine);
		}
		$docobj['lines'] = $newDocLines;

		// system entries
		// $docobj['lines'] = $doclins;

		$returnJSON = $this->_createDoc(json_encode($docobj), json_encode($formStructure));

		// if($returnJSON->docnumber != ''){
		// 	$sqlArray = array();
		// 	foreach ($newDocLines as $index => $line) {
		// 		$rrnumber = $line['rrnumber'];
		// 		$doclinenumber = $line['doclinenumber'];
		// 		$sql = "UPDATE erp_rrlines SET rrstatus = 3 , powonumber = '$returnJSON->docnumber',powolinenumber='$doclinenumber' WHERE rrnumber='$rrnumber'";
		// 		$sqlArray[] = $sql;
		// 	}	

		// 	foreach ($sqlArray as $index => $sql) {
		// 		$resultUpdate = $conn->query($sql);
		// 	}

		// }

		


		return $returnJSON;

	}


	function _createDoc($docdata, $formStructure){
		date_default_timezone_set("Asia/Dhaka");
		$conn = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$formStructure = json_decode($formStructure, true);
		$tablename = $formStructure['schema']['tablename'];
		$doctype   = $formStructure['header']['doctype'];
		$formtype  = $formStructure['header']['formtype'];
		$doccounter= $formStructure['doccounter'];

		$docobj = json_decode($docdata, true);
		$doclins = $docobj['lines'];
		unset($docobj['lines']);

		$sql_array = array();
		$hcolumnFields = array();
		$hfieldValues = array();
		// process header
		$docnumber = $docobj['docnumber'];
		unset($docobj['docnumber']);
		unset($docobj['docstatus']);
		unset($docobj['entrypersonbadge']);
		unset($docobj['entrypersonname']);
		unset($docobj['doccreationtime']);
		// system entries
		if($docnumber == ''){
			$docnumber = $this->getNextDocNumber($doccounter);
		}
		$hcolumnFields[] = 'docnumber';
		$hfieldValues[]  = $docnumber;

		$hcolumnFields[] = 'entrypersonbadge';
		$hfieldValues[]  = $_SESSION['LoggedBadge'];

		$entrypersonname = "";
		$sqlGetName = "SELECT * from mrd_employee_basicinfo where Badge='".$_SESSION['LoggedBadge']."';";
		$result = $conn->query($sqlGetName);
		while($row = $result->fetch_assoc()){
			$entrypersonname = $row['Name'];
		}
		$hcolumnFields[] = 'entrypersonname';
		$hfieldValues[]  = $entrypersonname;

		$hcolumnFields[] = 'docstatus';
		$hfieldValues[]  = '0';
		$hcolumnFields[] = 'doccreationtime';
		$hfieldValues[]  = date('Y-m-d H:i:s', time());

		foreach ($docobj as $fieldname => $fieldvalue) {
			$hcolumnFields[] = $fieldname;
			$hfieldValues[] = $fieldvalue;
		}

		// process lines
		foreach ($doclins as $index => $line) {

			$columnFields = array();
			$fieldValues = array();
			unset($line['lineentrytime']);
			unset($line['linestatus']);
			unset($line['idlines']);
			foreach ($line as $fieldname => $fieldvalue) {
				$columnFields[] = $fieldname;
				$fieldValues[] = $fieldvalue;
			}
			// push header data in line
			foreach ($hcolumnFields as $index => $fieldname) {
				$columnFields[] = $fieldname;
				$fieldValues[]  = $hfieldValues[$index];		
			}		

			$columnFields = implode(", ", $columnFields);
			$fieldValues  = "'" . implode("','", $fieldValues) . "'";

			$sql = "INSERT INTO $tablename ($columnFields) VALUES($fieldValues)";
			$sql_array[] = $sql;
			

		}

		// Execute Query
		foreach ($sql_array as $key => $sql) {
			$result = $conn->query($sql);	  
			if(!$result){
				array_push($returnJSON->errormsgs, "Error, $sql");
				return $returnJSON;
			}
		}
      	$conn->close();

		if ($result) {
			$returnJSON->docnumber = $docnumber;
		} else {
			array_push($returnJSON->errormsgs, "Error, please tell ERP department: commit failed.");
		}
		return $returnJSON;

	}

	function updateDoc($docdata, $formStructure){
		$conn = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$formStructure = json_decode($formStructure, true);
		$tablename = $formStructure['schema']['tablename'];		

		$newdocobj = json_decode($docdata, true);
		$docnumber = $newdocobj['docnumber'];
		
		$doclins = $newdocobj['lines']; // format: lines = array(0 => array, 1 => array, ....)
		unset($newdocobj['lines']);

		foreach ($newdocobj as $key => $value) {
			$newValue = str_replace("'", "\'", $value);
			$newdocobj[$key] = $newValue;
		}
		
		foreach ($doclins as $key => $value) {
			$newValue = str_replace("'", "\'", $value);
			$doclins[$key] = $newValue;
		}

		$newDocLines = array();
		foreach ($doclins as $docLine) {

			$currLine                = $docLine;
			// translate line status
			$currLine['doclinenumber'] = $docnumber . '-' . $currLine['linenumber'];
			// $currLine['itemcode'] = $docnumber . '-' . $currLine['linenumber'];
			// unset some field
			unset($currLine['linestatus']);
			unset($currLine['lineentrytime']);
			array_push($newDocLines, $currLine);
		}

		$newdocobj['lines'] = $newDocLines;
		// $newdocobj['docstatus'] = $this->docStatusTranslatorB[$newdocobj['docstatus']]; // it should be base class
		$returnJSON = $this->_updateDoc(json_encode($newdocobj), json_encode($formStructure));

		// $updatePOInfo = ['itemcode','itemname','itemdescription','unitprice','iduom','extracost','deliverydate','orderqty','sizeormeasurement','brand','costdept','costcenter','amountwithoutdiscount','discountamount','amount','currency','capexno','suppliername','supplieraddress','purchasemode','currency','company'];
		// $updateString = "";
		// foreach ($updatePOInfo as $key => $value) {
		// 	$updateString .= 'po.'.$value. '= pr.'.$value.', ';
		// }

		// $updateString = rtrim($updateString, ',');

		// if($returnJSON->docnumber != ''){
		// 	$sqlArray = array();
		// 	$prLineArray = array();
		// 	foreach ($newDocLines as $index => $line) {
		// 		$doclinenumber = $line['doclinenumber'];
		// 		$sql = "UPDATE  erp_nonpo po, erp_nonpo pr SET $updateString WHERE po.requisitionlinenumber=pr.doclinenumber AND pr.doclinenumber='$doclinenumber'";
		// 		$sqlArray[] = $sql;
		// 		$prLineArray[] = $doclinenumber;
		// 	}	

		// 	foreach ($sqlArray as $index => $sql) {
		// 		$resultUpdate = $conn->query($sql);
		// 	}

		// }

		return $returnJSON;

	}


	function _updateDoc($docdata, $formStructure){
		$conn = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$formStructure = json_decode($formStructure, true);
		$tablename = $formStructure['schema']['tablename'];		

		$newdocobj = json_decode($docdata, true);
		$docnumber = $newdocobj['docnumber'];
		$olddocobj = json_decode($this->_readDoc($docnumber, json_encode($formStructure)), true);

		// $newdocobj['docstatus'] = $this->docStatusTranslatorB[$newdocobj['docstatus']];

		$docLinesArray = $newdocobj['lines']; // format: lines = array(0 => array, 1 => array, ....)
		unset($newdocobj['lines']);
		$docHeaderArray = $newdocobj;

		// Generating query varriables
		// HEADER
		// update SQL for header
		$sql_array = array();
		$updateSet = "";
		foreach ($docHeaderArray as $keyHeader => $valueHeader) {
			if ($keyHeader != 'docnumber') {
				$updateSet .= $keyHeader . "=" . "'" . $valueHeader . "',";
			}
		}

		date_default_timezone_set("Asia/Dhaka");
		$updateSet .= "lastupdateuser =" . "'" . $_SESSION["USERNAME"] . "',"; 

		$lastUpdateTime  = date('Y-m-d H:i:s', time());
		$updateSet .= "lastupdatetime =" . "'" . $lastUpdateTime . "',"; 

		$updateSet = rtrim($updateSet ,',');
		$sqlH = "UPDATE $tablename SET $updateSet WHERE docnumber = '$docnumber'";
		
		// LINES
		// Case 1 - New Lines: idlines will be blank. (user can add new lines in document's update mode.)
		// Case 2 - Existing Lines: idlines will be specified. (user just updated these lines)
		// Case 3 - Removed Lines: line will be missing.

		// Calculate the differences
		foreach ($docLinesArray as $docLine) {
			$lineNumbers_new[] = $docLine['linenumber'];
		}
		$lineNumbers_new = array_unique($lineNumbers_new, SORT_NUMERIC);
		foreach ($olddocobj['lines'] as $docLine) {
			$lineNumbers_old[] = $docLine['linenumber'];
		}
		$lineNumbers_old = array_unique($lineNumbers_old, SORT_NUMERIC);

		$lineNumbers_added   = array_diff($lineNumbers_new, $lineNumbers_old);
		$lineNumbers_same    = array_intersect($lineNumbers_new, $lineNumbers_old);
		$lineNumbers_removed = array_diff($lineNumbers_old, $lineNumbers_new);


		/*
		Iterate through the lines and build an array of SQL queries
		*/
		

		foreach ($docLinesArray as $lineIndex => $LineArray) {
			// here, value is also an array
			// $idlines_this = $LineArray['idlines'];
			$this_linenumber = $LineArray['linenumber'];
			$idlines = $LineArray['idlines'];
			unset($LineArray['idlines']);
			

			if (in_array($this_linenumber, $lineNumbers_added)) {
				  // Case 1 - New Line
				$columnFields = array();
				$fieldValues = array();
				unset($LineArray['lineentrytime']);
				foreach ($LineArray as $fieldname => $fieldvalue) {
					$columnFields[] = $fieldname;
					$fieldValues[] = $fieldvalue;
				}
				$columnFields[] = 'docnumber';
				$fieldValues[] = $docnumber;

				$columnFields = implode(", ", $columnFields);
				$fieldValues  = "'" . implode("','", $fieldValues) . "'";
				$sql = "INSERT INTO $tablename ($columnFields) VALUES ($fieldValues)";
				$sql_array[] = $sql;


				

			} else {
			  	// Case 2 - Existing Line
				$insertlogObj = new InsertLogTableData();
			    $insertlogObj->insertDataIntoLogTable('idlines', $idlines, 'int_purchase_order', 'int_purchase_order_log', 'Update');
				

				$updateSet = "";
				foreach ($LineArray as $fieldname => $fieldvalue) {
					$updateSet .= $fieldname . "=" . "'" . $fieldvalue . "',";
				}			
				$updateSet = rtrim($updateSet ,',');
				$sql = "UPDATE $tablename SET $updateSet WHERE docnumber = '$docnumber' AND linenumber = '$this_linenumber'";
				$sql_array[] = $sql;

				
			}
		}

		// Case 3 - Removed Lines
		if (sizeof($lineNumbers_removed) > 0) {
			$lineNumbers_removed = implode(",", $lineNumbers_removed);

			$sql = "DELETE FROM $tablename WHERE docnumber = '$docnumber' AND linenumber IN ($lineNumbers_removed)";
			$sql_array[] = $sql;
		}


		// Execute Query
		$sql_array[] = $sqlH;
		foreach ($sql_array as $key => $sql) {
			$result = $conn->query($sql);	  
			if(!$result){
				array_push($returnJSON->errormsgs, "Error, $sql");
				return $returnJSON;
			}
		}
		

		$conn->close();

		if ($result) {
			$returnJSON->docnumber = $docnumber;
		} else {
			array_push($returnJSON->errormsgs, "Error, please tell ERP department: commit failed.");
		}
		return $returnJSON;

	}

	function insertDataIntoLogTable($idlines){

		$conn                  = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		date_default_timezone_set("Asia/Dhaka");

		$tablename     = 'int_purchase_order';
		$logtablename  = 'int_purchase_order_log';
		$operationtype = 'Update';

		$sql = "SELECT * FROM $tablename WHERE idlines = '$idlines'";
		$allinfo = json_decode( $this->conn->sqlToJson($sql), true);

        foreach ($allinfo as $index => $info) {
            $columnFields = array();
            $fieldValues = array();

            unset($info['IDLINES']);    
            unset($info['idlines']);    

            $info['OPERATIONTYPE'] = $operationtype;
            $info['OPERATIONUSER'] = $_SESSION['USERNAME'];
            $info['OPERATIONTIME'] = date('Y-m-d H:i:s', time());              

            foreach ($info as $fieldname => $fieldvalue) {
                $columnFields[] = $fieldname;
                $fieldValues[] = $fieldvalue;
            }

    		$columnFields = implode(", ", $columnFields);
    		$fieldValues  = "'" . implode("','", $fieldValues) . "'";

    		// echo <pre>;
    		// print_r($fieldValues);
    		// exit();
    		
    		$sql = "INSERT INTO $logtablename ($columnFields) VALUES($fieldValues)";

    		$queryResult = $this->conn->query($sql);

            if(!$queryResult){
              die("fail query" . $sql); exit();
              return false;
            }
        } 
        return $returnJSON;
	}



	function changeDocStatus($docnumber, $docstatus){

		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$genericDocument = new ErpDocumentIPO();
		$formStructure = json_encode($genericDocument->formStructure($formtype, $crudmode), JSON_PRETTY_PRINT);

		$returnJSON = $this->_changeDocStatus($docnumber, $docstatus, $formStructure);

		$this->updateInfoByDocStatus($docnumber, $docstatus);

		return $returnJSON;

	}

	function poAmendment($docnumber, $docstatus){
		$conn     = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$sqlUpdate = "UPDATE erp_purchaseorder SET docstatus = '$docstatus' , amendstatus = (amendstatus+1) WHERE docnumber='$docnumber';";
		$result = $conn->query($sqlUpdate);

		if($result){
			$returnJSON->result = "success";
		}else{
			$returnJSON->result = "error ".$sqlUpdate;
		}

		return json_encode($returnJSON);

	}

	function updateInfoByDocStatus($docnumber, $docstatus){
		$conn = new ErpDbConn;

		$realtimeUser = $_SESSION["USERNAME"]; //current user of system
		date_default_timezone_set("Asia/Dhaka"); //setting the timezone of BD
		$nowdate_time = date('Y-m-d H:i:s', time()); //current date time of system

		if($docstatus == '1'){
			$sql = "UPDATE erp_requisition SET usersectionheadsign = '$realtimeUser', sectionsigndatetime = '$nowdate_time' WHERE docnumber = '$docnumber'";
			$queryResult = $conn->query($sql);
		}else if($docstatus == '2'){
			$sql = "UPDATE erp_requisition SET userdepartmentheadsign = '$realtimeUser', departmentsigndatetime = '$nowdate_time' WHERE docnumber = '$docnumber'";
			$queryResult = $conn->query($sql);
		}else if($docstatus == '3'){
			$sql = "UPDATE erp_requisition SET approvalofcoosign = '$realtimeUser', coosigndatetime = '$nowdate_time' WHERE docnumber = '$docnumber'";
			$queryResult = $conn->query($sql);
		}else if($docstatus == '4'){
			$sql = "UPDATE erp_requisition SET approvalofceo = '$realtimeUser', ceosigndatetime = '$nowdate_time' WHERE docnumber = '$docnumber'";
			$queryResult = $conn->query($sql);
		}

		$conn->close();
	}

	// function updateAllRRLineStatus_sentToTextile($docnumber){
	// 	$conn = new ErpDbConn;

	// 	$sql = "SELECT rrnumber FROM erp_purchaseorder WHERE docnumber = '$docnumber'";

	// 	echo "string...... KLM" . $sql;
	// 	$queryResult = $conn->query($sql);

	// 	while ($row = $queryResult->fetch_assoc()) {
	// 		$rrnumber = $row['rrnumber'];
	// 		$sql = "UPDATE erp_rrlines SET rrstatus = '4' WHERE rrnumber = '$rrnumber'";
	// 		echo "string...... XXFD" . $sql;
	// 		$conn->query($sql);
	// 	}

	// 	$conn->close();
	// }


	function updateRevisedPO($podocnumber){
		$conn = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$sqlUpd = "UPDATE erp_purchaseorder SET docstatus='0', amendmenttimes=(amendmenttimes+1), amendstatus = (amendstatus+1) WHERE docnumber='$podocnumber'";
		$queryUpdResult = $conn->query($sqlUpd);

		$sql = "SELECT rrnumber,tnxqty FROM erp_purchaseorder WHERE docnumber='$podocnumber' AND ispoautoupdateflag='1'";
		$queryResult = $conn->query($sql);

		$getSOsql = "SELECT distinct(salesorder) AS salesorder FROM erp_purchaseorder WHERE docnumber='$podocnumber' AND ispoautoupdateflag='1'";
		$queryResultSOsql = $conn->query($getSOsql);

		while ($row = $queryResult->fetch_assoc()) {
			$rrnumber = $row['rrnumber'];
			$previousqty = $row['tnxqty'];
			$sqlUpdPO = "SELECT * FROM erp_rrlines WHERE rrnumber='$rrnumber'";
			$resultRRRow = $conn->query($sqlUpdPO);
			$queryRowsNum = $resultRRRow->num_rows;

			if($queryRowsNum != 0){
				$rrrows = $resultRRRow->fetch_assoc();


				$pofield = array();
				$pofield['itemcode']               = $rrrows['itemcode'];
				$pofield['itemtype']               = $rrrows['itemtype'];
				$pofield['itemdescription']        = $rrrows['itemdescription'];
				$pofield['pricerequisitionnumber'] = $rrrows['pricerequisitionnumber'];
				$pofield['unitprice']              = $rrrows['unitprice'];
				$pofield['iduom']                  = $rrrows['iduom'];
				$pofield['fabricinhousedate']      = $rrrows['fabricinhousedate'];
				$pofield['rrnumber']               = $rrrows['rrnumber'];
				$pofield['parentrrnumber']         = $rrrows['parentrrnumber'];
				$pofield['tnxqty']                 = $rrrows['requirednetqty'];
				$pofield['iduom']                  = $rrrows['iduom'];
				$pofield['dlvbrktext']             = $rrrows['dlvbrktext'];
				$pofield['salesorder']             = $rrrows['salesorder'];
				$pofield['previousqty']            = $previousqty;

				$updatePO = array();
				foreach ($pofield as $key => $value) {
					$updatePO[] = $key . "='" . $value . "'";
				}

				$updateString = implode(',', $updatePO);
				$sqlUpdate = "UPDATE erp_purchaseorder SET $updateString,ispoautoupdateflag='0' WHERE rrnumber='$rrnumber' AND docnumber='$podocnumber' AND ispoautoupdateflag='1'";
			}else{
				$sqlUpdate = "UPDATE erp_purchaseorder SET linestatus='9',ispoautoupdateflag='0' WHERE rrnumber='$rrnumber' AND docnumber='$podocnumber'";
			}

			// echo $sqlUpdate;
			
			$result = $conn->query($sqlUpdate);

		}

		if($result){
			$returnJSON->result = "success";
		}else{
			$returnJSON->result = "error ".$sqlUpdate;
		}

		return json_encode($returnJSON);
	}


	// function getCostCenterAndDept(){
	// 	$conn = new ErpDbConn;
	// 	$returnJSON            = new stdClass();
	// 	$returnJSON->errormsgs = array();

	// 	// $data = array();

	// 	$sql = "SELECT costcenter,costdepartment FROM `mrd_costcenter&costdepartment` where costcenter is not null AND costdepartment is not null";
	// 	$queryResult = $conn->query($sql);

	// 	$arrayCostCenter = array();
	// 	while( $row = $queryResult->fetch_assoc() ){
	// 		$arrayCostCenter[] = $row['costcenter'];
	// 	}


	// 	$sql = "SELECT projectcode,costcenter,costdepartment from erp_nonpo_project";
	// 	$queryResult = $conn->query($sql);

	// 	$arrayCostCenter = array();
	// 	while( $row = $queryResult->fetch_assoc() ){
	// 		$arrayProjectCode[] = $row['projectcode'];
	// 	}


	// 	$sql = "SELECT ItemName FROM `tnx_nonpo_itemlist`";
	// 	// return $sql;
	// 	$queryResult = $conn->query($sql);

	// 	$arrayItemName = array();
	// 	while( $row = $queryResult->fetch_assoc() ){
	// 		$arrayItemName[] = $row['ItemName'];
	// 	}

	// 	$sql = "SELECT PurchaseMode FROM `ref_purchasemode_nonpo` WHERE PurchaseMode is not null";
	// 	$queryResult = $conn->query($sql);

	// 	$arrayPurchaseMode = array();
	// 	while( $row = $queryResult->fetch_assoc() ){
	// 		$arrayPurchaseMode[] = $row['PurchaseMode'];
	// 	}

	// 	$sql = "SELECT Description FROM mrd_library where LibraryName='UOM'";
	// 	$queryResult = $conn->query($sql);

	// 	$arrayUOM = array();
	// 	while( $row = $queryResult->fetch_assoc() ){
	// 		$arrayUOM[] = $row['Description'];
	// 	}

	// 	$sql = "SELECT UnitName FROM `mrd_factoryunit_list`";
	// 	$queryResult = $conn->query($sql);

	// 	$arrayFactoryUnitName = array();
	// 	while( $row = $queryResult->fetch_assoc() ){
	// 		$arrayFactoryUnitName[] = $row['UnitName'];
	// 	}


	// 	$sql = "SELECT ItemDescription FROM `nonpo_itemdescription`";
	// 	$queryResult = $conn->query($sql);

	// 	$arrayItemDescription = array();
	// 	while( $row = $queryResult->fetch_assoc() ){
	// 		$arrayItemDescription[] = $row['ItemDescription'];
	// 	}


	// 	$sql = "SELECT Size FROM `nonpo_sizeormeasure`";
	// 	$queryResult = $conn->query($sql);

	// 	$arraySize = array();
	// 	while( $row = $queryResult->fetch_assoc() ){
	// 		$arraySize[] = $row['Size'];
	// 	}


	//    	// $queryResult = $conn->query($sqlAdditionRR);
	//     // $data = array();
	//     // while($row = $queryResult->fetch_assoc()){

	//     // 	array_push($data, $row);
	//     // }

	// 	// $data['costcenter'] = array();
	// 	// $data['purchasemode'] = array();
	// 	// $data['iduom'] = array();
	// 	// $data['itemname'] = array();
	// 	// $data['factoryunit'] = array();

	// 	// $data[] = $arrayCostCenter;
	// 	// $data[] = $arrayPurchaseMode;
	// 	// $data[] = $arrayUOM;
	// 	// $data[] = $arrayItemName;
	// 	// $data[] = $arrayFactoryUnitName;

	// 	$data = array(
	// 		'costcenter' => json_encode($arrayCostCenter),
	// 		'projectcode' => json_encode($arrayProjectCode),
	// 		'purchasemode' => json_encode($arrayPurchaseMode),
	// 		'iduom' => json_encode($arrayUOM),
	// 		'factoryunit' => json_encode($arrayFactoryUnitName),
	// 		'itemdescription' => json_encode($arrayItemDescription),
	// 		'size' => json_encode($arraySize),
	// 	);
	//     $conn->close();

	//    	return json_encode($data);
	// }









	//Non-PO-Item-Code_AND_Item-NatureGenaeration_Start--------------------------------------------------------------

	function checkItemCodeAndAutoFill($itemcode){
		$conn = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$sql = "SELECT * FROM `nonpo_itemcode` WHERE ItemCode = '$itemcode'";
		$queryResult = $conn->query($sql);
		$row = $queryResult->fetch_assoc();

		$ItemName        =  $row['ItemName'];
		$ItemNature      =  $row['ItemNature'];
		$Brand           =  $row['Brand'];
		$ColorCode       =  $row['ColorCode'];
		$Size            =  $row['Size'];
		$ItemDescription =  $row['ItemDescription'];
		$BrandDes        =  $row['BrandDes'];
		$ColorDes        =  $row['ColorDes'];

		$data = array(
			'ItemName'        => json_encode($ItemName),
			'ItemNature'      => json_encode($ItemNature),
			'Brand'           => json_encode($BrandDes),
			'ColorCode'       => json_encode($ColorDes),
			'Size'            => json_encode($Size),
			'ItemDescription' => json_encode($ItemDescription),
		);

	    $conn->close();
	   	return json_encode($data);
	}


	function checkItemNature($itemName, $itemNature){
		$conn = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$sql = "SELECT ItemNature FROM `nonpo_itemname_library` WHERE ItemName = '$itemName'";
		$queryResult = $conn->query($sql);
		$row = $queryResult->fetch_assoc();
		$existingNature =  $row['ItemNature'];

		$conn->close();
	   	return json_encode($existingNature);
	}




	function checkItemCodeAvailability($lineObj){
		$conn = new ErpDbConn;

		$itemName   = $lineObj['itemname'];
		$brandDes      = $lineObj['brand'];
		$colorDes      = $lineObj['color'];
		$size       = $lineObj['sizeormeasurement'];
		$itemDesc   = $lineObj['itemdescription'];
		$itemNature = $lineObj['itemnature'];

		// return $brand;

		//update itemnature in nonpo_itemname
		$sql = "UPDATE `nonpo_itemname_library` SET ItemNature = '$itemNature' WHERE ItemName = '$itemName'";
		$queryResult = $conn->query($sql);

		// return $color;

		//Item Brand----------------------------------------------------------------------------
		$sql = "SELECT Code FROM `mrd_library` WHERE LibraryName = 'NonPOBrand' AND Description = '$brandDes'";
		$queryResult = $conn->query($sql);

		$row = $queryResult->fetch_assoc();
		$brand =  $row['Code'];	
		


		//Item Color----------------------------------------------------------------------------
		$sql = "SELECT Code FROM `mrd_library` WHERE LibraryName = 'NonPOColor' AND Description = '$colorDes'";
		$queryResult = $conn->query($sql);

		$row = $queryResult->fetch_assoc();
		$color =  $row['Code'];	


		$newFullItemCode = $this->checkForIDLines($itemName, $brand, $color, $size, $itemDesc, $itemNature);

		$sql = "SELECT distinct(ItemCode) AS itemcode FROM `nonpo_itemcode` WHERE ItemCode = '$newFullItemCode'";
		$queryResult = $conn->query($sql);

		$row = $queryResult->fetch_assoc();
		$existingItemCode =  $row['itemcode'];

		if($existingItemCode == $newFullItemCode){
			//nothing to do
		}else{
			$this->createItemCode($newFullItemCode, $itemName, $brand, $color, $size, $itemDesc, $itemNature, $brandDes, $colorDes);
		}

	    $conn->close();
	   	return $newFullItemCode;
	}

	function checkForIDLines($itemName, $brand, $color, $size, $itemDesc, $itemNature){
		$conn = new ErpDbConn;



		//Item Name----------------------------------------------------------------------------
		$sql = "SELECT id FROM `nonpo_itemname_library` WHERE ItemName = '$itemName'";
		$queryResult = $conn->query($sql);

		$row = $queryResult->fetch_assoc();
		$itemNameID =  $row['id'];	
		
		$newItemCode = $itemNameID;


		//Item Brand----------------------------------------------------------------------------
		$sql = "SELECT Code FROM `mrd_library` WHERE LibraryName = 'NonPOBrand' AND Code = '$brand'";
		$queryResult = $conn->query($sql);

		$row = $queryResult->fetch_assoc();
		$itemBrand =  $row['Code'];	
		
		$newItemCode = $newItemCode . "-" . $itemBrand;


		//Item Color----------------------------------------------------------------------------
		$sql = "SELECT Code FROM `mrd_library` WHERE LibraryName = 'NonPOColor' AND Code = '$color'";
		$queryResult = $conn->query($sql);

		$row = $queryResult->fetch_assoc();
		$itemColor =  $row['Code'];	
		
		$newItemCode = $newItemCode . "-" . $itemColor;
		

		//Item Size----------------------------------------------------------------------------
		$sql = "SELECT idlines FROM `nonpo_sizeormeasure` WHERE Size = '$size'";
		$queryResult = $conn->query($sql);

		$row = $queryResult->fetch_assoc();
		$sizeID =  $row['idlines'];	
		
		if($sizeID != ''){

			$newItemCode = $newItemCode . "-" . $sizeID;
		}else{

			$sql1 = "INSERT INTO `nonpo_sizeormeasure` (Size) VALUES ('$size')";
			$queryResult = $conn->query($sql1);

			$sql2 = "SELECT idlines FROM `nonpo_sizeormeasure` WHERE Size = '$size'";
			$queryResult = $conn->query($sql2);

			$row = $queryResult->fetch_assoc();
			$sizeID =  $row['idlines'];

			$newItemCode = $newItemCode . "-" . $sizeID;
		}

		//Description----------------------------------------------------------------------------
		$sql = "SELECT idlines FROM `nonpo_itemdescription` WHERE ItemDescription = '$itemDesc'";
		$queryResult = $conn->query($sql);

		$row = $queryResult->fetch_assoc();
		$descriptionID =  $row['idlines'];	
		
		if($descriptionID != ''){

			$newItemCode = $newItemCode . "-" . $descriptionID;
		}else{

			$sql1 = "INSERT INTO `nonpo_itemdescription` (ItemDescription) VALUES ('$itemDesc')";
			$queryResult = $conn->query($sql1);

			$sql2 = "SELECT idlines FROM `nonpo_itemdescription` WHERE ItemDescription = '$itemDesc'";
			$queryResult = $conn->query($sql2);

			$row = $queryResult->fetch_assoc();
			$descriptionID =  $row['idlines'];

			$newItemCode = $newItemCode . "-" . $descriptionID;
		}

		$newFullItemCode = $newItemCode;

		$conn->close();	
		return $newFullItemCode;
	}

	function createItemCode($newFullItemCode, $itemName, $brand, $color, $size, $itemDesc, $itemNature, $brandDes, $colorDes){
		$conn = new ErpDbConn;

		$sql = "INSERT INTO `nonpo_itemcode` (ItemName, Brand, ColorCode, Size, ItemDescription, ItemNature, ItemCode, BrandDes, ColorDes) VALUES 
						('$itemName', '$brand', '$color', '$size', '$itemDesc', '$itemNature', '$newFullItemCode', '$brandDes', '$colorDes')";
		$queryResult = $conn->query($sql);

		$conn->close();

	}

	//Non-PO-Item-Code_Genaeration_End-------------------------------------------------------------
















	//**************************************************************************************************************
	//***************************************Capex Requisition_By_Nazmul********************************************



	// function serachAndFillCompany($department){
	// 	$conn                  = new ErpDbConn;
	// 	$returnJSON            = new stdClass();
	// 	$returnJSON->errormsgs = array();

	// 	$sql = "SELECT companycode AS company FROM `erp_requisition_library` WHERE departmentcode = '$department' LIMIT 1";
	// 	$queryResult = $conn->query($sql);

	// 	$row = $queryResult->fetch_assoc();
	// 	$fatherField = $row['company'];

	//     $conn->close();
	//    	return $fatherField;
	// }


	// function serachAndFillCompanyDepartment($section){
	// 	$conn                  = new ErpDbConn;
	// 	$returnJSON            = new stdClass();
	// 	$returnJSON->errormsgs = array();

	// 	$sql = "SELECT companycode AS company, departmentcode AS department  FROM `erp_requisition_library` WHERE sectioncode = '$section' LIMIT 1";
	// 	$queryResult = $conn->query($sql);
	// 	$row = $queryResult->fetch_assoc();

	// 	$company    = $row['company'];
	// 	$department = $row['department'];

	// 	$returnData = array(
	// 		'company'    => json_encode($company),
	// 		'department' => json_encode($department),
	// 	);

	// 	$conn->close();
	// 	return json_encode($returnData);
	// }




	// function serachAndFillpreFields($username){
	// 	$conn                  = new ErpDbConn;
	// 	$returnJSON            = new stdClass();
	// 	$returnJSON->errormsgs = array();

	// 	$sql = "SELECT companycode AS company, departmentcode AS department, sectioncode AS section  FROM `erp_requisition_library` WHERE username = '$username' LIMIT 1";
	// 	$queryResult = $conn->query($sql);
	// 	$row = $queryResult->fetch_assoc();

	// 	$company    = $row['company'];
	// 	$department = $row['department'];
	// 	$section    = $row['section'];

	// 	$returnData = array(
	// 		'company'    => json_encode($company),
	// 		'department' => json_encode($department),
	// 		'section'    => json_encode($section),
	// 	);

	// 	$conn->close();
	// 	return json_encode($returnData);
	// }



	//**************************************************************************************************************
	//**************************************************************************************************************









	function getItemName($itemname){
		$conn = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();


		$sql = "SELECT distinct(ItemName) AS ItemName FROM `tnx_nonpo_itemlist` WHERE ItemName like '%$itemname%'";
		$queryResult = $conn->query($sql);

		$arrayItemName = array();
		while( $row = $queryResult->fetch_assoc() ){
			$arrayItemName[] = $row['ItemName'];
		}

	    $conn->close();

	   	return json_encode($arrayItemName);
	}

	function getSupplierName($suppliername){
		$conn = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();


		$sql = "SELECT distinct(SupplierName) AS SupplierName FROM `mrd_nonpo_supplierlist` WHERE SupplierAddress is not null AND SupplierName is not null AND SupplierName like '%$suppliername%'";
		$queryResult = $conn->query($sql);

		$arraySupplierName = array();
		while( $row = $queryResult->fetch_assoc() ){
			$arraySupplierName[] = $row['SupplierName'];
		}

	    $conn->close();

	   	return json_encode($arraySupplierName);
	}


	function getSupplierAddress($suppliername){
		$conn = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();


		$sql = "SELECT SupplierAddress, SupplierOrigin FROM `mrd_nonpo_supplierlist` WHERE SupplierName= '$suppliername'";
		// $queryResult = $conn->query($sql);

		// $row = $queryResult->fetch_assoc();
		// $SupplierAddress =  $row['SupplierAddress'];

	   //  $conn->close();

	   // return json_encode($SupplierAddress);
        return $conn->sqlToJson($sql);
	}

	function getCostDept($project){
		$conn = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();


		$sql = "SELECT costcenter,costdepartment from erp_nonpo_project WHERE projectcode= '$project' LIMIT 1";
		$queryResult = $conn->query($sql);

		$row = $queryResult->fetch_assoc();
		$costDept =  $row['costdepartment'];

	    $conn->close();

	   	return json_encode($row);
	}


	function autoRevisedButtonVisibility($docnumber){
		$conn = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$countSql = "SELECT rrnumber FROM erp_purchaseorder WHERE docnumber='$docnumber' AND ispoautoupdateflag='1'";
		$queryResult = $conn->query($countSql);
		$queryRowsNum = $queryResult->num_rows;

		if($queryRowsNum == 0){
			return 0;
		}else{
			return 1;
		}

	}


	function updateRRStatus($rrnumber, $ponumber,$polinenumber){
		$conn = new ErpDbConn();
		$sql = "UPDATE erp_rrlines SET rrstatus = 3, powonumber = '$ponumber', powolinenumber='$polinenumber' WHERE rrnumber='$rrnumber'";
		$conn->query($sql);
	}


	function _saveLine($line){
		$conn = new ErpDbConn;
		date_default_timezone_set("Asia/Dhaka"); 

		$lineObj = json_decode($line, true);
		// $newFullItemCode = $this->checkItemCodeAvailability($lineObj);



		foreach ($lineObj as $key => $value) {
			$newValue = str_replace("'", "\'", $value);
			$lineObj[$key] = $newValue;
		}
		
		$docnumber = $lineObj['docnumber'];
		$idlines = $lineObj['idlines'];

		$doctype = $lineObj['doctype'];
		$formtype = $lineObj['formtype'];

		$genericDocument = new ErpDocumentIPO();
		$formStructure = json_encode($genericDocument->formStructure($doctype, $formtype, 'create'), JSON_PRETTY_PRINT);	
		$formStructure = json_decode($formStructure, true);

		$tablename = $formStructure['schema']['tablename'];
		$doccounter= $formStructure['doccounter'];

		

		// create doc with this line
		if($docnumber == ""){
			// process lines
			$columnFields = array();
			$fieldValues = array();
			unset($lineObj['linenumber']);
			unset($lineObj['lineentrytime']);
			unset($lineObj['linestatus']);
			unset($lineObj['idlines']);
			// process header
			unset($lineObj['docnumber']);
			unset($lineObj['docstatus']);
			unset($lineObj['entrypersonbadge']);
			unset($lineObj['entrypersonname']);
			unset($lineObj['doccreationtime']);

			$docnumber = $this->getNextDocNumber($doccounter);
			$lineObj['docnumber'] = $docnumber;
			$lineObj['linenumber'] = '1';

			// apply critaria if have
			$lineObj['doclinenumber'] = $docnumber . '-' . $lineObj['linenumber'];
			// $lineObj['itemcode'] = $docnumber . '-' . $lineObj['linenumber'];
			// $lineObj['itemcode'] = $newFullItemCode;
			// $polinenumber = $lineObj['doclinenumber'];

			// if($lineObj['purchasemode'] != '' AND $lineObj['suppliername'] != '' AND $lineObj['unitprice'] != '' AND $lineObj['currency'] != ''){
			// 	$lineObj['linestatus'] = '1';
			// }else{
			// 	$lineObj['linestatus'] = '0';
			// }
			
			foreach ($lineObj as $fieldname => $fieldvalue) {
				$columnFields[] = $fieldname;
				$fieldValues[] = $fieldvalue;
			}		

			$columnFields[] = 'entrypersonbadge';
			$fieldValues[]  = $_SESSION['LoggedBadge'];


			$entrypersonname = "";
			$sqlGetName = "SELECT * from mrd_employee_basicinfo where Badge='".$_SESSION['LoggedBadge']."';";
			$result = $conn->query($sqlGetName);
			while($row = $result->fetch_assoc()){
				$entrypersonname = $row['Name'];
			}
			$columnFields[] = 'entrypersonname';
			$fieldValues[]  = $entrypersonname;

			$columnFields[] = 'docstatus';
			$fieldValues[]  = '0';
			$columnFields[] = 'doccreationtime';
			$fieldValues[]  = date('Y-m-d H:i:s', time());


			$columnFields = implode(", ", $columnFields);
			$fieldValues  = "'" . implode("','", $fieldValues) . "'";
			$sql = "INSERT INTO $tablename ($columnFields) VALUES($fieldValues)";

			// return $sql;
			$conn->conn->query($sql);
			$idlines = $conn->conn->insert_id;

			

			$lineData = $this->readDocLineWise($docnumber, $idlines);
			$lineObj = json_decode($lineData, true);
			$lineObj['doccreate'] = 'yes';
			return json_encode($lineObj);

		}

		// insert new line
		if($idlines == ""){

			// process lines
			$columnFields = array();
			$fieldValues = array();
			unset($lineObj['linenumber']);
			unset($lineObj['lineentrytime']);
			unset($lineObj['linestatus']);
			unset($lineObj['idlines']);

			$sql = "SELECT idlines, linenumber FROM $tablename WHERE docnumber = '$docnumber' ORDER BY idlines DESC";
			$queryResult = $conn->query($sql);
			$last_linenumber =  $queryResult->fetch_assoc()['linenumber'];
			$lineObj['linenumber'] = (int)$last_linenumber + 1;

			// apply critaria if have
			$lineObj['doclinenumber'] = $docnumber . '-' . $lineObj['linenumber'];
			// $lineObj['itemcode'] = $docnumber . '-' . $lineObj['linenumber'];
			// $lineObj['itemcode'] = $newFullItemCode;
			$polinenumber = $lineObj['doclinenumber'];

			// if($lineObj['purchasemode'] != '' AND $lineObj['suppliername'] != '' AND $lineObj['unitprice'] != '' AND $lineObj['currency'] != ''){
			// 	$lineObj['linestatus'] = '1';
			// }else{
			// 	$lineObj['linestatus'] = '0';
			// }
			
			foreach ($lineObj as $fieldname => $fieldvalue) {
				$columnFields[] = $fieldname;
				$fieldValues[] = $fieldvalue;
			}		

			// $columnFields[] = 'itemcode';
			// $fieldValues[]  = $newFullItemCode;

			$columnFields = implode(", ", $columnFields);
			$fieldValues  = "'" . implode("','", $fieldValues) . "'";
			$sql = "INSERT INTO $tablename ($columnFields) VALUES($fieldValues)";


			$conn->conn->query($sql);
			$idlines = $conn->conn->insert_id;

			
			return $this->readDocLineWise($docnumber, $idlines);

		}

		// update line
		if($idlines != ""){
			unset($lineObj['linenumber']);
			unset($lineObj['lineentrytime']);
			unset($lineObj['linestatus']);

			$doclinenumber =  $lineObj['doclinenumber'];
			// $lineObj['itemcode'] = $newFullItemCode;

			// if($lineObj['purchasemode'] != '' AND $lineObj['suppliername'] != '' AND $lineObj['unitprice'] != '' AND $lineObj['currency'] != ''){
			// 	$lineObj['linestatus'] = '1';
			// }else{
			// 	$lineObj['linestatus'] = '0';
			// }
			
			date_default_timezone_set("Asia/Dhaka");
			$updateSet = "";
			foreach ($lineObj as $fieldname => $fieldvalue) {
				$updateSet .= $fieldname . "=" . "'" . $fieldvalue . "',";
			}		



			$updateSet .= "lastlineupdateuser =" . "'" . $_SESSION["USERNAME"] . "',"; 
			
			// $updateSet .= "itemcode =" . "'" . $newFullItemCode . "',"; 

			$lastLineUpdateTime  = date('Y-m-d H:i:s', time());
			$updateSet .= "lastlineupdatetime =" . "'" . $lastLineUpdateTime . "',"; 

			$updateSet = rtrim($updateSet ,',');
			$sql = "UPDATE $tablename SET $updateSet WHERE idlines = '$idlines'";

			// return $sql;

			$conn->query($sql);
			

			return $this->readDocLineWise($docnumber, $idlines);

		}

	}

	function updateTotalAmount($docnumber){
		$conn = new ErpDbConn;

		$sqlTotalAmount = "SELECT SUM(amount) AS totalamount FROM erp_nonpo WHERE docnumber='$docnumber'";
		$queryResult = $conn->query($sqlTotalAmount);

		$row = $queryResult->fetch_assoc();

		$totalamount = $row['totalamount'];

		$f = new NumberToWordConverter;
		$totalamountwords = $f->numberTowords($totalamount);

		$sqlUpdateTotalAmount = "UPDATE erp_nonpo SET totalamount='$totalamount',totalamountwords='$totalamountwords' WHERE docnumber='$docnumber'";
		$queryResult = $conn->query($sqlUpdateTotalAmount);

	}



	function searchHeaderInfo($params){
		$conn = new ErpDbConn;

		unset($params['reqType']);
		$docnumber = $params['docnumber'];
		

		$sql = "SELECT * FROM erp_bom WHERE docnumber='$docnumber'";

		return $conn->sqlToJson($sql);

	}

	function getPOLineInfo($searchParams){
	    $conn = new ErpDbConn;
	  
	    $idlines = $searchParams['idlines'];
	    $idlinesArray = explode(',', $idlines);

	    $idlinesArray = "'" . implode("','", $idlinesArray) . "'";

	    $sql = "SELECT * FROM erp_rrlines WHERE idlines IN ($idlinesArray)";
	   	$queryResult = $conn->query($sql);
	    $data = array();
	    while($row = $queryResult->fetch_assoc()){
	    	$rrnumber = $row['rrnumber'];
	    	$salesorder = $row['salesorder'];
	    	$itemcode = $row['itemcode'];
	    	$projectionPOInfo = $this->getProjectionPOInfo($rrnumber);
	    	$MLInfo = $this->getMLInfo($salesorder, $itemcode);
	    	$row['parentponumber'] = $projectionPOInfo['docnumber'];
	    	$row['parentpolinenumber'] = $projectionPOInfo['doclinenumber'];
	    	$row['orderqtycondition'] = $MLInfo['orderqtycondition'];
	    	$row['conditiondetails'] = $MLInfo['conditiondetails'];

	    	array_push($data, $row);
	    }

	    $conn->close();

	   	return json_encode($data);

	}	

	function getMLInfo($salesorder, $itemcode){
		$conn = new ErpDbConn;
		$sql = "SELECT * FROM erp_fabricmaterialline WHERE materiallistid IN(SELECT materiallistid FROM erp_salesorder WHERE docnumber = '$salesorder') AND itemcode='$itemcode'";		
		$result  = $conn->query($sql);
		$row  = $result->fetch_assoc();

		return $row; 
	}	

	function getProjectionPOInfo($rrnumber){
		$conn = new ErpDbConn;
		$sql = "SELECT docnumber,doclinenumber FROM erp_purchaseorder WHERE rrnumber IN(SELECT parentrrnumber FROM erp_rrlines WHERE rrnumber='$rrnumber')";
		$result  = $conn->query($sql);
		$row  = $result->fetch_assoc();

		return $row; 
	}

	function getSOInfo($searchParams){
	    $conn = new ErpDbConn;

	    // $idlines = json_decode($idlines, true);
	  
	    $salesorder = $searchParams['salesorder'];


	    // $sql = "SELECT * FROM erp_rrlines WHERE idlines='$idlines'";
	    $sql = "SELECT * FROM erp_salesorder WHERE docnumber='$salesorder'";
	    // return $sql;
	   	$result =  $conn->sqlToJson($sql);

	    $conn->close();

	   	return $result;

	}	

	function getRRLineInfo($searchParams){
	    $conn = new ErpDbConn;

	    // $idlines = json_decode($idlines, true);
	  
	    $rrnumber = $searchParams['rrnumber'];


	    // $sql = "SELECT * FROM erp_rrlines WHERE idlines='$idlines'";
	    $sql = "SELECT * FROM erp_rrlines WHERE rrnumber='$rrnumber'";
	    // return $sql;
	   	$result =  $conn->sqlToJson($sql);

	    $conn->close();

	   	return $result;

	}	

	function senttoTextile($data){
		$returnJson = new stdClass();
		$conn = new ErpDbConn;

		$data      = json_decode($data, true);
		$docnumber = $data['docnumber'];
		$rrnumber  = $data['rrnumber'];
		$rrnumber  = "'" . implode("','",$rrnumber) . "'";
		$posenttotextiletime = date("Y-m-d H:i:s");

		$sqlUpdateDocStatus = "UPDATE erp_purchaseorder SET docstatus='1',linestatus='1', posenttotextiletime = '$posenttotextiletime' WHERE docnumber='$docnumber' AND linestatus!='9'";
		$sql                = "UPDATE erp_rrlines SET rrstatus = '4', linestatus = '5' WHERE rrnumber IN($rrnumber)";

		$result      = $conn->query($sqlUpdateDocStatus);
		$queryResult = $conn->query($sql);

		if($queryResult){
			$returnJson->result = 'success';
		} else {
			$returnJson->result = 'fail';
		}
		$conn->close();
		return json_encode($returnJson);

	}	

	function cancelPRLine($idlines){
		$returnJson = new stdClass();
		$conn = new ErpDbConn;

		$sqlUpdate = "UPDATE erp_nonpo SET linestatus='9' WHERE idlines='$idlines'";
		$queryResult = $conn->query($sqlUpdate);

		$sql = "SELECT doclinenumber FROM erp_nonpo WHERE idlines='$idlines'";
		$queryResultPR = $conn->query($sql);
		$row = $queryResultPR->fetch_assoc();
		$requisitionLineNumber = $row['doclinenumber'];
		//auto update po
		$sqlUpdatePO = "UPDATE erp_nonpo SET linestatus='9' WHERE requisitionlinenumber='$requisitionLineNumber'";
		$queryResultPO = $conn->query($sqlUpdatePO);

		if($queryResult){
			$returnJson->result = 'success';
		} else {
			$returnJson->result = 'fail';
		}
		$conn->close();
		return json_encode($returnJson);
	}

	function removePOLine($idlines){
		$conn = new ErpDbConn;
		$returnJSON           = new stdClass();
		$returnJSON->errormsgs = array();
		


		$sql = "DELETE FROM int_purchase_order WHERE idlines = '$idlines'";
		$result = $conn->query($sql);


		
      	$conn->close();

		if($result){
      		$returnJSON->result = 'success';
			
		} else {
			array_push($returnJSON->errormsgs, "Error, please contact system.support@lizfashion.com: commit failed.");
		}
		return json_encode($returnJSON);
	}


	function uploadFile($formStructure){

		$conn = new ErpDbConn;		
		$returnJSON  = new stdClass();
		$returnJSON->errormsgs = array();

		$fileClientObj = new FileClient();
		$docnumber = $_POST['docnumber'];
		$linenumber = $_POST['linenumber'];
		$directorypath = $_POST['directorypath'];
		$filepathsavingcolumnname = $_POST['filepathsavingcolumnname'];

	    $rootPath = $_SERVER['DOCUMENT_ROOT'];
	    $thisPath = dirname($_SERVER['PHP_SELF']);
	    $onlyPath = str_replace($rootPath, '', $thisPath);
	    // $directoryPath = $rootPath . "/attachments/erp-inquiry/inquiry-requisition/" . $docnumber . "-" . $linenumber;
	    $directoryPath = $rootPath . $directorypath;

		$n = 0;
		$filePaths = array();
		foreach($_FILES as $file){

		    $fileFieldName = "file_" . $n;
			$file = $_FILES[$fileFieldName];
			$fileName = $_FILES[$fileFieldName]['name'];
			$fileNewName = $docnumber . "--" . $linenumber . "_" . $fileName; // if user want to rename file name
			$n++;

			$filePath = $fileClientObj->saveFileInGivenDirectory_SingleFile($directoryPath, $fileFieldName, $file, true, $fileNewName);
			if(!$filePath){
				array_push($returnJSON->errormsgs, $fileName);
				$returnJSON->result = 'fail to upload';
				return json_encode($returnJSON);
			} 
			$filePath = "/attachments" . explode("attachments", $filePath)[1];
			$filePaths[] = $filePath;
		}

		if(count($filePaths) > 1){
			$filePaths = implode("::", $filePaths);
		} else {
			$filePaths = $filePaths[0] . "::";
		}

		$formStructure = json_decode($formStructure, true);
		$tablename = $formStructure['schema']['tablename'];

		// concate file path if exist
		$sql = "SELECT $filepathsavingcolumnname FROM $tablename WHERE docnumber = '$docnumber' AND linenumber = '$linenumber'";
		$queryResult = $conn->query($sql);
		$row = $queryResult->fetch_assoc();
		$filePath = $row[$filepathsavingcolumnname];
		if($filePath != "" && $filePath != null){
			// $filePath = explode("::", $filePath);
			$filePaths = $filePath . $filePaths;
		}

        $sql = "UPDATE $tablename SET $filepathsavingcolumnname = '$filePaths' WHERE docnumber = '$docnumber' AND linenumber = '$linenumber'";
		$queryResult  = $conn->query($sql);

		if($queryResult){
			$returnJSON->result = 'success';
			return json_encode($returnJSON);			
		} else {
			array_push($returnJSON->errormsgs, $sql);
			return json_encode($returnJSON);
		}

	}


	function deletePRLine($idlines){
		$returnJson = new stdClass();
		$conn = new ErpDbConn;


		$sqlDelete = "DELETE FROM erp_nonpo WHERE idlines='$idlines'";
		$queryResult = $conn->query($sqlDelete);

		if($queryResult){
			$returnJson->result = 'success';
		} else {
			$returnJson->result = 'fail';
		}
		$conn->close();
		return json_encode($returnJson);
	}

	function  deleteFile($formStructure){

		$conn = new ErpDbConn;		
		$returnJSON  = new stdClass();
		$returnJSON->errormsgs = array();

	    $rootPath = $_SERVER['DOCUMENT_ROOT'];
	    // $directoryPath = $rootPath . "/attachments/erp-inquiry/inquiry-requisition/" . $docnumber . "-" . $linenumber;
	    $filepathcolumnname =  $_POST['filepathcolumnname'];
	    $keycolumnname =  $_POST['keycolumnname'];
	    $keycolumnvalue =  $_POST['keycolumnvalue'];
	    $filePath =  $_POST['filePath'];
	    $searchPath = $filePath;
	    $deletePath = $filePath;

	    $filePath = substr($filePath, 1);
		$filePath = $rootPath . $filePath;

		$fileClientObj = new FileClient();
		$result = $fileClientObj->deleteFile($filePath);

		$formStructure = json_decode($formStructure, true);
		$tablename = $formStructure['schema']['tablename'];

		// concate file path if exist
		$sql = "SELECT $filepathcolumnname FROM $tablename WHERE $keycolumnname = '$keycolumnvalue'";
		$queryResult = $conn->query($sql);
		$row = $queryResult->fetch_assoc();
		$existFilePath = $row[$filepathcolumnname];

		if($existFilePath != "" && $existFilePath != null){

			$allFilePaths = split("::", $existFilePath);
			$deleteFilePath = array($deletePath);

			$keepFilePaths = array_diff($allFilePaths, $deleteFilePath);
			$keepFilePaths = implode("::", $keepFilePaths);

	        $sql = "UPDATE $tablename SET $filepathcolumnname = '$keepFilePaths' WHERE $keycolumnname = '$keycolumnvalue'";
			$queryResult  = $conn->query($sql);

			if($queryResult){
				$returnJSON->result = 'success';
				return json_encode($returnJSON);			
			} else {
				array_push($returnJSON->errormsgs, $sql);
				return json_encode($returnJSON);
			}
		
		} else {

			$returnJSON->result = 'fail';
			return json_encode($returnJSON);		

		}


	}
			

}


/**
 * Routing ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 */
if ( basename(__FILE__) == basename($_SERVER["SCRIPT_FILENAME"]) ) {
    // called directly
	if ( $_SERVER['REQUEST_METHOD'] == 'GET' ) {

		if(isset($_GET['reqType'])){

			$reqType = $_GET['reqType'];
			$obTest  = new ThisDocAPI();

			if($reqType == 'readDoc') {

				$docnumber = $_GET['docnumber'];
				$idlines   = $_GET['idlines'];
				if($idlines != ""){
					$returnData = $obTest->readDocLineWise($docnumber, $idlines);
				} else {
					$returnData = $obTest->readDoc($docnumber);
				}
				echo $returnData;

			}

			if($reqType == '_searchDoc') {
				$genericDocument = new ErpDocumentIPO();
				$formStructure = json_encode($genericDocument->formStructure('', '', ''), JSON_PRETTY_PRINT);

				$where = $_GET['where'];
				$columns = $_GET['columns'];
				$returnData = $obTest->_searchDoc($formStructure, $where, $columns);
				echo $returnData;
			}

			if($reqType == 'searchHeaderInfo') {

				$returnData = $obTest->searchHeaderInfo($_GET);
				echo $returnData;

			}


			// if($reqType == 'getPOLineInfo') {

			// 	$returnData = $obTest->getPOLineInfo($_GET);
			// 	echo $returnData;

			// }

			// if($reqType == 'getSOInfo') {

			// 	$returnData = $obTest->getSOInfo($_GET);
			// 	echo $returnData;

			// }

			// if($reqType == 'getRRLineInfo') {

			// 	$returnData = $obTest->getRRLineInfo($_GET);
			// 	echo $returnData;

			// }


			// if($reqType == 'autoRevisedButtonVisibility') {

			// 	$returnData = $obTest->autoRevisedButtonVisibility($_GET['docnumber']);
			// 	echo $returnData;

			// }

			// if($reqType == 'getCostCenterAndDept') {

			// 	$returnData = $obTest->getCostCenterAndDept();
			// 	echo $returnData;

			// }

			// if($reqType == 'serachAndFillCompany') {

			// 	$department = $_GET['department'];
			// 	$returnData = $obTest->serachAndFillCompany($department);
			// 	echo $returnData;

			// }

			// if($reqType == 'serachAndFillCompanyDepartment') {

			// 	$section = $_GET['section'];
			// 	$returnData = $obTest->serachAndFillCompanyDepartment($section);
			// 	echo $returnData;

			// }


			// if($reqType == 'serachAndFillpreFields') {

			// 	$username = $_GET['username'];
			// 	$returnData = $obTest->serachAndFillpreFields($username);
			// 	echo $returnData;

			// }

			

			// if($reqType == 'getItemName') {

			// 	$itemname = $_GET['itemname'];
			// 	$returnData = $obTest->getItemName($itemname);
			// 	echo $returnData;

			// }

			// if($reqType == 'getCostDept') {

			// 	$project = $_GET['project'];
			// 	$returnData = $obTest->getCostDept($project);
			// 	echo $returnData;

			// }

			// if($reqType == 'getSupplierName') {

			// 	$suppliername = $_GET['suppliername'];
			// 	$returnData = $obTest->getSupplierName($suppliername);
			// 	echo $returnData;

			// }

			// if($reqType == 'getSupplierAddress') {

			// 	$suppliername = $_GET['suppliername'];
			// 	$returnData = $obTest->getSupplierAddress($suppliername);
			// 	echo $returnData;

			// }

			// if($reqType == 'updateRevisedNP') {

			// 	$podocnumber = $_GET['docnumber'];
			// 	$returnData = $obTest->updateRevisedPO($podocnumber);
			// 	echo $returnData;

			// }

			// if($reqType == 'checkItemNature') {

			// 	$itemName   = $_GET['itemName'];
			// 	$itemNature = $_GET['itemNature'];
			// 	$returnData = $obTest->checkItemNature($itemName, $itemNature);
			// 	echo $returnData;

			// }

			// if($reqType == 'checkItemCodeAndAutoFill') {

			// 	$itemcode   = $_GET['itemcode'];
			// 	$returnData = $obTest->checkItemCodeAndAutoFill($itemcode);
			// 	echo $returnData;

			// }

		}


	} else if( $_SERVER['REQUEST_METHOD'] == 'POST' ){
	
		if(isset($_POST['reqType'])){

			$reqType = $_POST['reqType'];
			$obTest  = new ThisDocAPI();

			if($reqType == "saveDoc"){
		
				$docobj = $_POST['docobj'];
				$returnData = $obTest->saveDoc($docobj);
				echo $returnData;
			}

			if($reqType == "_saveLine"){
		
				$line = $_POST['line'];
				$returnData = $obTest->_saveLine($line);
				echo $returnData;
			}

			if($reqType == "changeDocStatus"){

				$docnumber = $_POST['docnumber'];
				$docstatus = $_POST['docstatus'];
				$returnData = $obTest->changeDocStatus($docnumber, $docstatus);
				echo $returnData;
			}

			// if($reqType == "poAmendment"){

			// 	$docnumber = $_POST['docnumber'];
			// 	$docstatus = $_POST['docstatus'];
			// 	$returnData = $obTest->poAmendment($docnumber, $docstatus);
			// 	echo $returnData;
			// }

			// if($reqType == "cancelPRLine"){

			// 	$idlines = $_POST['idlines'];
			// 	$returnData = $obTest->cancelPRLine($idlines);
			// 	echo $returnData;
			// }

			// if($reqType == 'removePOLine') {
			// 	$idlines = $_POST['idlines'];
			// 	$returnData = $obTest->removePOLine($idlines);
			// 	echo $returnData;
			// }			
			
			if($reqType == "uploadFile"){

				$genericDocument = new ErpDocumentIPO();
				$formStructure = json_encode($genericDocument->formStructure($formtype, $crudmode), JSON_PRETTY_PRINT);				
				$returnData = $obTest->uploadFile($formStructure);
				echo $returnData;
			}

			if($reqType == "deleteFile"){

				$genericDocument = new ErpDocumentIPO();
				$formStructure = json_encode($genericDocument->formStructure($formtype, $crudmode), JSON_PRETTY_PRINT);				
				$returnData = $obTest->deleteFile($formStructure);
				echo $returnData;
			}

			// if($reqType == "senttoTextile"){

			// 	$data = $_POST['data'];
			// 	$returnData = $obTest->senttoTextile($data);
			// 	echo $returnData;
			// }

			// if($reqType == 'updateRevisedNP') {

			// 	$podocnumber = $_POST['docnumber'];
			// 	$returnData = $obTest->updateRevisedPO($podocnumber);
			// 	echo $returnData;

			// }

			// if($reqType == "deletePRLine"){

			// 	$idlines = $_POST['idlines'];
			// 	$returnData = $obTest->deletePRLine($idlines);
			// 	echo $returnData;
			// }


		}



	}

} else {
    // included/required

}
?>