<?php
session_start();
$directory = __DIR__ ;
// require_once __DIR__ . "/classes/config.php";
require_once $_SERVER["DOCUMENT_ROOT"] . '/includes/configli.php'; // mysql connections
require_once __DIR__ . "/classes/myclassautoloader.php";
require_once __DIR__ . "/api/FileClient.class.php";
/**
* ThisDocAPI class
*/
class ThisDocAPI extends BaseDocAPI
{

	function __construct(){
	}



	function readDoc($docnumber){

		$genericDocument = new ErpDocumentPO();
		$formStructure = json_encode($genericDocument->formStructure('NP', 'default', 'read'), JSON_PRETTY_PRINT);

		$docnumber = $_GET['docnumber'];
		$apiObj = new ThisDocAPI();
		$docData = $apiObj->_readDoc($docnumber, $formStructure);
		$docObj = json_decode($docData, true);

		// again read doc with doctype and formtype
		$doctype = $docObj['doctype'];
		$formtype = $docObj['formtype'];
		$formStructure = json_encode($genericDocument->formStructure($doctype, $formtype, 'read'), JSON_PRETTY_PRINT);
		$docData = $apiObj->_readDoc($docnumber, $formStructure);
		$docObj = json_decode($docData, true);

		// $docObj['docstatus'] = $apiObj->docStatusTranslatorF[$docObj['docstatus']];

		$docLines = $docObj['lines'];
		unset($docObj['lines']);
		$newDocLines = array();
		foreach ($docLines as $docLine) {
			$currLine                = $docLine;
			// $currLine['linestatus'] = $this->lineStatusTranslatorF[$docLine['linestatus']];
			array_push($newDocLines, $currLine);
		}
		$docObj['lines'] = $newDocLines;

		return json_encode($docObj);

	}

	function readDocLineWise($docnumber, $idlines){

		$genericDocument = new ErpDocumentPO();
		$formStructure = json_encode($genericDocument->formStructure('NP', 'default', 'read'), JSON_PRETTY_PRINT);

		// $docnumber = $_GET['docnumber'];
		$docData = $this->_readDocLineWise($docnumber, $formStructure , $idlines);
		$docObj = json_decode($docData, true);

		$doctype = $docObj['doctype'];
		$formtype = $docObj['formtype'];
		$formStructure = json_encode($genericDocument->formStructure($doctype, $formtype, 'read'), JSON_PRETTY_PRINT);
		$docData = $this->_readDocLineWise($docnumber, $formStructure , $idlines);
		$docObj = json_decode($docData, true);


		$docLines = $docObj['lines'];
		unset($docObj['lines']);
		$newDocLines = array();
		foreach ($docLines as $docLine) {
			$currLine                = $docLine;
			array_push($newDocLines, $currLine);
		}
		$docObj['lines'] = $newDocLines;
		return json_encode($docObj);

	}



	function saveDoc($docdata, $formStructure){

		$docobj = json_decode($docdata, true);
		$doctype = $docobj['doctype'];
		$formtype = $docobj['formtype'];

		$genericDocument = new ErpDocumentPO();
		$formStructure = json_encode($genericDocument->formStructure($doctype, $formtype, 'create'), JSON_PRETTY_PRINT);		

		if(isset($docobj['docnumber']) && $docobj['docnumber'] != ""){ // update Doc
			$returnJSON = $this->updateDoc($docdata, $formStructure);
			return json_encode($returnJSON);	
		} else {													   // create Doc
			$returnJSON = $this->createDoc($docdata, $formStructure);
			$returnJSON->createdocheader = "yes";
			return json_encode($returnJSON);
		}
	}



	function createDoc($docdata, $formStructure){
		$conn = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$formStructure = json_decode($formStructure, true);
		$tablename = $formStructure['schema']['tablename'];
		$doctype   = $formStructure['header']['doctype'];
		$formtype  = $formStructure['header']['formtype'];
		$doccounter= $formStructure['doccounter'];

		$docobj = json_decode($docdata, true);
		$doclins = $docobj['lines'];
		unset($docobj['lines']);

		foreach ($docobj as $key => $value) {
			$newValue = str_replace("'", "\'", $value);
			$docobj[$key] = $newValue;
		}

		foreach ($doclins as $key => $value) {
			$newValue = str_replace("'", "\'", $value);
			$doclins[$key] = $newValue;
		}

		$docnumber = $this->getNextDocNumber($doccounter);
		$docobj['docnumber'] = $docnumber;
		$newDocLines = array();
		foreach ($doclins as $docLine) {

			$currLine                = $docLine;
			// translate line status
			$currLine['doclinenumber'] = $docnumber . '-' . $currLine['linenumber'];
			// unset some field
			array_push($newDocLines, $currLine);
		}
		$docobj['lines'] = $newDocLines;

		// system entries
		// $docobj['lines'] = $doclins;

		$returnJSON = $this->_createDoc(json_encode($docobj), json_encode($formStructure));

		$this->updateTotalAmount($returnJSON->docnumber);

		if($returnJSON->docnumber != ''){
			$sqlArray = array();
			foreach ($newDocLines as $index => $line) {
				$requisitionlinenumber = $line['requisitionlinenumber'];
				$doclinenumber = $line['doclinenumber'];
				$sql = "UPDATE erp_nonpo SET linestatus = 2 , ponumber = '$returnJSON->docnumber',polinenumber='$doclinenumber' WHERE doclinenumber='$requisitionlinenumber'";
				$sqlArray[] = $sql;
			}	

			foreach ($sqlArray as $index => $sql) {
				$resultUpdate = $conn->query($sql);
			}

		}


		return $returnJSON;

	}

	function updateTotalAmount($docnumber){
		$conn = new ErpDbConn;

		$sqlTotalAmount = "SELECT SUM(amount) AS totalamount,povatandtax,podiscountamount,poadditionalcost FROM erp_nonpo WHERE docnumber='$docnumber'";
		$queryResult = $conn->query($sqlTotalAmount);

		$row = $queryResult->fetch_assoc();

		$totalamount = $row['totalamount'];

		$f = new NumberToWordConverter;



		$poadditionalcost = $row['poadditionalcost'];
		$podiscountamount = $row['podiscountamount'];
		$vattax = (($row['povatandtax'] * ($totalamount-$podiscountamount)) / 100);

		$nettotal = ($totalamount + $vattax + $poadditionalcost - $podiscountamount);
		$nettotalW = floor($nettotal);
		$totalamountwords = $f->numberTowords($nettotalW);



		$sqlUpdateTotalAmount = "UPDATE erp_nonpo SET totalamount='$totalamount',totalamountwords='$totalamountwords',ponettotal='$nettotal', vattaxamount='$vattax' WHERE docnumber='$docnumber'";
		$queryResult = $conn->query($sqlUpdateTotalAmount);

	}


	function _createDoc($docdata, $formStructure){
		$conn = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$formStructure = json_decode($formStructure, true);
		$tablename = $formStructure['schema']['tablename'];
		$doctype   = $formStructure['header']['doctype'];
		$formtype  = $formStructure['header']['formtype'];
		$doccounter= $formStructure['doccounter'];

		$docobj = json_decode($docdata, true);
		$doclins = $docobj['lines'];
		unset($docobj['lines']);

		$sql_array = array();
		$hcolumnFields = array();
		$hfieldValues = array();
		// process header
		$docnumber = $docobj['docnumber'];
		unset($docobj['docnumber']);
		unset($docobj['docstatus']);
		unset($docobj['entrypersonbadge']);
		unset($docobj['entrypersonname']);
		unset($docobj['doccreationtime']);
		// system entries
		if($docnumber == ''){
			$docnumber = $this->getNextDocNumber($doccounter);
		}
		$hcolumnFields[] = 'docnumber';
		$hfieldValues[]  = $docnumber;

		$hcolumnFields[] = 'entrypersonbadge';
		$hfieldValues[]  = $_SESSION['LoggedBadge'];

		$entrypersonname = "";
		$sqlGetName = "SELECT * from mrd_employee_basicinfo where Badge='".$_SESSION['LoggedBadge']."';";
		$result = $conn->query($sqlGetName);
		while($row = $result->fetch_assoc()){
			$entrypersonname = $row['Name'];
		}
		$hcolumnFields[] = 'entrypersonname';
		$hfieldValues[]  = $entrypersonname;

		$hcolumnFields[] = 'docstatus';
		$hfieldValues[]  = '0';
		$hcolumnFields[] = 'doccreationtime';
		$hfieldValues[]  = date('Y-m-d H:i:s', time());

		$totalamount = $docobj['totalamount'];

		$vattax = (($docobj['povatandtax'] * $totalamount) / 100);
		$poadditionalcost = $docobj['poadditionalcost'];
		$podiscountamount = $docobj['podiscountamount'];

		$nettotal = ($totalamount + $vattax + $poadditionalcost - $podiscountamount);

		$docobj['ponettotal'] = $nettotal;

		$f = new NumberToWordConverter;
		$nettotalW = floor($nettotal);
		$docobj['totalamountwords'] = $f->numberTowords($nettotalW);

		foreach ($docobj as $fieldname => $fieldvalue) {
			$hcolumnFields[] = $fieldname;
			$hfieldValues[] = $fieldvalue;
		}

		// process lines
		foreach ($doclins as $index => $line) {

			$columnFields = array();
			$fieldValues = array();
			unset($line['lineentrytime']);
			unset($line['linestatus']);
			unset($line['idlines']);
			foreach ($line as $fieldname => $fieldvalue) {
				$columnFields[] = $fieldname;
				$fieldValues[] = $fieldvalue;
			}
			// push header data in line
			foreach ($hcolumnFields as $index => $fieldname) {
				$columnFields[] = $fieldname;
				$fieldValues[]  = $hfieldValues[$index];		
			}		

			$columnFields = implode(", ", $columnFields);
			$fieldValues  = "'" . implode("','", $fieldValues) . "'";

			$sql = "INSERT INTO $tablename ($columnFields) VALUES($fieldValues)";
			$sql_array[] = $sql;

		}

		// Execute Query
		foreach ($sql_array as $key => $sql) {
			$result = $conn->query($sql);	  
			if(!$result){
				array_push($returnJSON->errormsgs, "Error, $sql");
				return $returnJSON;
			}
		}
      	$conn->close();

		if ($result) {
			$returnJSON->docnumber = $docnumber;
		} else {
			array_push($returnJSON->errormsgs, "Error, please tell ERP department: commit failed.");
		}
		return $returnJSON;

	}

	function updateDoc($docdata, $formStructure){
		$conn = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$formStructure = json_decode($formStructure, true);
		$tablename = $formStructure['schema']['tablename'];		

		$newdocobj = json_decode($docdata, true);
		$docnumber = $newdocobj['docnumber'];


		$totalamount = $newdocobj['totalamount'];
		$f = new NumberToWordConverter;


		$vattax = (($newdocobj['povatandtax'] * $totalamount) / 100);
		$poadditionalcost = $newdocobj['poadditionalcost'];
		$podiscountamount = $newdocobj['podiscountamount'];

		$nettotal = ($totalamount + $vattax + $poadditionalcost - $podiscountamount);

		$newdocobj['ponettotal'] = $nettotal;
		
		$nettotalW = floor($nettotal);
		$newdocobj['totalamountwords'] = $f->numberTowords($nettotalW);


		$doclins = $newdocobj['lines']; // format: lines = array(0 => array, 1 => array, ....)
		unset($newdocobj['lines']);

		foreach ($newdocobj as $key => $value) {
			$newValue = str_replace("'", "\'", $value);
			$newdocobj[$key] = $newValue;
		}
		
		foreach ($doclins as $key => $value) {
			$newValue = str_replace("'", "\'", $value);
			$doclins[$key] = $newValue;
		}

		$newDocLines = array();
		foreach ($doclins as $docLine) {

			$currLine                = $docLine;
			// translate line status
			$currLine['doclinenumber'] = $docnumber . '-' . $currLine['linenumber'];
			// unset some field
			unset($currLine['linestatus']);
			unset($currLine['lineentrytime']);
			array_push($newDocLines, $currLine);
		}

		$newdocobj['lines'] = $newDocLines;
		// $newdocobj['docstatus'] = $this->docStatusTranslatorB[$newdocobj['docstatus']]; // it should be base class
		$returnJSON = $this->_updateDoc(json_encode($newdocobj), json_encode($formStructure));

		if($returnJSON->docnumber != ''){
			$sqlArray = array();
			foreach ($newDocLines as $index => $line) {
				$requisitionlinenumber = $line['requisitionlinenumber'];
				$doclinenumber = $line['doclinenumber'];
				$sql = "UPDATE erp_nonpo SET linestatus = 2 , ponumber = '$returnJSON->docnumber',polinenumber='$doclinenumber' WHERE doclinenumber='$requisitionlinenumber'";
				$sqlArray[] = $sql;
			}	

			foreach ($sqlArray as $index => $sql) {
				$resultUpdate = $conn->query($sql);
			}

		}

		$this->updateTotalAmount($docnumber);

		return $returnJSON;

	}



	function changeDocStatus($docnumber, $docstatus){

		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$genericDocument = new ErpDocumentPO();
		$formStructure = json_encode($genericDocument->formStructure($formtype, $crudmode), JSON_PRETTY_PRINT);

		$returnJSON = $this->_changeDocStatus($docnumber, $docstatus, $formStructure);

		// $this->updateAllRRLineStatus_sentToTextile($docnumber);

		return $returnJSON;

	}

	function poAmendment($docnumber, $docstatus){
		$conn     = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$sqlUpdate = "UPDATE erp_purchaseorder SET docstatus = '$docstatus' , amendstatus = (amendstatus+1) WHERE docnumber='$docnumber';";
		$result = $conn->query($sqlUpdate);

		if($result){
			$returnJSON->result = "success";
		}else{
			$returnJSON->result = "error ".$sqlUpdate;
		}

		return json_encode($returnJSON);

	}

	function updateAllRRLineStatus_sentToTextile($docnumber){
		$conn = new ErpDbConn;

		$sql = "SELECT rrnumber FROM erp_purchaseorder WHERE docnumber = '$docnumber'";

		echo "string...... KLM" . $sql;
		$queryResult = $conn->query($sql);

		while ($row = $queryResult->fetch_assoc()) {
			$rrnumber = $row['rrnumber'];
			$sql = "UPDATE erp_rrlines SET rrstatus = '4' WHERE rrnumber = '$rrnumber'";
			echo "string...... XXFD" . $sql;
			$conn->query($sql);
		}

		$conn->close();
	}


	function updateRevisedPO($podocnumber){
		$conn = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$sqlUpd = "UPDATE erp_purchaseorder SET docstatus='0', amendmenttimes=(amendmenttimes+1), amendstatus = (amendstatus+1) WHERE docnumber='$podocnumber'";
		$queryUpdResult = $conn->query($sqlUpd);

		$sql = "SELECT rrnumber,tnxqty FROM erp_purchaseorder WHERE docnumber='$podocnumber' AND ispoautoupdateflag='1'";
		$queryResult = $conn->query($sql);

		$getSOsql = "SELECT distinct(salesorder) AS salesorder FROM erp_purchaseorder WHERE docnumber='$podocnumber' AND ispoautoupdateflag='1'";
		$queryResultSOsql = $conn->query($getSOsql);

		while ($row = $queryResult->fetch_assoc()) {
			$rrnumber = $row['rrnumber'];
			$previousqty = $row['tnxqty'];
			$sqlUpdPO = "SELECT * FROM erp_rrlines WHERE rrnumber='$rrnumber'";
			$resultRRRow = $conn->query($sqlUpdPO);
			$queryRowsNum = $resultRRRow->num_rows;

			if($queryRowsNum != 0){
				$rrrows = $resultRRRow->fetch_assoc();


				$pofield = array();
				$pofield['itemcode']               = $rrrows['itemcode'];
				$pofield['itemtype']               = $rrrows['itemtype'];
				$pofield['itemdescription']        = $rrrows['itemdescription'];
				$pofield['pricerequisitionnumber'] = $rrrows['pricerequisitionnumber'];
				$pofield['unitprice']              = $rrrows['unitprice'];
				$pofield['iduom']                  = $rrrows['iduom'];
				$pofield['fabricinhousedate']      = $rrrows['fabricinhousedate'];
				$pofield['rrnumber']               = $rrrows['rrnumber'];
				$pofield['parentrrnumber']         = $rrrows['parentrrnumber'];
				$pofield['tnxqty']                 = $rrrows['requirednetqty'];
				$pofield['iduom']                  = $rrrows['iduom'];
				$pofield['dlvbrktext']             = $rrrows['dlvbrktext'];
				$pofield['salesorder']             = $rrrows['salesorder'];
				$pofield['previousqty']            = $previousqty;

				$updatePO = array();
				foreach ($pofield as $key => $value) {
					$updatePO[] = $key . "='" . $value . "'";
				}

				$updateString = implode(',', $updatePO);
				$sqlUpdate = "UPDATE erp_purchaseorder SET $updateString,ispoautoupdateflag='0' WHERE rrnumber='$rrnumber' AND docnumber='$podocnumber' AND ispoautoupdateflag='1'";
			}else{
				$sqlUpdate = "UPDATE erp_purchaseorder SET linestatus='9',ispoautoupdateflag='0' WHERE rrnumber='$rrnumber' AND docnumber='$podocnumber'";
			}

			// echo $sqlUpdate;
			
			$result = $conn->query($sqlUpdate);

		}

		if($result){
			$returnJSON->result = "success";
		}else{
			$returnJSON->result = "error ".$sqlUpdate;
		}

		return json_encode($returnJSON);
	}


	function getAdditionalRRPOLineInfo($podocnumber){
		$conn = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$sql = "SELECT rrnumber FROM erp_purchaseorder WHERE docnumber='$podocnumber' AND ispoautoupdateflag='1'";
		$queryResult = $conn->query($sql);

		$getSOsql = "SELECT distinct(salesorder) AS salesorder FROM erp_purchaseorder WHERE docnumber='$podocnumber' AND ispoautoupdateflag='1'";
		$queryResultSOsql = $conn->query($getSOsql);

		$arraySO = array();
		while( $rowso = $queryResultSOsql->fetch_assoc() ){
			$arraySO[] = $rowso['salesorder'];
		}

		$sonumbers = "'" . implode("','", $arraySO) . "'";

		$sqlAdditionRR = "SELECT * FROM erp_rrlines WHERE salesorder IN($sonumbers) AND rrnumber NOT IN(SELECT rrnumber FROM erp_purchaseorder WHERE docnumber='$podocnumber')";

	   	$queryResult = $conn->query($sqlAdditionRR);
	    $data = array();
	    while($row = $queryResult->fetch_assoc()){
	    	$rrnumber = $row['rrnumber'];
	    	$salesorder = $row['salesorder'];
	    	$itemcode = $row['itemcode'];
	    	$projectionPOInfo = $this->getProjectionPOInfo($rrnumber);
	    	$MLInfo = $this->getMLInfo($salesorder, $itemcode);
	    	$row['parentponumber'] = $projectionPOInfo['docnumber'];
	    	$row['parentpolinenumber'] = $projectionPOInfo['doclinenumber'];
	    	$row['orderqtycondition'] = $MLInfo['orderqtycondition'];
	    	$row['conditiondetails'] = $MLInfo['conditiondetails'];

	    	array_push($data, $row);
	    }

	    $conn->close();

	   	return json_encode($data);
	}


	function autoRevisedButtonVisibility($docnumber){
		$conn = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$countSql = "SELECT rrnumber FROM erp_purchaseorder WHERE docnumber='$docnumber' AND ispoautoupdateflag='1'";
		$queryResult = $conn->query($countSql);
		$queryRowsNum = $queryResult->num_rows;

		if($queryRowsNum == 0){
			return 0;
		}else{
			return 1;
		}

	}


	function updateRRStatus($rrnumber, $ponumber,$polinenumber){
		$conn = new ErpDbConn();
		$sql = "UPDATE erp_rrlines SET rrstatus = 3, powonumber = '$ponumber', powolinenumber='$polinenumber' WHERE rrnumber='$rrnumber'";
		$conn->query($sql);
	}


	function _saveLine($line){
		$conn = new ErpDbConn;

		$lineObj = json_decode($line, true);

		foreach ($lineObj as $key => $value) {
			$newValue = str_replace("'", "\'", $value);
			$lineObj[$key] = $newValue;
		}

		$docnumber = $lineObj['docnumber'];
		$idlines = $lineObj['idlines'];

		$doctype = $lineObj['doctype'];
		$formtype = $lineObj['formtype'];

		$genericDocument = new ErpDocumentPO();
		$formStructure = json_encode($genericDocument->formStructure($doctype, $formtype, 'create'), JSON_PRETTY_PRINT);	
		$formStructure = json_decode($formStructure, true);

		$tablename = $formStructure['schema']['tablename'];
		$doccounter= $formStructure['doccounter'];

		// create doc with this line
		if($docnumber == ""){
			// process lines
			$columnFields = array();
			$fieldValues = array();
			unset($lineObj['linenumber']);
			unset($lineObj['lineentrytime']);
			unset($lineObj['linestatus']);
			unset($lineObj['idlines']);
			// process header
			unset($lineObj['docnumber']);
			unset($lineObj['docstatus']);
			unset($lineObj['entrypersonbadge']);
			unset($lineObj['doccreationtime']);

			$docnumber = $this->getNextDocNumber($doccounter);
			$lineObj['docnumber'] = $docnumber;
			$lineObj['linenumber'] = '1';

			// apply critaria if have
			$lineObj['doclinenumber'] = $docnumber . '-' . $lineObj['linenumber'];
			$polinenumber = $lineObj['doclinenumber'];
			
			foreach ($lineObj as $fieldname => $fieldvalue) {
				$columnFields[] = $fieldname;
				$fieldValues[] = $fieldvalue;
			}		

			$columnFields[] = 'entrypersonbadge';
			$fieldValues[]  = $_SESSION['LoggedBadge'];

			$columnFields[] = 'docstatus';
			$fieldValues[]  = '0';
			$columnFields[] = 'doccreationtime';
			$fieldValues[]  = date('Y-m-d H:i:s', time());


			$columnFields = implode(", ", $columnFields);
			$fieldValues  = "'" . implode("','", $fieldValues) . "'";
			$sql = "INSERT INTO $tablename ($columnFields) VALUES($fieldValues)";


			$conn->conn->query($sql);
			$idlines = $conn->conn->insert_id;

			// update rr status
			$this->updateRRStatus($lineObj['rrnumber'], $docnumber, $polinenumber);

			$lineData = $this->readDocLineWise($docnumber, $idlines);
			$lineObj = json_decode($lineData, true);
			$lineObj['doccreate'] = 'yes';
			return json_encode($lineObj);

		}

		// insert new line
		if($idlines == ""){

			// process lines
			$columnFields = array();
			$fieldValues = array();
			unset($lineObj['linenumber']);
			unset($lineObj['lineentrytime']);
			unset($lineObj['linestatus']);
			unset($lineObj['idlines']);

			$sql = "SELECT idlines, linenumber FROM $tablename WHERE docnumber = '$docnumber' ORDER BY idlines DESC";
			$queryResult = $conn->query($sql);
			$last_linenumber =  $queryResult->fetch_assoc()['linenumber'];
			$lineObj['linenumber'] = (int)$last_linenumber + 1;

			// apply critaria if have
			$lineObj['doclinenumber'] = $docnumber . '-' . $lineObj['linenumber'];
			$polinenumber = $lineObj['doclinenumber'];
			
			foreach ($lineObj as $fieldname => $fieldvalue) {
				$columnFields[] = $fieldname;
				$fieldValues[] = $fieldvalue;
			}		

			$columnFields = implode(", ", $columnFields);
			$fieldValues  = "'" . implode("','", $fieldValues) . "'";
			$sql = "INSERT INTO $tablename ($columnFields) VALUES($fieldValues)";


			$conn->conn->query($sql);
			$idlines = $conn->conn->insert_id;

			// update rr status
			$this->updateRRStatus($lineObj['rrnumber'], $docnumber,$polinenumber);
			
			return $this->readDocLineWise($docnumber, $idlines);

		}

		// update line
		if($idlines != ""){
			unset($lineObj['linenumber']);
			unset($lineObj['lineentrytime']);
			unset($lineObj['linestatus']);
			unset($lineObj['idlines']);

			$updateSet = "";
			foreach ($lineObj as $fieldname => $fieldvalue) {
				$updateSet .= $fieldname . "=" . "'" . $fieldvalue . "',";
			}			
			$updateSet = rtrim($updateSet ,',');
			$sql = "UPDATE $tablename SET $updateSet WHERE idlines = '$idlines'";

			$conn->query($sql);
			return $this->readDocLineWise($docnumber, $idlines);

		}

	}



	function searchHeaderInfo($params){
		$conn = new ErpDbConn;

		unset($params['reqType']);
		$docnumber = $params['docnumber'];

		$sql = "SELECT * FROM erp_bom WHERE docnumber='$docnumber'";

		return $conn->sqlToJson($sql);

	}

	function getPOLineInfo($searchParams){
	    $conn = new ErpDbConn;
	  
	    $idlines = $searchParams['idlines'];
	    $idlinesArray = explode(',', $idlines);

	    $idlinesArray = "'" . implode("','", $idlinesArray) . "'";

	    $sql = "SELECT * FROM erp_nonpo WHERE idlines IN ($idlinesArray)";
	   	$queryResult = $conn->query($sql);
	    $data = array();
	    while($row = $queryResult->fetch_assoc()){
	    	

	    	array_push($data, $row);
	    }

	    $conn->close();

	   	return json_encode($data);

	}	

	function getMLInfo($salesorder, $itemcode){
		$conn = new ErpDbConn;
		$sql = "SELECT * FROM erp_fabricmaterialline WHERE materiallistid IN(SELECT materiallistid FROM erp_salesorder WHERE docnumber = '$salesorder') AND itemcode='$itemcode'";		
		$result  = $conn->query($sql);
		$row  = $result->fetch_assoc();

		return $row; 
	}	

	function getProjectionPOInfo($rrnumber){
		$conn = new ErpDbConn;
		$sql = "SELECT docnumber,doclinenumber FROM erp_purchaseorder WHERE rrnumber IN(SELECT parentrrnumber FROM erp_rrlines WHERE rrnumber='$rrnumber')";
		$result  = $conn->query($sql);
		$row  = $result->fetch_assoc();

		return $row; 
	}

	function getSOInfo($searchParams){
	    $conn = new ErpDbConn;

	    // $idlines = json_decode($idlines, true);
	  
	    $salesorder = $searchParams['salesorder'];


	    // $sql = "SELECT * FROM erp_rrlines WHERE idlines='$idlines'";
	    $sql = "SELECT * FROM erp_salesorder WHERE docnumber='$salesorder'";
	    // return $sql;
	   	$result =  $conn->sqlToJson($sql);

	    $conn->close();

	   	return $result;

	}	

	function getRRLineInfo($searchParams){
	    $conn = new ErpDbConn;

	    // $idlines = json_decode($idlines, true);
	  
	    $requisitionlinenumber = $searchParams['requisitionlinenumber'];


	    
	    $sql = "SELECT * FROM erp_nonpo WHERE doclinenumber='$requisitionlinenumber'";
	    // return $sql;
	   	$result =  $conn->sqlToJson($sql);

	    $conn->close();

	   	return $result;

	}	

	function senttoTextile($data){
		$returnJson = new stdClass();
		$conn = new ErpDbConn;

		$data      = json_decode($data, true);
		$docnumber = $data['docnumber'];
		$rrnumber  = $data['rrnumber'];
		$rrnumber  = "'" . implode("','",$rrnumber) . "'";
		$posenttotextiletime = date("Y-m-d H:i:s");

		$sqlUpdateDocStatus = "UPDATE erp_purchaseorder SET docstatus='1',linestatus='1', posenttotextiletime = '$posenttotextiletime' WHERE docnumber='$docnumber' AND linestatus!='9'";
		$sql                = "UPDATE erp_rrlines SET rrstatus = '4', linestatus = '5' WHERE rrnumber IN($rrnumber)";

		$result      = $conn->query($sqlUpdateDocStatus);
		$queryResult = $conn->query($sql);

		if($queryResult){
			$returnJson->result = 'success';
		} else {
			$returnJson->result = 'fail';
		}
		$conn->close();
		return json_encode($returnJson);

	}	

	function deletePOLine($idlines){
		$returnJson = new stdClass();
		$conn = new ErpDbConn;

		$sql = "SELECT requisitionlinenumber FROM erp_nonpo WHERE idlines='$idlines'";
		$sqlResult = $conn->query($sql);

		$row = $sqlResult->fetch_assoc();
		$doclinenumber = $row['requisitionlinenumber'];

		$sqlUpdate = "UPDATE erp_nonpo SET linestatus='1', ponumber = '', polinenumber=''  WHERE doclinenumber='$doclinenumber'";
		$queryResult = $conn->query($sqlUpdate);

		$sqlDelete = "DELETE FROM erp_nonpo WHERE idlines='$idlines'";
		$queryResult = $conn->query($sqlDelete);

		if($queryResult){
			$returnJson->result = 'success';
		} else {
			$returnJson->result = 'fail';
		}
		$conn->close();
		return json_encode($returnJson);
	}

	function removePOLine($idlines){
		$conn = new ErpDbConn;
		$returnJSON           = new stdClass();
		$returnJSON->errormsgs = array();

		$sql = "DELETE FROM erp_purchaseorder WHERE idlines = '$idlines'";
		$result = $conn->query($sql);
		
      	$conn->close();

		if($result){
      		$returnJSON->result = 'success';
			
		} else {
			array_push($returnJSON->errormsgs, "Error, please contact system.support@lizfashion.com: commit failed.");
		}
		return json_encode($returnJSON);
	}	

}


/**
 * Routing ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 */
if ( basename(__FILE__) == basename($_SERVER["SCRIPT_FILENAME"]) ) {
    // called directly
	if ( $_SERVER['REQUEST_METHOD'] == 'GET' ) {

		if(isset($_GET['reqType'])){

			$reqType = $_GET['reqType'];
			$obTest  = new ThisDocAPI();

			if($reqType == 'readDoc') {

				$docnumber = $_GET['docnumber'];
				$idlines   = $_GET['idlines'];
				if($idlines != ""){
					$returnData = $obTest->readDocLineWise($docnumber, $idlines);
				} else {
					$returnData = $obTest->readDoc($docnumber);
				}
				echo $returnData;

			}

			if($reqType == '_searchDoc') {
				$genericDocument = new ErpDocumentPO();
				$formStructure = json_encode($genericDocument->formStructure('NP', '', ''), JSON_PRETTY_PRINT);

				$where = $_GET['where'];
				$columns = $_GET['columns'];
				$returnData = $obTest->_searchDoc($formStructure, $where, $columns);
				echo $returnData;
			}

			if($reqType == 'searchHeaderInfo') {

				$returnData = $obTest->searchHeaderInfo($_GET);
				echo $returnData;

			}


			if($reqType == 'getPOLineInfo') {

				$returnData = $obTest->getPOLineInfo($_GET);
				echo $returnData;

			}

			if($reqType == 'getSOInfo') {

				$returnData = $obTest->getSOInfo($_GET);
				echo $returnData;

			}

			if($reqType == 'getRRLineInfo') {

				$returnData = $obTest->getRRLineInfo($_GET);
				echo $returnData;

			}


			if($reqType == 'autoRevisedButtonVisibility') {

				$returnData = $obTest->autoRevisedButtonVisibility($_GET['docnumber']);
				echo $returnData;

			}

			if($reqType == 'getAdditionalRRPOLineInfo') {

				$podocnumber = $_GET['docnumber'];
				$returnData = $obTest->getAdditionalRRPOLineInfo($podocnumber);
				echo $returnData;

			}

			if($reqType == 'updateRevisedNP') {

				$podocnumber = $_GET['docnumber'];
				$returnData = $obTest->updateRevisedPO($podocnumber);
				echo $returnData;

			}

		}


	} else if( $_SERVER['REQUEST_METHOD'] == 'POST' ){
	
		if(isset($_POST['reqType'])){

			$reqType = $_POST['reqType'];
			$obTest  = new ThisDocAPI();

			if($reqType == "saveDoc"){
		
				$docobj = $_POST['docobj'];
				$returnData = $obTest->saveDoc($docobj);
				echo $returnData;
			}

			if($reqType == "_saveLine"){
		
				$line = $_POST['line'];
				$returnData = $obTest->_saveLine($line);
				echo $returnData;
			}

			if($reqType == "changeDocStatus"){

				$docnumber = $_POST['docnumber'];
				$docstatus = $_POST['docstatus'];
				$returnData = $obTest->changeDocStatus($docnumber, $docstatus);
				echo $returnData;
			}

			if($reqType == "poAmendment"){

				$docnumber = $_POST['docnumber'];
				$docstatus = $_POST['docstatus'];
				$returnData = $obTest->poAmendment($docnumber, $docstatus);
				echo $returnData;
			}

			if($reqType == "deletePOLine"){

				$idlines = $_POST['idlines'];
				$returnData = $obTest->deletePOLine($idlines);
				echo $returnData;
			}

			if($reqType == 'removePOLine') {
				$idlines = $_POST['idlines'];
				$returnData = $obTest->removePOLine($idlines);
				echo $returnData;
			}			
			
			if($reqType == "uploadFile"){

				$genericDocument = new ErpDocumentPO();
				$formStructure = json_encode($genericDocument->formStructure($formtype, $crudmode), JSON_PRETTY_PRINT);				
				$returnData = $obTest->uploadFile($formStructure);
				echo $returnData;
			}

			if($reqType == "deleteFile"){

				$genericDocument = new ErpDocumentPO();
				$formStructure = json_encode($genericDocument->formStructure($formtype, $crudmode), JSON_PRETTY_PRINT);				
				$returnData = $obTest->deleteFile($formStructure);
				echo $returnData;
			}

			if($reqType == "senttoTextile"){

				$data = $_POST['data'];
				$returnData = $obTest->senttoTextile($data);
				echo $returnData;
			}

			if($reqType == 'updateRevisedNP') {

				$podocnumber = $_POST['docnumber'];
				$returnData = $obTest->updateRevisedPO($podocnumber);
				echo $returnData;

			}


		}



	}

} else {
    // included/required

}
?>