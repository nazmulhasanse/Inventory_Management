<?php
$formTitle = 'PO Creation RR Lines List';
$pageTittle= 'PO Creation RR Lines List';
$mainHTML  = 'html/listerp.html';
$mainJS    = 'js/list-erp.js?t=2017-10-15';
$customJS  = 'js/list-pocreation-rr-lines.js?t=2017-10-15';
$apiURL    = 'list-pocreation-rr-lines_api.php';
$formId    = 'searchForm';
?>
<!-- Default List CSS -->
<link rel="stylesheet" type="text/css" href="css/listerp.css">
<link rel="stylesheet" type="text/css" href="css/material-button.css">

<!-- PAGE CONTENTS -->
<?php
include $mainHTML;
?>

<!-- Jquery Library -->
<!-- <script src="/js/jquery-2.1.3.min.js"></script> -->

<!-- Java script code -->
<script type="text/javascript" src="api/client_api.js"></script>
<script type="text/javascript" src="<?php echo $mainJS; ?>"></script>	
<script type="text/javascript" src="<?php echo $customJS; ?>"></script>	
<script type="text/javascript">
$(document).ready(function() {

    var endcustomer = $('#formERP #endcustomer').val();
    var searchParams = {};
    searchParams.endcustomer = endcustomer
	var apiURL = '<?php echo $apiURL;?>';
	//                  show, 	page, 	api_url
    ERPLIST.getListData(10,     1,      apiURL, searchParams);
    // ERPLIST.getListData(10,		1, 		apiURL);
});	
</script>

<!-- Override some js code  -->
<script type="text/javascript">
$(document).ajaxStop(function() {
    // place code to be executed on completion of last outstanding ajax call here
    $.fancybox.update(); // this is needed// because ajax call is asyncronus
    // $('#listTable td:nth-child(1)').hide();
    // $('#listTable th:nth-child(1)').hide();
    // ERPLIST.sendBackSearchChoice = function(thisRow){
    //     var docnumber = $(thisRow).find('td[fieldname=docnumber]').text();
    //     alert('docnumber');
    // }
});
// $( document ).ajaxComplete(function( event, xhr, settings ) {
//   if ( settings.url === "ajax/test.html" ) {
//     $( ".log" ).text( "Triggered ajaxComplete handler. The result is " + xhr.responseText );
//   }
// });
</script>

<!-- Override some CSS -->
<style type="text/css">
#ctable .ccell1, .ccell2, .ccell3, .ccell4 {
    padding: 10px;
    border: none;
}  
/*#listTable td:nth-child(1){ display:none;}   */
</style>