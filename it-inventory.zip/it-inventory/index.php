<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/user.cookies.php';    // check user login
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';          // mysql connections
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/user-privilege.php';  // privilege function

include_once("resource/session/session-cheking.php");
// check privilege (keep module and section empty to skip privilege check)

// User Privilege


$module = "ict";
$section = "ict";
$privilege = userPrivileges($module, $section);
if (!$privilege['R']) { header("Location: ../user/no-permission.php"); exit();}


$pageTitle = 'Information Technology Dashboard';
$formTitle = 'Information Technology Dashboard'; 

$mainHTML  = '';
$mainJS    = '';



?>

<!DOCTYPE HTML>
<html>
<head>
	<?php require_once($_SERVER['DOCUMENT_ROOT'] . '/includes/head.php') ;?>

	<style type="text/css">
		fieldset                   { border: 1px solid; border-radius:5px;}
		legend                     { border: 1px solid; padding: 5px; border-radius:5px; font-weight: bold;}
		table, td, th              { border: none;}
		fieldset.responsiveElement { padding: 15px; margin: 15px;}
		.docname                   { font-weight: bold; font-size: 16px; }
		.right                     { text-align: right;}
		.green a.button            { background-color: green;}
		.cyan a.button             { background-color: #00b2b3;}

		.green fieldset, fieldset.green, .green legend { border-color: green;}
		.cyan fieldset, fieldset.cyan, .cyan legend    { border-color: #00b2b3;}
	</style>
	<title><?php echo $pageTitle;?></title>
</head>
<body class="right-sidebar">

<!-- Header Wrapper -->
<div id="header-wrapper">
<div class="container">
<div class="row">
<div class="12u">
<!-- Header -->
	<header id="header">
		<?php 
		include_once($_SERVER['DOCUMENT_ROOT'] . '/includes/mainmenu.php');
		?>
	    <link rel="stylesheet" type="text/css" href="css/material-button.css">
	</header>
</div>
</div>
</div>
</div>

<!-- Main Wrapper -->
<div id="main-wrapper">
<div class="container">
<div class="row">
	<div class="12u skel-cell-important">
		<!-- Content -->
		<div id="content">
		<article class="last">
	<!-- HEADLINES -->

			<div class="headline1">
				<a href="http://erp.liz.com/it-dashboard/">Home</a> -
				<?php echo $formTitle; ?>
			</div>

			

		<div class="headline2"></div> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<br><br>

<!-- PAGE CONTENTS -->
		<!-- <div class='responsiveRow marketingandsales'> -->

		<fieldset class='responsiveElement black'>
					<!-- <legend id="apparel_legend">INT Inventory Module</legend> -->

					<table>	


						<h1 class="doclist_headline"><a href="erpdocument.php?doctype=TI&formtype=TI">Create Inventory</a></h1>

						<hr class="doclist_separator">		

						<h1 class="doclist_headline"><a href="list-inventory.php">IT Inventory List</a></h1>

						<hr class="doclist_separator">		

						<h1 class="doclist_headline"><a href="list-inventory-log.php">IT Inventory History</a></h1>

						<hr class="doclist_separator">	

						<h1 class="doclist_headline"><a href="/it-inventory/user-log/user-log.php">User Log Sheet</a></h1>

						<hr class="doclist_separator">	
	

					</table>

		</fieldset>		
		
		
		</article>
		</div>
	</div>
</div>
</div>
</div>


<style type="text/css">
fieldset                   { border: 1px solid; border-radius:5px;}
legend                     { border: 1px solid; padding: 5px; border-radius:5px; font-weight: bold;}
table, td, th              { border: none;}
fieldset.responsiveElement { padding: 15px; margin: 15px;}
.docname                   { font-weight: bold; font-size: 25px; }
.right                     { text-align: right;}
.green a.button            { background-color: green;}
.cyan a.button             { background-color: #00b2b3;}

.green fieldset, fieldset.green, .green legend {border-color: black; border: 2px solid green;}
.black fieldset, fieldset.black, .black legend {border-color: black; border: 2px solid black;}
.cyan fieldset, fieldset.cyan, .cyan legend    {border-color: #00b2b3; border: 2px solid #00b2b3;}

.doclist_headline {
	/*display: block;*/
	/*border: none; */
	font-weight: normal; 
	padding: 8px;
	font-size: 25px;
	margin-bottom: 2px;
	color: darkcyan;
	font-family: Georgia, serif;
}

.doclist_headline a {
    /*color: #FFFFFF;*/
    text-decoration: none;
}

.doclist_separator {
    display: block;
    margin-top: 0.1em;
    margin-bottom: 3em;
    margin-left: auto;
    margin-right: auto;
    border-style: inset;

    /*Custom*/
    /*border-width: 0.5px;*/
    /*border: 0.5px solid lightblue;*/
	height: 1px;
	border-width: 1px;	
	border-style: solid;

	padding: right;
	margin-left: 6px;
	border-top: lightblue;

	/*border-color: rgba(0,0,255,0.25);*/
	/*border-top: rgba(0,0,255,0.25);*/

	/*background-color: lightblue !important;*/
}
.apparel {
	display: block;
	overflow: hidden;
	padding: 20px;
	margin-bottom: 20px;
}	
.apparel #apparel_legend {
	border: none !important; 
	margin-left: 50px; 
	font-weight: bold; 
	font-size: 30px;
	font-style: italic;
}
.textile {
	display: block;
	overflow: hidden;
	padding: 20px;
	margin-bottom: 20px;
}
.textile #textile_legend {
	border: none !important; 
	margin-left: 20px; 
	font-weight: bold; 
	font-size: 20px;
	font-style: italic;
}	
.store {
	display: block;
	overflow: hidden;
	padding: 20px;
	margin-bottom: 20px;
}	
.store #store_legend {
	border: none !important; 
	margin-left: 50px; 
	font-weight: bold; 
	font-size: 20px;
	font-style: italic;
}

.marketingandsales {
	/*border: 1px solid blue !important;*/
	display: block;
	overflow: hidden;
	margin-bottom: 20px;
	padding: 20px;
}
.marketingandsales #marketingandsales_legend {
	border: none !important; 
	/*padding-left: 50px; */
	margin-left: 50px; 
	/*border-radius:5px; */
	font-weight: bold; 
	font-size: 20px;
	font-style: italic;
}
.capacityplan {
	/*border: 1px solid blue !important;*/
	display: block;
	overflow: hidden;
	margin-bottom: 20px;
	padding: 20px;
}
.capacityplan #capacityplan_legend {
	border: none !important; 
	/*padding-left: 50px; */
	margin-left: 50px; 
	/*border-radius:5px; */
	font-weight: bold; 
	font-size: 20px;
	font-style: italic;
}
.bom {
	/*border: 1px solid blue !important;*/
	display: block;
	overflow: hidden;
	margin-bottom: 20px;
	padding: 20px;
}
.bom #bom_legend {
	border: none !important; 
	/*padding-left: 50px; */
	margin-left: 50px; 
	/*border-radius:5px; */
	font-weight: bold; 
	font-size: 20px;
	font-style: italic;
}
.appearlmaterial {
	/*border: 1px solid blue !important;*/
	display: block;
	overflow: hidden;
	padding: 20px;
}
.appearlmaterial #appearlmaterial_legend {
	border: none !important; 
	/*padding-left: 50px; */
	margin-left: 50px; 
	/*border-radius:5px; */
	font-weight: bold; 
	font-size: 20px;
	font-style: italic;
}


#style_legend {
	border: none !important; 
	/*padding-left: 50px; */
	margin-left: 50px; 
	/*border-radius:5px; */
	font-weight: bold; 
	font-size: 15px;
	font-style: italic;
}
</style>

<style type="text/css">
/**{padding:0;margin:0;}
body{font:16px/1 sans-serif}*/

/*VERTICAL MENU*/
nav.verticalxx {
  position:relative;

  /*background:#667;*/
  /*min-width:200px;*/
}

/* ALL UL */
nav.verticalxx ul{
  /*color: green;*/
  list-style: none;
}
/* ALL LI */
nav.verticalxx li{
  position:relative;
}
/* ALL A */
nav.verticalxx a{
  display:block;
  color: darkcyan;
  /*color:#eee;*/
  text-decoration:none;
  /*padding:10px 15px;*/
  transition:0.2s;
}

/*nav.verticalxx ul li ul li a{
  display:block;
  color:#eee;
  text-decoration:none;
  padding:10px 15px;
  transition:0.2s;
}*/
/* ALL A HOVER */

/* INNER UL HIDE */
nav.verticalxx ul ul{
  background:rgba(0,0,0,0.1);
  padding-left:20px;
  transition: max-height 0.2s ease-out;
  max-height:0;
  overflow:hidden;
}
/* INNER UL SHOW */
nav.verticalxx li:hover > ul{
  max-height:500px;
  transition: max-height 0.25s ease-in;
}

</style>

<style type="text/css">
/**{padding:0;margin:0;}
body{font:16px/1 sans-serif}*/

/*VERTICAL MENU*/
nav.vertical{
  position:relative;
  width:200px;
}

/* ALL UL */
nav.vertical ul{
  list-style: none;
}
/* ALL LI */
nav.vertical li{
  position:relative;
}
/* ALL A */
nav.vertical a{
  display:block;
  color:#eee;
  text-decoration:none;
  padding:10px 15px;
  background:#667;
  transition:0.2s;
}
/* ALL A HOVER */
nav.vertical li:hover > a{
  background:#778;
}

/* INNER UL HIDE */
nav.vertical ul ul{
  position:absolute;
  left:0%;
  top:0;
  width:100%;
  visibility:hidden;
  opacity:0;
  transition: transform 0.2s;
  transform: translateX(50px);
}
/* INNER UL SHOW */
nav.vertical li:hover > ul{
  left:100%;
  visibility:visible;
  opacity:1;
  transform: translateX(0px);
}
</style>

<!-- Footer Wrapper -->
<div id="footer-wrapper">
	<?php include_once($_SERVER['DOCUMENT_ROOT'] . '/includes/footer.php') ;?>
</div>
</body>
</html>