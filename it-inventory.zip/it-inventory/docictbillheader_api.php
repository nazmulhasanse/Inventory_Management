<?php
session_start();
$directory = __DIR__ ;
// require_once __DIR__ . "/classes/config.php";
require_once $_SERVER["DOCUMENT_ROOT"] . '/includes/configli.php'; // mysql connections
require_once __DIR__ . "/classes/myclassautoloader.php";
require_once __DIR__ . "/api/FileClient.class.php";
/**
* ThisDocAPI class
*/
class ThisDocAPI extends BaseDocAPI
{

	function __construct(){
	}

	function _readDoc($docnumber, $formStructure){
		$conn = new ErpDbConn;
		$formStructure = json_decode($formStructure, true);
		$tablename = $formStructure['schema']['tablename'];

		// get the list of fields
		// $fieldHeader = "h." . implode(", h.", array_diff(array_keys($formStructure['header']), array('docstatus')));
		$fieldHeader = "h." . implode(", h.", array_diff(array_keys($formStructure['header']), array('systemfield')));
		$fieldLines  = implode(",", array_keys($formStructure['lines']));

		// get the header info in docobj
		$sql = "SELECT $fieldHeader
		  FROM  $tablename h
		  WHERE h.docnumber = '$docnumber' LIMIT 1";

		$result = $conn->query($sql);
		$docobj = $result->fetch_assoc();

		foreach ($docobj as $fieldname => $fieldvalue) {
			if ($fieldvalue == NULL) {
			  unset($docobj[$fieldname]);
			}
		}

		// add all the lines in docobj
		$sql = "SELECT $fieldLines FROM $tablename WHERE docnumber = '$docnumber' ORDER BY linenumber DESC";
		$result = $conn->query($sql);
		$lines  = array();
		while ($row = $result->fetch_assoc()) {
		foreach ($row as $fieldname => $fieldvalue) {
		  if ($fieldvalue == NULL) {
		  	$row[$fieldname] = '';
		    // unset($row[$fieldname]);
		  }

		}
		array_push($lines, $row);
		}

		$docobj['lines'] = $lines;
		return json_encode($docobj);

	}


	function readDoc($docnumber){

		$genericDocument = new ErpDocumentIctBillHeader();
		$formStructure = json_encode($genericDocument->formStructure('NP', 'PR', 'read'), JSON_PRETTY_PRINT);

		$docnumber = $_GET['docnumber'];
		$apiObj = new ThisDocAPI();
		$docData = $this->_readDoc($docnumber, $formStructure);
		$docObj = json_decode($docData, true);

		// again read doc with doctype and formtype
		$doctype = $docObj['doctype'];
		$formtype = $docObj['formtype'];
		$formStructure = json_encode($genericDocument->formStructure($doctype, $formtype, 'read'), JSON_PRETTY_PRINT);
		$docData = $this->_readDoc($docnumber, $formStructure);
		$docObj = json_decode($docData, true);

		// $docObj['docstatus'] = $apiObj->docStatusTranslatorF[$docObj['docstatus']];

		$docLines = $docObj['lines'];
		unset($docObj['lines']);
		$newDocLines = array();
		foreach ($docLines as $docLine) {
			$currLine                = $docLine;
			// $currLine['linestatus'] = $this->lineStatusTranslatorF[$docLine['linestatus']];
			array_push($newDocLines, $currLine);
		}
		$docObj['lines'] = $newDocLines;

		return json_encode($docObj);

	}

	function readDocLineWise($docnumber, $idlines){

		$genericDocument = new ErpDocumentIctBillHeader();
		$formStructure = json_encode($genericDocument->formStructure('NP', 'PR', 'read'), JSON_PRETTY_PRINT);

		// $docnumber = $_GET['docnumber'];
		$docData = $this->_readDocLineWise($docnumber, $formStructure , $idlines);
		$docObj = json_decode($docData, true);

		$doctype = $docObj['doctype'];
		$formtype = $docObj['formtype'];
		$formStructure = json_encode($genericDocument->formStructure($doctype, $formtype, 'read'), JSON_PRETTY_PRINT);
		$docData = $this->_readDocLineWise($docnumber, $formStructure , $idlines);
		$docObj = json_decode($docData, true);


		$docLines = $docObj['lines'];
		unset($docObj['lines']);
		$newDocLines = array();
		foreach ($docLines as $docLine) {
			$currLine                = $docLine;
			array_push($newDocLines, $currLine);
		}
		$docObj['lines'] = $newDocLines;
		return json_encode($docObj);

	}



	function saveDoc($docdata, $formStructure){

		$docobj = json_decode($docdata, true);
		$doctype = $docobj['doctype'];
		$formtype = $docobj['formtype'];

		$genericDocument = new ErpDocumentIctBillHeader();
		$formStructure = json_encode($genericDocument->formStructure($doctype, $formtype, 'create'), JSON_PRETTY_PRINT);		

		if(isset($docobj['docnumber']) && $docobj['docnumber'] != ""){ // update Doc
			$returnJSON = $this->updateDoc($docdata, $formStructure);
			return json_encode($returnJSON);	
		} else {													   // create Doc
			$returnJSON = $this->createDoc($docdata, $formStructure);
			$returnJSON->createdocheader = "yes";
			return json_encode($returnJSON);
		}
	}



	function createDoc($docdata, $formStructure){
		$conn = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$formStructure = json_decode($formStructure, true);
		$tablename = $formStructure['schema']['tablename'];
		$doctype   = $formStructure['header']['doctype'];
		$formtype  = $formStructure['header']['formtype'];
		$doccounter= $formStructure['doccounter'];

		$docobj = json_decode($docdata, true);
		$doclins = $docobj['lines'];
		unset($docobj['lines']);

		foreach ($docobj as $key => $value) {
			$newValue = str_replace("'", "\'", $value);
			$docobj[$key] = $newValue;
		}

		foreach ($doclins as $key => $value) {
			$newValue = str_replace("'", "\'", $value);
			$doclins[$key] = $newValue;
		}

		$docnumber = $this->getNextDocNumber($doccounter);
		$docobj['docnumber'] = $docnumber;
		$newDocLines = array();
		foreach ($doclins as $docLine) {

			$currLine                = $docLine;
			// translate line status
			$currLine['doclinenumber'] = $docnumber . '-' . $currLine['linenumber'];
			// unset some field
			unset($currLine['_ckb_linechooser']);
			array_push($newDocLines, $currLine);
		}
		$docobj['lines'] = $newDocLines;

		// system entries
		// $docobj['lines'] = $doclins;

		$returnJSON = $this->_createDoc(json_encode($docobj), json_encode($formStructure));

		if($returnJSON->docnumber != ''){
			$sqlArray = array();
			foreach ($newDocLines as $index => $line) {
				$rrnumber = $line['rrnumber'];
				$doclinenumber = $line['doclinenumber'];
				$sql = "UPDATE erp_rrlines SET rrstatus = 3 , powonumber = '$returnJSON->docnumber',powolinenumber='$doclinenumber' WHERE rrnumber='$rrnumber'";
				$sqlArray[] = $sql;
			}	

			foreach ($sqlArray as $index => $sql) {
				$resultUpdate = $conn->query($sql);
			}

		}


		return $returnJSON;

	}


	function _createDoc($docdata, $formStructure){
		date_default_timezone_set("Asia/Dhaka");
		$conn = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$formStructure = json_decode($formStructure, true);
		$tablename = $formStructure['schema']['tablename'];
		$doctype   = $formStructure['header']['doctype'];
		$formtype  = $formStructure['header']['formtype'];
		$doccounter= $formStructure['doccounter'];

		$docobj = json_decode($docdata, true);
		$doclins = $docobj['lines'];
		unset($docobj['lines']);

		$sql_array = array();
		$hcolumnFields = array();
		$hfieldValues = array();
		// process header
		$docnumber = $docobj['docnumber'];
		unset($docobj['docnumber']);
		unset($docobj['docstatus']);
		unset($docobj['entrypersonbadge']);
		unset($docobj['entrypersonname']);
		unset($docobj['doccreationtime']);
		// system entries
		if($docnumber == ''){
			$docnumber = $this->getNextDocNumber($doccounter);
		}
		$hcolumnFields[] = 'docnumber';
		$hfieldValues[]  = $docnumber;

		$hcolumnFields[] = 'entrypersonbadge';
		$hfieldValues[]  = $_SESSION['LoggedBadge'];

		$entrypersonname = "";
		$sqlGetName = "SELECT * from mrd_employee_basicinfo where Badge='".$_SESSION['LoggedBadge']."';";
		$result = $conn->query($sqlGetName);
		while($row = $result->fetch_assoc()){
			$entrypersonname = $row['Name'];
		}
		$hcolumnFields[] = 'entrypersonname';
		$hfieldValues[]  = $entrypersonname;

		$hcolumnFields[] = 'docstatus';
		$hfieldValues[]  = '0';
		$hcolumnFields[] = 'doccreationtime';
		$hfieldValues[]  = date('Y-m-d H:i:s', time());

		foreach ($docobj as $fieldname => $fieldvalue) {
			$hcolumnFields[] = $fieldname;
			$hfieldValues[] = $fieldvalue;
		}

		// process lines
		foreach ($doclins as $index => $line) {

			$columnFields = array();
			$fieldValues = array();
			unset($line['lineentrytime']);
			unset($line['linestatus']);
			unset($line['idlines']);
			foreach ($line as $fieldname => $fieldvalue) {
				$columnFields[] = $fieldname;
				$fieldValues[] = $fieldvalue;
			}
			// push header data in line
			foreach ($hcolumnFields as $index => $fieldname) {
				$columnFields[] = $fieldname;
				$fieldValues[]  = $hfieldValues[$index];		
			}		

			$columnFields = implode(", ", $columnFields);
			$fieldValues  = "'" . implode("','", $fieldValues) . "'";

			$sql = "INSERT INTO $tablename ($columnFields) VALUES($fieldValues)";
			$sql_array[] = $sql;

		}

		// Execute Query
		foreach ($sql_array as $key => $sql) {
			$result = $conn->query($sql);	  
			if(!$result){
				array_push($returnJSON->errormsgs, "Error, $sql");
				return $returnJSON;
			}
		}
      	$conn->close();

		if ($result) {
			$returnJSON->docnumber = $docnumber;
		} else {
			array_push($returnJSON->errormsgs, "Error, please tell ERP department: commit failed.");
		}
		return $returnJSON;

	}

	function updateDoc($docdata, $formStructure){
		$conn = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$formStructure = json_decode($formStructure, true);
		$tablename = $formStructure['schema']['tablename'];		

		$newdocobj = json_decode($docdata, true);
		$docnumber = $newdocobj['docnumber'];
		
		$doclins = $newdocobj['lines']; // format: lines = array(0 => array, 1 => array, ....)
		unset($newdocobj['lines']);

		foreach ($newdocobj as $key => $value) {
			$newValue = str_replace("'", "\'", $value);
			$newdocobj[$key] = $newValue;
		}
		
		foreach ($doclins as $key => $value) {
			$newValue = str_replace("'", "\'", $value);
			$doclins[$key] = $newValue;
		}

		$newDocLines = array();
		foreach ($doclins as $docLine) {

			$currLine                = $docLine;
			// translate line status
			$currLine['doclinenumber'] = $docnumber . '-' . $currLine['linenumber'];
			// $currLine['itemcode'] = $docnumber . '-' . $currLine['linenumber'];
			// unset some field
			unset($currLine['linestatus']);
			unset($currLine['lineentrytime']);
			unset($currLine['_ckb_linechooser']);
			array_push($newDocLines, $currLine);
		}

		$newdocobj['lines'] = $newDocLines;
		// $newdocobj['docstatus'] = $this->docStatusTranslatorB[$newdocobj['docstatus']]; // it should be base class
		$returnJSON = $this->_updateDoc(json_encode($newdocobj), json_encode($formStructure));

		// if($returnJSON->docnumber != ''){
		// 	$sqlArray = array();
		// 	$prLineArray = array();
		// 	foreach ($newDocLines as $index => $line) {
		// 		$doclinenumber = $line['doclinenumber'];
		// 		$sql = "UPDATE  erp_nonpo po, erp_nonpo pr SET $updateString WHERE po.requisitionlinenumber=pr.doclinenumber AND pr.doclinenumber='$doclinenumber'";
		// 		$sqlArray[] = $sql;
		// 		$prLineArray[] = $doclinenumber;
		// 	}	

		// 	foreach ($sqlArray as $index => $sql) {
		// 		$resultUpdate = $conn->query($sql);
		// 	}

		// }

		return $returnJSON;

	}


	function _updateDoc($docdata, $formStructure){
		$conn = new ErpDbConn;
		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$formStructure = json_decode($formStructure, true);
		$tablename = $formStructure['schema']['tablename'];		

		$newdocobj = json_decode($docdata, true);
		$docnumber = $newdocobj['docnumber'];
		$olddocobj = json_decode($this->_readDoc($docnumber, json_encode($formStructure)), true);

		// $newdocobj['docstatus'] = $this->docStatusTranslatorB[$newdocobj['docstatus']];

		$docLinesArray = $newdocobj['lines']; // format: lines = array(0 => array, 1 => array, ....)
		unset($newdocobj['lines']);
		$docHeaderArray = $newdocobj;

		// Generating query varriables
		// HEADER
		// update SQL for header
		$sql_array = array();
		$updateSet = "";
		foreach ($docHeaderArray as $keyHeader => $valueHeader) {
		if ($keyHeader != 'docnumber') {
			$updateSet .= $keyHeader . "=" . "'" . $valueHeader . "',";
		}
		}

		date_default_timezone_set("Asia/Dhaka");
		$updateSet .= "headerlastupdateuser =" . "'" . $_SESSION["USERNAME"] . "',"; 

		$lastUpdateTime  = date('Y-m-d H:i:s', time());
		$updateSet .= "headerlastupdatedatetime =" . "'" . $lastUpdateTime . "',"; 

		$updateSet = rtrim($updateSet ,',');
		$sqlH = "UPDATE $tablename SET $updateSet WHERE docnumber = '$docnumber'";
		
		// LINES
		// Case 1 - New Lines: idlines will be blank. (user can add new lines in document's update mode.)
		// Case 2 - Existing Lines: idlines will be specified. (user just updated these lines)
		// Case 3 - Removed Lines: line will be missing.

		// Calculate the differences
		foreach ($docLinesArray as $docLine) {
			$lineNumbers_new[] = $docLine['linenumber'];
		}
		$lineNumbers_new = array_unique($lineNumbers_new, SORT_NUMERIC);
		foreach ($olddocobj['lines'] as $docLine) {
			$lineNumbers_old[] = $docLine['linenumber'];
		}
		$lineNumbers_old = array_unique($lineNumbers_old, SORT_NUMERIC);

		$lineNumbers_added   = array_diff($lineNumbers_new, $lineNumbers_old);
		$lineNumbers_same    = array_intersect($lineNumbers_new, $lineNumbers_old);
		$lineNumbers_removed = array_diff($lineNumbers_old, $lineNumbers_new);


		/*
		Iterate through the lines and build an array of SQL queries
		*/
		foreach ($docLinesArray as $lineIndex => $LineArray) {
		// here, value is also an array
		// $idlines_this = $LineArray['idlines'];
		$this_linenumber = $LineArray['linenumber'];
		unset($LineArray['idlines']);

		if (in_array($this_linenumber, $lineNumbers_added)) {
			  // Case 1 - New Line
				$columnFields = array();
				$fieldValues = array();
				unset($LineArray['lineentrytime']);
				foreach ($LineArray as $fieldname => $fieldvalue) {
					$columnFields[] = $fieldname;
					$fieldValues[] = $fieldvalue;
				}
				$columnFields[] = 'docnumber';
				$fieldValues[] = $docnumber;

				$columnFields = implode(", ", $columnFields);
				$fieldValues  = "'" . implode("','", $fieldValues) . "'";
				$sql = "INSERT INTO $tablename ($columnFields) VALUES($fieldValues)";
				$sql_array[] = $sql;

			} else {
			  // Case 2 - Existing Line
				$updateSet = "";
				foreach ($LineArray as $fieldname => $fieldvalue) {
					$updateSet .= $fieldname . "=" . "'" . $fieldvalue . "',";
				}			
				$updateSet = rtrim($updateSet ,',');
				$sql = "UPDATE $tablename SET $updateSet WHERE docnumber = '$docnumber' AND linenumber = '$this_linenumber'";
				$sql_array[] = $sql;
			}
		}

		// Case 3 - Removed Lines
		if (sizeof($lineNumbers_removed) > 0) {
			$lineNumbers_removed = implode(",", $lineNumbers_removed);
			$sql = "DELETE FROM $tablename WHERE docnumber = '$docnumber' AND linenumber IN ($lineNumbers_removed)";
			$sql_array[] = $sql;
		}


		// Execute Query
		$sql_array[] = $sqlH;
		foreach ($sql_array as $key => $sql) {
			$result = $conn->query($sql);	  
			if(!$result){
				array_push($returnJSON->errormsgs, "Error, $sql");
				return $returnJSON;
			}
		}

        $insertlogObj = new InsertLogTableData();
        $insertlogObj->insertDataIntoLogTable_New('docnumber', $docnumber, 'erp_ict_billing_header', 'erp_ict_billing_header_log', 'Update');		
		$conn->close();

		if ($result) {
			$returnJSON->docnumber = $docnumber;
		} else {
			array_push($returnJSON->errormsgs, "Error, please tell ERP department: commit failed.");
		}
		return $returnJSON;

	}



	function changeDocStatus($docnumber, $docstatus){

		$returnJSON            = new stdClass();
		$returnJSON->errormsgs = array();

		$genericDocument = new ErpDocumentIctBillHeader();
		$formStructure = json_encode($genericDocument->formStructure($formtype, $crudmode), JSON_PRETTY_PRINT);

		$returnJSON = $this->_changeDocStatus($docnumber, $docstatus, $formStructure);

		// $this->updateAllRRLineStatus_sentToTextile($docnumber);

		return $returnJSON;

	}







	function _saveLine($line){
		$conn = new ErpDbConn;
		date_default_timezone_set("Asia/Dhaka"); 
		$insertlogObj = new InsertLogTableData();

		$lineObj = json_decode($line, true);

		foreach ($lineObj as $key => $value) {
			$newValue = str_replace("'", "\'", $value);
			$lineObj[$key] = $newValue;
		}
		
		$docnumber = $lineObj['docnumber'];
		$idlines = $lineObj['idlines'];

		$doctype = $lineObj['doctype'];
		$formtype = $lineObj['formtype'];

		$genericDocument = new ErpDocumentIctBillHeader();
		$formStructure = json_encode($genericDocument->formStructure($doctype, $formtype, 'create'), JSON_PRETTY_PRINT);	
		$formStructure = json_decode($formStructure, true);

		$tablename = $formStructure['schema']['tablename'];
		$doccounter= $formStructure['doccounter'];

        if($idlines == ''){
            if(isset($lineObj['headercreationdatetime'])) $lineObj['headercreationdatetime'] = date('Y-m-d H:i:s', time());
            if(isset($lineObj['headercreationuser'])) $lineObj['headercreationuser'] = $_SESSION['USERNAME'];
            if(isset($lineObj['headerlastupdatedatetime'])) unset($lineObj['headerlastupdatedatetime']);
            if(isset($lineObj['headerlastupdateuser'])) unset($lineObj['headerlastupdateuser']);            
            if(isset($lineObj['creationdatetime'])) $lineObj['creationdatetime'] = date('Y-m-d H:i:s', time());
            if(isset($lineObj['creationuser'])) $lineObj['creationuser'] = $_SESSION['USERNAME'];
            if(isset($lineObj['lastupdatedatetime'])) unset($lineObj['lastupdatedatetime']);
            if(isset($lineObj['lastupdateuser'])) unset($lineObj['lastupdateuser']); 

        } else{
            if(isset($lineObj['headercreationdatetime'])) unset($lineObj['headercreationdatetime']);
            if(isset($lineObj['headercreationuser'])) unset($lineObj['headercreationuser']);              
            if(isset($lineObj['creationdatetime'])) unset($lineObj['creationdatetime']);
            if(isset($lineObj['creationuser'])) unset($lineObj['creationuser']);  
        }
        if($docnumber != ''){
            if(isset($lineObj['headerlastupdatedatetime'])) $lineObj['headerlastupdatedatetime'] = date('Y-m-d H:i:s', time());
            if(isset($lineObj['headerlastupdateuser'])) $lineObj['headerlastupdateuser'] = $_SESSION['USERNAME'];            
            if(isset($lineObj['lastupdatedatetime'])) $lineObj['lastupdatedatetime'] = date('Y-m-d H:i:s', time());
            if(isset($lineObj['lastupdateuser'])) $lineObj['lastupdateuser'] = $_SESSION['USERNAME'];
        } 
		
		//check for duplicate Supplier entry
		$suppliername = $lineObj['suppliername'];
        $sqlcheck = "SELECT * FROM erp_ict_billing_header WHERE suppliername = '$suppliername'";
        $resultcheck = $conn->conn->query($sqlcheck);
        if($resultcheck->num_rows != 0){
        	$docnumber =$resultcheck->fetch_assoc()['docnumber'];

			$lineObj['alreadyCreated'] = 'yes';
			$lineObj['docnumber'] = $docnumber;
			return json_encode($lineObj);
        } else{
        
			// create doc with this line
			if($docnumber == ""){
				// process lines
				$columnFields = array();
				$fieldValues = array();
				unset($lineObj['linenumber']);
				unset($lineObj['lineentrytime']);
				unset($lineObj['linestatus']);
				unset($lineObj['idlines']);
				// process header
				unset($lineObj['docnumber']);
				unset($lineObj['docstatus']);
				unset($lineObj['_ckb_linechooser']);

				$docnumber = $this->getNextDocNumber($doccounter);
				$lineObj['docnumber'] = $docnumber;
				$lineObj['linenumber'] = '1';

				// apply critaria if have
				$lineObj['doclinenumber'] = $docnumber . '-' . $lineObj['linenumber'];
				// $lineObj['itemcode'] = $docnumber . '-' . $lineObj['linenumber'];
				
				foreach ($lineObj as $fieldname => $fieldvalue) {
					$columnFields[] = $fieldname;
					$fieldValues[] = $fieldvalue;
				}		

				$columnFields = implode(", ", $columnFields);
				$fieldValues  = "'" . implode("','", $fieldValues) . "'";
				$sql = "INSERT INTO $tablename ($columnFields) VALUES($fieldValues)";

				// return $sql;
				$conn->conn->query($sql);
				$idlines = $conn->conn->insert_id;

            	$insertlogObj->insertDataIntoLogTable_New('idlines', $idlines, 'erp_ict_billing_header', 'erp_ict_billing_header_log', 'Create');

				$lineData = $this->readDocLineWise($docnumber, $idlines);
				$lineObj = json_decode($lineData, true);
				$lineObj['doccreate'] = 'yes';
				return json_encode($lineObj);

			}

			// insert new line
			if($idlines == ""){

				// process lines
				$columnFields = array();
				$fieldValues = array();
				unset($lineObj['linenumber']);
				unset($lineObj['lineentrytime']);
				unset($lineObj['linestatus']);
				unset($lineObj['idlines']);
				unset($lineObj['_ckb_linechooser']);

				$sql = "SELECT idlines, linenumber FROM $tablename WHERE docnumber = '$docnumber' ORDER BY idlines DESC";
				$queryResult = $conn->query($sql);
				$last_linenumber =  $queryResult->fetch_assoc()['linenumber'];
				$lineObj['linenumber'] = (int)$last_linenumber + 1;

				// apply critaria if have
				$lineObj['doclinenumber'] = $docnumber . '-' . $lineObj['linenumber'];
				// $lineObj['itemcode'] = $docnumber . '-' . $lineObj['linenumber'];
				
				foreach ($lineObj as $fieldname => $fieldvalue) {
					$columnFields[] = $fieldname;
					$fieldValues[] = $fieldvalue;
				}		


				$columnFields = implode(", ", $columnFields);
				$fieldValues  = "'" . implode("','", $fieldValues) . "'";
				$sql = "INSERT INTO $tablename ($columnFields) VALUES($fieldValues)";
				// return $sql;
				$conn->conn->query($sql);
				$idlines = $conn->conn->insert_id;

				$insertlogObj->insertDataIntoLogTable_New('idlines', $idlines, 'erp_ict_billing_header', 'erp_ict_billing_header_log', 'Create');
				
				return $this->readDocLineWise($docnumber, $idlines);

			}

			// update line
			if($idlines != ""){
				unset($lineObj['linenumber']);
				unset($lineObj['lineentrytime']);
				unset($lineObj['linestatus']);
				unset($lineObj['_ckb_linechooser']);

				$updateSet = "";
				foreach ($lineObj as $fieldname => $fieldvalue) {
					$updateSet .= $fieldname . "=" . "'" . $fieldvalue . "',";
				}		

				$updateSet = rtrim($updateSet ,',');
				$sql = "UPDATE $tablename SET $updateSet WHERE idlines = '$idlines'";

				// return $sql;

				$conn->query($sql);

				$insertlogObj->insertDataIntoLogTable_New('idlines', $idlines, 'erp_ict_billing_header', 'erp_ict_billing_header_log', 'Update');

				return $this->readDocLineWise($docnumber, $idlines);

			}
		}

	}


	function uploadFile($formStructure){

		$conn = new ErpDbConn;		
		$returnJSON  = new stdClass();
		$returnJSON->errormsgs = array();

		$fileClientObj = new FileClient();
		$docnumber = $_POST['docnumber'];
		$linenumber = $_POST['linenumber'];
		$directorypath = $_POST['directorypath'];
		$filepathsavingcolumnname = $_POST['filepathsavingcolumnname'];

	    $rootPath = $_SERVER['DOCUMENT_ROOT'];
	    $thisPath = dirname($_SERVER['PHP_SELF']);
	    $onlyPath = str_replace($rootPath, '', $thisPath);
	    // $directoryPath = $rootPath . "/attachments/erp-inquiry/inquiry-requisition/" . $docnumber . "-" . $linenumber;
	    $directoryPath = $rootPath . $directorypath;

		$n = 0;
		$filePaths = array();
		foreach($_FILES as $file){

		    $fileFieldName = "file_" . $n;
			$file = $_FILES[$fileFieldName];
			$fileName = $_FILES[$fileFieldName]['name'];
			$fileNewName = $docnumber . "--" . $linenumber . "_" . $fileName; // if user want to rename file name
			$n++;

			$filePath = $fileClientObj->saveFileInGivenDirectory_SingleFile($directoryPath, $fileFieldName, $file, true, $fileNewName);
			if(!$filePath){
				array_push($returnJSON->errormsgs, $fileName);
				$returnJSON->result = 'fail to upload';
				return json_encode($returnJSON);
			} 
			$filePath = "/attachments" . explode("attachments", $filePath)[1];
			$filePaths[] = $filePath;
		}

		if(count($filePaths) > 1){
			$filePaths = implode("::", $filePaths);
		} else {
			$filePaths = $filePaths[0] . "::";
		}

		$formStructure = json_decode($formStructure, true);
		$tablename = $formStructure['schema']['tablename'];

		// concate file path if exist
		$sql = "SELECT $filepathsavingcolumnname FROM $tablename WHERE docnumber = '$docnumber' AND linenumber = '$linenumber'";
		$queryResult = $conn->query($sql);
		$row = $queryResult->fetch_assoc();
		$filePath = $row[$filepathsavingcolumnname];
		if($filePath != "" && $filePath != null){
			// $filePath = explode("::", $filePath);
			$filePaths = $filePath . $filePaths;
		}

        $sql = "UPDATE $tablename SET $filepathsavingcolumnname = '$filePaths' WHERE docnumber = '$docnumber' AND linenumber = '$linenumber'";
		$queryResult  = $conn->query($sql);

		if($queryResult){
			$returnJSON->result = 'success';
			return json_encode($returnJSON);			
		} else {
			array_push($returnJSON->errormsgs, $sql);
			return json_encode($returnJSON);
		}

	}

	function updateTotalAmount($docnumber){
		$conn = new ErpDbConn;
		date_default_timezone_set("Asia/Dhaka"); 

		$sqlTotalAmount = "SELECT SUM(amount) AS totalamount, SUM(vatamount) AS totalvatamount, SUM(tdsamount) AS totaltdsamount, SUM(discountamount) AS totaldiscountamount, SUM(finalamount) AS totalfinalamount  FROM erp_ict_billing WHERE docnumber='$docnumber'";
		$queryResult = $conn->query($sqlTotalAmount);

		$row = $queryResult->fetch_assoc();

		$totalamount = $row['totalamount'];
		$totalvatamount = $row['totalvatamount'];
		$totaltdsamount = $row['totaltdsamount'];
		$totaldiscountamount = $row['totaldiscountamount'];
		$totalfinalamount = $row['totalfinalamount'];

		$totalamount = number_format($totalamount, 2, '.', '');
		$totalvatamount = number_format($totalvatamount, 2, '.', '');
		$totaltdsamount = number_format($totaltdsamount, 2, '.', '');
		$totaldiscountamount = number_format($totaldiscountamount, 2, '.', '');
		$totalfinalamount = number_format($totalfinalamount, 2, '.', '');

		$sqlUpdateTotalAmount = "UPDATE erp_ict_billing SET totalamount='$totalamount', totalvatamount='$totalvatamount', totaltdsamount='$totaltdsamount', totaldiscountamount='$totaldiscountamount', totalfinalamount='$totalfinalamount' WHERE docnumber='$docnumber'";
		$queryResult = $conn->query($sqlUpdateTotalAmount);		

		$sqlHUpdateTotalAmount = "UPDATE erp_ict_billing_header SET totalamount='$totalamount', totalvatamount='$totalvatamount', totaltdsamount='$totaltdsamount', totaldiscountamount='$totaldiscountamount', totalfinalamount='$totalfinalamount' WHERE doclinenumber='$docnumber'";
		$queryResult = $conn->query($sqlHUpdateTotalAmount);

		return;
	}

	function getAmountCalculation($singleline){
		$conn = new ErpDbConn;

		$quantity = $singleline['quantity'];
		$unitprice = $singleline['unitprice'];
		$discountpercent = $singleline['discountpercent'];
		
		// if($quantity == '') return;
		if($quantity == '') $quantity = 0;
		if($discountpercent == '') $discountpercent = 0;
		$paymentpercent = 100 - $discountpercent;
		$netprice = $quantity * $unitprice;
		if($discountpercent == '' || $discountpercent  == 0){
			$amountexcludingvat = $netprice;
		} else{
			$amountexcludingvat = $netprice * ($paymentpercent/100);
		}
			$vatamount = $amountexcludingvat * (5/100);
			$tdsamount = $amountexcludingvat * (10/100);
			$vatamount = round($vatamount);
			$tdsamount = round($tdsamount);
			$amountexcludingvat = round($amountexcludingvat);
			$netamount = $amountexcludingvat - $tdsamount;
			$finalamount = $amountexcludingvat + $vatamount;
			$amount = ($finalamount * 100) / $paymentpercent;
			$amount = round($amount);
			$discountamount = $amount * ($discountpercent / 100);
			$discountamount = round($discountamount);
		
		$returnArray = array();

		$returnArray['amountexcludingvat']  = $amountexcludingvat;
		$returnArray['vatamount']  = $vatamount;
		$returnArray['tdsamount']  = $tdsamount;
		$returnArray['netamount']  = $netamount;
		$returnArray['finalamount']  = $finalamount;
		$returnArray['amount']  = $amount;
		$returnArray['discountamount']  = $discountamount;

		return $returnArray;
	} 


	function checkNewLineEntry($docnumber){
		$returnJson = new stdClass();
		$conn = new ErpDbConn;
        $insertlogObj = new InsertLogTableData();
        $columnFields = array();
        $fieldValues = array();
        $currentMonth = date("M-y");
        $username = $_SESSION['USERNAME'];
        $today = date('Y-m-d H:i:s', time());
        $headerData = array();

        $unsetFileds = array('idlines','doclinenumber', 'linenumber', 'billingmonth', 'finalamount', 'totalamount', 'totalfinalamount', 'totalvatamount', 'totaldiscountamount', 'headerlastupdatedatetime', 'headerlastupdateuser', 'creationdatetime', 'creationuser', 'lastupdatedatetime', 'lastupdateuser');

        $sql = "SELECT * FROM erp_ict_billing_header WHERE docnumber='$docnumber' ORDER BY idlines DESC LIMIT 1";
        $data =  json_decode( $conn->sqlToJson($sql), true )[0];
		
		$last_linenumber =  $data['linenumber'];

		$billingmonth = $data['billingmonth'];
		if($billingmonth == $currentMonth){
			$returnJson->isApprove = 'No';
			// return json_encode($returnJson);
		} else{
			
            $headerData['docnumber'] = $docnumber;
            $headerData['doctype'] = $data['doctype'];
            $headerData['headercreationdatetime'] = $data['headercreationdatetime'];
            $headerData['headercreationuser'] = $data['headercreationuser'];
            $headerData['suppliername'] = $data['suppliername'];
            $headerData['supplieraddress'] = $data['supplieraddress'];
            $headerData['linenumber'] = (int)$last_linenumber + 1;
        	$headerData['doclinenumber'] = $docnumber . '-' . $headerData['linenumber'];
        	$headerData['billingmonth'] = $currentMonth;
        	$headerData['headerlastupdatedatetime'] = $today;
        	$headerData['headerlastupdateuser'] = $username;
        	$headerData['creationdatetime'] = $today;
        	$headerData['creationuser'] = $username;

        	foreach ($headerData as $fieldname => $fieldvalue) {
                $columnFields[] = $fieldname;
                $fieldValues[] = $fieldvalue;
            }   

            $columnFields = implode(", ", $columnFields);
            $fieldValues  = "'" . implode("','", $fieldValues) . "'";

            $sql1 = "INSERT INTO erp_ict_billing_header ($columnFields) VALUES($fieldValues)";
            $result1 = $conn->query($sql1);
            $last_id = $conn->conn->insert_id;

            $sqlUpdateH = "UPDATE erp_ict_billing_header SET headerlastupdatedatetime = '$today' WHERE docnumber = '$docnumber'";
            $conn->query($sqlUpdateH);

            //=======================================For log table Entry start===============================
            $insertlogObj = new InsertLogTableData();
            $insertlogObj->insertDataIntoLogTable_New('idlines', $last_id, 'erp_ict_billing_header', 'erp_ict_billing_header_log', 'Create');
            //==============================================================

            //==================For Individual entry================================
            $unsetFileds = array('idlines','doclinenumber', 'linenumber', 'billingmonth', 'finalamount', 'totalamount', 'totalfinalamount', 'totalvatamount', 'totaldiscountamount', 'headerlastupdatedatetime', 'headerlastupdateuser', 'creationdatetime', 'creationuser', 'lastupdatedatetime', 'lastupdateuser');

			$suppliername =  $headerData['suppliername'];
			$suppliersql = "SELECT * FROM erp_ict_billing_library WHERE suppliername = '$suppliername'";
        	$datasupplier =  json_decode( $conn->sqlToJson($suppliersql), true );
        	$linenumber = 1;
        	foreach ($datasupplier as $singleline) {
        		$lcolumnFields = array();
        		$lfieldValues = array();
        		$billingData = array();
        		$returnArray = $this->getAmountCalculation($singleline);

				$billingData['docnumber'] = $headerData['doclinenumber'];
				$billingData['doclinenumber'] = $headerData['doclinenumber'] .'-'. $linenumber;
				$billingData['linenumber'] = $linenumber;
				$billingData['doctype'] = 'BILL';
				$billingData['billingmonth'] = $currentMonth;
				$billingData['suppliername'] = $suppliername;
				$billingData['supplieraddress'] = $supplieraddress;
				$billingData['division'] = $singleline['division'];
				$billingData['subdivision'] = $singleline['subdivision'];
				$billingData['description'] = $singleline['description'];
				$billingData['unitprice'] = $singleline['unitprice'];
				$billingData['servicecharge'] = $singleline['servicecharge'];
				$billingData['discountpercent'] = $singleline['discountpercent'];
				$billingData['quantity'] = $singleline['quantity'];
				$billingData['vatpercent'] = '5.00';
				$billingData['tdspercent'] = '10.00';
				$billingData['creationdatetime'] = $today;
				$billingData['creationuser'] = $username;
				$billingData['headercreationdatetime'] = $today;
				$billingData['headercreationuser'] = $username;
				$billingData['amountexcludingvat'] = $returnArray['amountexcludingvat'];
				$billingData['vatamount'] = $returnArray['vatamount'];
				$billingData['tdsamount'] = $returnArray['tdsamount'];
				$billingData['netamount'] = $returnArray['netamount'];
				$billingData['finalamount'] = $returnArray['finalamount'];
				$billingData['amount'] = $returnArray['amount'];
				$billingData['discountamount'] = $returnArray['discountamount'];

				foreach ($billingData as $fieldname => $fieldvalue) {
					$lcolumnFields[] = $fieldname;
					$lfieldValues[] = $fieldvalue;
				}

                $lcolumnFields = implode(", ", $lcolumnFields);
            	$lfieldValues  = "'" . implode("','", $lfieldValues) . "'";

            	$sqll = "INSERT INTO erp_ict_billing ($lcolumnFields) VALUES($lfieldValues)";
            	$resultl = $conn->query($sqll);
            	$llast_id = $conn->conn->insert_id;    

            	//=======================================For log table Entry start===============================
            	$insertlogObj = new InsertLogTableData();
            	$insertlogObj->insertDataIntoLogTable_New('idlines', $llast_id, 'erp_ict_billing', 'erp_ict_billing_log', 'Create');
            	//==============================================================   		
				

				$linenumber++;
            }
            $this->updateTotalAmount($headerData['doclinenumber']);
		}
		
		// For extra check duplicate billing month
		$sqlcheck = "SELECT bill.* FROM erp_ict_billing_header bill INNER JOIN (SELECT * FROM erp_ict_billing_header GROUP BY billingmonth, suppliername HAVING COUNT(*) > 1) dup ON bill.billingmonth = dup.billingmonth";
        $queryResultcheck = $conn->query($sqlcheck);
		$queryRowsNum = $queryResultcheck->num_rows;
		if($queryRowsNum != 0){
			while($rowcheck = $queryResultcheck->fetch_assoc()){
				$billingmonth = $rowcheck['billingmonth'];
				$doclinenumber = $rowcheck['doclinenumber'];

            	//=======================================For log table Entry start===============================
            	$insertlogObj = new InsertLogTableData();
            	$insertlogObj->insertDataIntoLogTable_New('doclinenumber', $doclinenumber, 'erp_ict_billing_header', 'erp_ict_billing_header_log', 'Delete');
            	$insertlogObj->insertDataIntoLogTable_New('docnumber', $doclinenumber, 'erp_ict_billing', 'erp_ict_billing_log', 'Delete');
            	//============================================================== 


				$sqldeleteH = "DELETE FROM erp_ict_billing_header WHERE doclinenumber='$doclinenumber'";
				// error_log('dft--'.$sqldeleteH);
        		$conn->query($sqldeleteH);			

        		$sqldelete = "DELETE FROM erp_ict_billing WHERE docnumber='$doclinenumber'";
        		$conn->query($sqldelete);
        	}
        	$returnJson->isApprove = 'NoDup';
		}

		if($queryResult){
			$returnJson->result = 'success';
		} else {
			$returnJson->result = 'fail';
		}
		$conn->close();
		return json_encode($returnJson);
	}

	function deleteFile($formStructure){

		$conn = new ErpDbConn;		
		$returnJSON  = new stdClass();
		$returnJSON->errormsgs = array();

	    $rootPath = $_SERVER['DOCUMENT_ROOT'];
	    // $directoryPath = $rootPath . "/attachments/erp-inquiry/inquiry-requisition/" . $docnumber . "-" . $linenumber;
	    $filepathcolumnname =  $_POST['filepathcolumnname'];
	    $keycolumnname =  $_POST['keycolumnname'];
	    $keycolumnvalue =  $_POST['keycolumnvalue'];
	    $filePath =  $_POST['filePath'];
	    $searchPath = $filePath;
	    $deletePath = $filePath;

	    $filePath = substr($filePath, 1);
		$filePath = $rootPath . $filePath;

		$fileClientObj = new FileClient();
		$result = $fileClientObj->deleteFile($filePath);

		$formStructure = json_decode($formStructure, true);
		$tablename = $formStructure['schema']['tablename'];

		// concate file path if exist
		$sql = "SELECT $filepathcolumnname FROM $tablename WHERE $keycolumnname = '$keycolumnvalue'";
		$queryResult = $conn->query($sql);
		$row = $queryResult->fetch_assoc();
		$existFilePath = $row[$filepathcolumnname];

		if($existFilePath != "" && $existFilePath != null){

			$allFilePaths = split("::", $existFilePath);
			$deleteFilePath = array($deletePath);

			$keepFilePaths = array_diff($allFilePaths, $deleteFilePath);
			$keepFilePaths = implode("::", $keepFilePaths);

	        $sql = "UPDATE $tablename SET $filepathcolumnname = '$keepFilePaths' WHERE $keycolumnname = '$keycolumnvalue'";
			$queryResult  = $conn->query($sql);

			if($queryResult){
				$returnJSON->result = 'success';
				return json_encode($returnJSON);			
			} else {
				array_push($returnJSON->errormsgs, $sql);
				return json_encode($returnJSON);
			}
		
		} else {

			$returnJSON->result = 'fail';
			return json_encode($returnJSON);		

		}


	}

	function confirmBill($doclinenumbers){
		$conn = new ErpDbConn;
		date_default_timezone_set("Asia/Dhaka"); 		
		$today = date("Y-m-d H:i:s");
		$username = $_SESSION['USERNAME'];

		$doclinenumbers = json_decode($doclinenumbers, true);
		foreach ($doclinenumbers as $index => $doclinenumber) {

			$sql = "UPDATE erp_ict_billing_header SET linestatus = '1', confirmationtime = '$today', confirmationuser = '$username', headerlastupdatedatetime = '$today', headerlastupdateuser = '$username', lastupdatedatetime = '$today', lastupdateuser = '$username' WHERE doclinenumber = '$doclinenumber'";
			$result = $conn->query($sql);

			$insertlogObj = new InsertLogTableData();
            $insertlogObj->insertDataIntoLogTable_New('doclinenumber', $doclinenumber, 'erp_ict_billing_header', 'erp_ict_billing_header_log', 'Update');

		}
		$conn->close();
 
   		if($result){
      		$data->result = 'success';
			return json_encode($data);
    	}
	}

		

}


/**
 * Routing ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 */
if ( basename(__FILE__) == basename($_SERVER["SCRIPT_FILENAME"]) ) {
    // called directly
	if ( $_SERVER['REQUEST_METHOD'] == 'GET' ) {

		if(isset($_GET['reqType'])){

			$reqType = $_GET['reqType'];
			$obTest  = new ThisDocAPI();

			if($reqType == 'readDoc') {

				$docnumber = $_GET['docnumber'];
				$idlines   = $_GET['idlines'];
				if($idlines != ""){
					$returnData = $obTest->readDocLineWise($docnumber, $idlines);
				} else {
					$returnData = $obTest->readDoc($docnumber);
				}
				echo $returnData;

			}

			if($reqType == '_searchDoc') {
				$genericDocument = new ErpDocumentIctBillHeader();
				$formStructure = json_encode($genericDocument->formStructure('NP', '', ''), JSON_PRETTY_PRINT);

				$where = $_GET['where'];
				$columns = $_GET['columns'];
				$returnData = $obTest->_searchDoc($formStructure, $where, $columns);
				echo $returnData;
			}

			if($reqType == 'searchHeaderInfo') {

				$returnData = $obTest->searchHeaderInfo($_GET);
				echo $returnData;

			}

			if($reqType == "checkNewLineEntry"){

				$docnumber = $_GET['docnumber'];
				$returnData = $obTest->checkNewLineEntry($docnumber);
				echo $returnData;
			}

		}


	} else if( $_SERVER['REQUEST_METHOD'] == 'POST' ){
	
		if(isset($_POST['reqType'])){

			$reqType = $_POST['reqType'];
			$obTest  = new ThisDocAPI();

			if($reqType == "saveDoc"){
		
				$docobj = $_POST['docobj'];
				$returnData = $obTest->saveDoc($docobj);
				echo $returnData;
			}

			if($reqType == "_saveLine"){
		
				$line = $_POST['line'];
				$returnData = $obTest->_saveLine($line);
				echo $returnData;
			}

			if($reqType == "changeDocStatus"){

				$docnumber = $_POST['docnumber'];
				$docstatus = $_POST['docstatus'];
				$returnData = $obTest->changeDocStatus($docnumber, $docstatus);
				echo $returnData;
			}

			if($reqType == "cancelPRLine"){

				$idlines = $_POST['idlines'];
				$returnData = $obTest->cancelPRLine($idlines);
				echo $returnData;
			}		
			
			if($reqType == "uploadFile"){

				$genericDocument = new ErpDocumentIctBillHeader();
				$formStructure = json_encode($genericDocument->formStructure($formtype, $crudmode), JSON_PRETTY_PRINT);				
				$returnData = $obTest->uploadFile($formStructure);
				echo $returnData;
			}

			if($reqType == "deleteFile"){

				$genericDocument = new ErpDocumentIctBillHeader();
				$formStructure = json_encode($genericDocument->formStructure($formtype, $crudmode), JSON_PRETTY_PRINT);				
				$returnData = $obTest->deleteFile($formStructure);
				echo $returnData;
			}

			if($reqType == "checkNewLineEntry"){

				$docnumber = $_POST['docnumber'];
				$returnData = $obTest->checkNewLineEntry($docnumber);
				echo $returnData;
			}
			if($reqType == "confirmBill"){

				$doclinenumbers = $_POST['doclinenumbers'];
				$returnData = $obTest->confirmBill($doclinenumbers);
				echo $returnData;
			}


		}



	}

} else {
    // included/required

}
?>