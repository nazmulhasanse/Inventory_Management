<?php
session_start();
$directory = __DIR__ ;
require_once $_SERVER["DOCUMENT_ROOT"] . '/includes/configli.php';         // mysql connections
require_once __DIR__ . "/classes/myclassautoloader.php";
/**
* ThisListAPI class
*/
class ThisListAPI extends BaseDocAPI
{	
	public $conn;
	public $queryResult;
	public $sql;
	public $dbname;

	public $poFormTypeTransaltor = array(
		'Projection' => 'Blanket',
		'Confirmed'  => 'Under Blanket',
		'direct'     => 'Blanket',
		);

	public function __construct($dbnum = 1) {
		if ($dbnum === '2') {
			$this->conn = new ErpDbConn('2');
			$this->dbname = "erpprod_bulbul";
		} else {
			$this->conn = new ErpDbConn;
			$this->dbname = "erpprod";
		}
	}

		function getBlanketPOLineTable($params){

		$fieldArray = array(
			'idlines'                => '`po`.`idlines`',
			'doctype'                => '`po`.`doctype`',
			'formtype'               => '`po`.`formtype`',
			'company'                => '`po`.`company`',
			'docnumber'              => '`po`.`docnumber`',
			'linenumber'             => '`po`.`linenumber`',
			'ubpolines'              => 'virtual', // under blanket po lines numvre
			'rrnumber'               => '`po`.`rrnumber`',
			'docstatus'              => '`po`.`docstatus`',
			'linestatus'             => '`po`.`linestatus`',
			'inhousedstatus'         => 'virtual',
			'numberoflotrcv'         => 'virtual',
			'numberofqualitychecked' => 'virtual',
			'itemtype'               => '`po`.`itemtype`',
			'itemcode'               => '`po`.`itemcode`',
			'itemdescription'        => '`po`.`itemdescription`',
			'tnxqty'                 => '`po`.`tnxqty`',
			'iduom'                  => '`po`.`iduom`',
			'consumtionstatus'       => 'virtual',
			'consumedqty'            => 'virtual',
			'balanceqty'             => 'virtual',
			'shipdatetoapparel'      => 'virtual',
			'internalplannedeta'     => 'internalplannedeta',
			'internalplannedqty'     => 'internalplannedqty',
			'publishedplannedeta'    => 'publishedplannedeta',
			'publishedplannedqty'    => 'publishedplannedqty',
			// 'itemdescription'     => '`item`.`itemdescription`',
			// 'balance'             => 'SUM(`po`.`tnxqty`)',
			// 'idquality'           => '`po`.`idquality`',
			// 'quality'             => '`qua`.`Description`',	
			);
		$groupArray = array(
			'doctype'       => 'doctype',
			'formtype'      => 'formtype',
			'linenumber'    => 'linenumber',
		);
		$whereClauses = array(
			"(1=1)",
			"(`po`.`linestatus` = '1')",
		);		

		// Process field clause
		$fieldClause = array();
		foreach ($fieldArray as $fieldKey => $fieldValue) {
			if($fieldValue == 'virtual'){
				array_push($fieldClause, "''" . ' AS `' . $fieldKey . '`');
			}else{
				array_push($fieldClause, $fieldValue . ' AS `' . $fieldKey . '`');
			}
		}
		$fieldClause = implode(' , ', $fieldClause);

		// Process group clause
		$groupClause = array();
		foreach ($groupArray as $groupField) {
			array_push($groupClause, $fieldArray[$groupField]);
		}
		$groupClause = implode(' , ', $groupClause);	

		// Process where clause		
		$searchParams = $params;
		unset($searchParams['reqType']);
		unset($searchParams['_']);		
		
		unset($searchParams['rrtype']);		
		if (isset($searchParams) && count($searchParams) > 0) {
			foreach ($searchParams as $paramkey => $paramvalue) {
				if($paramvalue == "") unset($searchParams[$paramkey]);
			}
			foreach ($searchParams as $paramkey => $paramvalue) {
				array_push($whereClauses, "( $fieldArray[$paramkey] = '" . $paramvalue . "')");
			}
		}
		$whereClause = implode(' AND ', $whereClauses);	


  		$sql = <<<EOF
SELECT
  $fieldClause
FROM
  `erp_purchaseorder` `po`
WHERE $whereClause
GROUP BY $groupClause
EOF;
// return $sql;
// 
		$queryResult = $this->conn->query($sql);
		$data = array();
		while ( $rows = $queryResult->fetch_assoc() ) {

			$rows['formtype'] = $this->poFormTypeTransaltor[$rows['formtype']];
			$rows['ubpolines'] = $this->loadUnderBlanketPOLines($rows['rrnumber']);
			
			$consumptionInfo= $this->getConsumptionInfo($rows['rrnumber']);
			$rows['consumtionstatus'] = $consumptionInfo['consumtionstatus'];
			$rows['consumedqty'] = $consumptionInfo['consumedqty'];
			$rows['balanceqty'] = $consumptionInfo['balanceqty'];

			array_push($data, $rows);
		}
		$this->conn->close();
		return json_encode($data);

	}

	function getListData($params) {

		$fieldArray = array(
			'idlines'                => '`po`.`idlines`',
			'doctype'                => '`po`.`doctype`',
			'formtype'               => '`po`.`formtype`',
			'company'                => '`po`.`company`',
			'docnumber'              => '`po`.`docnumber`',
			'linenumber'             => '`po`.`linenumber`',
			// 'ubpolines'              => 'virtual', // under blanket po lines numvre
			'rrnumber'               => '`po`.`rrnumber`',
			'parentrrnumber'         => '`po`.`parentrrnumber`',
			'docstatus'              => '`po`.`docstatus`',
			'linestatus'             => '`po`.`linestatus`',
			'inhousedstatus'         => 'virtual',
			'numberoflotrcv'         => 'virtual',
			'numberofqualitychecked' => 'virtual',
			'itemtype'               => '`po`.`itemtype`',
			'itemcode'               => '`po`.`itemcode`',
			'itemdescription'        => '`po`.`itemdescription`',
			'tnxqty'                 => '`po`.`tnxqty`',
			'iduom'                  => '`po`.`iduom`',
			// 'consumtionstatus'       => 'virtual',
			// 'consumedqty'            => 'virtual',
			// 'balanceqty'             => 'virtual',
			// 'shipdatetoapparel'      => 'virtual',
			'internalplannedeta'     => 'internalplannedeta',
			'internalplannedqty'     => 'internalplannedqty',
			'publishedplannedeta'    => 'publishedplannedeta',
			'publishedplannedqty'    => 'publishedplannedqty',
			// 'itemdescription'     => '`item`.`itemdescription`',
			// 'balance'             => 'SUM(`po`.`tnxqty`)',
			// 'idquality'           => '`po`.`idquality`',
			// 'quality'             => '`qua`.`Description`',
		);
		$groupArray = array(
			'doctype'       => 'doctype',
			'formtype'      => 'formtype',
			'idlines'       => 'idlines',
		);
		$whereClauses = array(
			"(1=1)",
			"(`po`.`linestatus` = '1')",
		);		

		// Process field clause
		$fieldClause = array();
		foreach ($fieldArray as $fieldKey => $fieldValue) {
			if($fieldValue == 'virtual'){
				array_push($fieldClause, "''" . ' AS `' . $fieldKey . '`');
			}else{
				array_push($fieldClause, $fieldValue . ' AS `' . $fieldKey . '`');
			}
		}
		$fieldClause = implode(' , ', $fieldClause);

		// Process group clause
		$groupClause = array();
		foreach ($groupArray as $groupField) {
			array_push($groupClause, $fieldArray[$groupField]);
		}
		$groupClause = implode(' , ', $groupClause);

		// Process where clause
		$searchParams = $params;
		unset($searchParams['showLimit']);
		unset($searchParams['pageNum']);
		unset($searchParams['reqType']);		
		unset($searchParams['output']);		
		unset($searchParams['print']);		
		unset($searchParams['_']);		
		if (isset($searchParams) && count($searchParams) > 0) {
			foreach ($searchParams as $paramkey => $paramvalue) {
				if($paramvalue == "") unset($searchParams[$paramkey]);
			}
            foreach ($searchParams as $paramkey => $paramvalue) {
              // $compositeClauses = array("1=1",);
              $compositeClauses = array();
              $compositeParamkey = explode("__", $paramkey);
              $compositeParamVal = explode(",__", $paramvalue);

              if(sizeof($compositeParamkey) > 1 && sizeof($compositeParamVal) > 1 ){
                foreach ($compositeParamkey as $key => $fieldname) {
                	$fieldvalue = $compositeParamVal[$key];
                	if($fieldvalue == ""){
                		continue;
                	} else if(strpos($fieldvalue, '_to_') !== false){
						$from_to_dates = explode('_to_', $fieldvalue);
						$form_date = $from_to_dates[0];
						$to_date = $from_to_dates[1];
						array_push($compositeClauses, "( $fieldArray[$fieldname] BETWEEN '$form_date' AND '$to_date')");
	                } else {
	                  	array_push($compositeClauses, "( $fieldArray[$fieldname] LIKE '%" . $fieldvalue. "%')");
	                }  	
                }
                $compositeClause = '(' . implode(' AND ', $compositeClauses) .')';
                array_push($whereClauses, $compositeClause);

              } else if(sizeof($compositeParamkey) > 1){
                foreach ($compositeParamkey as $key => $fieldname) {
                  array_push($compositeClauses, "( $fieldArray[$fieldname] LIKE '%" . $paramvalue . "%')");
                }
                $compositeClause = '(' . implode(' OR ', $compositeClauses) . ')';
                array_push($whereClauses, $compositeClause);

              } else{
              	if(strpos($paramvalue, '_to_') !== false){ // date field search
              		$from_to_dates = explode('_to_', $paramvalue);
              		$form_date = $from_to_dates[0];
              		$to_date = $from_to_dates[1];
              		array_push($whereClauses, "( $fieldArray[$paramkey] BETWEEN '$form_date' AND '$to_date')");
              	} else {									 // normal field search
              		array_push($whereClauses, "( $fieldArray[$paramkey] LIKE '%" . $paramvalue . "%')");
              	}
              }
            }
		}
		$whereClause = implode(' AND ', $whereClauses);


  		$sql = <<<EOF
SELECT
  $fieldClause
FROM
  `erp_purchaseorder` `po`
WHERE $whereClause
GROUP BY $groupClause
EOF;
// return $sql;

		/**
		 * Pagination work
		 * Very important to set the page number first.
		 */
		$pageNum = (!isset($params['pageNum'])) ? 1 : intval($params['pageNum']);
		/**
		 * Number of results displayed per page 	by default its 10.
		 */
		$showLimit =  ($params["showLimit"] <> "" && is_numeric($params["showLimit"]) ) ? intval($params["showLimit"]) : 10;

		/**
		 * Get the total number of rows in the table
		 */
		$countSql = $sql ;
		$queryResult = $this->conn->query($countSql);
		$queryRowsNum = $queryResult->num_rows;
		/**
		 * if no record found then, apply
		 */
		if($queryRowsNum == 0){
			$tableParts = explode("\r\n", $sql);
			$mainTableName = $tableParts[3];

			$tableParts = explode("WHERE", $sql);
			$joinedSql = substr($sql, 0,strripos($sql, 'WHERE'));
			// $joinedSql = $tableParts[0] . $tableParts[1] . $tableParts[2] . $tableParts[3];

			$maxidSql= "SELECT @last_id := MAX(idlines) FROM $mainTableName";
			$fakeSql = "$joinedSql WHERE idlines = @last_id";	
			$this->conn->query($maxidSql);
			$queryResult = $this->conn->query($fakeSql);
			// echo "maxidSql -- " . $maxidSql . "<br/><br/> fakeSql -- " . $fakeSql;
			$data = array();
			while ( $rows = $queryResult->fetch_assoc() ) {
			  array_push($data, $rows);
			}

			$returnJson = "";
			$returnArray = array();
			$returnArray['listData']     = $data;
			$returnArray['noResult']     = true;
			$returnArray['queryRowsNum'] = $queryRowsNum;
			$returnArray['showLimit']    = $showLimit; // per page limit
			$returnArray['pageNum']      = 0;
			$returnArray['lastPageNum']  = 0;
			$returnJson = json_encode($returnArray);
			return $returnJson;
		}

		/**
		 * Calculate the lastPageNum page based on total number of rows and rows per page. 
		 */
		$lastPageNum = ceil($queryRowsNum/$showLimit); 

		/**
		 * this makes sure the page number isn't below one, or more than our maximum pages 
		 */
		if ($pageNum < 1) { 
		  $pageNum = 1; 
		} elseif ($pageNum > $lastPageNum)  { 
		  $pageNum = $lastPageNum; 
		}
		$lowerLimit = ($pageNum - 1) * $showLimit;

		// $sql2 = " SELECT * FROM tbl_pagination WHERE 1 LIMIT ". ($lowerLimit)." ,  ". ($showLimit). " ";
		$sql = $sql . " LIMIT ". ($lowerLimit)." ,  ". ($showLimit). " ";

		$queryResult = $this->conn->query($sql);
		$data = array();
		while ( $rows = $queryResult->fetch_assoc() ) {
			$rows['formtype'] = $this->poFormTypeTransaltor[$rows['formtype']];
			// $rows['ubpolines'] = $this->loadUnderBlanketPOLines($rows['rrnumber']);
			
			// $consumptionInfo= $this->getConsumptionInfo($rows['rrnumber']);
			// $rows['consumtionstatus'] = $consumptionInfo['consumtionstatus'];
			// $rows['consumedqty'] = $consumptionInfo['consumedqty'];
			// $rows['balanceqty'] = $consumptionInfo['balanceqty'];
			
		  	array_push($data, $rows);
		}


		if (isset($params['output']) && $params['output'] == 'table') {
		return '<html><head>
		  <style type="text/css">
		  /*keep html line-breaks within one cell*/
		  br {
		      mso-data-placement:same-cell;
		  }
		  body {
		      font-family : monospace;
		      font-size : small;
		  }
		  table {
		      border: solid 1px;
		      border-collapse: collapse;
		  }
		  td {
		      border : solid 1px;
		      border-color : lightgray;
		  }
		  </style>
		</head><body>' . $this->conn->sqlToTable($sql) . '</body></html>';
		$this->conn->close();
		} else if (isset($params['print']) && $params['print'] == 'sql'){
			echo $sql;
		} else {

			$returnJson = "";
			$returnArray = array();

			$returnArray['listData']     = $data;
			$returnArray['noResult']     = false;
			$returnArray['queryRowsNum'] = $queryRowsNum;
			$returnArray['showLimit']    = $showLimit; // per page limit
			$returnArray['pageNum']      = $pageNum;
			$returnArray['lastPageNum']  = $lastPageNum;

			$returnJson = json_encode($returnArray);
			$this->conn->close();
			return $returnJson;

		}


	}


	function loadUnderBlanketPOLines($rrnumber){
		$sql = "SELECT * FROM erp_purchaseorder WHERE parentrrnumber = '$rrnumber'";
		$queryResult = $this->conn->query($sql);
		$returnData = ($queryResult->num_rows > 0) ? "<a class='red strong' href='/erp-apparel/list-ub-po-lines.php?parentrrnumber=$rrnumber' target='_blank'>($queryResult->num_rows)</a>" : $queryResult->num_rows;
		return $returnData;
	}


	function getConsumptionInfo($rrnumber){

		$sql_PR = "SELECT tnxqty FROM erp_purchaseorder WHERE rrnumber = '$rrnumber'";
		$projectionQty = json_decode( $this->conn->sqlToJson($sql_PR), true)[0]['tnxqty'];

		$sql_UP = "SELECT SUM(tnxqty) AS tnxqty FROM erp_purchaseorder WHERE parentrrnumber = '$rrnumber'";
		$underProjectionQty = json_decode( $this->conn->sqlToJson($sql_UP), true)[0]['tnxqty'];

		$consumtionstatus = ($projectionQty == $underProjectionQty) ? "Full" : "Partial";
		$balanceqty = $projectionQty - $underProjectionQty;

		return array(
			'consumtionstatus' => $consumtionstatus,
			'consumedqty' => $underProjectionQty,
			'balanceqty' => $balanceqty,
			);

	}



	function setEntryEditFieldValue($data){
		$returnJson = new stdClass();

		$postData = json_decode($data, true);
		$dbsetkey = $postData['dbsetkey'];
		unset($postData['dbsetkey']);
		$fieldname = array_keys($postData)[0];
		$fieldvalue = array_values($postData)[0];

		$sql = "UPDATE erp_purchaseorder SET $fieldname = '$fieldvalue' WHERE idlines = '$dbsetkey'";
		// return $sql;
		$result = $this->conn->query($sql);
		if($result){
			$returnJson->result = 'success';
		} else {
			$returnJson->result = 'fail';
		}
		return json_encode($returnJson);

	}



}


/**
 * Routing ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 */
if ( basename(__FILE__) == basename($_SERVER["SCRIPT_FILENAME"]) ) {
    // called directly
	if ( $_SERVER['REQUEST_METHOD'] == 'GET' ) {

		if(isset($_GET['reqType'])){

			$reqType = $_GET['reqType'];
			$listObj  = new ThisListAPI();

			if($reqType == 'getListData') {
				$params = $_GET;
				$returnData = $listObj->getListData($params);
				echo $returnData;
			}

			if($reqType == 'getBlanketPOLineTable') {

				$returnData = $listObj->getBlanketPOLineTable($_GET);
				echo $returnData;

			}


		}


	} else if( $_SERVER['REQUEST_METHOD'] == 'POST' ){
	
		if(isset($_POST['reqType'])){

			$reqType = $_POST['reqType'];
			$listObj  = new ThisListAPI();

			if($reqType == "saveDoc"){

				$docobj = $_POST['docobj'];
				$returnData = $listObj->saveDoc($docobj);
				echo $returnData;
			}

			if($reqType == "setEntryEditFieldValue"){

				$data = $_POST['data'];
				$returnData = $listObj->setEntryEditFieldValue($data);
				echo $returnData;
			}

		}


	}

} else {
    // included/required

}
?>